    //
//  TwitterPopoverViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 6/2/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "TwitterPopoverViewController.h"
#import "SA_OAuthTwitterEngine.h"


#define kOAuthConsumerKey				@"CaFlUVfpFOEu99H1IgJ8g"
#define kOAuthConsumerSecret			@"2IGlIA1Qufj5b2ZGnhlaaeI3f5cyEYvTj9a4Xmzus9Q"

@implementation TwitterPopoverViewController

@synthesize tweetField;
@synthesize delegate;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil product:(ProductDetail*)aProduct{
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
		// Custom initialization
		product = aProduct;
    }
    return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	self.tweetField.delegate = self;
	[self setTitle:@"Twitter"];
	if (_engine) return;
	_engine = [[SA_OAuthTwitterEngine alloc] initOAuthWithDelegate: self];
	_engine.consumerKey = kOAuthConsumerKey;
	_engine.consumerSecret = kOAuthConsumerSecret;
	
	UIViewController *controller = [SA_OAuthTwitterController controllerToEnterCredentialsWithTwitterEngine: _engine delegate: self];
	
	if (controller) 
    {
		[self presentModalViewController: controller animated: YES];
	}
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Overriden to allow any orientation.
    return YES;
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc {
	[_engine release];
	[tweetField release];
	[delegate release];
    [super dealloc];
}

#pragma mark Text View delegate methods

/*!
 @function		textViewShouldEndEditing
 @abstract		should end editing on textview
 @discussion	when editing ends on textview
 @param			textView - textView on which editing should end
 @result        BOOL - returns YES
 */
- (BOOL)textViewShouldEndEditing:(UITextView *)textView
{
	[textView resignFirstResponder];
	[self moveView:-45];
	
	return YES;
}

/*!
 @function		shouldChangeTextInRange
 @abstract		should change text in textview
 @discussion	should change text in textview
 @param			range - on which new text should replace with
 @param         replacementText - text which needs to replace
 @result        BOOL - if text is valid return YES else returns NO.
 */
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    // Check if user has entered space at first position.
    if ([text isEqualToString:@" "] && [textView.text length]==1)
	{ 
		textView.text = @"";
		return NO;
	}
    int limit = 140;
    return !([textView.text length]>limit && [text length] > range.length);
}

/*!
 @function		moveView
 @abstract		animate view  
 @discussion	animate view up when keyboard appears.
 @param			vertOffset - size value to moveup view
 @result        void
 */
-(void)moveView:(int)vertOffset
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.5]; // if you want to slide up the view
	
    CGRect rect = self.view.frame;
    
	rect.origin.y -= vertOffset;
	
    self.view.frame = rect;
	
    [UIView commitAnimations];
}

/*!
 @function		textViewDidBeginEditing
 @abstract		editing ends in textView
 @discussion	editing ends in textView
 @param			textView - textView on which editing should end
 @result        void
 */
- (void)textViewDidBeginEditing:(UITextView *)textView
{
	if  (self.view.frame.origin.y >= 0)
		[self moveView:45];
 	
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ((range.location > 0 && [string length] > 0 && [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[string characterAtIndex:0]] &&           [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[[textField text] characterAtIndex:range.location - 1]])) 
    {
        return NO;
    } 
    if ([string isEqualToString:@" "] && [textField.text length]==0)
	{ 
		return NO;
	}
    
    return YES;
}

/*!
 @function		stringByTrimmingString
 @abstract		trim string
 @discussion	trim string
 @param			stringToTrim - string needs to trim
 @param         toCharacterIndex - index till trim needs to done
 @result        NSString - trimmed string
 */
- (NSString *)stringByTrimmingString:(NSString *)stringToTrim toChar:(NSUInteger)toCharacterIndex {
	
	if (toCharacterIndex > [stringToTrim length]) return @"";
	
	NSString *devString = [[[NSString alloc] init] autorelease];
	
	for (int i = 0; i <= toCharacterIndex; i++) {
		
		devString = [NSString stringWithFormat:@"%@%@", devString, [NSString stringWithFormat:@"%c", [stringToTrim characterAtIndex:(i-1)]]]; 
		
	}
	
	return devString;
	
	[devString release];
}

/*!
 @function		postTweet
 @abstract		posting messages on Tweet action
 @discussion	posting messages on Tweet action
 @param			sender - Tweet button
 */
- (IBAction)postTweet:(id)sender
{
	if(isAuthenticated)
	{
        NSString* postText = self.tweetField.text;
        
        if(postText)
        {
            postText = [postText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            if([postText length] == 0) return;
            
            NSString *phoneRegex = @"\\s{1,}";            
            NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
            
            if (![phoneTest evaluateWithObject:postText]) 
            {
                [_engine sendUpdate:postText];
            }           
 
        }         

	}
}

/*!
 @function		cancel
 @abstract		cancel twitter page action
 @discussion	cancel twitter page action
 @param			sender - cancel button
 */
- (IBAction)cancel:(id)sender {
	[self.tweetField resignFirstResponder];
	[delegate closePopover];
}

/*!
 @function		statusFinished
 @abstract		custom function when task finished 
 @discussion	custom function when task finished 
 @param			nil
 @result        void
 */
- (void)statusFinished
{
    [self showAlertView:kTwitterUpdateSuccessful alertMessage:kTwitterUpdateSuccessfulDesctiption setDelegate:nil];
    
    [self redirectToProductDetailsPage];
}

/*!
 @function			redirectToProductDetailsPage
 @abstract			redirecting to ProductDetailsPage 
 @discussion		redirecting to ProductDetailsPage 
 @param				none
 @result			void
 */
- (void)redirectToProductDetailsPage
{
	[self.tweetField resignFirstResponder];
	[delegate closePopover];
	
	[self.navigationController popViewControllerAnimated:YES];
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function			showAlertView
 @abstract			Common method to display alert message 
 @discussion		Common method to display alert message 
 @param				alertTitle - Title for AlertView
                    alertMessage - Message description for AlertView		
 @result			void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
	[alert show];
	[alert release];
}

/*!
 @method			clickedButtonAtIndex
 @abstract			redirect to Login Page 
 @discussion		redirect to Login Page when password sent successfully
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	
}

//========================================================================================================

#pragma mark SA_OAuthTwitterEngineDelegate
/*!
 @function			storeCachedTwitterOAuthData
 @abstract			delegate method while initiating caching authorized data 
 @discussion		delegate method while initiating caching authorized data 
 @param				data - string containes the data
 @param				username - string containes the user name
 @result			void
 */
- (void)storeCachedTwitterOAuthData: (NSString *)data forUsername:(NSString *)username {
	NSUserDefaults			*defaults = [NSUserDefaults standardUserDefaults];
	
	[defaults setObject: data forKey: @"authData"];
	[defaults synchronize];
}

/*!
 @function			storeCachedTwitterOAuthData
 @abstract			delegate method while caching authorized data finished.
 @discussion		delegate method while caching authorized data finished. 
 @param				username - string containes the user name
 @result			NSString - data which cached
 */
- (NSString *)cachedTwitterOAuthDataForUsername:(NSString *)username {
	isAuthenticated = TRUE;
	return [[NSUserDefaults standardUserDefaults] objectForKey: @"authData"];
}

//========================================================================================================

/*!
 @function			OAuthTwitterController
 @abstract			authenticate user 
 @discussion		authenticate user 
 @param				username - string containes the user name
 @result			void
 */
#pragma mark SA_OAuthTwitterControllerDelegate
- (void) OAuthTwitterController: (SA_OAuthTwitterController *) controller authenticatedWithUsername: (NSString *) username {
	TRC_DBG(@"Authenicated for %@", username);
	isAuthenticated = TRUE;
}

/*!
 @function			OAuthTwitterControllerFailed
 @abstract			when authentication failed  
 @discussion		when authentication failed 
 @param				controller - on which authentication failed.
 @result			void
 */
- (void) OAuthTwitterControllerFailed: (SA_OAuthTwitterController *) controller {
	TRC_DBG(@"Authentication Failed!");
	isAuthenticated = FALSE;
	[self statusFinished];

}

/*!
 @function			OAuthTwitterControllerCanceled
 @abstract			when authentication Canceled  
 @discussion		when authentication Canceled 
 @param				controller - on which authentication Canceled.
 @result			void
 */
- (void) OAuthTwitterControllerCanceled: (SA_OAuthTwitterController *) controller {
	TRC_DBG(@"Authentication Canceled.");
	isAuthenticated = FALSE;
	[self redirectToProductDetailsPage];
}

//========================================================================================================

/*!
 @function			requestSucceeded
 @abstract			when message updated on twitter successfully   
 @discussion		when message updated on twitter successfully 
 @param				requestIdentifier - message which updated.
 @result			void
 */
#pragma mark TwitterEngineDelegate
- (void) requestSucceeded: (NSString *) requestIdentifier {
	TRC_DBG(@"Request %@ succeeded", requestIdentifier);
	[self statusFinished];
}


/*!
 @function			requestFailed
 @abstract			when message updates on twitter fails   
 @discussion		when message updates on twitter fails   
 @param				requestIdentifier - message which updated.
 @param             error - error when update failes
 @result			void
 */
- (void) requestFailed: (NSString *) requestIdentifier withError: (NSError *) error {
	TRC_DBG(@"Request %@ failed with error: %@", requestIdentifier, error);
    
    [self showAlertView:kTwitterUpdateFailure alertMessage:kTwitterUpdateFailureDesctiption setDelegate:nil];
}

@end
