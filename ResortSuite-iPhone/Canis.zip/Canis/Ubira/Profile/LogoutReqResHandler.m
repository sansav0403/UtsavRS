//
//  LogoutReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "LogoutReqResHandler.h"


@implementation LogoutReqResHandler

@synthesize userBasicDetails =_user;

- (void)logOut:(User*)user
{
	self.userBasicDetails = user;
	
	
	NSString* postData = [NSString stringWithFormat:@"userid=%@",self.userBasicDetails.userId];
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];	
	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/signout",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
	
}


- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
	TRC_ENTRY
	
	/*NSString* resultString;
	resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];

	TRC_DBG(@"%@",resultString);

	NSDictionary *dictionary = [resultString JSONValue];
    [resultString release];
    
	TRC_DBG(@"Dictionary value for \"userid\" is \"%@\"", [dictionary objectForKey:@"userid"]);
	TRC_DBG(@"Dictionary value for \"name\" is \"%@\"", [dictionary objectForKey:@"name"]);
	*/
	
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:nil];
    }
}

- (void)dealloc
{	
	[_user release];
	[super dealloc];
}

@end
