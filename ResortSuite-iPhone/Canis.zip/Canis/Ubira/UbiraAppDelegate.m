//
//  UbiraAppDelegate.m
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "UbiraAppDelegate.h"
#import "CoreDataApplicationStack.h"
#import "Review.h"
#import "UserExtended.h"
#import "KeychainItemWrapper.h"
#import "NetworkManager.h"
#import "UserAnalytics.h"
#import "FavouritesViewController.h"
#import "CouponsViewController.h"

@implementation UbiraAppDelegate

@synthesize window=_window;

@synthesize tabBarController = _tabBarController;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.	

    // Set the application defaults
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *appDefaults = [NSDictionary dictionaryWithObject:@"YES" forKey:@"enabledSpecialOffers"];
    [defaults registerDefaults:appDefaults];
    
    [defaults synchronize];
    
    //Network manager will start notifying the network status
	[[NetworkManager sharedManager] startNotifier];
		
	// redirect to login page.
	[self redirectToLoginView];
    [self setTabBarItemText];
    //[self.window setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];

    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
    
    //stop the anyalitics life cycle
    [[UserAnalytics sharedInstance] stopApplicationLifeCycle];
    
    NSError *error = nil;
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription 
                                   entityForName:@"ApplicationLifeCycle" inManagedObjectContext:[[CoreDataApplicationStack globalStack] analyticsManagedObjectContext]];
    [fetchRequest setEntity:entity];
    
    NSArray *fetchedObjects = [[[CoreDataApplicationStack globalStack] analyticsManagedObjectContext] executeFetchRequest:fetchRequest error:&error];
    if(!error)
    {
        for (NSManagedObject *info in fetchedObjects) {
            TRC_DBG(@"Name: %@", [info valueForKey:@"ApplicationLifeID"])
        }
    }
    [fetchRequest release];
    
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
    //Start the anyalitics life cycle
    [[UserAnalytics sharedInstance] startApplicationLifeCycle];

}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Saves changes in the application's managed object context before the application terminates.

}

- (void)dealloc
{
	[_tabBarController release];
    [_window release];
	[loginReqResHandler release];
    [super dealloc];
}

/*!
    @function   redirectToLoginView
    @abstract   redirecting to login page
    @discussion redirecting to login page
    @param      none
    @result     void
*/
- (void)redirectToLoginView
{
	if (_tabBarController)
	{
		[_tabBarController.view removeFromSuperview];
	}
	loginViewController = [[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:[NSBundle mainBundle]];
	[loginViewController setDelegate:self];
	
	navigationController = [[UINavigationController alloc] initWithRootViewController:loginViewController];
	[navigationController setNavigationBarHidden:YES];
	
	[self.window addSubview:navigationController.view];
}


#pragma mark - Login status delegate
/*!
    @function		loginStatusDelegate
    @abstract		delgate for login result
    @discussion		checks if login is done successfully then redirecting to Home page.
    @param			aStatus - bool value to check if login done successfully or not
    @result			void
*/
- (void)loginStatusDelegate:(BOOL)aStatus
{
    if(aStatus)
    {
		if (loginViewController)
		{
			[loginViewController.view removeFromSuperview];
			[loginViewController release];
		}
        
		if (navigationController)
		{
			[navigationController.view removeFromSuperview];
			[navigationController release];
		}
				
		[self.window addSubview:_tabBarController.view];
		[_tabBarController setSelectedIndex:0];
        _tabBarController.delegate = self;
    }
	else
	{
        [self handleLogOut];
		[self redirectToLoginView];
	}

}

#pragma mark - Application's Documents directory

/**
 Returns the URL to the application's Documents directory.
 */
- (NSURL *)applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

//---------------------------------------------------------------------------------------------
// Redirect to Login Page when password sent successfully.
//---------------------------------------------------------------------------------------------
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	[self redirectToLoginView];		
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    UINavigationController *navCont = (UINavigationController *)viewController;
    NSArray *viewControllerArr = [navCont viewControllers];
    
    switch (tabBarController.selectedIndex)
    {
        case 2:
        {
            FavouritesViewController *favController =(FavouritesViewController*)[viewControllerArr objectAtIndex:0];
            [favController refreshData];
        }
            break;
        case 4:
        {
            CouponsViewController *couponController =(CouponsViewController*)[viewControllerArr objectAtIndex:0];
            [couponController refreshData];
        }
            break;
            
        default:
            break;
    }
}

- (void)setTabBarItemText
{
    int index = 0;
    for(UITabBarItem *tabBarItemObj in _tabBarController.tabBar.items)
    {
        switch (index) {
            case 0:
                [tabBarItemObj setTitle:kHomeTitle];
                break;
            case 1:
                [tabBarItemObj setTitle:kSearchTitle];
                break;
            case 2:
                [tabBarItemObj setTitle:kFavouritesTitle];
                break;
            case 3:
                [tabBarItemObj setTitle:kProfileTabTitle];
                break;
            case 4:
                [tabBarItemObj setTitle:kCouponsTitle];
                break;
            default:
                break;
        }
        index ++;
    }
}

- (void)handleLogOut
{     
    //Set all Tab navigation controller on root.
    for (UINavigationController *viewController in self.tabBarController.viewControllers) {
        
        [viewController popToRootViewControllerAnimated:NO];
    }
} 

@end
