//
//  Anyalitics.m
//  Ubira
//
//  Created by [Cybage Team] on 13/06/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "Analytics.h"


@implementation Analytics
@dynamic ScreenID;
@dynamic StartDate;
@dynamic EndDate;
@dynamic AnyaliticsToApplicationLifeCycle;


@end
