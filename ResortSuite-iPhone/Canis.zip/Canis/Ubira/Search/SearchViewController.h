//
//  SearchViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"

/*!
 @class SearchViewController
 @abstract handler the search request response.
 @discussion handle the text and barcode search for product.
 */
@interface SearchViewController : UIViewController<ZBarReaderDelegate>{
    
    IBOutlet UISearchBar        *searchBar;
    IBOutlet UIButton           *scanBtn;
    IBOutlet UILabel            *notCheckInReminderLbl;
    ZBarReaderViewController    *reader;
    NSDate                      *_startDate;
}
@property (nonatomic, retain) IBOutlet UISearchBar  *searchBar;
@property (nonatomic, retain) IBOutlet UIButton     *scanBtn;
@property (nonatomic, retain) IBOutlet UILabel      *notCheckInReminderLbl;
@property (nonatomic, retain) NSDate                *startDate;
- (IBAction)scanBarAction:(id)sender;
- (void)checkIntoStore;

- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;
@end
