//
//  MerchantStoreCell.m
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "MerchantStoreCell.h"


@implementation MerchantStoreCell
@synthesize delegate = _delegate;
@synthesize merchantName;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self setSelectionStyle:UITableViewCellEditingStyleNone];
        [self.contentView setBackgroundColor:[UIColor whiteColor]];
        
        storeImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:storeImageView];
        
        merchantName = [[UILabel alloc] initWithFrame:CGRectZero];
        [merchantName setBackgroundColor:[UIColor clearColor]];
        [merchantName setTextAlignment:UITextAlignmentCenter];
        merchantName.numberOfLines = 0;
        [merchantName sizeToFit];
        [self.contentView addSubview:merchantName];
        
        productPrice = [[UILabel alloc] initWithFrame:CGRectZero];
        [productPrice setBackgroundColor:[UIColor clearColor]];
        [productPrice setTextAlignment:UITextAlignmentCenter];
        [self.contentView addSubview:productPrice];
        
        buyButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [buyButton setTitle:kBuyButtonTitle forState:UIControlStateNormal];
        [buyButton setBackgroundImage:[UIImage imageNamed:kCommonRedBtnImg] forState:UIControlStateNormal];
        [buyButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [buyButton.titleLabel setFont:[UIFont fontWithName:@"Helvetica" size:14]];
        [buyButton addTarget:self action:@selector(buyAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:buyButton];
        
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;        
        frame = CGRectMake(10, 10, 50, 50);
        [storeImageView setFrame:frame];
        
        frame = CGRectMake(5, 5, 104, 60);
        [merchantName setFrame:frame];
        
        frame = CGRectMake(self.contentView.frame.size.width/2, self.contentView.frame.size.height/2 , 100, 20);
        [productPrice setFrame:frame];
        [productPrice setCenter:CGPointMake(self.contentView.frame.size.width/2, self.contentView.frame.size.height/2)];
         
        frame = CGRectMake(228, 25, 85, 20);
        [buyButton setFrame:frame];

	}
}

/*!
 @function	 setMerchantStoreDetails
 @abstract   set product merchant details to cell.
 @discussion set product merchant details to cell.
 @param      MerchantStore - store of which details need to set to cell.
             BOOL - instore whether the instore value is available or not.
 @result     void
 */
- (void)setMerchantStoreDetails:(MerchantStore*)aMerchantStore inStore:(BOOL)inStore storeIndex:(int)storeIndex
{
    checkInStore = inStore;
    if(inStore)
    {
        [buyButton setTitle:kUpdateButtonTitle forState:UIControlStateNormal];
        [buyButton addTarget:self action:@selector(updateAction:) forControlEvents:UIControlEventTouchUpInside];
        [productPrice setTextColor:[UIColor redColor]];
    }
    else
    {
        [buyButton setTitle:kBuyButtonTitle forState:UIControlStateNormal];
        [buyButton addTarget:self action:@selector(buyAction:) forControlEvents:UIControlEventTouchUpInside];
        [productPrice setTextColor:[UIColor blackColor]];
    }
    merchantStore = aMerchantStore;
    if(!merchantStore.storeImage)
    {
        [merchantStore setDelegate:self];
        [merchantStore downloadImage];
    }
    [productPrice setText:merchantStore.price];
    [merchantName setText:merchantStore.merchantId];
    
    CGSize expectedLabelSize = [merchantStore.name sizeWithFont:[UIFont fontWithName:@"Helvetica" size:12] constrainedToSize:CGSizeMake(104,60) 
                                lineBreakMode:UILineBreakModeWordWrap]; 
    
    CGRect frame = CGRectMake(5, 5, expectedLabelSize.width, expectedLabelSize.height);
    [merchantName setFrame:frame];
}

/*!
 @function	 buyAction
 @abstract   buy button action.
 @discussion buy button action to delegate to the update price screen.
 @param      id.
 @result     void
 */
- (IBAction)buyAction:(id)sender
{
    //inf check in store then ask for update
    if(!checkInStore)
    {
        if([self.delegate respondsToSelector:@selector(buyActionDelegate:)])
        {
            [self.delegate buyActionDelegate:merchantStore];
        }
    }
}

/*!
 @function	 updateAction
 @abstract   update button action.
 @discussion update button action to delegate to the update price screen.
 @param      id.
 @result     void
 */
- (IBAction)updateAction:(id)sender
{
    //inf check in store then ask for update
    if(checkInStore)
    {
        if([self.delegate respondsToSelector:@selector(updateActionDelegate:)])
        {
            [self.delegate updateActionDelegate:merchantStore];
        }
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc
{
    _delegate = nil;
    [storeImageView release];
    [productPrice   release];
    [merchantName release];
    [super dealloc];
}
#pragma mark
//- (void)imageDownloadComplete:(NSError*)error;
#pragma mark - ImageDownloadComplete Delegate
-(void)imageDownloadComplete:(NSError*)error storeIndex:(int)storeIndex
{
	TRC_ENTRY
	if (error)
	{
		TRC_ERR(@"Summary image %@",error)
        //merchantStore.storeImage = [UIImage imageNamed:@"Noimages.png"];
	}
	else
	{		
		TRC_DBG(@"Setting product summary image" )
        //if(!merchantStore.storeImage)
            //merchantStore.storeImage = [UIImage imageNamed:@"Noimages.png"];
    
	}
    if(merchantStore.storeIndex == storeIndex)
    {
       [storeImageView setImage:merchantStore.storeImage];
       [merchantName removeFromSuperview];
    }
	TRC_EXIT
	
}

@end
