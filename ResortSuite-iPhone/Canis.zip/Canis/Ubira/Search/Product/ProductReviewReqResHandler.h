//
//  ProductReviewReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"
#import "Review.h"
#import "NSString+HTML.h"
/*!
 @class ProductReviewReqResHandler
 @abstract Handler the review request response.
 @discussion Create the required url request and respond to the caller.
 */
@interface ProductReviewReqResHandler : RequestResponseBase {
    NSArray     *_productReviewList;
}
@property (nonatomic, retain) NSArray     *productReviewList;
-(void)productReviews:(NSString*)productId review:(NSArray *)reviewList;


@end
