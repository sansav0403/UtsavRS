//
//  ProductReviewCell.m
//  Ubira
//
//  Created by [Cybage Team] on 30/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProductReviewCell.h"
#import "Review.h"

@implementation ProductReviewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code

        postLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [postLabel setBackgroundColor:[UIColor clearColor]];
        [postLabel setFont:[UIFont boldSystemFontOfSize:13]];
        [postLabel setTextColor:[UIColor redColor]];
        [postLabel setText:kPosted];
        [self.contentView addSubview:postLabel];

        ratingLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [ratingLabel setBackgroundColor:[UIColor clearColor]];
        [ratingLabel setFont:[UIFont boldSystemFontOfSize:13]];
        [ratingLabel setTextColor:[UIColor redColor]];
        [ratingLabel setText:kRating];
        [self.contentView addSubview:ratingLabel];

        
        postDateLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [postDateLabel setBackgroundColor:[UIColor clearColor]];
        [postDateLabel setFont:[UIFont systemFontOfSize:13]];
        [self.contentView addSubview:postDateLabel];
        
        productDescriptionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [productDescriptionLabel setBackgroundColor:[UIColor clearColor]];
        [productDescriptionLabel setLineBreakMode:UILineBreakModeWordWrap];
        [productDescriptionLabel setNumberOfLines:0];
        [productDescriptionLabel setFont:[UIFont systemFontOfSize:13]];
        [self.contentView addSubview:productDescriptionLabel];
        
        ratingView = [[RatingView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:ratingView];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        //set frame for the title
        frame = CGRectMake(5, 5, 70, 20);
        [postLabel setFrame:frame];
        
        frame = CGRectMake(5, postLabel.frame.size.height + 5, 70, 20);
        [ratingLabel setFrame:frame];
        
        frame = CGRectMake(postLabel.frame.size.width, 5, 200, 20);
        [postDateLabel setFrame:frame];
        
        frame = CGRectMake(ratingLabel.frame.size.width, postLabel.frame.size.height + 5, 70, 16);
        [ratingView setFrame:frame];
        
        frame = CGRectMake(5, ratingView.frame.origin.y+ratingView.frame.size.height, 300, 40);
        [productDescriptionLabel setFrame:frame];
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function	 setReviewDetails
 @abstract   set the review of product.
 @discussion set the review of product with ratings and review post date.
 @param      Review
 @result     void
 */
- (void)setReviewDetails:(Review*)review
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat: @"yyyy-MM-dd HH:mm:ss"]; 
    NSString *dateString = [formatter stringFromDate:review.createDate];
    [formatter release];
    
    [postDateLabel setText:dateString];
    CGRect rect = CGRectMake(5, ratingView.frame.origin.y+ratingView.frame.size.height, 300, [self calculateHeightForCell:review.description]);
	[productDescriptionLabel setFrame:rect];
    
    [productDescriptionLabel setText:review.description];
    
    [ratingView setRating:review.rating];
}

/*!
 @function	 calculateHeightForCell
 @abstract   This function will calculate the hight for the lable.
 @discussion This function will calculate the hight for the lable based on the description
 for the product and break the lable accordingly.
 @param      NSString - description of which details need to set to cell.
 @result     void
 */
- (float)calculateHeightForCell:(NSString *)description
{
	CGSize size = [description sizeWithFont:[UIFont systemFontOfSize:13.0] constrainedToSize:CGSizeMake(300,250) lineBreakMode:UILineBreakModeWordWrap];
	return size.height + 10;
}

- (void)dealloc
{
    [postLabel release];
    [ratingLabel release];
    [postDateLabel release];
    [productDescriptionLabel release];
    [ratingView release];
    [super dealloc];
}

@end
