//
//  ProductDetailReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"
#import "ProductDetail.h"

/*!
 @class ProductDetailReqResHandler
 @abstract Handler the product detail request response.
 @discussion Create the required url request and respond to the caller.
 */

@interface ProductDetailReqResHandler : RequestResponseBase {

	ProductDetail       *_productDetail;
}

- (void)productDetails:(NSString*)productId merchantid:(NSString*)merchantId productDetails:(ProductDetail*)product;

@end
