//
//  ProductSearchReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+HTML.h"
#import "RequestResponseBase.h"
#import "ProductSearch.h"
/*!
 @class ProductSearchReqResHandler
 @abstract Handler the search request response.
 @discussion Create the required url request and respond to the caller.
 */

@interface ProductSearchReqResHandler : RequestResponseBase {

	NSString                                *searchString;
    NSNumber                                *pageSize;
    NSNumber                                *currentPage;
    BOOL                                    requestInProgress;
    
    NSFetchRequest                          *fetchRequestForProductSearch; 
    ProductSearch                           *searchData;
    NSFetchedResultsController              *fetchedResultsController;
    
    id<NSFetchedResultsControllerDelegate>  delegateForNSFetchResultsController;
    
}


@property (nonatomic, retain) NSString                                *searchString;
@property (nonatomic, retain) NSNumber                                *pageSize;
@property (nonatomic, retain) NSNumber                                *currentPage;

@property (nonatomic, retain) NSFetchedResultsController              *fetchedResultsController;
@property (nonatomic,assign)  id<NSFetchedResultsControllerDelegate>  delegateForNSFetchResultsController;
@property (nonatomic) BOOL                                    requestInProgress;

- (void)prepareForNewSearch;
- (void)searchForProduct:(BOOL)newSearch;
- (void)fetchProductSearch:(BOOL)newSearch;
- (void)saveDataToStore;

+ (int)getCurrentRowIndex; 
+ (void)flushSearchData;

@end
