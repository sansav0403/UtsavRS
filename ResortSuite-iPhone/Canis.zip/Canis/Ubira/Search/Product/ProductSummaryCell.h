//
//  ProductSummaryCell.h
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
//  Copyright 2011 Cybage. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductDetail.h"

/*!
 @class ProductSummaryCell
 @abstract create the custom product summary cell.
 @discussion create the custom cell for all the screens which are showing the product summary.
 */
@interface ProductSummaryCell : UITableViewCell <ImageDownloadDelegate>{
    UIImageView     *productImageView;
    UILabel         *descriptionLabel;
    ProductDetail   *productDetails;
}

- (void)setSummaryDetails:(ProductDetail*)productDetail;
- (float)calculateHeightForCell:(NSString *)description;
@end
