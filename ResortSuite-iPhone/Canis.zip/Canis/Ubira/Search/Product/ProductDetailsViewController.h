//
//  ProductDetailsViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductDetailReqResHandler.h"
#import "ProductDetail.h"
#import "MerchantStoreCell.h"
#import "SocialServiceCell.h"
#import "RelatedProductCell.h"
#import "ProductData.h"
#import "Coupon.h"
#import "CouponReqResHandler.h"
#import "MerchantStore.h"

#define kOfferDetailsViewController   @"OfferDetailsViewController"

typedef enum
{
	kFirstCell,	
	kSecondCell,
	kThirdCell
} ProductDetails;

/*!
 @class         ProductDetailsViewController
 @abstract      handler the product details presentation.
 @discussion    handler the product details presentation.
 */
@interface ProductDetailsViewController : UIViewController <RequestResponseBaseDelegate, MerchantStoreDelegate, SocialServiceCellDelegate, RelatedProdcutCellDelegate>{
    
    IBOutlet UIView                 *relatedProductView;
    IBOutlet UILabel                *relatedProductLbl;
    UIActivityIndicatorView         *activityIndicator;
	ProductDetailReqResHandler      *productDetailReqResHandler;
	ProductDetail                   *productDetail;
    UITableView                     *productDetailsTable;
    Product                         *_product;
    NSDate                          *_startDate;
    
    BOOL                            isBuying;
    Coupon                          *_coupon;
    CouponReqResHandler				*couponReqResHandler;
    MerchantStore                   *_merchantStore;
    
}
@property (nonatomic, retain) IBOutlet UITableView              *productDetailsTable;
@property (nonatomic, retain) IBOutlet UIView                   *relatedProductView;
@property (nonatomic, retain) IBOutlet UILabel                  *relatedProductLbl;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView  *activityIndicator;
@property (nonatomic, retain) Product                           *product;
@property (nonatomic, retain) NSDate                            *startDate;
@property (nonatomic, retain) Coupon                            *coupon;
@property (nonatomic, retain) MerchantStore                     *_merchantStore;

- (void)setProductData:(ProductData*) productData;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;

@end
