//
//  ProductCell.m
//  Ubira
//
//  Created by [Cybage Team] on 25/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProductCell.h"


@implementation ProductCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        productTitleLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [productTitleLbl setBackgroundColor:[UIColor clearColor]];
        [productTitleLbl setTextColor:[UIColor redColor]];
        [productTitleLbl setFont:[UIFont boldSystemFontOfSize:14]];
        [self.contentView addSubview:productTitleLbl];
        
        productDescriptionLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [productDescriptionLbl setBackgroundColor:[UIColor clearColor]];
        [productDescriptionLbl setFont:[UIFont systemFontOfSize:14]];
        [self.contentView addSubview:productDescriptionLbl];
        
        productImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:productImageView];
        
        activityIndicatorView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectZero];
        [activityIndicatorView setHidesWhenStopped:YES];
        [activityIndicatorView setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
        [self.contentView addSubview:activityIndicatorView];
        
        ratingView = [[RatingView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:ratingView];
        
        [self setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        //set frame for the title
        frame = CGRectMake(100, 0, 200, 40);
        [productTitleLbl setFrame:frame];

        frame = CGRectMake(100, 22, 200, 40);
        [productDescriptionLbl setFrame:frame];

        frame = CGRectMake(10, 1, 80, 80);
        [productImageView setFrame:frame];

        frame = CGRectMake(35, 35, 20, 20);
        [activityIndicatorView setFrame:frame];
        
        frame = CGRectMake(100, 57, 70, 16);
        [ratingView setFrame:frame];
	}
}


/*!
 @function	 setProductData
 @abstract   set product details to cell.
 @discussion set product details to cell.
 @param      Product - product of which details need to set to cell.
             int - cell index
 @result     void
 */
- (void)setProductData :(Product*)aProduct index:(int)index
{
    [productImageView setImage:nil];
    product = aProduct;
    [productDescriptionLbl setText:product.name];
    [productTitleLbl setText:product.description];
    [ratingView setRating:product.rating];
    if(product.image)
    {
        [productImageView setImage:product.image];
        [activityIndicatorView stopAnimating];
    }
    else
    {
        [activityIndicatorView startAnimating];
    }
}

/*!
 @function	 setProductData
 @abstract   set product details to cell.
 @discussion set product details to cell.
 @param      Product - product of which details need to set to cell.
             int - cell index
 @result     void
 */
- (void) setProductData :(ProductData*) productData
{
    [productImageView setImage:nil];
    [productDescriptionLbl setText:productData.productDescription];
    [productTitleLbl setText:productData.productName];
    [ratingView setRating:[productData.rating floatValue]];
    if(!productData.imageData)
    {
        [productImageView setImage:[UIImage imageNamed:@"Noimages.png"]];
        [activityIndicatorView startAnimating];
    }
    else
    {   
        [activityIndicatorView stopAnimating];
        [productImageView setImage:[UIImage imageWithData:productData.imageData]];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

#pragma mark - ImageDownloadComplete Delegate
-(void)imageDownloadComplete:(NSError*)error productIndex:(int)productIndex
{
	TRC_ENTRY
	if (error)
	{
		TRC_ERR(@"%@",error)
        if(productIndex == product.productIndex)
            product.image = [UIImage imageNamed:@"Noimages.png"];
	}
	else
	{		
		TRC_DBG(@"Setting product image" )
        if(productIndex == product.productIndex)
        if(!product.image)
             product.image = [UIImage imageNamed:@"Noimages.png"];
	}
    if(productIndex == product.productIndex)
    {
        [activityIndicatorView stopAnimating];
        [productImageView setImage:product.image];
    }
    
    
	TRC_EXIT
	
}

- (void)dealloc
{
    [productTitleLbl        release];
    [productDescriptionLbl  release];
    [productImageView       release];
    [activityIndicatorView  release];
    [ratingView             release];
    
    [super dealloc];
}

@end
