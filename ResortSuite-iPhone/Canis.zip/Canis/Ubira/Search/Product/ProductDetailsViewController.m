//
//  ProductDetailsViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProductDetailsViewController.h"
#import "ProductSummaryCell.h"
#import "RelatedProductCell.h"
#import "UpdatePriceViewController.h"
#import "ProductSummaryViewController.h"
#import "ProductReviewViewController.h"
#import "TwitterPopoverViewController.h"
#import "ImageDownloadQueue.h"
#import "OfferDetailsViewController.h"
#import "CouponDetailViewController.h"
#import "UserAnalytics.h"

#define kProductSummaryCell     @"ProductSummaryCell"
#define kProductSocialCell      @"SocialServiceCell"
#define kMerchantsCell          @"MerchantStoreCell"
#define kRelatedProductCell     @"RelatedProductCell"

#define kProductSummaryViewController   @"ProductSummaryViewController"
#define kProductReviewViewController    @"ProductReviewViewController"
#define kUpdatePriceViewController      @"UpdatePriceViewController"

#define kTotalSections              3
#define kSummaryCellHeight          95
#define kStoreCellHeight            70
#define kRelatedProductCellHeight   120

#define kCouponDetailViewController   @"CouponDetailViewController"

@implementation ProductDetailsViewController

@synthesize productDetailsTable;
@synthesize product = _product;
@synthesize relatedProductView;
@synthesize relatedProductLbl; 
@synthesize activityIndicator;
@synthesize startDate = _startDate;
@synthesize coupon = _coupon;
@synthesize _merchantStore;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        productDetailReqResHandler  = [[ProductDetailReqResHandler alloc]init];
        [productDetailReqResHandler setDelegate:self];
    }
    return self;
}

- (void)dealloc
{
    [[ImageDownloadQueue sharedQueue] cancelAllOperations];
    
    [_product                   release];
    [productDetail				release];
    [relatedProductView         release];
    [relatedProductLbl          release];
    [productDetailsTable        release];
	[productDetailReqResHandler release];
    [activityIndicator          release];
    [_coupon                    release];
    [couponReqResHandler        release];
    [_startDate                 release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

/*!
 @function	 storeDetails
 @abstract   set name of the product
 @discussion 
 @param      product name
 @result     void
 */
- (void)setProductData:(ProductData*) productData
{
    _product = [[Product alloc] init];
    _product.name = productData.productName;
    _product.productId = productData.productId;
}

/*!
 @function	 storeDetails
 @abstract   load the store details
 @discussion load the store details and chech whether user is logged into any store or not.
 @param      void
 @result     void
 */
- (void)storeDetails
{
    if(productDetail)
    {
        [productDetail release];
    }        
	productDetail = [[ProductDetail alloc] init];
    Store * store = [Store sharedStore];
    if(store.storeId)
    {
        [productDetailReqResHandler productDetails:self.product.productId merchantid:store.storeId productDetails:productDetail];
    }
	else
        [productDetailReqResHandler productDetails:self.product.productId merchantid:@"0" productDetails:productDetail];
    [self.productDetailsTable setUserInteractionEnabled:NO];
    
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
	[super viewDidLoad];
    [self setTitle:self.product.name];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
    [productDetailsTable setBackgroundColor:[UIColor clearColor]];
    [self.productDetailsTable setUserInteractionEnabled:FALSE];
    [self.relatedProductLbl setText:kRelatedProductsLblText];
    // Do any additional setup after loading the view from its nib.
	
	UIView	*view = [[UIView alloc]initWithFrame:CGRectZero];
	[self.productDetailsTable setTableFooterView:view];
	[view release];
	
    //set the navigation back button with back title
    UIBarButtonItem *back = [[UIBarButtonItem alloc] initWithTitle:kBack style:UIBarButtonItemStylePlain target:self action:nil];	
	self.navigationItem.backBarButtonItem = back;
    [back release];
    
    isBuying = NO;
    [self storeDetails];
    
     [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(storeDetails) name:kCheckInCheckOutNotificationKey object:nil];
}

- (void)viewDidUnload
{
    [self setRelatedProductView:nil];
    [self setRelatedProductLbl:nil];
    [self setProductDetailsTable:nil];
    [self setActivityIndicator:nil];
     [[NSNotificationCenter defaultCenter]removeObserver:self name:kCheckInCheckOutNotificationKey object:nil];
    
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsProductDetailScreen startDate:self.startDate endDate:[NSDate date]];       
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table view datasource and delegate methods

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    float cellHeight = kSummaryCellHeight;
    
    switch (indexPath.section) 
    {
        case kFirstCell:
            cellHeight = kSummaryCellHeight;
            break;
        case kSecondCell:
            cellHeight = kStoreCellHeight;
            break;
        case kThirdCell:
            cellHeight = kRelatedProductCellHeight;
            break;
    }
    return cellHeight;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	// Number of sections is the number of regions
    if(![productDetail.releatedProducts count])
        return kTotalSections - 1;
	return kTotalSections;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case kFirstCell:
            return 0;
        case kSecondCell:
            return 0;
        case kThirdCell:
            return relatedProductView.frame.size.height;
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case kFirstCell:
            return nil;
            
        case kSecondCell:
            return nil;
            
        case kThirdCell:
            return relatedProductView;
            
      }
    return nil;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	// Number of rows is the number of time zones in the region for the specified section
    
    if(productDetail.name)
    {
        switch (section) {
            case kFirstCell:
                return 2;
                
            case kSecondCell:
                return [productDetail.inStore count] + [productDetail.merchantStoreList count];
                
            case kThirdCell:
                return 1;
                
        }
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
    static NSString *summaryIdentifier = kProductSummaryCell;
    static NSString *socialIdentifier = kProductSocialCell;
    static NSString *merchantIdentifier = kMerchantsCell;
    static NSString *relatedProductIdentifier = kRelatedProductCell;
    UITableViewCell *cell = nil;
    switch (indexPath.section) 
    {
        case kFirstCell:
        {
            switch (indexPath.row) 
            {
                case kFirstCell:
                {
                    ProductSummaryCell *cell = (ProductSummaryCell *)[tableView dequeueReusableCellWithIdentifier:summaryIdentifier];
                    if(!cell)
                    {
                        cell = [[[ProductSummaryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:summaryIdentifier] autorelease];
                    }
                    [cell setSummaryDetails:productDetail];
                    return cell;
                }
                break;
                case kSecondCell:
                {
                    SocialServiceCell *cell = (SocialServiceCell *)[tableView dequeueReusableCellWithIdentifier:socialIdentifier];
                    if(!cell)
                    {
                        cell = [[[SocialServiceCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:socialIdentifier] autorelease];
                    }
                    [cell setDelegate:self];
                    [cell setReviewsDetails:productDetail];
                    return cell;
                }
                    break;
            }

        }
        break;
        case kSecondCell:
        {
            MerchantStoreCell *cell = (MerchantStoreCell *)[tableView dequeueReusableCellWithIdentifier:merchantIdentifier];
            if(!cell)
            {
                cell = [[[MerchantStoreCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:merchantIdentifier] autorelease];
            }
            if([productDetail.inStore count] > indexPath.row)
            {
                TRC_DBG(@"productDetail.inStore == %d \t Row --%d", [productDetail.inStore count], indexPath.row);
                [cell setMerchantStoreDetails:[productDetail.inStore objectAtIndex:indexPath.row] inStore:YES storeIndex:indexPath.row];
                [cell setDelegate:self];
            }
            else
            {
                int indexCount = indexPath.row;
                if([productDetail.inStore count])
                {
                    //This will make index count to start from 0 to iterate in merchant store list
                    indexCount = indexPath.row - [productDetail.inStore count];
                }
                [cell setMerchantStoreDetails:[productDetail.merchantStoreList objectAtIndex:indexCount] inStore:NO storeIndex:indexPath.row];
                [cell setDelegate:self];
            }
            return cell;
        }
        break;
        default:
        {
            RelatedProductCell *cell = (RelatedProductCell *)[tableView dequeueReusableCellWithIdentifier:relatedProductIdentifier];
            if(!cell)
            {
                cell = [[[RelatedProductCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:relatedProductIdentifier] autorelease];
                [cell setRelatedProducts:productDetail.releatedProducts];
                [cell setRelatedProductsData];
            }
            [cell setDelegate:self];
            return cell;
        }
        break;
    }

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	/*
	 To conform to the Human Interface Guidelines, selections should not be persistent --
	 deselect the row after it has been selected.
	 */
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.section) 
    {
        case kFirstCell:
        {
            switch (indexPath.row) 
            {
                case kFirstCell: //If summary cell
                {
                    ProductSummaryViewController *productSummaryViewController = [[ProductSummaryViewController alloc] initWithNibName:kProductSummaryViewController bundle:[NSBundle mainBundle]];
                    productSummaryViewController.productDetail = productDetail;
                    [self.navigationController pushViewController:productSummaryViewController animated:YES];
                    [productSummaryViewController release];

                }
                break;
                case kSecondCell: //If rating cell
                {
                    ProductReviewViewController *productReviewViewController = [[ProductReviewViewController alloc] initWithNibName:kProductReviewViewController bundle:[NSBundle mainBundle] productId:productDetail.productId];
                    [self.navigationController pushViewController:productReviewViewController animated:YES];
                    [productReviewViewController release];
                }    
                break;
            }
        } 
        break;
            
        default:
            break;
    }

}


#pragma mark - Parsing complete delegate
-(void)parseComplete:(NSError*)error
{
       
	TRC_ENTRY
	if(error != nil)
	{
		TRC_ERR(@"%@",error)
        NSString *errorString = [[error userInfo] valueForKey:@"error"];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kProductDetails message:errorString delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
	}
	else
	{
		//update UI		
        
        if(isBuying)
        {
            isBuying = NO;
            //Navigate to details screen of the selected product
            CouponDetailViewController *couponDetailViewController = [[CouponDetailViewController alloc] initWithNibName:kCouponDetailViewController bundle:[NSBundle mainBundle]];
            [couponDetailViewController setCoupon:_coupon];
            
            [self.navigationController pushViewController:couponDetailViewController animated:YES];	
            [couponDetailViewController release];
            
        }
        else
        {
            TRC_DBG(@"=============================================================")
            TRC_DBG(@"Product Name : %@",productDetail.name)
            TRC_DBG(@"Product instore Count : %d",[productDetail.inStore count])
            [self.productDetailsTable reloadData];
        }
       
		 
	}
    [self.activityIndicator stopAnimating];
    [self.productDetailsTable setUserInteractionEnabled:TRUE];
	TRC_EXIT
}
#pragma mark - SocialServiceCellDelegate
- (void)twitterButtonActionDelegate
{
    TwitterPopoverViewController *tweet = [[TwitterPopoverViewController alloc] initWithNibName:@"TwitterPopoverViewController" bundle:[NSBundle mainBundle] product:productDetail];
    [self.navigationController pushViewController:tweet animated:YES];
	[tweet release];
}

#pragma mark - Buy Button or Update Button action
/*!
 @function	 buyActionDelegate
 @abstract   delegate method to load the update price screen
 @discussion This is the delegate method for the update button click.
 @param      merchantStore
 @result     void
 */
- (void)buyActionDelegate:(MerchantStore*)merchantStore
{
    _merchantStore = merchantStore;
    Store *sharedStore = [Store sharedStore];
    
    // Get user preference
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    BOOL enabled = [defaults boolForKey:@"enabledSpecialOffers"];
    
    if (sharedStore.storeId && enabled)
    {
        
        NSString *altMsg = [NSString stringWithFormat:@"%@ %@ %@ %@",sharedStore.name,kPurchaseProductDescriptionFirst,merchantStore.price,kPurchaseProductDescriptionSecond];
        [self showAlertView:nil alertMessage:altMsg setDelegate:self];
    }
    else
    {
        //Navigate to details screen of the selected product
        OfferDetailsViewController *offerDetailsViewController = [[OfferDetailsViewController alloc] initWithNibName:kOfferDetailsViewController bundle:[NSBundle mainBundle] url:merchantStore.detailsUrl];
        
        [self.navigationController pushViewController:offerDetailsViewController animated:YES];
        [offerDetailsViewController release];
    }
    
}

/*!
 @function	 updateActionDelegate
 @abstract   delegate method to load the update price screen
 @discussion This is the delegate method for the update button click.
 @param      merchantStore
 @result     void
 */
- (void)updateActionDelegate:(MerchantStore*)merchantStore
{
    UpdatePriceViewController *updatePriceViewController = [[UpdatePriceViewController alloc] initWithNibName:kUpdatePriceViewController bundle:[NSBundle mainBundle]];
    [updatePriceViewController setMerchantId:merchantStore.storeId];
    [updatePriceViewController setProductId:productDetail.productId];
    [updatePriceViewController setProductTitle:productDetail.name];
    [self.navigationController pushViewController:updatePriceViewController animated:YES];
    [updatePriceViewController release];
}


#pragma make - RelatedProductCellDelegate
/*!
 @function	 relatedProdcutTapedDelegate
 @abstract   delegate method to load related product
 @discussion delegate method to load selected related product for details.
 @param      currentIndex
 @result     void
 */
-(void) relatedProdcutTapedDelegate :(int)currentIndex
{
    [self.productDetailsTable setUserInteractionEnabled:FALSE];
    self.product = [productDetail.releatedProducts objectAtIndex:currentIndex];
    [self.activityIndicator startAnimating];
    [self.productDetailsTable reloadData];
    isBuying = NO;
    [self storeDetails];
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function			showAlertView
 @abstract			Common method to display alert message 
 @discussion		Common method to display alert message 
 @param				alertTitle - Title for AlertView
 alertMessage - Message description for AlertView		
 @result			void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kRejectButtonTitle otherButtonTitles:kAcceptButtonTitle, nil];
	[alert show];
	[alert release];
}

/*!
 @method			clickedButtonAtIndex
 @abstract			redirect to Login Page 
 @discussion		redirect to Login Page when password sent successfully
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0:
        {
            //Navigate to details screen of the selected product
            OfferDetailsViewController *offerDetailsViewController = [[OfferDetailsViewController alloc] initWithNibName:kOfferDetailsViewController bundle:[NSBundle mainBundle] url:_merchantStore.detailsUrl];
            
            [self.navigationController pushViewController:offerDetailsViewController animated:YES];
            [offerDetailsViewController release];

        }
             break;
        case 1:
        {
            
            [self.activityIndicator stopAnimating];
            [self.productDetailsTable setUserInteractionEnabled:FALSE];
            
            isBuying = YES;
            if (_coupon)
            {
                [_coupon release];
                _coupon = nil;
            }
            _coupon = [[Coupon alloc] init];
            
            if (couponReqResHandler)
            {
                [couponReqResHandler release];
                couponReqResHandler = nil;
            }
            couponReqResHandler = [[CouponReqResHandler alloc] init];
            [couponReqResHandler setDelegate:self];
            
            [couponReqResHandler couponDetails:_merchantStore.productId merchantid:_merchantStore.merchantId coupon:_coupon];
            
        }
            break;
        default:
            break;
    }
}

@end
