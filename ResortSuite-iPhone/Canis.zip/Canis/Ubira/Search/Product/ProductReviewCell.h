//
//  ProductReviewCell.h
//  Ubira
//
//  Created by [Cybage Team] on 30/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RatingView.h"

@class Review;
@interface ProductReviewCell : UITableViewCell {
    UILabel     *postLabel;
    UILabel     *ratingLabel;
    UILabel     *postDateLabel;
    UILabel     *productDescriptionLabel;
    RatingView  *ratingView;
}
- (void)setReviewDetails:(Review*)review;
- (float)calculateHeightForCell:(NSString *)description;
@end
