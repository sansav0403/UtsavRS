//
//  ProductReviewReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "ProductReviewReqResHandler.h"
#import "LocationManager.h"

#define kReview @"Review"
#define kProductReviewID @"productid"
#define kAuthor @"author"
@implementation ProductReviewReqResHandler
@synthesize productReviewList = _productReviewList;
/*!
 @function productReviews
 @abstract create the url for to get the reviews from server.
 @discussion create the url for to get the reviews from server.
 @param productId - for which product we want review.
 @param review - pass the server response in this param.
 */
- (void)productReviews:(NSString*)productId review:(NSArray *)review
{
    self.productReviewList = review;
	NSString* queryString = [NSString stringWithFormat:@"%@/product/review/?productid=%@&lat=%d&long=%d"
							 ,kUbiraServerUrl
							 ,productId
							 ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
							 ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
							 ];
	
	NSURL* url = [NSURL URLWithString:queryString];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kGet];			
	
	[webService makeRequest:theRequest];
}

/*!
 @function handleReceivedData
 @abstract parse the review response.
 @discussion parse the review response.
 @param data - server response.
 */
- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
    TRC_ENTRY
    //Get the json key value dictionary for the data
    NSString *resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    
    NSString *newResponse = [resultString stringByDecodingXMLEntities];
    
	TRC_DBG(@"%@",newResponse)
	
	NSDictionary *resultDictionary = [newResponse JSONValue];

    [resultString release];
    
    NSArray *reviewDetail	= [resultDictionary valueForKey:kProduct];
    for(NSDictionary *productDict in reviewDetail)
    {   
        Review *productReview = [[Review alloc] init];
         TRC_DBG(@"Product Reviews :", productDict);
        
        productReview.reviewId = [productDict valueForKey:kId];
         TRC_DBG(@"Product reviewId : %@",productReview.reviewId )
        
       	NSString* dateString	=	[productDict valueForKey:kCreateDate];		
		NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];		
		[dateFormatter setDateFormat:kDateFormat];		
		productReview.createDate = [dateFormatter dateFromString:dateString];
		TRC_DBG(@" create_date : %@",productReview.createDate)
		[dateFormatter release];
        
        productReview.description = [productDict valueForKey:kDescription];
        productReview.description = [productReview.description stringByDecodingXMLEntities]; 
        TRC_DBG(@"Product Description : %@",productReview.description )
        
        productReview.productId = [productDict valueForKey:kProductReviewID];
        TRC_DBG(@"Product Id : %@",productReview.productId )
        
        productReview.rating = [[productDict valueForKey:kRatings] intValue];
        TRC_DBG(@"Product rating : %d",productReview.rating )
        
        productReview.author = [productDict valueForKey:kAuthor];
        TRC_DBG(@"Product author: %@",productReview.author )
        
        [(NSMutableArray*)self.productReviewList addObject:productReview];
        [productReview release];
    }

	if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:nil];
    }
}


- (void)dealloc
{	
    TRC_DBG(@"ProductReviewReqResHandler ------------ Release")
	[_productReviewList release];
	[super dealloc];
}

@end
