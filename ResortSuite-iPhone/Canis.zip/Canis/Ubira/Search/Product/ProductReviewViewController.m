//
//  ProductReviewViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProductReviewViewController.h"
#import "ProductReviewCell.h"
#import "UserAnalytics.h"

@implementation ProductReviewViewController
@synthesize activityIndicator;
@synthesize productReviews;
@synthesize startDate = _startDate;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil productId:(NSString *)aProductId
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        productId = [[NSString alloc] initWithString:aProductId];
    }
    return self;
}

- (void)dealloc
{
    TRC_DBG(@"ProductReviewViewController ------------ Release")
    [productReviewReqResHandler release];
    [productId release];
    [reviewList release];
    [productReviews release];
    [activityIndicator release];
    [_startDate release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setTitle:kReviewTitle];
    // Do any additional setup after loading the view from its nib.
    
	UIView	*view = [[UIView alloc]initWithFrame:CGRectZero];
	[self.productReviews setTableFooterView:view];
	[view release];
	
    productReviewReqResHandler = [[ProductReviewReqResHandler alloc] init];
	[productReviewReqResHandler setDelegate:self];
	reviewList = [[NSMutableArray alloc] init];
    [productReviewReqResHandler productReviews:productId review:reviewList];
}

- (void)viewDidUnload
{
    [productReviewReqResHandler setDelegate:nil];
    [productReviews release];
    productReviews = nil;
    [productId release];
    productId = nil;
    [self setActivityIndicator:nil];
    
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsProductReviewScreen startDate:self.startDate endDate:[NSDate date]];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table view datasource and delegate methods
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100.0f;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	// Number of sections is the number of regions
	return 1;
}


- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	// Number of rows is the number of time zones in the region for the specified section
	return [reviewList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
    static NSString *identifier = @"ReviewCell";
    ProductReviewCell *cell = (ProductReviewCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if(!cell)
    {
        cell = [[[ProductReviewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
    }
    Review *review =[reviewList objectAtIndex:indexPath.row];
    [cell setReviewDetails:review];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	/*
	 To conform to the Human Interface Guidelines, selections should not be persistent --
	 deselect the row after it has been selected.
	 */
	[tableView deselectRowAtIndexPath:indexPath animated:YES];

}

#pragma mark - Parsing complete delegate
-(void)parseComplete:(NSError*)error
{
	TRC_ENTRY
	if(error != nil)
	{
		TRC_ERR(@"%@",error)
        NSString *errorString = [[error userInfo] valueForKey:@"error"];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kReviews message:errorString delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
	}
	else
	{
		//update UI		
		TRC_DBG(@"=========================== Product Review ==================================")
        [self.productReviews reloadData];
        
	}
    [activityIndicator stopAnimating];
	TRC_EXIT
}
@end
