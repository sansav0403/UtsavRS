//
//  ProductDetail.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Product.h"

@interface ProductDetail : Product {

	NSArray    *merchantStoreList;
	NSArray    *releatedProducts;
    NSArray    *inStore;
}

@property(nonatomic, retain) NSArray    *merchantStoreList;
@property(nonatomic, retain) NSArray    *releatedProducts;
@property(nonatomic, retain) NSArray    *inStore;
@end
