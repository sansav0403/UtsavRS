//
//  ProductData.m
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
// Copyright 2011 FreeCause. All rights reserved.
//

#import "ProductData.h"
#import "ProductSearch.h"
#import "CoreDataApplicationStack.h"
#import "ImageDownloadQueue.h"
#import "ProductSearchReqResHandler.h"



@implementation ProductData


@dynamic productId;
@dynamic productName;
@dynamic productDescription;
@dynamic rating;
@dynamic reviews;
@dynamic rowIndex;
@dynamic imageUrl;
@dynamic imageData;
@dynamic creationDate;
@dynamic productDataToProductSearch;

/*!
 @function	 awakeFromInsert
 @abstract   overided function to insert row index to rows.
 @discussion this method will be called by core data framework before inserting a row to database.
 @param      none
 @result     void
 */
- (void)awakeFromInsert
{
    [super awakeFromInsert];
    [self setRowIndex:[NSNumber numberWithInt:[ProductSearchReqResHandler getCurrentRowIndex]]];
}


/*!
 @function	 downloadImage
 @abstract   Request to start download image.
 @discussion Request to start download image.
 @param      none
 @result     void
 */
- (void)downloadImage
{
    if( imageRequestInProgress == NO )
    {
        NSURLRequest *imageUrlRequest = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:self.imageUrl]];
        _imageDownloadOperation = [[RemoteDataOperation alloc] initWithUrlRequest:imageUrlRequest];
        [_imageDownloadOperation addObserver:self forKeyPath:@"isFinished" options:NSKeyValueObservingOptionNew context:NULL];
        [[ImageDownloadQueue sharedQueue] addOperation:_imageDownloadOperation];	
        [imageUrlRequest release];
        imageRequestInProgress = YES;
    }
}

#pragma mark RemoteDataOperation keyValue callback method


/*!
 @function	 observeValueForKeyPath
 @abstract   RemoteDataOperation keyValue callback
 @discussion RemoteDataOperation keyValue callback
 @param      
 @result     void
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
	@try {
		RemoteDataOperation* remoteDataOperation = (RemoteDataOperation*)object;
		[remoteDataOperation removeObserver:self forKeyPath:@"isFinished"];
		
        //if there is an error set default image else set image data received from server
        if( [remoteDataOperation error] ) 
		{
			self.imageData = UIImagePNGRepresentation([UIImage imageNamed:@"Noimages.png"]);
		} 
		else
		{
			self.imageData = remoteDataOperation.remoteData;
		}
        
        //Copy managed object from reading coontext to adding context
        NSManagedObjectID *objectID = [self objectID];
        NSManagedObject *objectRef = [ [[CoreDataApplicationStack globalStack] addingManagedObjectContext] objectWithID:objectID];
        
        if( objectRef)
        {
            //commit data to store
            [[CoreDataApplicationStack globalStack] commitData];
        }
        
        //release memory
		if( remoteDataOperation == _imageDownloadOperation ) {
			[_imageDownloadOperation release];
			_imageDownloadOperation =  nil;
		}
        
        imageRequestInProgress = NO;
        
	}
	@catch (NSException * e) {
		TRC_ERR(@"%@", [e reason]);
	}
}

/*!
 @function		dealloc
 @abstract		release data member variables
 @discussion	release data member variables
 @param			none
 @result		void
 */
-(void)dealloc
{
    [_imageDownloadOperation release];
    _imageDownloadOperation =  nil;
    [super dealloc];
}



@end
