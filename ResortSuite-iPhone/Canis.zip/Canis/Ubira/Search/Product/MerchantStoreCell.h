//
//  MerchantStoreCell.h
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MerchantStore.h"

@protocol MerchantStoreDelegate <NSObject>
- (void)buyActionDelegate:(MerchantStore*)merchantStore;
- (void)updateActionDelegate:(MerchantStore*)merchantStore;
@end
/*!
 @class MerchantStoreCell
 @abstract create the merchant store product cell.
 @discussion create the custom cell for all the screens which are showing the merchant in list.
 */
@interface MerchantStoreCell : UITableViewCell <StoreImageDownloadDelegate>{
    UIImageView                 *storeImageView;
    UILabel                     *merchantName;
    UILabel                     *productPrice;
    UIButton                    *buyButton;
    MerchantStore               *merchantStore;
    BOOL                        checkInStore;
    id <MerchantStoreDelegate>  _delegate;
}
@property (nonatomic, assign) id <MerchantStoreDelegate> delegate;
@property (nonatomic, retain) UILabel                    *merchantName;

- (void)setMerchantStoreDetails:(MerchantStore*)aMerchantStore inStore:(BOOL)inStore storeIndex:(int)storeIndex;
@end
