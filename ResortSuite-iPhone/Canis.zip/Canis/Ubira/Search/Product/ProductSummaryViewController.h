//
//  ProductSummaryViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductDetail.h"
/*!
 @class         ProductSummaryViewController
 @abstract      handler the product summary details presentation.
 @discussion    handler the product summary details presentation.
 */
@interface ProductSummaryViewController : UIViewController {
    
    UIPageControl   *pageControl;
    UIScrollView    *scrollView;
    NSMutableArray  *imageViewArray;
    UILabel         *descriptionLabel;
    UITextView      *descriptionView;
    BOOL            pageControlUsed;
    ProductDetail   *productDetail;
    NSDate          *_startDate;
}
@property (nonatomic, retain) IBOutlet UIScrollView     *scrollView;
@property (nonatomic, retain) IBOutlet UIPageControl    *pageControl;
@property (nonatomic, retain) IBOutlet UILabel          *descriptionLabel;
@property (nonatomic, retain) IBOutlet UITextView       *descriptionView;
@property (nonatomic, retain) NSMutableArray            *imageViewArray;
@property (nonatomic, retain) ProductDetail             *productDetail;
@property (nonatomic, retain) NSDate                    *startDate;

- (IBAction)pageChanged:(id)sender;

@end
