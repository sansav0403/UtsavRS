//
//  Favorites.m
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "Favorites.h"

@implementation Favorites

@synthesize 	favoriteId = _favoriteId;
@synthesize     product = _product;


/*!
 @function		init
 @abstract		init LocationController
 @discussion	This function initializes CLLocationManager object.
 @param			none 
 @result		id ehich is self of LocationController
 */

- (id)init {
    if ((self = [super init]))
    {
        _product = [[Product alloc] init];
    }
    return self;
}

- (void)dealloc
{
    [_favoriteId release];
	[_product release];
	[super dealloc];
}
@end
