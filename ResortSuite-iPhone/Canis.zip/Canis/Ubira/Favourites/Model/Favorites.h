//
//  Favorites.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Product.h"

@interface Favorites : NSObject 
{
    NSString    *_favoriteId;
	Product     *_product;
}
@property (nonatomic, copy) NSString    *favoriteId;
@property (nonatomic, retain) Product     *product;
@end
