//
//  FavoriteReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"

typedef enum
{
	kFavReqGetFavorite,
	kFavReqAddFavorite,
	kFavReqDeleteFavorite
} FavReqState;

@class Favorites;

/*!
 @class FavoriteReqResHandler
 @abstract Handler the favorites request response.
 @discussion Create the required url request and respond to the caller.
 */
@interface FavoriteReqResHandler : RequestResponseBase {

	FavReqState     _favReqState;
    NSArray         *favoritesArray;
}   

@property (nonatomic) FavReqState       _favReqState;
@property (nonatomic,retain) NSArray    *favoritesArray;

- (void)favorites:(NSArray*)aFavorites;
- (void)addFavorite:(NSString*)productId;
- (void)deleteFavorite:(NSString*)favoriteId;

@end
