//
//  AddNewStoreViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StoreReqResHandler.h"
#import "Commons.h"

#define kStoreNameMaxLength		150
#define kPhoneMaxLength			11
#define kViewAnimationDuration  0.3 

@interface AddNewStoreViewController : UIViewController <RequestResponseBaseDelegate,UITextViewDelegate>
{
    
	// IBoutlets
	IBOutlet UILabel					*_storeMandatoryLbl;
	IBOutlet UITextField				*_storeNameTxtField;
	IBOutlet UITextField                *_storeAddressTxtField;
	IBOutlet UITextField				*_storeTelNoTxtField;
	IBOutlet UITextView                 *_storeDescriptionTxtView;
	IBOutlet UIButton					*_storeSubmitBtn;
	IBOutlet UIView						*activityIndicatorView; 
	IBOutlet UIActivityIndicatorView	*spinner;
	
	
	// BOOL
	BOOL								ischeckInToStore;
	
	// ViewController object
	StoreReqResHandler					*_storeReqResHandler;
	
	// Others
	Store								*_store;
	
	NSString							*_storeId;
    NSDate                              *_startDate;
    
    CGRect                              viewFrame;
    NSInteger                           animatedDis;
    CGFloat                             yForKeyBoard;
}

@property (nonatomic,retain) Store								*store;
@property (nonatomic,copy)	  NSString							*storeId;

@property (nonatomic,retain) IBOutlet UILabel					*storeMandatoryLbl;
@property (nonatomic,retain) IBOutlet UITextField				*storeNameTxtField;
@property (nonatomic,retain) IBOutlet UITextField				*storeAddressTxtField;
@property (nonatomic,retain) IBOutlet UITextField				*storeTelNoTxtField;
@property (nonatomic,retain) IBOutlet UITextView				*storeDescriptionTxtView;
@property (nonatomic,retain) IBOutlet UIButton					*storeSubmitBtn;
@property (nonatomic,retain) IBOutlet UIView					*activityIndicatorView;
@property (nonatomic,retain) IBOutlet UIActivityIndicatorView	*spinner;
@property (nonatomic, retain) NSDate                            *startDate;

- (void)initialSetup;
- (void)viewAnimationwithFrame:(CGRect)currentFrame;
- (void)animateTextControl:(UIControl*)textControl up:(BOOL)up;
- (void)showActivityIndicator;
- (void)stopActivityIndicator;
- (BOOL)validateTextFields;

- (void)addRequireObservers;
- (void)removeObservers;

- (IBAction)backgroundTouched:(id)sender;
- (IBAction)submitAction:(id)sender;

@end
