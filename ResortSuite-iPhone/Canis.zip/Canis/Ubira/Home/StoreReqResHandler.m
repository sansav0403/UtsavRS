//
//  StoreReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "StoreReqResHandler.h"
#import "UbiraAppDelegate.h"
#import "LocationManager.h"

@implementation StoreReqResHandler

@synthesize storeDetails =_store,_storeReqState , storeList = _storeList, newlyAddedstoreId = _storeId ;


#pragma mark request functions
/*!
 @function		storeList
 @abstract		makes a request to get store list.
 @discussion	makes a request to get store list.
 @param			none
 @result		void
 */

- (void)storeList:(NSArray*)storeList
{	
	TRC_ENTRY
	
	self._storeReqState = kSTReqGettingStoreList;
	self.storeList		= storeList; 
	
	//Get current location

	
	
#if TARGET_IPHONE_SIMULATOR
	// This is for testing on simulator as core location does not provide any values on simulator
	NSString* latString = [NSString stringWithFormat:@"%d",40];
	NSString* longString =[NSString stringWithFormat:@"%d",44];
	
#else
	NSString* latString = [NSString stringWithFormat:@"%d",[LocationManager sharedInstance].currentLocation.coordinate.latitude];
	NSString* longString =[NSString stringWithFormat:@"%d",[LocationManager sharedInstance].currentLocation.coordinate.longitude];
	
#endif
	
	NSString* queryString = [NSString stringWithFormat:@"%@/geo/nearby_stores?lat=%@&long=%@"
							 ,kUbiraServerUrl
							 ,latString
							 ,longString];
	TRC_DBG(@"%@",queryString)
	NSURL* url = [NSURL URLWithString:queryString];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kGet];			
	
	[webService makeRequest:theRequest];
	
	TRC_EXIT
}

/*!
 @function		addStore
 @abstract		makes a request to add new store
 @discussion	makes a request to add new store
 @param			store	- set all store data in Store model object.
 @param			storeId - on success, server will return store id.
 @result		void
 */

- (void)addStore:(Store*)store storeid:(NSString*)storeId
{
	TRC_ENTRY
	
	self._storeReqState			= kSTReqAddingNewStore;
	self.newlyAddedstoreId		= storeId;
	self.storeDetails			= store;
	
	NSString* latString = [NSString stringWithFormat:@"%d",[LocationManager sharedInstance].currentLocation.coordinate.latitude];
	NSString* longString =[NSString stringWithFormat:@"%d",[LocationManager sharedInstance].currentLocation.coordinate.longitude];
	
	
	NSString* postData = [NSString stringWithFormat:@"name=%@&address=%@&phone=%@&description=%@&lat=%@&long=%@"
						  ,self.storeDetails.name
						  ,self.storeDetails.address
						  ,self.storeDetails.phone
						  ,self.storeDetails.description
						  ,latString
						  ,longString];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];

	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/store/add",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
	
	TRC_EXIT
}

/*!
 @function		checkIn
 @abstract		makes a request to check in the store
 @discussion	makes a request to check in the store
 @param			storeId - set store id in user wants to check in.
 @param			store	- on success, server will return store information. 
 @result		void
 */

- (void)checkIn:(NSString*)storeId storeInformation:(Store*)store
{
	TRC_ENTRY
	
	self._storeReqState			= kSTReqCheckIn;
	self.storeDetails			= store;
	
	//user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
	NSString* postData = [NSString stringWithFormat:@"userid=%@&storeid=%@&lat=%d&long=%d"
						  ,userId
						  ,storeId
						  ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
						  ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
						  ];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/store/checkin",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
	
	TRC_EXIT
}

#pragma mark parsing functions

/*!
 @function		handleReceivedData
 @abstract		decides the action based on the request.
 @discussion	decides the action based on the request.
 @param			data - server response.
 @result		bool
 */

- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
	TRC_ENTRY
	switch (self._storeReqState) {
		case kSTReqGettingStoreList:
			{
				//Store List Parse
				[self parseStorelist:data];
			}	break;
		case kSTReqAddingNewStore:
			{
				//Add Store Parsing
				[self parseAddStore:data];
			}	break;
		case kSTReqCheckIn:
			{
				//Store Check In Parsing
				[self parseCheckIn:data];
			}	break;
			
		default:
			break;
	}

	TRC_EXIT
}

/*!
 @function		handleReceivedData
 @abstract		decides the action based on the request.
 @discussion	decides the action based on the request.
 @param			data - server response.
 @result		bool
 */

- (void)parseStorelist:(NSData*)data
{
	TRC_ENTRY
	//Get the json key value dictionary for the data
	NSString *resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
	
    NSDictionary *resultDictionary = [resultString JSONValue];
    
	[resultString release];
	    
	
	NSError*	error = nil ;

		
		NSArray *resultList = [resultDictionary valueForKey:kStores];
		
		//Create the all available offer models 
		for(NSDictionary *storeDict in resultList)
		{    
			TRC_DBG(@"-------------------Store List---------------------")
			Store *store = [[Store alloc] init];
			
			store.createDate = [storeDict valueForKey:kStoreCreateDate];
			TRC_DBG(@"Store createDate : %@",store.createDate)
			
			store.description = [storeDict valueForKey:kDescription];
			TRC_DBG(@"Store description : %@",store.description)
			
			store.storeId = [storeDict valueForKey:kId];
			TRC_DBG(@"Store storeId : %@",store.storeId)

			store.address = [storeDict valueForKey:kStoreAddress];
			TRC_DBG(@"Store Address : %@",store.address)
			
			store.imageUrl = [storeDict valueForKey:kImageUrl];
			TRC_DBG(@"Store imageUrl : %@",store.imageUrl)
			
			store.phone = [storeDict valueForKey:kPhone];
			TRC_DBG(@"Store phone : %@",store.phone)
			
			store.name = [storeDict valueForKey:kName];
			TRC_DBG(@"Store name : %@",store.name)
			
			//lat long parsing
			store.latitude = [storeDict valueForKey:kLat];
			TRC_DBG(@"Store lat : %@",store.latitude)
			
			store.longitude = [storeDict valueForKey:kLong];
			TRC_DBG(@"Store long : %@",store.longitude)
			
			TRC_DBG(@"Store Reference Count :%d", [store retainCount])
			[(NSMutableArray *)self.storeList addObject:store];
			[store release];
			TRC_DBG(@"Store Reference Count :%d", [store retainCount])
			
		}
    
    //Update the caller about the result
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
	TRC_EXIT
}

/*!
 @function		handleReceivedData
 @abstract		decides the action based on the request.
 @discussion	decides the action based on the request.
 @param			data - server response.
 @result		bool
 */

- (void)parseAddStore:(NSData*)data 
{
	TRC_ENTRY
	
	NSString* responseString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
	TRC_DBG(@"%@",responseString)
	
	NSDictionary *resultDictionary = [responseString JSONValue];
	
	[responseString release];
		
	NSError*	error = nil ;

	[(NSMutableString *)self.newlyAddedstoreId appendString:[[resultDictionary objectForKey:kStoreId] stringValue]];
	self.newlyAddedstoreId = [[resultDictionary objectForKey:kStoreId] copy];
	TRC_DBG(@"Store ID = %@", self.newlyAddedstoreId)
	
	
	//Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:error];
	}
	
	TRC_EXIT	
}

/*!
 @function		handleReceivedData
 @abstract		decides the action based on the request.
 @discussion	decides the action based on the request.
 @param			data - server response.
 @param			store - on success sever will response store information.
 @result		bool
 */

- (void)parseCheckIn:(NSData*)data 
{
	TRC_ENTRY
	
	NSString* responseString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
	TRC_DBG(@"%@",responseString)
	
	NSDictionary *resultDictionary = [responseString JSONValue];
	
	[responseString release];

	NSArray *resultList = [resultDictionary valueForKey:kStore];
	
	//Create the all available offer models 
	for(NSDictionary *storeDict in resultList)
	{    
		//Store *store = [[Store alloc] init];
		
		/*self.storeDetails.createDate = [storeDict valueForKey:kStoreCreateDate];
		TRC_DBG(@"Store createDate : %@",self.storeDetails.createDate)*/
		NSString* dateString	=	[storeDict valueForKey:kStoreCreateDate];		
		NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];		
		[dateFormatter setDateFormat:kDateFormat];		
		self.storeDetails.createDate = [dateFormatter dateFromString:dateString];
		TRC_DBG(@" create_date : %@",[dateFormatter stringFromDate:self.storeDetails.createDate])
		[dateFormatter release];
		
		self.storeDetails.description = [storeDict valueForKey:kDescription];
		TRC_DBG(@"Store description : %@",self.storeDetails.description)
		
		self.storeDetails.storeId = [storeDict valueForKey:kId];
		TRC_DBG(@"Store storeId : %@",self.storeDetails.storeId)
		
		self.storeDetails.imageUrl = [storeDict valueForKey:kImageUrl];
		TRC_DBG(@"Store imageUrl : %@",self.storeDetails.imageUrl)
		
		self.storeDetails.phone = [storeDict valueForKey:kPhone];
		TRC_DBG(@"Store phone : %@",self.storeDetails.phone)
		
		self.storeDetails.name = [storeDict valueForKey:kName];
		TRC_DBG(@"Store name : %@",self.storeDetails.name)
		
		self.storeDetails.address = [storeDict valueForKey:kAddress];
		TRC_DBG(@"Store name : %@",self.storeDetails.address)
		
		//lat long parsing reamin
		self.storeDetails.latitude = [storeDict valueForKey:kLat];
		TRC_DBG(@"Store lat : %@",self.storeDetails.latitude)
		
		self.storeDetails.longitude = [storeDict valueForKey:kLong];
		TRC_DBG(@"Store long : %@",self.storeDetails.longitude)
	}
		
	//Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:nil];
	}
	
	TRC_EXIT
}

/*!
 @function		dealloc
 @abstract		release data member variables
 @discussion	release data member variables
 @param			none
 @result		void
 */

#pragma mark memory management

- (void)dealloc
{	
	[_storeList release];
	[_store		release];
	[_storeId	release];
	[super		dealloc];
}
@end
