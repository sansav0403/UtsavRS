//
//  Store.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RemoteDataOperation.h"

@protocol StoreImageDownloadDelegate

- (void)imageDownloadComplete:(NSError*)error storeIndex:(int)storeIndex; 

@end


@interface Store : NSObject {

	NSString                        *storeId;
	NSString                        *name;
	NSString                        *address;
	NSString                        *phone;
	NSString                        *description;
	NSString                        *imageUrl;
	NSDate                          *createDate;
	
	NSString                        *latitude;
	NSString                        *longitude;
	
	UIImage                         *_storeImage;
	int                             _storeIndex;
	RemoteDataOperation             *_imageDownloadOperation;
    BOOL                            imageRequestInProgress;
	id<StoreImageDownloadDelegate>	_delegate;
	
}
@property (nonatomic, copy) NSString                        *storeId;
@property (nonatomic, copy) NSString                        *name;
@property (nonatomic, copy) NSString                        *address;
@property (nonatomic, copy) NSString                        *phone;
@property (nonatomic, copy) NSString                        *description;
@property (nonatomic, copy) NSString                        *imageUrl;
@property (nonatomic, copy) NSString                        *latitude;
@property (nonatomic, copy) NSString                        *longitude;

@property (nonatomic, assign) NSDate                        *createDate;
@property (nonatomic, retain) UIImage                       *storeImage;
@property (nonatomic, assign) int                           storeIndex;
@property (nonatomic, assign)id<StoreImageDownloadDelegate>	delegate;

+ (id)sharedStore;
- (void)downloadImage;

@end
