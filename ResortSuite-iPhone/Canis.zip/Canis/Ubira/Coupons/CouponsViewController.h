//
//  CouponsViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CouponReqResHandler.h"

typedef enum
{
	kCouponFetchRequest,
	kCouponDeleteRequest
}CouponsRequestState;

@interface CouponsViewController : UIViewController<RequestResponseBaseDelegate> {
    CouponReqResHandler				*couponReqResHandler;
    NSArray							*couponsList;
	
	IBOutlet UITableView			*couponTbl;
	
	CouponsRequestState				couponsRequestState;
    NSDate                          *_startDate;
    
    UIActivityIndicatorView         *activityIndicator;
    IBOutlet UILabel                *NoCouponLbl;
    
    NSIndexPath                     *deleteCouponIndexPath;
}
@property (nonatomic, retain) IBOutlet UITableView                  *couponTbl;
@property (nonatomic, retain) IBOutlet UILabel                      *NoCouponLbl;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView      *activityIndicator;
@property (nonatomic, retain) NSDate                                *startDate;

- (void)refreshData;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage 
		  setDelegate:(id)currentDelegate 
	cancelButtonTitle:(NSString *)cancelButtonTitle
	 otherButtonTitle:(NSString *)otherButtonTitle;
@end
