//
//  CouponCell.m
//  Ubira
//
//  Created by [Cybage Team] on 08/06/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "CouponCell.h"


@implementation CouponCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code.        
        couponDescriptionLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [couponDescriptionLbl setBackgroundColor:[UIColor clearColor]];
		[couponDescriptionLbl setTextColor:[UIColor redColor]];
        [couponDescriptionLbl setFont:[UIFont systemFontOfSize:14]];
        [self.contentView addSubview:couponDescriptionLbl];
		
		couponExpireLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [couponExpireLbl setBackgroundColor:[UIColor clearColor]];
        [couponExpireLbl setTextColor:[UIColor blackColor]];
        [couponExpireLbl setFont:[UIFont systemFontOfSize:14]];
        [self.contentView addSubview:couponExpireLbl];
        
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return self;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state.
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        //set frame for the title      
		
        frame = CGRectMake(10, 0, 200, 40);
        [couponDescriptionLbl setFrame:frame];	
		
		frame = CGRectMake(10, 22, 200, 40);
        [couponExpireLbl setFrame:frame];

	}
}

- (void)setCouponData:(Coupon*)aCoupon
{
	coupon = aCoupon;
	[couponDescriptionLbl setText:coupon.description];
	
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];			
	[dateFormatter setDateFormat:@"dd/MM/yyyy"];

	[couponExpireLbl setText:[NSString stringWithFormat:@"%@ %@",kValidTill, [dateFormatter stringFromDate:coupon.expireDate]]];
	[dateFormatter release];
	

}
- (void)dealloc {
    [super dealloc];
	[couponDescriptionLbl        release];
    [couponExpireLbl			 release];
}


@end
