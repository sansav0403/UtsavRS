//
//  CouponReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"
#import "Coupon.h"

typedef enum
{
	kCUPReqGetCoupon,	
	kCUPReqDeleteCoupon,
	kCUPReqCouponDetails
} CUPReqState;

/*!
 @class CouponReqResHandler
 @abstract Handler the coupon request response.
 @discussion Create the required url request and respond to the caller.
 */
@interface CouponReqResHandler : RequestResponseBase {
	
	CUPReqState     _cupReqState;
    Coupon          *coupon;
    NSArray         *_couponsList;
}

@property (nonatomic) CUPReqState       cupReqState;
@property (nonatomic, retain) NSArray   *couponsList;

- (void)coupons:(NSArray *)coupons;
- (void)deleteCoupon:(NSString*)couponId;
- (void)couponDetails:(NSString*)productId merchantid:(NSString*) merchantId coupon:(Coupon*)aCoupon;

@end
