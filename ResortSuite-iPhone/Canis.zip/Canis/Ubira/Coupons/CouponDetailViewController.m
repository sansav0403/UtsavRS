//
//  CouponDetailViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 09/06/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "CouponDetailViewController.h"
#import "ImageDownloadQueue.h"

@implementation CouponDetailViewController

@synthesize couponDescriptionLbl ,couponCodeLbl ,couponValidTillLbl ,couponImageView,couponCodeTitleLbl;
@synthesize coupon = _coupon;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	[self setTitle:kUbiraTitle];
	[self updateDataValue];
}

- (void)didReceiveMemoryWarning {
   
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
   
    self.couponImageView = nil;
    self.coupon = nil;
    self.couponDescriptionLbl = nil;
    self.couponCodeLbl = nil;
    self.couponValidTillLbl = nil;	
	self.couponCodeTitleLbl = nil;
    [super viewDidUnload];
}


- (void)dealloc {
    
	[[ImageDownloadQueue sharedQueue] cancelAllOperations];
	
	[couponDescriptionLbl release];
	[couponCodeLbl release];
	[couponValidTillLbl release];
	[couponImageView release];
	[couponCodeTitleLbl release];
	[_coupon release];
	[super dealloc];
}

- (void)updateDataValue
{
	self.coupon.delegate = self;
	[self.coupon downloadImage];
	
	[couponCodeTitleLbl setText:kCouponCodeLabelTitle];
	[couponImageView setImage:[UIImage imageNamed:@"Noimages.png"]];
	[couponDescriptionLbl setText:self.coupon.description];
	[couponCodeLbl setText:self.coupon.code];	
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];			
	[dateFormatter setDateFormat:@"dd/MM/yyyy"];

	[couponValidTillLbl setText:[NSString stringWithFormat:@"%@ %@",kValidTill, [dateFormatter stringFromDate:self.coupon.expireDate]]];
	[dateFormatter release];
	
}

#pragma mark Coupon:ImageDownloadDelegate
- (void)imageDownloadComplete:(NSError*)error
{
	if (error)
    {

	}else {
		[couponImageView setImage:self.coupon.image];
	}

}


@end
