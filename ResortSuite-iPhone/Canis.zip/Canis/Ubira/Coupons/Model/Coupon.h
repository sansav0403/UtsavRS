//
//  Coupon.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RemoteDataOperation.h"

@protocol CouponImageDownloadDelegate

- (void)imageDownloadComplete:(NSError*)error;

@end

@interface Coupon : NSObject {

	NSString    *_couponId;
	NSString    *_code;
	NSString    *_description;
	NSString    *_imageUrl;
	NSDate      *_createDate;
	NSDate      *_expireDate;
	NSString    *_productId;
	NSString    *_merchantId;
	NSString    *_userId;
	int         _active;
	
	UIImage		*_image;
	
	RemoteDataOperation		*_imageDownloadOperation;
    BOOL                    imageRequestInProgress;        
	id<CouponImageDownloadDelegate>_delegate;
}

@property (nonatomic, copy) NSString    *couponId;
@property (nonatomic, copy) NSString    *code;
@property (nonatomic, copy) NSString    *description;
@property (nonatomic, copy) NSString    *imageUrl;
@property (nonatomic, retain) NSDate    *createDate;
@property (nonatomic, retain) NSDate    *expireDate;
@property (nonatomic, copy) NSString    *productId;
@property (nonatomic, copy) NSString    *merchantId;
@property (nonatomic, copy) NSString    *userId;
@property (nonatomic, retain) UIImage   *image;

@property (nonatomic, assign) int       active;
@property (nonatomic, assign) id<CouponImageDownloadDelegate>	delegate;

- (void)downloadImage;
@end
