//
//  CouponCell.h
//  Ubira
//
//  Created by [Cybage Team] on 08/06/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Coupon.h"

@interface CouponCell : UITableViewCell {
	
    UILabel                 *couponDescriptionLbl;
	UILabel                 *couponExpireLbl;
	
	Coupon					*coupon;
}

- (void)setCouponData:(Coupon*)aCoupon;

@end
