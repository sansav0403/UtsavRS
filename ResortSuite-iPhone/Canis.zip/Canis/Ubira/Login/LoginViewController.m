//
//  LoginViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "ForgotPasswordViewController.h"

#import "UserExtended.h"
#import "KeychainItemWrapper.h"
#import "ValidationHandler.h"

#import "UbiraAppDelegate.h"
#import "UserAnalytics.h"

@implementation LoginViewController
@synthesize delegate = _delegate;
@synthesize emailTxtField;
@synthesize passwordTxtField;
@synthesize checkRememberPasswordBtn;
@synthesize activityIndicatorView; 
@synthesize spinner;
@synthesize startDate = _startDate;

@synthesize ubiraLogoImgView,rememberPasswordLbl,forgotPasswordBtn,newUserLbl,registerHereBtn,loginBtn;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    TRC_DBG(@"LoginViewController ----------- Release")
    _delegate= nil;    
	[ubiraLogoImgView release];
	[rememberPasswordLbl release];
	[forgotPasswordBtn release];
	[newUserLbl release];
	[registerHereBtn release];
    [emailTxtField release];
    [passwordTxtField release];
    [checkRememberPasswordBtn release];
    [activityIndicatorView release];
	[loginBtn release];
    [spinner release];
	[loginReqResHandler release];
    [_startDate release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    [[self.navigationController navigationBar] setTintColor:kSCNavigationBarTintColor];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg.png"]]];
	[self setLocalizableText];
	
    //set Initials
    viewFrame = self.view.frame;
    
	// set rememberPassword default to NO.
	rememberPassword = NO;
	_userExtended = [UserExtended sharedUserExteded];
	int retVal = [self autoLogin];
    TRC_DBG(@"retVal : %d", retVal)
	// Check if remember password selected and user has not log out 
	if(retVal)
    {        
		TRC_DBG(@"Auto Login = FALSE")
		TRC_DBG(@"In Auto Login Process = TRUE")
		KeychainItemWrapper *keychainItemWrapper = [[KeychainItemWrapper alloc] initWithIdentifier:kEmailAndPasswordFromKeychain accessGroup:kBundleIdentifier];
		
		_userExtended.email = [keychainItemWrapper objectForKey:(id)kSecAttrAccount];
        
        [keychainItemWrapper release];
        keychainItemWrapper = nil;
        
        keychainItemWrapper = [[KeychainItemWrapper alloc] initWithIdentifier:@"Ubira1" accessGroup:kBundleIdentifier];
        
		_userExtended.password = [keychainItemWrapper objectForKey:(id)kSecAttrAccount];
		
		//TRC_DBG(@"Email Address =%@",[wrapper objectForKey:(id)kSecAttrAccount])
		//TRC_DBG(@"Password =%@",[wrapper objectForKey:(id)kSecValueData])
		[keychainItemWrapper release];
		
		emailTxtField.text = _userExtended.email;
		passwordTxtField.text = _userExtended.password;
        
        [checkRememberPasswordBtn setBackgroundImage:[UIImage imageNamed:kCheckImage] forState:UIControlStateNormal];
        
		loginReqResHandler = [[LoginReqResHandler alloc]init];
		[loginReqResHandler setDelegate:self];
		[loginReqResHandler logIn:_userExtended];
		
		
		// show actitivty indicator while auto login 
		[self.view addSubview:activityIndicatorView];
		[spinner startAnimating];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
	
	// Register the keyboard nofification to know when it appear and disappears 
	// to animate view when keyboard overlays view's textfields. 
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];

    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
    
}

- (void)viewDidUnload
{
    [self setUbiraLogoImgView:nil];
    [self setRememberPasswordLbl:nil];
    [self setNewUserLbl:nil];
    [self setEmailTxtField:nil];
    [self setPasswordTxtField:nil];
    [self setCheckRememberPasswordBtn:nil];
    [self setLoginBtn:nil];
    [self setForgotPasswordBtn:nil];
    [self setRegisterHereBtn:nil];
    [self setActivityIndicatorView:nil];
    [self setSpinner:nil];
    
    [super viewDidUnload];
    
}

- (void)viewWillDisappear:(BOOL)animated
{
	// unregister for keyboard notifications while not visible.
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil]; 
	[[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil]; 	
    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsLoginScreen startDate:self.startDate endDate:[NSDate date]];
    

}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*!
    @function   textFieldShouldReturn
    @abstract   delegate for textField 
    @discussion discard the keyboard when tap on return button of keyboard
    @param      textField - selected textField 
    @result     will return YES 
*/
- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{
	// Discard keyBoard form window when return key tap on keyboard.
	[textField resignFirstResponder];
	return YES;
}

#pragma TextField Delegate methods
/*!
 @function		shouldChangeCharactersInRange
 @abstract		delegate for textField 
 @discussion	entered text should replace
 @param			range - on which entered text needs to replace 
 string - needs to replace
 @result		BOOL - if space entered returns NO else YES. 
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ((range.location > 0 && [string length] > 0 && [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[string characterAtIndex:0]] &&           [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[[textField text] characterAtIndex:range.location - 1]])) 
    {
        return NO;
    }
    // if first character is a space
    if ([string isEqualToString:@" "] && [textField.text length]==0)
	{ 
		return NO;
	}
    return YES;
}

#pragma mark -
#pragma mark KeyBoard delegate methods
/*!
    @function		keyboardWillShow
    @abstract		keyboard about to appear on view
    @discussion		keyboard about to appear on view
    @param			nNotification - notificationo object 
    @result			void
*/
- (void)keyboardWillShow:(NSNotification*)aNotification
{	
	[self animateView:aNotification keyboardWillShow:YES];
}

/*!
    @function		keyboardWillHide
    @abstract		keyboard about to disappear from view
    @discussion		keyboard about to disappear from view
    @param			aNotification - Notification object
    @result			void
*/
- (void)keyboardWillHide:(NSNotification*)aNotification
{
	[self animateView:aNotification keyboardWillShow:NO];
}

/*!
    @function		animateView
	@abstract		animate view up or down when keyboard overlays
    @discussion		Common function to animate view up or down when keyboard overlays
					view's textfield
    @param			keyboardWillHide
    @result			void
*/
- (void)animateView:(NSNotification*)aNotification keyboardWillShow:(BOOL)keyboardWillShow
{
	[UIView beginAnimations:nil context:NULL];
	
	[UIView setAnimationDuration:0.3];
	
	CGRect rect = [[self view] frame];
	if (keyboardWillShow)
	{
		rect.origin.y -= 60;
	}
	else
	{
        rect = viewFrame;
	}
	[[self view] setFrame: rect];
	
	[UIView commitAnimations];
}

#pragma mark 
#pragma mark Action Methods
/*!
    @method			backgroundTouched
    @abstract		discard keyboard when tapped on view apart from keyBoard
    @discussion		discard keyboard when tapped on view apart from keyBoard
*/
- (IBAction)backgroundTouched:(id)sender
{
	[emailTxtField resignFirstResponder];
	[passwordTxtField resignFirstResponder];
}

/*!
    @method			loginAction
    @abstract		login for user
    @discussion		initiate login process for user
*/
- (IBAction)loginAction:(id)sender 
{
	// Discard the keyboard from window
	[emailTxtField resignFirstResponder];
	[passwordTxtField resignFirstResponder];
	
	// If entered email and password are valide initiate login process
	if ([self validateEmailAndPassword])
	{	
        // show the activityIndicator while login activity is running. 
		[self.view addSubview:activityIndicatorView];
		[spinner startAnimating];
        
		// set email and password in singleton object to use through out the application.
		_userExtended.email = emailTxtField.text;
		_userExtended.password = passwordTxtField.text;
		
		if (loginReqResHandler)
		{
			[loginReqResHandler release];
			loginReqResHandler = nil;
		}
		loginReqResHandler = [[LoginReqResHandler alloc]init];
		[loginReqResHandler setDelegate:self];
		[loginReqResHandler logIn:_userExtended];
	}
}

/*!
    @method			forgotPasswordAction
    @abstract		redirect to forgot password page
    @discussion		redirect to forgot password page when tapping forgot password button 
*/
- (IBAction)forgotPasswordAction:(id)sender 
{
    forgotPasswordViewController = [[ForgotPasswordViewController alloc] initWithNibName:@"ForgotPasswordViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:forgotPasswordViewController animated:YES];

    [forgotPasswordViewController release];
}

/*!
    @method			registerNewUserAction
    @abstract		redirect to registration page
    @discussion		redirect to registration page when tapping new user registration button 
*/
- (IBAction)registerNewUserAction:(id)sender 
{
    registerViewController = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:registerViewController animated:YES];
    
    [registerViewController release];
}

/*! 
    @method			rememberPasswordAction
    @abstract		check the rememberPassword button
    @discussion		set the check or uncheck image for button and set the rememberpassword
					bool variable
*/
- (IBAction)rememberPasswordAction:(id)sender
{
	rememberPassword = !rememberPassword;
	UIImage *checkImg =	rememberPassword ? [UIImage imageNamed:kCheckImage] : [UIImage imageNamed:kUnCheckImage];
	[checkRememberPasswordBtn setBackgroundImage:checkImg forState:UIControlStateNormal];
}

#pragma mark - Parsing complete delegate
/*!
 @function		parseComplete
 @abstract		delegate on parse complete.
 @discussion	Take the action based on the parameter.
 @param			error - server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
	// Remove activity indicator
	[self stopActivityIndicator];
    if(error)
    {
        TRC_ERR(@"Login Error %@",error)
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
		[self showAlertView:kPleaseLogin alertMessage:errorString setDelegate:nil];
	}
    else
    {
        //update UI
		
		// check if the rememberPassword check box is cheked or not
		// if checked then store password into keychain
		if (rememberPassword)
		{
			KeychainItemWrapper *keychainItemWrapper = [[KeychainItemWrapper alloc] initWithIdentifier:@"Ubira" accessGroup:kBundleIdentifier];
			
			// save edits
			[keychainItemWrapper setObject:emailTxtField.text forKey:(id)kSecAttrAccount];
            [keychainItemWrapper release];
            keychainItemWrapper = nil;
            
            keychainItemWrapper = [[KeychainItemWrapper alloc] initWithIdentifier:@"Ubira1" accessGroup:kBundleIdentifier];
            
            NSString* passwordString = passwordTxtField.text;
            [keychainItemWrapper setObject:passwordString forKey:(id)kSecAttrAccount];			
			
			[keychainItemWrapper release];
            
            NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
            NSString *finalPath = [[pathsArray objectAtIndex:0] stringByAppendingPathComponent:@"myList.plist"];
            
            NSDictionary *array = [[NSDictionary alloc] initWithObjectsAndKeys:@"TRUE",kAutoLoginKey, nil];           
            [array writeToFile:finalPath atomically: TRUE];
            [array release];            
		}
		else
		{         
            NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
            NSString *finalPath = [[pathsArray objectAtIndex:0] stringByAppendingPathComponent:@"myList.plist"];
            
            NSDictionary *array = [[NSDictionary alloc] initWithObjectsAndKeys:@"FALSE",kAutoLoginKey, nil];           
            [array writeToFile:finalPath atomically: TRUE];
            [array release];           
            
		}
		
		// send response to delegate about login
		if([self.delegate respondsToSelector:@selector(loginStatusDelegate:)])
		{
			[self.delegate loginStatusDelegate:YES];
		}
    }
}

#pragma mark 
#pragma mark Other Methods

/*!
 @function   setLocalizableText
 @abstract   set localizable text 
 @discussion set localizable text for UI
 @param      none
 @result     void
 */
- (void)setLocalizableText
{
	// set text for navigation title, buttons and textfield's placeholder text
	[self setTitle:kLogin];

	[self.emailTxtField setPlaceholder:kEmailAddress];
	[self.passwordTxtField setPlaceholder:kPassword];
	[self.rememberPasswordLbl setText:kRememberPasswordLblText];
	[self.newUserLbl setText:kNewUser];
	
	[self.loginBtn setTitle:kLogin forState:UIControlStateNormal];
	[self.forgotPasswordBtn setTitle:kForgotPassword forState:UIControlStateNormal];
	[self.registerHereBtn setTitle:kRegisterHere forState:UIControlStateNormal];
	
}


/*!
    @function		validateEmailAndPassword
    @abstract		validate email and password 
    @discussion		validate email and password 
    @param			none
    @result			will return YES if email and password both will comply  
					business rule else NO
*/
- (BOOL)validateEmailAndPassword
{
	// Check is textFields are blank or not
	if ([emailTxtField.text length]<=0 || [passwordTxtField.text length]<=0)
	{
		[self showAlertView:kPleaseLogin alertMessage:kPleaseLoginDescription setDelegate:nil];
		return NO;
	}
	
	// check is email entered valid or not
	if (![ValidationHandler emailValidate:emailTxtField.text]) 
	{
		[self showAlertView:kEmailInvalid alertMessage:kEmailInvalidDescription setDelegate:nil];
		return NO;
	}
	
	// check entered password's length 
	if (![ValidationHandler checkMinLength:8 string:passwordTxtField.text]) 
	{
		[self showAlertView:kPasswordInvalid alertMessage:kPasswordInvalidDescription setDelegate:nil];
		return NO;
	}
	
	// check is password entered is valid or not
	if (![ValidationHandler passwordValidate:passwordTxtField.text]) 
	{
		[self showAlertView:kPasswordInvalid alertMessage:kPasswordInvalidDescription setDelegate:nil];
		return NO;
	}
	
	return YES;
}

/*!
    @function		showAlertView
    @abstract		Common method to display alert message 
    @discussion		Common method to display alert message 
    @param			alertTitle - Title for AlertView
					alertMessage - Message description for AlertView		
    @result			void
*/
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
	[alert show];
	[alert release];
}

/*!
    @function		stopActivityIndicator
    @abstract		stop activity indicator
    @discussion		stop activity indicator and remove from superview
    @param			none
    @result			Void
*/
- (void)stopActivityIndicator
{
	[spinner stopAnimating];
	[activityIndicatorView removeFromSuperview];
}

/*!
    @function		autoLogin
    @abstract		check for is password remembered or not  
    @discussion		check if remember password selected and user has not log out
    @param			none
    @result			will return YES or NO based on password stored or not 
*/
- (BOOL)autoLogin
{
    int retVal = 0; 

    NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *finalPath = [[pathsArray objectAtIndex:0] stringByAppendingPathComponent:@"myList.plist"];
    NSDictionary* plistDictionary = [NSDictionary dictionaryWithContentsOfFile:finalPath] ;    
	NSString* isAutoLoginVal = [plistDictionary valueForKey:kAutoLoginKey]; 

    
    if ([isAutoLoginVal compare:@"TRUE"] == 0 && isAutoLoginVal != nil) {        
        retVal = 1;
        rememberPassword = YES;
    }else{        
        retVal = 0;
    }    
    return retVal;
}



@end
