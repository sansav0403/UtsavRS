//
//  NewUserReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "NewUserReqResHandler.h"
#import "LocationManager.h"

@implementation NewUserReqResHandler


@synthesize userDetail = _user;


/*!
 @function	registerNewUser
 @abstract   login request to server.
 @discussion login request to server.
 @param      UserExtended - UserExtended model class having name,email,password,address as optional
 @result     void
 */

- (void)registerNewUser:(UserExtended*)user
{
		
	self.userDetail = user;
	
	//Set device ID	
	NSString* deviceId = [[UIDevice currentDevice] uniqueIdentifier];
	
	//Optional fields in this request lat and long
	NSString* postData = [NSString stringWithFormat:@"name=%@&email=%@&password=%@&password2=%@&address=%@&deviceid=%@&lat=%d&long=%d"
						  ,self.userDetail.name
						  ,self.userDetail.email
						  ,self.userDetail.password
						  ,self.userDetail.password
						  ,self.userDetail.address
						  ,deviceId
						  ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
						  ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
						  ];
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];
	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/signup",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
}

/*!
 @function   handleReceivedData
 @abstract   response data for signup request to server.
 @discussion response data for signup request to server.
 @param      data - response data
 @result     bool
 */


- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
	TRC_ENTRY
	
	NSString* responseString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
	TRC_DBG(@"%@",responseString)
	
	NSDictionary *resultDictionary = [responseString JSONValue];
	[responseString release];
	
		
	self.userDetail.userId = [resultDictionary objectForKey:kUserId];	
	TRC_DBG(@"User ID = %@", self.userDetail.userId)
	

	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:nil];
	}
	
	
	TRC_EXIT
}

/*!
 @function	dealloc
 @abstract   release data member variables
 @discussion	release data member variables
 @param		none
 @result     void
 */

- (void)dealloc
{	
	[_user release];
	[super dealloc];
}
@end
