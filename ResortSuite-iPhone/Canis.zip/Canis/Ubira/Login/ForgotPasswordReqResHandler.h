//
//  ForgotPasswordReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"


/*!
    @class	ForgotPasswordReqResHandler
    @abstract    This class hadles all forgot password releated network and parsing functionality.
    @discussion  This class hadles all forgot password releated network and parsing functionality.
*/

@interface ForgotPasswordReqResHandler : RequestResponseBase {

}

- (void)forgetPassword:(NSString*)email;

@end
