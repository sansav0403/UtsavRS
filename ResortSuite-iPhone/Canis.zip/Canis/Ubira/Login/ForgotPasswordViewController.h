//
//  ForgotPasswordViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ForgotPasswordReqResHandler.h"
#import "RegisterViewController.h"

/*!
 @class			ForgotPasswordViewController
 @abstract		This class hadles releated UI interaction functionality for forgotPassword.
 @discussion	This class hadles all validations for email and password along with
				implementation of TextField and ReQuestResponseBase Delegate.
 */

@interface ForgotPasswordViewController : UIViewController <UITextFieldDelegate,RequestResponseBaseDelegate>
{
	// IBOutlets
	IBOutlet UILabel					*forgotPasswordLbl;
	IBOutlet UIButton					*doneBtn;
	IBOutlet UIButton					*newRegistrationBtn;
	IBOutlet UITextField				*emailTxtField;
	IBOutlet UIView						*activityIndicatorView; 
	IBOutlet UIActivityIndicatorView	*spinner;
	
	// ViewControllers
	RegisterViewController				*registerViewController;
	
	// Others
	ForgotPasswordReqResHandler			*forgotPasswordReqResHandler;
    NSDate                              *_startDate;
}
@property (nonatomic, retain) IBOutlet UILabel					*forgotPasswordLbl;
@property (nonatomic, retain) IBOutlet UIButton					*doneBtn;
@property (nonatomic, retain) IBOutlet UIButton					*newRegistrationBtn;
@property (nonatomic, retain) IBOutlet UITextField				*emailTxtField;
@property (nonatomic, retain) IBOutlet UIView					*activityIndicatorView;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView	*spinner;
@property (nonatomic, retain) NSDate                            *startDate;

- (void)setLocalizableText;

- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage delegate:(id)delegate;
- (void)stopActivityIndicator;
- (BOOL)validateEmail;

- (IBAction)backgroundTouched:(id)sender;
- (IBAction)doneAction:(id)sender ;
- (IBAction)registerNewUserAction:(id)sender;

@end
