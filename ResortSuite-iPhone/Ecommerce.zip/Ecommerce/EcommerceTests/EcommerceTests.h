//
//  EcommerceTests.h
//  EcommerceTests
//
//  Created by sandeep on 07/03/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import "Product.h"
#import "FavoriteProduct.h"
#import "ProductSearchViewController.h"
#import "ProductSearchReqResHandler.h"
#import "CartReqResHandler.h"

@interface EcommerceTests : SenTestCase
{
    Product                     *_product;
    ProductSearch               *_productSearch;
    NSArray                     *_productArray;
    ProductSearchViewController *productSearchVC;
    FavoriteProduct             *_favoriteProduct;
}

@property(nonatomic, strong) ProductSearch   *productSearch;
@property(nonatomic, strong) FavoriteProduct *favoriteProduct;
@property(nonatomic, strong) NSArray *productArray;

@end
