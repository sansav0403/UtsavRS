//
//  EcommerceTests.m
//  EcommerceTests
//
//  Created by sandeep on 07/03/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "EcommerceTests.h"
#import "ProductSearchXMLParser.h"
#import "ProductPriceInfoXMLParser.h"
#import "ProductSearch.h"
#import "FavoriteProduct.h"
#import "FavoriteInfoXMLParser.h"
#import "AvailabilityXMLParser.h"

@implementation EcommerceTests
@synthesize productSearch = _productSearch;
@synthesize productArray =_productArray;
@synthesize favoriteProduct = _favoriteProduct;

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
    productSearchVC = [[ProductSearchViewController alloc] init];
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

/*- (void)testAddition
{
    float expectedResult = 5.5;
    float actualResult = [productSearchVC addTwoNumbers:5 second:0.5];
    //STAssertEquals(expectedResult, actualResult, @"Expected Result is different from Actual Result", nil);
    STAssertEquals(expectedResult, actualResult, @"Fail", @"True");
}*/

/*!
 @function		testParseXMLForProductSearch
 @abstract		This function requests for product search data tobe parsed.
 @discussion	This function requests for product search data tobe parsed.
 @result		void
 */
/*- (void)testParseXMLForProductSearch
{
    // Obtain file from resource bundle
    NSString *XMLPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"SearchProductList.xml"];
    NSData *XMLData   = [NSData dataWithContentsOfFile:XMLPath];
    
    //get the product list from the server
	if(self.productArray)
	{
        self.productArray = nil;
	}
    _productArray = [[NSMutableArray alloc] init];
    
    ProductSearchXMLParser *productSearchXMLParser = [[ProductSearchXMLParser alloc]init];
    [productSearchXMLParser parseXMLDataForProductSearch:XMLData productSearchList:_productArray];
    
    TRC_DBG(@"product count =%d",[_productArray count]);
    
    NSInteger actualResult = 10;
    NSInteger expectedResult = [_productArray count];
    
    STAssertEquals(expectedResult, actualResult, @"Fail", nil);
}
*/
/*!
 @function		testParseXMLForProductDetails
 @abstract		This function requests for product details data tobe parsed.
 @discussion	This function requests for product details data tobe parsed.
 @result		void
 */
/*- (void)testParseXMLForProductDetails
{
    // Obtain file from resource bundle
    NSString *XMLPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"ProductDetails.xml"];
    NSData *XMLData   = [NSData dataWithContentsOfFile:XMLPath];
    
    //get the product list from the server   
    _productSearch = [[ProductSearch alloc]init];
    
    ProductSearchXMLParser *productSearchXMLParser = [[ProductSearchXMLParser alloc]init];
    [productSearchXMLParser parseXMLDataForProductDetails:XMLData productId:@"2" productSearch:_productSearch];
    TRC_DBG(@"product Id =%@", _productSearch.productId);
    
    NSInteger  actualResultId = 2;
    NSInteger  expectedResultId = [_productSearch.productId integerValue];
    
    //STFail(@"Unit tests are not implemented yet in EcommerceTests");
    STAssertEquals(expectedResultId, actualResultId, @"Fail", nil);
}
*/

/*!
 @function		testParseXMLForProductPriceInfoList
 @abstract		This function requests for product price and offers data to be parsed.
 @discussion	This function requests for product price and offers data to be parsed.
 @result		void
 */
/*- (void)testParseXMLForProductPriceInfoList
{
    // Obtain file from resource bundle
    NSString *XMLPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"ProductPriceInfoList.xml"];
    NSData *XMLData   = [NSData dataWithContentsOfFile:XMLPath];
    
    //get the product list from the server
	if(self.productArray)
	{
        self.productArray = nil;
	}
    _productArray = [[NSMutableArray alloc] init];
    
    ProductPriceInfoXMLParser *productPriceInfoXMLParser = [[ProductPriceInfoXMLParser alloc]init];
    [productPriceInfoXMLParser parseXMLDataForProductPriceInfo:XMLData productPriceInfoList:_productArray];
    
    TRC_DBG(@"product count =%d",[_productArray count]);
    
    NSInteger actualResult = 10;
    NSInteger expectedResult = [_productArray count];
    
    STAssertEquals(expectedResult, actualResult, @"Fail", nil);
}*/

/*!
 @function		testParseXMLForProductPriceInfoList
 @abstract		This function requests for product price and offers data to be parsed.
 @discussion	This function requests for product price and offers data to be parsed.
 @result		void
 */
/*- (void)testParseXMLForFavoriteProductInfoList
{
    // Obtain file from resource bundle
    NSString *XMLPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"FavoriteProductDetails.xml"];
    NSData *XMLData   = [NSData dataWithContentsOfFile:XMLPath];
    
    //get the product list from the server
	if(self.productArray)
	{
        self.productArray = nil;
	}
    _productArray = [[NSMutableArray alloc] init];
    
    FavoriteInfoXMLParser *favoriteProductInfoXMLParser = [[FavoriteInfoXMLParser alloc]init];
    [favoriteProductInfoXMLParser parseXMLDataForFavoriteProductInfo:XMLData favoriteInfoList:_productArray];
    
    TRC_DBG(@"product count =%d",[_productArray count]);
    
    NSInteger actualResult = 5;
    NSInteger expectedResult = [_productArray count];
    
    STAssertEquals(expectedResult, actualResult, @"Fail", nil);
}*/

/*!
 @function		testParseXMLForProductPriceInfoList
 @abstract		This function requests for product price and offers data to be parsed.
 @discussion	This function requests for product price and offers data to be parsed.
 @result		void
 */
- (void)testParseXMLForAvailabilityList
 {
    // Obtain file from resource bundle
    NSString *XMLPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"AvailabilityList.xml"];
    NSData *XMLData   = [NSData dataWithContentsOfFile:XMLPath];

    //get the product list from the server
    if(self.productArray)
    {
        self.productArray = nil;
    }
    _productArray = [[NSMutableArray alloc] init];

    AvailabilityXMLParser *availabilityXMLParser = [[AvailabilityXMLParser alloc]init];
    [availabilityXMLParser parseXMLDataForAvailabilitySearch:XMLData productSearchList:_productArray];

    TRC_DBG(@"product count =%d",[_productArray count]);

    NSInteger actualResult = 10;
    NSInteger expectedResult = [_productArray count];

    STAssertEquals(expectedResult, actualResult, @"Fail", nil);
 }
 
/*!
 @function		testParseXMLForProductPriceInfoList
 @abstract		This function requests for product price and offers data to be parsed.
 @discussion	This function requests for product price and offers data to be parsed.
 @result		void
 */
- (void)testParseXMLForCartList
{
    // Obtain file from resource bundle
    NSString *XMLPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"CartList.xml"];
    NSData *XMLData   = [NSData dataWithContentsOfFile:XMLPath];
    
    //get the product list from the server
    if(self.productArray)
    {
        self.productArray = nil;
    }
    _productArray = [[NSMutableArray alloc] init];
    
    CartListXMLParser *cartListXMLParser = [[CartListXMLParser alloc]init];
    [cartXMLParser parseXMLDataForCartList:(NSData *)data cartProductList:_productArray];
    
    TRC_DBG(@"product count =%d",[_productArray count]);
    
    NSInteger actualResult = 7;
    NSInteger expectedResult = [_productArray count];
    
    STAssertEquals(expectedResult, actualResult, @"Fail", nil);
}


@end
