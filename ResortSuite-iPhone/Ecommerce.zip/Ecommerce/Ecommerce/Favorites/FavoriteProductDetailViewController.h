/* 
 File: FavoriteProductDetailViewController.h
 Abstract: This class is responsible for displaying favorite product details.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "FavoriteProductReqResHandler.h"
#import "FavoriteProduct.h"

@interface FavoriteProductDetailViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,NetworkRequestResponseBaseDelegate>
{
    FavoriteProduct                 *_favoriteProductDetail;
    FavoriteProductReqResHandler    *_favoriteProductReqHandler;
}

@property(nonatomic, weak) NSString               *favoriteProductId;
@property(nonatomic, weak) IBOutlet UITableView   *favoriteProductDetailTable;

@end
