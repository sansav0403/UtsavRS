/* 
 File: FavoriteListCustomCell.h
 Abstract: This interface class is responsible for maintaining favorite product information.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "FavoriteProduct.h"

@interface FavoriteListCustomCell : UITableViewCell<ProductImageDataDelegate>

- (void)setFavoriteListData:(FavoriteProduct*) favoriteProductList;

@property (nonatomic, weak) IBOutlet UIImageView  *favoriteProductImageView;
@property (nonatomic, weak) IBOutlet UILabel      *favoriteProductDescription;
@property (nonatomic, weak) IBOutlet UILabel      *favoriteProductName;
@property (nonatomic, strong) FavoriteProduct       *favoriteProductModel;

@end
