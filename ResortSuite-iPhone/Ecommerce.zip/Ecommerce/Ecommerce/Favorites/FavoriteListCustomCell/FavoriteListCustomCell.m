/* 
 File: FavoriteListCustomCell.h
 Abstract: This implementation class is responsible for maintaining favorite product information.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import "FavoriteListCustomCell.h"

@implementation FavoriteListCustomCell

@synthesize favoriteProductName;
@synthesize favoriteProductImageView;
@synthesize favoriteProductDescription;
@synthesize favoriteProductModel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setFavoriteListData
 @abstract      set product image into image view.
 @discussion    set product image into image view.
 @param         FavoriteProduct - Favorite Product Model Class
 @result        void
 */
- (void)setFavoriteListData:(FavoriteProduct*) favoriteProductList
{
    self.favoriteProductModel = favoriteProductList;
    
    [self.favoriteProductImageView setImage:nil];
    
    //image 
    if(self.favoriteProductModel.image)
    {
        [self.favoriteProductImageView setImage:self.favoriteProductModel.image];
    }

}

#pragma mark - Product image data DELEGETE
/*!
 @function      didReceivedData
 @abstract      set product image to cell.
 @discussion    set product image to cell.
 @param         Product - product of which details need to set to cell.
 @result        void
 */
- (void)didReceivedData:(id)imgData urlString:(NSString *)urlString
{
    TRC_DBG(@"%@", urlString );
    if([urlString isEqualToString:self.favoriteProductModel.imageUrl])
    {
        [self.favoriteProductImageView setImage:imgData];
    }
    TRC_DBG(@"Image Url %@", self.favoriteProductModel.imageUrl);
}

@end
