/* 
 File: FavoriteViewController.h
 Abstract: This class is responsible for product price and offers related parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "FavoriteProduct.h"
#import "FavoriteProductReqResHandler.h"

@interface FavoriteViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,NetworkRequestResponseBaseDelegate>
{
    FavoriteProductReqResHandler  *_favoriteProductReqResHandler;
}

@property(nonatomic, strong) IBOutlet UITableView   *favoriteProductTbl;
@property(nonatomic, strong) FavoriteProduct         *favoriteProduct;
@property(nonatomic, strong) NSMutableArray          *productArray;

- (void)favoriteProductList;
- (void)parseComplete:(NSError*)error;

@end
