/* 
 File: ProductSearch.m
 Abstract: This interface class is maintains favorite product details information.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import "FavoriteProduct.h"

@implementation FavoriteProduct

@synthesize productNumber = _productNumber;;
@synthesize modelNumber = _modelNumber;
@synthesize manufacturingDate = _manufacturingDate;
@synthesize expiryDate = _expiryDate;

@end
