/* 
 File: ProductSearch.h
 Abstract: This interface class is maintains favorite product details information.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "Product.h"

@interface FavoriteProduct : Product

@property(nonatomic, strong) NSString    *productNumber;
@property(nonatomic, strong) NSString    *modelNumber;
@property(nonatomic, strong) NSString    *manufacturingDate;
@property(nonatomic, strong) NSString    *expiryDate; 

@end
