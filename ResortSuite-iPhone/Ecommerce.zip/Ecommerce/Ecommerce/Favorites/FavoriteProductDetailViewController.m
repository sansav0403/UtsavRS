/* 
 File: FavoriteProductDetailViewController.h
 Abstract: This class is responsible for displaying favorite product details.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
 */

#import "FavoriteProductDetailViewController.h"
#import "ProductDetailCell.h"
#import "ProductDetailImageCell.h"
#import "ProductDetailDescriptionCell.h"
#import "FavoriteCommon.h"


// Need to move Favorite Common class
#define kTableViewSections 1
#define kTableViewRows     7
#define kFirstRowHeight    150.0
#define kFifthRowHeight    100.0
#define kNormalRowHeight   44.0 
#define k0Title            0 
#define k5Title            5 

@implementation FavoriteProductDetailViewController

@synthesize favoriteProductId;
@synthesize favoriteProductDetailTable;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setTitle:kProductDetailsTitle];
    
    if (_favoriteProductDetail) {
        _favoriteProductDetail = nil;
    }
    _favoriteProductDetail = [[FavoriteProduct alloc] init];
    _favoriteProductReqHandler = [[FavoriteProductReqResHandler alloc]init];
    
    //get the product details from the server
    [_favoriteProductReqHandler setDelegate:self];
    [_favoriteProductReqHandler favoriteProductDetailsDataForProductId:self.favoriteProductId favoriteProduct:_favoriteProductDetail];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_favoriteProductReqHandler setDelegate:nil];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return kTableViewSections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return kTableViewRows;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return kFirstRowHeight;     // Image Height
    } else if (indexPath.row == k5Title) {
        return kFifthRowHeight;     // Description
    } else {
        return kNormalRowHeight;
    }    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *imageIdentifier = kProductImageCell;
    static NSString *detailsIdentifier = kProductDetailCell;
    static NSString *detailDescriptionIdentifier = kProductDetailDescriptionCell;
    
    ProductDetailCell *cell = (ProductDetailCell*)[tableView dequeueReusableCellWithIdentifier:detailsIdentifier];
    if (cell == nil) {
        cell = [[ProductDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailsIdentifier];
    }
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    
    // Configure the cell...
    NSString *labelKey = nil;
    NSString *labelValue = nil;
    
    switch (indexPath.row)
    {
        case 0://Image Cell
        {
            ProductDetailImageCell *cell = (ProductDetailImageCell*)[tableView dequeueReusableCellWithIdentifier:imageIdentifier];
            if (cell == nil) {
                cell = [[ProductDetailImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:imageIdentifier];
            }
            if (!_favoriteProductDetail.image) {
                [_favoriteProductDetail setDelegate:cell];
                [_favoriteProductDetail startDownload];
            }
            [cell setProductImage:_favoriteProductDetail];
            return cell;
        }
            break;
        case 1:
        {
            labelKey = kProductNumber;
            labelValue = _favoriteProductDetail.productNumber;
            break;
        }
            
        case 2:
        {
            labelKey = kModelNumber;
            labelValue = _favoriteProductDetail.modelNumber;
            break;
        }

        case 3:
        {
            labelKey = kManufacturingDate;
            labelValue = _favoriteProductDetail.manufacturingDate;
            break;
        }

        case 4:
        {
            labelKey = kExpiryDate;
            labelValue = _favoriteProductDetail.expiryDate;
            break;
        }
            
        case 5://Description Cell
        {
            ProductDetailDescriptionCell *cell = (ProductDetailDescriptionCell*)[tableView dequeueReusableCellWithIdentifier:detailDescriptionIdentifier];
            if (cell == nil) {
                cell = [[ProductDetailDescriptionCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailDescriptionIdentifier];
            }
            //set product's description data
            labelKey = kDescription;
            labelValue = _favoriteProductDetail.description;
            [cell setProductData:labelKey labelValue:labelValue];
            return cell;
        }
            break;
            
        default:
            break;
    }
    [cell setProductData:labelKey labelValue:labelValue];
    return cell;
}

#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) {
        TRC_DBG(@"fail to load data from URL");
    }
    else{
        TRC_DBG(@"Pass to load data from URL");
        TRC_DBG(@"ProductSearch =%@",_favoriteProductDetail);
        [self.favoriteProductDetailTable reloadData];
    }        
}

@end
