/* 
 File: FavoriteInfoXMLParser.h
 Abstract: This class is responsible for product price and offers related parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "FavoriteProduct.h"


@interface FavoriteInfoXMLParser : NSObject

@property(nonatomic, strong)  FavoriteProduct    *favoriteProductInfo;
@property(nonatomic, strong)  NSMutableArray     *favoriteInfoList;

- (void)parseXMLDataForFavoriteProductListInfo:(NSData *)dataToBeParsed favoriteInfoList:(NSMutableArray*) favoriteProductInfoList;
- (void)parseXMLDataForFavoriteProductDetails:(NSData *)dataToBeParsed productId:(NSString *)productId FavoriteProduct:(FavoriteProduct *)favoriteProduct;

@end
