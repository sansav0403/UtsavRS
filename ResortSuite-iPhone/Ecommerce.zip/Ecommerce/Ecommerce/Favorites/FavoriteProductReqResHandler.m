/* 
 File: FavoriteProductReqResHandler.m
 Abstract: This implementation class is responsible for handling favorite product request.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import "FavoriteProductReqResHandler.h"
#import "FavoriteInfoXMLParser.h"
#import "FavoriteCommon.h"

@implementation FavoriteProductReqResHandler

@synthesize productArr = _productArr;
@synthesize productId = _productId;
@synthesize favoriteProduct = _favoriteProduct;
@synthesize requestState = _requestState;

/*!
 @function		favoriteProductDataList
 @abstract		get product list information.
 @discussion    parse product list.
 @param			productSearchDataList - result will be return in this array 
 */
- (void)favoriteProductDataList:(NSMutableArray*)productDataList
{
    self.productArr = productDataList;
    self.requestState = kFavoriteProductSearchListRquest;
    
    NSString *qString = [NSString stringWithFormat:@"%@/%@",kServerUrl,kFavoriteProductListAPI]; 
    TRC_DBG(@"qString = %@",qString);
	NSURL* url = [NSURL URLWithString:qString];  
    
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
    [theRequest setHTTPMethod:kGet];			
    
    //Black box method
    [self.netDataManager makeRequest:theRequest];
}

/*!
 @function		favoriteProductDetailsDataForProductId
 @abstract		request product details to server.
 @discussion    request product details to server.
 @param			productId - productId of requested product details
 productSearch - result will be return in this productsearch object 
 */
- (void)favoriteProductDetailsDataForProductId:(NSString *)productId favoriteProduct:(FavoriteProduct *)favoriteProduct
{
    self.productId = productId;
    self.favoriteProduct = favoriteProduct;
    self.requestState = kFavoriteProductDetailsRequest;
    
    TRC_DBG(@"productId = %@",productId);
    TRC_DBG(@"self.productId = %@",self.productId);
    
    NSString *qString = [NSString stringWithFormat:@"%@/%@",kServerUrl,kFavoriteProductDetailsAPI]; 
    TRC_DBG(@"qString = %@",qString);
	NSURL* url = [NSURL URLWithString:qString];  
    
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
    [theRequest setHTTPMethod:kGet];			
    
    [self.netDataManager makeRequest:theRequest];

}

/*!
 @function		didReceiveData
 @abstract		response data of network call.
 @discussion	response data of network call.
 @param			data - response data
 @result		void
 */
- (void)didReceiveData:(NSData*)data
{
    TRC_DBG(@"Data received");
    FavoriteInfoXMLParser *favoriteProductXMLParser = [[FavoriteInfoXMLParser alloc]init];
    
    switch (self.requestState) {
        case kFavoriteProductSearchListRquest:
        {
            [favoriteProductXMLParser parseXMLDataForFavoriteProductListInfo:data favoriteInfoList:_productArr];
            TRC_DBG(@"prodcuSearch count=%d",[self.productArr count]);
        }
            break;
            
        case kFavoriteProductDetailsRequest:
        {
            [favoriteProductXMLParser parseXMLDataForFavoriteProductDetails:data productId:self.productId FavoriteProduct:self.favoriteProduct];
            TRC_DBG(@"prodcuSearchData = %@",self.productId);
        }
            break;
            
        default:
            break;
    }
    
    //Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:nil];
	}
}

@end
