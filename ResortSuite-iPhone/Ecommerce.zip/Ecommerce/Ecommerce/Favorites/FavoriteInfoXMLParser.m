/* 
 File: FavoriteInfoXMLParser.m
 Abstract: This class is responsible for product price and offers related parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import "FavoriteInfoXMLParser.h"
#import "CXMLDocument.h"
#import "CXMLElement.h"
#import "FavoriteCommon.h"
#import "Common.h"

@implementation FavoriteInfoXMLParser

@synthesize favoriteProductInfo = _favoriteProductInfo;
@synthesize favoriteInfoList = _favoriteInfoList;

/*!
 @function      parseXMLDataForFavoriteProductListInfo
 @abstract      parse favorite product list data.
 @discussion    Parse supplied XML NSDATA and fill all favorite product node details into NSMutableArray.
 @param         NSData - XML Data that need to parse.
                NSMutableArray - Array to fill with Favorite Product Modal objects.
 @result        void
 */
- (void)parseXMLDataForFavoriteProductListInfo:(NSData *)dataToBeParsed favoriteInfoList:(NSMutableArray*) favoriteProductInfoList
{
    self.favoriteInfoList = favoriteProductInfoList;
    
    NSMutableArray *dictionaryArray = [[NSMutableArray alloc] init];
    
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kFavoriteProductXMLTag; 
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    for (CXMLElement *node in nodes) {
        
        NSArray *arAttr=[node attributes];
        NSString *strValue = nil;
        NSString *strName = nil;
        
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        
        // read attribute value
        for (NSInteger i = 0; i < [arAttr count]; i++) {
            strValue = [[arAttr objectAtIndex:i] stringValue];
            strName = [[arAttr objectAtIndex:i] name];
            if(strValue && strName){
                [item setValue:strValue forKey:strName];
            }
        }

        for(int counter = 0; counter < [node childCount]; counter++) {
             CXMLNode *childNode = [node childAtIndex:counter];
            //  common procedure: dictionary with keys/values from XML node
            [item setObject:[childNode stringValue] forKey:[childNode name]];
            
            NSString *value = [[childNode stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            if ([value length] != 0){
                [item setObject:[childNode stringValue] forKey:[childNode localName]];
            }
        } 
        
        [dictionaryArray addObject:item];
    }
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        FavoriteProduct *favoriteProductInfo = [[FavoriteProduct alloc] init];
        
        favoriteProductInfo.productId = [item valueForKey:kIdXMLTag];
        favoriteProductInfo.name = [item valueForKey:kNameXMLTag];
        favoriteProductInfo.description = [item valueForKey:kDescriptionXMLTag];
        favoriteProductInfo.modelNumber = [item valueForKey:kModelNumberXMLTag];
        favoriteProductInfo.manufacturingDate = [item valueForKey:kMfgDateXMLTag];
        favoriteProductInfo.expiryDate = [item valueForKey:kExpDateXMLTag];
        favoriteProductInfo.imageUrl = [item valueForKey:kImageUrlXMLTag];
        
        TRC_DBG(@"favoriteProductInfo.productId =%@",favoriteProductInfo.productId);        
        TRC_DBG(@"favoriteProductInfo.name =%@",favoriteProductInfo.name);        
        TRC_DBG(@"favoriteProductInfo.name =%@",favoriteProductInfo.description);        
        TRC_DBG(@"favoriteProductInfo.description =%@",favoriteProductInfo.modelNumber);        
        TRC_DBG(@"favoriteProductInfo.manufacturingDate =%@",favoriteProductInfo.manufacturingDate);        
        TRC_DBG(@"manufacturingDate.expiryDate =%@", favoriteProductInfo.expiryDate);
        TRC_DBG(@"productSearch.ThumbImgUrl =%@",favoriteProductInfo.imageUrl);
        
        [_favoriteInfoList addObject:favoriteProductInfo];
    }
    
    //  and we print our results    
    TRC_DBG(@"Array :::: %@", _favoriteInfoList);
    TRC_DBG(@"Array count:::: %d", [_favoriteInfoList count]);
    return;
}

/*!
 @function      parseXMLDataForFavoriteProductDetails
 @abstract      parse favorite product details data.
 @discussion    Parse supplied XML NSDATA and fill into favorite product Favorite Product Modal object.
 @param         NSData - XML Data that need to parse.
                NSMutableArray - Favorite Product Object to fill with Favorite Product Modal.
 @result        void
 */
- (void)parseXMLDataForFavoriteProductDetails:(NSData *)dataToBeParsed productId:(NSString *)productId FavoriteProduct:(FavoriteProduct *)favoriteProduct
{
    self.favoriteProductInfo = favoriteProduct;
    TRC_DBG(@"pID =%@",productId);
    NSMutableArray *dictionaryArray = [[NSMutableArray alloc] init];
    
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kFavoriteProductXMLTag; 
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    for (CXMLElement *node in nodes) {
        
        NSArray *arAttr=[node attributes];
        NSString *strValue = nil;
        NSString *strName = nil;
        
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        
        // read attribute value
        for (NSInteger i = 0; i < [arAttr count]; i++) {
            strValue=[[arAttr objectAtIndex:i] stringValue];
            strName=[[arAttr objectAtIndex:i] name];
            if(strValue && strName){
                [item setValue:strValue forKey:strName];
            }
        }
        
        for(int counter = 0; counter < [node childCount]; counter++) {
            
            CXMLNode *childNode = [node childAtIndex:counter];
            // process to read element attributes 
            if([childNode isMemberOfClass:[CXMLElement class]]){
                CXMLElement *childNode2=(CXMLElement*)childNode;
                NSArray *arAttr=[childNode2 attributes];
                for (int i=0; i<[arAttr count]; i++) {
                    strName=[[arAttr objectAtIndex:i] name];
                    strValue=[[arAttr objectAtIndex:i] stringValue];
                    if(strName && strValue){
                        [item setValue:strValue forKey:strName];
                    }
                }
            }
           
            //  common procedure: dictionary with keys/values from XML node
            [item setObject:[childNode stringValue] forKey:[childNode name]];
            
            NSString * value = [[childNode stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            if ([value length] != 0){
                [item setObject:[childNode stringValue] forKey:[childNode localName]];
            }
        } 
        
        [dictionaryArray addObject:item];
    }
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        self.favoriteProductInfo.productId = [item valueForKey:kIdXMLTag];
        self.favoriteProductInfo.name = [item valueForKey:kCartProductNameXMLTag];
        self.favoriteProductInfo.productNumber = [item valueForKey:kCartProductNumberXMLTag];
        self.favoriteProductInfo.modelNumber = [item valueForKey:kCartProductModelNumberXMLTag];
        self.favoriteProductInfo.manufacturingDate = [item valueForKey:kCartProductMfgDateXMLTag];
        self.favoriteProductInfo.expiryDate = [item valueForKey:kCartProductExpDateXMLTag];
        self.favoriteProductInfo.description = [item valueForKey:kCartProductDescXMLTag];
        self.favoriteProductInfo.imageUrl = [item valueForKey:kCartProductImageURLXMLTag];
        
        TRC_DBG(@"favoriteProductInfo.productId =%@",self.favoriteProductInfo.productId);       
        TRC_DBG(@"favoriteProductInfo.name = %@",self.favoriteProductInfo.name);
        TRC_DBG(@"favoriteProductInfo.productNumber =%@",self.favoriteProductInfo.productNumber);
        TRC_DBG(@"favoriteProductInfo.modelNumber =%@",self.favoriteProductInfo.modelNumber);
        TRC_DBG(@"favoriteProductInfo.manufacturingDate =%@",self.favoriteProductInfo.manufacturingDate);
        TRC_DBG(@"favoriteProductInfo.expiryDate =%@",self.favoriteProductInfo.expiryDate);        
        TRC_DBG(@"favoriteProductInfo.description =%@",self.favoriteProductInfo.description);        
        TRC_DBG(@"favoriteProductInfo.imageUrl =%@",self.favoriteProductInfo.imageUrl);
    }   
}

@end
