/* 
 File: FavoriteViewController.m
 Abstract: This class is responsible for product price and offers related parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
 */

#import "FavoriteViewController.h"
#import "FavoriteListCustomCell.h"
#import "FavoriteProductDetailViewController.h"
#import "FavoriteCommon.h"

  

@implementation FavoriteViewController

@synthesize favoriteProductTbl = _favoriteProductTbl;
@synthesize favoriteProduct = _favoriteProduct;
@synthesize productArray = _productArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
    self.title = kFavoriteTitle;
    self.productArray = nil;
    [self.favoriteProductTbl reloadData];
    [self favoriteProductList];
    
    TRC_DBG(@"Total Number of products are %d", [self.productArray count]);
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table view datasource and delegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	return kONE;
}

- (float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kTABLEVIEWROWHEIGHT;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section 
{	
    return [self.productArray count]; 
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
    static NSString *CellIdentifier = kFavoriteCustomCell;
    FavoriteListCustomCell *cell = (FavoriteListCustomCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell = (FavoriteListCustomCell *)[nib objectAtIndex:0];
    }    
    cell.favoriteProductName.text = [[self.productArray objectAtIndex:indexPath.row] name];
    TRC_DBG(@"Product Name %@", cell.favoriteProductName.text);
    cell.favoriteProductDescription.text = [[self.productArray objectAtIndex:indexPath.row] description];
       
    TRC_DBG(@"Product Description %@", [[self.productArray objectAtIndex:indexPath.row] description]);
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    self.favoriteProduct = [self.productArray objectAtIndex:indexPath.row];
    [self.favoriteProduct setDelegate:cell];
    [cell setFavoriteListData:self.favoriteProduct];
    
    if(!self.favoriteProduct.image)
    {
        [self.favoriteProduct startDownload];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    /*
	 To conform to the Human Interface Guidelines, selections should not be persistent --
	 deselect the row after it has been selected.
	 */
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //extract the selected product for details
    FavoriteProduct *favoriteProduct = [self.productArray objectAtIndex:indexPath.row];
    FavoriteProductDetailViewController *favoriteProductDetail = [[FavoriteProductDetailViewController alloc] initWithNibName:kFavorioteViewController bundle:[NSBundle mainBundle]];
    favoriteProductDetail.favoriteProductId = favoriteProduct.productId;
    
    [self.navigationController pushViewController:favoriteProductDetail animated:YES];
    favoriteProductDetail = nil;
}

#pragma Public Methods

/*
 @function      favoriteProductList
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)favoriteProductList
{
    if (_favoriteProductReqResHandler){
        [_favoriteProductReqResHandler setDelegate:nil];
    }
    _favoriteProductReqResHandler = [[FavoriteProductReqResHandler alloc]init];
    //get the product list from the server
	if(self.productArray)
	{
        self.productArray = nil;
	}
    self.productArray = [[NSMutableArray alloc] init];	
    [_favoriteProductReqResHandler setDelegate:self];
    [_favoriteProductReqResHandler favoriteProductDataList:self.productArray];
}

#pragma mark - Parse delegate 

/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) 
    {
        TRC_DBG(@"fail to load data from URL");
    }
    else
    {
        TRC_DBG(@"Pass to load data from URL");
        TRC_DBG(@"ProSearchArray count in VC =%d",[self.productArray count]);
        [self.favoriteProductTbl reloadData];
    } 
}

@end
