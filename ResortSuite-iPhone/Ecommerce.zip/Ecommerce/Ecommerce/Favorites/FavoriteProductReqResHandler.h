/* 
 File: FavoriteProductReqResHandler.h
 Abstract: This Interface class is responsible for handling favorite product requests.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
*/

#import <Foundation/Foundation.h>
#import "NetworkRequestResponseBase.h"
#import "FavoriteProduct.h"

typedef enum {
    kFavoriteProductSearchListRquest,
    kFavoriteProductDetailsRequest
}FavoriteProductSearchHandlerRequestState;
@interface FavoriteProductReqResHandler : NetworkRequestResponseBase


@property(nonatomic, strong) NSMutableArray                         *productArr;
@property(nonatomic, strong) NSString                               *productId;
@property(nonatomic, strong) FavoriteProduct                        *favoriteProduct;
@property(nonatomic)   FavoriteProductSearchHandlerRequestState      requestState;

- (void)favoriteProductDataList:(NSArray*)productSearchDataList;
- (void)favoriteProductDetailsDataForProductId:(NSString *)productId favoriteProduct:(FavoriteProduct *)favoriteProduct;
- (void)didReceiveData:(NSData*)data;

@end
