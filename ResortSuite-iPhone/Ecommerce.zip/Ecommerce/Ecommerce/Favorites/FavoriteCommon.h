/* 
 File: FavoriteCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for Favorite module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */


#define kFavoriteTitle          NSLocalizedString(@"Favorite", @"")
#define kFavorioteViewController @"FavoriteProductDetailViewController"
#define kFavoriteCustomCell     @"FavoriteListCustomCell"

#define kFavoriteProductXMLTag        @"FavoriteProduct"
#define kIdXMLTag             @"id"
#define kNameXMLTag           @"Name"
#define kDescriptionXMLTag    @"Description"
#define kThumbImgUrlXMLTag    @"ThumbImgUrl"
#define kPriceXMLTag          @"Price"
#define kActualPriceXMLTag    @"ActualPrice"
#define kOfferPriceXMLTag     @"OfferPrice"
#define kOfferXMLTag          @"Offer"
#define kQuantityXMLTag       @"Quantity"
#define kCurrencyXMLTag       @"currency"


#define kCartProductXMLTag              @"Product";
#define kCartProductIdXMLTag            @"id"
#define kCartProductNameXMLTag          @"Name"
#define kCartProductQuantityXMLTag      @"Quantity"
#define kShippingXMLTag                 @"Shipping"
#define kWarrantyXMLTag                 @"Warranty"
#define kCartProductPriceXMLTag         @"Price"
#define kCartProductImageURLXMLTag      @"ImageUrl"
#define kCartListCurrencyXMLTag         @"currency"
//Cart Detail

#define kCartProductNumberXMLTag        @"Number"
#define kCartProductModelNumberXMLTag   @"ModelNumber"
#define kCartProductMfgDateXMLTag       @"MfgDate"
#define kCartProductExpDateXMLTag       @"ExpDate"
#define kCartProductDescXMLTag          @"Description"
#define kCartProductImageURLXMLTag      @"ImageUrl"

#define kNumberXMLTag       @"Number"
#define kModelNumberXMLTag  @"ModelNumber"
#define kMfgDateXMLTag      @"MfgDate"
#define kExpDateXMLTag      @"ExpDate"
#define kImageUrlXMLTag     @"ImageUrl"

//Favorite ViewController
#define kTABLEVIEWROWHEIGHT  85.0
#define kONE 1

//req Res Handler
#define kFavoriteProductListAPI         @"FavoriteProductList.xml"
#define kFavoriteProductDetailsAPI      @"FavoriteProductDetails.xml"
#define kServerUrl                      @"http://172.27.47.116"
#define kGet                            @"GET"

//Fav Product detail View controller
#define kProductDetailsTitle        NSLocalizedString(@"Product_Details", @"")
#define kManufacturingDate          NSLocalizedString(@"Manufacturing_Date", @"")
#define kProductNumber              NSLocalizedString(@"Product_Number", @"")
#define kModelNumber                NSLocalizedString(@"Model_Number", @"")
#define kManufacturingDate          NSLocalizedString(@"Manufacturing_Date", @"")
#define kExpiryDate                 NSLocalizedString(@"Expiry_Date", @"")
#define kDescription                NSLocalizedString(@"Description", @"")
#define kProductImageCell               @"ProductImageCell"
#define kProductDetailCell              @"ProductDetailCell"
#define kProductDetailDescriptionCell   @"ProductDetailDesrciptionCell"