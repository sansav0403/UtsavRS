//
//  LoginXmlParser.m
//  Ecommerce
//
//  Created by sandeep on 03/05/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "LoginXmlParser.h"
#import "CXMLDocument.h"
#import "CXMLElement.h"
#import "LoginCommon.h"
#import "UserExtended.h"

@implementation LoginXmlParser


@synthesize productList = _productList;
@synthesize sessionId = _sessionId;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

/*!
 @function		parseXMLDataForLogin
 @abstract		This function parse xml data for product list.
 @discussion	This function parse xml data for product list.
 @param			dataToBeParsed - NSData to be parsed.
 @param			productSearchList - return array of product objects.
 @result		void
 */
- (void)parseXMLDataForLogin:(NSData *)dataToBeParsed
{    
    NSMutableArray *dictionaryArray = [[NSMutableArray alloc] init];
    
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kLoginReturnTag; 
    //NSString *tagName = @"SOAP-ENV:Body";
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    for (CXMLElement *node in nodes) {
        
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        
        [item setObject:[node stringValue] forKey:[node name]];
                [dictionaryArray addObject:item];
    }
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        TRC_DBG(@"se = %@",[item valueForKey:kLoginReturnTag]);
        UserExtended *userExtended = [UserExtended sharedUserExteded];
        userExtended.sessionId = [item valueForKey:kLoginReturnTag];
        TRC_DBG(@"userExtended.sessionId = %@",userExtended.sessionId);
    }
}
@end
