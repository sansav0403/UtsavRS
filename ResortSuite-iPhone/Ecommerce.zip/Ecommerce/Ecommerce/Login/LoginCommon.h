/* 
 File: LoginCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for Login module.
 Author: Cybage Software Pvt. Ltd
 Created: 18/04/12
 Modified: 18/04/12
 Version: 1.0 
*/

#ifndef Ecommerce_LoginCommon_h
#define Ecommerce_LoginCommon_h

#endif


#define kLogin                      NSLocalizedString(@"Login", @"")
#define kUserName                   NSLocalizedString(@"User_Name", @"")
#define kApiKey                     NSLocalizedString(@"Api_Key", @"")
#define kRememberPasswordLblText    NSLocalizedString(@"Remember_Password", @"")

#define kLoginReturnTag             @"loginReturn"
 
