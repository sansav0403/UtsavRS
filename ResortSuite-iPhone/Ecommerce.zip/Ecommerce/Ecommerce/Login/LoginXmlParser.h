//
//  LoginXmlParser.h
//  Ecommerce
//
//  Created by sandeep on 03/05/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LoginXmlParser : NSObject

@property(nonatomic, strong) NSString   *sessionId;
@property(nonatomic, strong) NSArray    *productList;

- (void)parseXMLDataForLogin:(NSData *)dataToBeParsed;

@end
