//
//  UserExtended.h
//  Canis
//
//  Created by Yifeng on 10/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "User.h"

typedef enum
{
	Undefined,
	Buy,
	Sell,
    SellingHistory,
}UserAction;

/*!
 @class         UserExtended
 @abstract		This class is inherited from super class User 
 @discussion	Object of this class would contain user details.
 */
@interface UserExtended : User {
    
    UserAction  _action;
}

@property (nonatomic, strong) NSString        *firstName;
@property (nonatomic, strong) NSString        *lastName;
@property (nonatomic, strong) NSString        *country;
@property (nonatomic, strong) NSString        *street;
@property (nonatomic, strong) NSString        *city;
@property (nonatomic, strong) NSString        *state;
@property (nonatomic, strong) NSString        *phoneNo;
@property (nonatomic, strong) NSString        *zipcode;
@property (nonatomic, strong) NSString        *password2;
@property (nonatomic, strong) NSString        *userType;
@property (nonatomic, strong) NSString        *sessionId;
@property (nonatomic, strong) NSString        *cartId;
@property (nonatomic, assign) UserAction    action;

+ (id)sharedUserExteded;

- (void)clear;

@end