//
//  UserExtended.m
//  Canis
//
//  Created by Yifeng on 10/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "UserExtended.h"

static UserExtended* userExtendedManager = nil;

@implementation UserExtended

@synthesize firstName = _firstName;
@synthesize lastName = _lastName;
@synthesize country =_country;
@synthesize street = _street;
@synthesize city = _city;
@synthesize state = _state;
@synthesize phoneNo = _phoneNo; 
@synthesize zipcode = _zipcode;
@synthesize password2 = _password2;
@synthesize sessionId = _sessionId;
@synthesize cartId = _cartId;
@synthesize action = _action;
@synthesize userType = _userType;

/*!
 @function      sharedManager
 @abstract      create and return a shared instance
 @discussion    create and return a shared instance of userExtended manager.
 @param         nil.
 */
+ (id)sharedUserExteded
{
	@synchronized(self)
	{
		if (userExtendedManager == nil) {
			userExtendedManager = [[self alloc]init];
		}
	}
	return userExtendedManager;
}

- (void)clear
{
    userId = nil;
    email = nil;
    password = nil;
    autoLogin = false;
    self.password2 = nil;
    self.firstName = nil;
    self.lastName = nil;
    self.country = nil;
    self.state = nil;
    self.city = nil;
    self.street = nil;
    self.phoneNo = nil;
    self.zipcode = nil;
    self.action = Undefined;
}

@end

