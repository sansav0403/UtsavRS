//
//  User.h
//  Canis
//
//  Created by Yifeng on 10/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
 @class         User
 @abstract		This class will used for user details 
 @discussion	Object of this class would contain generic user details.
 */
@interface User : NSObject {
	@public
	NSString    *userId;
	NSString    *email;
	NSString    *password;
	bool		autoLogin;
}

@property (nonatomic, strong) NSString    *userId;
@property (nonatomic, strong) NSString    *email;
@property (nonatomic, strong) NSString    *password;
@property (nonatomic, assign) bool		  autoLogin;

@end
