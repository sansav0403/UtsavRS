/* 
 File: LoginViewController.h
 Abstract: This class hadles releated UI interaction functionality for login.
 Author: Cybage Software Pvt. Ltd
 Created: 18/04/12
 Modified: 18/04/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "LoginReqResHandler.h"

/*!
 @protocol      LoginViewControllerDelegate
 @abstract      delegate for login status
 @discussion    implement delegate for login status
 */
@protocol LoginViewControllerDelegate <NSObject>
- (void)loginStatusDelegate:(BOOL)aStatus;
@end

/*!
 @class         LoginViewController
 @abstract		This class hadles releated UI interaction functionality for login.
 @discussion	This class hadles all validations for email and password along with
                implementation of TextField and ReQuestResponseBase Delegate.
 */
@interface LoginViewController : UIViewController <UITextFieldDelegate,NetworkRequestResponseBaseDelegate>
{
    // BOOL
	BOOL								rememberPassword;
    
	// Others
    CGRect                              viewFrame;
}

@property (nonatomic, weak) id <LoginViewControllerDelegate>  delegate;
@property (nonatomic, weak) IBOutlet UILabel					*rememberPasswordLbl;
@property (nonatomic, weak) IBOutlet UITextField				*userNameTxtField;
@property (nonatomic, weak) IBOutlet UITextField				*apiKeyTxtField;
@property (nonatomic, weak) IBOutlet UIButton					*loginBtn;
@property (nonatomic, weak) IBOutlet UIActivityIndicatorView	*spinner;

@property (nonatomic, strong) LoginReqResHandler    *loginReqResHandler;

- (IBAction)backgroundTouched:(id)sender;
- (IBAction)loginAction:(id)sender;
- (IBAction)rememberPasswordAction:(id)sender;

- (void)setLocalizableText;
- (void)animateView:(NSNotification*)aNotification keyboardWillShow:(BOOL)keyboardWillShow;
- (void)stopActivityIndicator;

- (BOOL)validateEmailAndPassword;

@end
