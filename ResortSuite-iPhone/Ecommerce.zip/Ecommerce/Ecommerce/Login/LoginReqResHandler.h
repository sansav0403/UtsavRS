/* 
 File: LoginReqResHandler.h
 Abstract: This class hadles request and response functionality for login.
 Author: Cybage Software Pvt. Ltd
 Created: 18/04/12
 Modified: 18/04/12
 Version: 1.0 
*/

#import <Foundation/Foundation.h>
#import "NetworkRequestResponseBase.h"

typedef enum
{
    KMagentoReqXmlParserNone,
    KMagentoReqXmlParserLogin
}MagentoReqXmlParserState;

@interface LoginReqResHandler : NetworkRequestResponseBase

@property(nonatomic, strong) NSString *sessionId;
@property(nonatomic, assign) MagentoReqXmlParserState magentoReqXmlParserState;

- (void)login:(NSString *)userName apiKey:(NSString*)apiKey;
- (void)requestWithSoapMessage:(NSString *)soapMsg;
- (void)didReceiveData:(NSData*)data;

@end
