/* 
 File: LoginViewController.m
 Abstract: This class hadles releated UI interaction functionality for login.
 Author: Cybage Software Pvt. Ltd
 Created: 18/04/12
 Modified: 18/04/12
 Version: 1.0 
*/

#import "LoginViewController.h"
#import "LoginCommon.h"

@implementation LoginViewController

@synthesize delegate = _delegate;
@synthesize userNameTxtField = _userNameTxtField;
@synthesize apiKeyTxtField = _apiKeyTxtField;
@synthesize spinner = _spinner;
@synthesize rememberPasswordLbl = _rememberPasswordLbl;
@synthesize loginBtn = _loginBtn;
@synthesize loginReqResHandler = _loginReqResHandler;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    //set localizable text for UI control and messages
	[self setLocalizableText];
	
    //set Initials
    viewFrame = self.view.frame;
    
	// set rememberPassword default to NO.
	rememberPassword = NO;
    
    self.loginReqResHandler = [[LoginReqResHandler alloc] init];
    self.spinner.hidden = TRUE;
}

- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES];
	
	// Register the keyboard nofification to know when it appear and disappears 
	// to animate view when keyboard overlays view's textfields. 
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewDidUnload
{
    [self setRememberPasswordLbl:nil];
    [self setUserNameTxtField:nil];
    [self setApiKeyTxtField:nil];
    [self setLoginBtn:nil];
    [self setSpinner:nil];
    
    [super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated
{
	// unregister for keyboard notifications while not visible.
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil]; 
	[[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil]; 	
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*!
 @function      textFieldShouldReturn
 @abstract      delegate for textField 
 @discussion    discard the keyboard when tap on return button of keyboard
 @param         textField - selected textField 
 @result        will return YES 
 */
- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{
	// Discard keyBoard form window when return key tap on keyboard.
	[textField resignFirstResponder];
	return YES;
}

#pragma TextField Delegate methods
/*!
 @function		shouldChangeCharactersInRange
 @abstract		delegate for textField 
 @discussion    entered text should replace
 @param			range - on which entered text needs to replace 
                string - needs to replace
 @result        BOOL - if space entered returns NO else YES. 
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ((range.location > 0 && [string length] > 0 && [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[string characterAtIndex:0]] &&           [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[[textField text] characterAtIndex:range.location - 1]])) 
    {
        return NO;
    }
    // if first character is a space
    if ([string isEqualToString:@" "] && [textField.text length]==0)
	{ 
		return NO;
	}
    return YES;
}

#pragma mark -
#pragma mark KeyBoard delegate methods
/*!
 @function		keyboardWillShow
 @abstract		keyboard about to appear on view
 @discussion	keyboard about to appear on view
 @param			nNotification - notificationo object 
 @result		void
 */
- (void)keyboardWillShow:(NSNotification*)aNotification
{	
	[self animateView:aNotification keyboardWillShow:YES];
}

/*!
 @function		keyboardWillHide
 @abstract		keyboard about to disappear from view
 @discussion    keyboard about to disappear from view
 @param			aNotification - Notification object
 @result		void
 */
- (void)keyboardWillHide:(NSNotification*)aNotification
{
	[self animateView:aNotification keyboardWillShow:NO];
}

/*!
 @function      animateView
 @abstract		animate view up or down when keyboard overlays
 @discussion	Common function to animate view up or down when keyboard overlays
                view's textfield
 @param			keyboardWillHide
 @result		void
 */
- (void)animateView:(NSNotification*)aNotification keyboardWillShow:(BOOL)keyboardWillShow
{
	[UIView beginAnimations:nil context:NULL];
	
	[UIView setAnimationDuration:0.3];
	
	CGRect rect = [[self view] frame];
	if (keyboardWillShow)
	{
		rect.origin.y -= 60;
	}
	else
	{
        rect = viewFrame;
	}
	[[self view] setFrame: rect];
	
	[UIView commitAnimations];
}

#pragma mark 
#pragma mark Action Methods
/*!
 @method		backgroundTouched
 @abstract		discard keyboard when tapped on view apart from keyBoard
 @discussion	discard keyboard when tapped on view apart from keyBoard
 */
- (IBAction)backgroundTouched:(id)sender
{
	[self.userNameTxtField resignFirstResponder];
	[self.apiKeyTxtField resignFirstResponder];
}

/*!
 @method		loginAction
 @abstract		login for user
 @discussion	initiate login process for user
 */
- (IBAction)loginAction:(id)sender 
{
	// Discard the keyboard from window
	[self.userNameTxtField resignFirstResponder];
	[self.apiKeyTxtField resignFirstResponder];
	
	// If entered email and password are valide initiate login process
	if ([self validateEmailAndPassword])
	{	
        //Login request 
        [self.loginReqResHandler setDelegate:self];
        //[self.mgentoReqResHandler login:@"mobiletest" apiKey:@"mobiletest"];
        //[self.loginReqResHandler login:@"sandeep" apiKey:@"sandeep"];
        
        if (self.userNameTxtField.text != nil && self.apiKeyTxtField.text !=nil) {
            [self.loginReqResHandler login:self.userNameTxtField.text apiKey:self.apiKeyTxtField.text];
        }
        
        
        // show the activityIndicator while login activity is running. 
        [self.spinner setHidden:FALSE];
		[self.spinner startAnimating];
        [self.view addSubview:self.spinner];
    }
}

/*! 
 @method		rememberPasswordAction
 @abstract		check the rememberPassword button
 @discussion	set the check or uncheck image for button and set the rememberpassword
                bool variable
 */
- (IBAction)rememberPasswordAction:(id)sender
{
	/*rememberPassword = !rememberPassword;
	UIImage *checkImg =	rememberPassword ? [UIImage imageNamed:kMarkImg] : [UIImage imageNamed:kUnMarkImg];
	[checkRememberPasswordBtn setBackgroundImage:checkImg forState:UIControlStateNormal];*/
}

#pragma mark 
#pragma mark Other Methods
/*!
 @function      setLocalizableText
 @abstract      set localizable text 
 @discussion    set localizable text for UI
 @param         none
 @result        void
 */
- (void)setLocalizableText
{
	// set text for navigation title, buttons and textfield's placeholder text
	[self setTitle:kLogin];
    
	[self.userNameTxtField setPlaceholder:kUserName];
	[self.apiKeyTxtField setPlaceholder:kApiKey];
	[self.rememberPasswordLbl setText:kRememberPasswordLblText];
	
	[self.loginBtn setTitle:kLogin forState:UIControlStateNormal];
}

/*!
 @function		validateEmailAndPassword
 @abstract		validate email and password 
 @discussion	validate email and password 
 @param			none
 @result		will return YES if email and password both will comply  
                business rule else NO
 */
- (BOOL)validateEmailAndPassword
{	
	return YES;
}

/*!
 @method		clickedButtonAtIndex
 @abstract		redirect to Login Page 
 @discussion	redirect to Login Page when password sent successfully
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{   
    /*// Show indicator while registration activity is running
    [self.spinner startAnimating];
    self.navigationController.navigationBar.userInteractionEnabled = NO;
    
    // TODO we just show the HOME page here
    homeViewController = [[HomeViewController alloc] initWithNibName:@"HomeViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:homeViewController animated:YES];
    
    [homeViewController release];*/
}

/*!
 @function      stopActivityIndicator
 @abstract		stop activity indicator
 @discussion	stop activity indicator and remove from superview
 @param			none
 @result		Void
 */
- (void)stopActivityIndicator
{
	[self.spinner stopAnimating];
    [self.spinner setHidden:FALSE];
    [self.spinner removeFromSuperview];
}

- (void)parseComplete:(NSError*)error
{
    [self stopActivityIndicator];
    if (error) {
        if([self.delegate respondsToSelector:@selector(loginStatusDelegate:)]){
            [self.delegate loginStatusDelegate:FALSE];
        }
    }
    else{
        if([self.delegate respondsToSelector:@selector(loginStatusDelegate:)]){
            [self.delegate loginStatusDelegate:TRUE];
        }
    }
}

- (void)dealloc
{
    self.delegate = nil;
}

@end