/* 
 File: LoginReqResHandler.m
 Abstract: This class hadles request and response functionality for login.
 Author: Cybage Software Pvt. Ltd
 Created: 18/04/12
 Modified: 18/04/12
 Version: 1.0 
 */

#import "LoginReqResHandler.h"
#import "Common.h"
#import "UserExtended.h"
#import "LoginXmlParser.h"

@implementation LoginReqResHandler
@synthesize sessionId =_sessionId;
@synthesize magentoReqXmlParserState = _magentoReqXmlParserState;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

/*!
 @function		Login
 @abstract		Callback function of RemoteData for handling recieved data. 
 @discussion	When data is recieved successfully then this call back function is get called 
 to handle/process recieved data.
 @param			data - recieved data
 @result		void
 */
- (void)login:(NSString *)userName apiKey:(NSString*)apiKey
{
    self.magentoReqXmlParserState = KMagentoReqXmlParserLogin;
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:login soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><username xsi:type=\"xsd:string\">%@</username><apiKey xsi:type=\"xsd:string\">%@</apiKey></urn:login></soapenv:Body></soapenv:Envelope>",userName,apiKey];
                                
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		requestWithSoapMessage
 @abstract		request to server with soap request object.
 @discussion	request to server with soap request object.
 @param			soapMsg - soap message 
                soapAction - soap action
                httpMethod - httpMethod
 @result		void
*/
- (void)requestWithSoapMessage:(NSString *)soapMsg 
{
    //create a url load request
    NSURL *url __weak = nil;
    url = [NSURL URLWithString: kMagentoServerUrl];
    NSMutableURLRequest *req __weak= nil;
    req = [NSMutableURLRequest requestWithURL:url];
    
    //populate the request object with the various headers,
    //such as Content-Type, SOAPAction, and Content-Length. You also set the HTTP method and HTTP body:
    NSString *msgLength = nil;
    msgLength = [NSString stringWithFormat:@"%d", [soapMsg length]];    
    [req addValue:kContentTypeValue  forHTTPHeaderField:kContentType];
    [req addValue:kAcceptEncodingValue  forHTTPHeaderField:kAcceptEncoding];
    [req addValue:kUserAgentValue  forHTTPHeaderField:kUserAgent];
    [req addValue:kHostValue forHTTPHeaderField:kHost];    
    [req addValue:kSoapActionValue forHTTPHeaderField:kSoapAction];
    [req addValue:msgLength forHTTPHeaderField:kContentLength];
    [req setHTTPMethod:kPost];
    [req setHTTPBody:[soapMsg dataUsingEncoding:NSUTF8StringEncoding]];
    
    //TRC_DBG(@"reqString = %@",[req HTTPMethod]);
    [self.netDataManager makeRequest:req];
}

/*!
 @function		didReceiveData
 @abstract		response data of network call.
 @discussion	response data of network call.
 @param			data - response data
 @result		void
 */
- (void)didReceiveData:(NSData*)data
{   
   // NSString *newStr = [NSString stringWithUTF8String:[data bytes]];
    //TRC_DBG(@"NSData = %@",newStr);
    NSError *error = nil;
    LoginXmlParser *loginXmlParser = [[LoginXmlParser alloc] init];
    
    switch (self.magentoReqXmlParserState) {
        case KMagentoReqXmlParserLogin:
        {
            [loginXmlParser parseXMLDataForLogin:data];
            UserExtended *userExtended = [UserExtended sharedUserExteded];
            self.sessionId = userExtended.sessionId;
            TRC_DBG(@"Handler sessionId =%@",self.sessionId);
            
            //check for success
            if (!self.sessionId){
                //create error object
                error = [[NSError alloc] init];        
            }
        }
            break;
        default:
            break;
    }
    
    //Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)]){
		[self.delegate parseComplete:error];
	}
    TRC_DBG(@"did Receive Data ");
}

@end
