/* 
 File: EcommerceAppDelegate.h
 Abstract: This class is responsible for launching and shutdown operation for application.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
*/

#import <UIKit/UIKit.h>
#import "KeychainItemWrapper.h"
#import "LoginViewController.h"

@interface EcommerceAppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate,LoginViewControllerDelegate>

@property(nonatomic, strong) UIWindow               *window;
@property(nonatomic, strong) UITabBarController     *tabBarController;
@property(nonatomic, strong) UINavigationController *navigationController;
@property(nonatomic, strong) LoginViewController    *loginViewController;  
@property(nonatomic, strong) KeychainItemWrapper    * keychainItemWrapper;

- (void)initTabBarController;
- (void)handleLogOut;
- (void)redirectToLoginView;
- (void)redirectToTabBar;

@end
