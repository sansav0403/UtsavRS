/* 
 File: NetworkDataManager.m
 Abstract: This class is responsible for the web service request response handler.
 Author: Cybage Software Pvt. Ltd
 Created: 17/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import "NetworkDataManager.h"
#import "NetworkStatusManager.h"
#import "Common.h"
/*!
 @class         NetworkDataManager (Private)
 @abstract      This category is to create and private method for the NetworkDataManager.  
 @discussion    This category will extend the functionality of the NetworkDataManager.
 */
@interface NetworkDataManager (Private)
- (void)cleanup;
@end

@implementation NetworkDataManager (Private)

/*!
 @function      cleanup
 @abstract      private method to change the status of operation
 @discussion    This method is just for convenience. It cancels the URL connection if it
                still exists and finishes up the operation.
 @param         void
 @result        void
 */
- (void)cleanup
{
	@try {
        
        //Cancel and release the connection
		[_connection cancel];
		_connection = nil;
		
		//Release from active connections
        [[NetworkStatusManager sharedNetworkStatusManager] releaseFromActiveConnections];		
				
	}
	@catch (NSException * exception) {
		TRC_DBG(@"%@",exception); 
	}	
}

@end

@implementation NetworkDataManager

@synthesize connection = _connection, downloadedData = _downloadedData;
@synthesize delegate = _delegate, urlRequest =_urlRequest;
@synthesize requestTimeOut = _requestTimeOut;


/*!
 @function      initWithUrlRequest
 @abstract      initialise the request object and take the ownership of request
 @discussion    nitialise the request object and take the ownership of request and make
                the request call.
 @param         requestUrl
 @param         remoteDelegate.
 @return        void
 */
- (void)initWithUrlRequest:(NSURLRequest*)requestUrl delegate:(id)remoteDelegate
{
	self.delegate = remoteDelegate;
	[self makeRequest:requestUrl];
}

/*!
 @function      makeRequest
 @abstract      initiat server request
 @discussion    initiate the server request if network is available else return and error.
 @param         requestUrl
 @param         remoteDelegate.
 @return        void
 */
- (void)makeRequest:(NSURLRequest*)requestUrl
{    
    @try {
        if([[NetworkStatusManager sharedNetworkStatusManager] isReachable]){
            
            
            self.urlRequest = requestUrl;
            
            // if timeout for the request has been specified
            if (_requestTimeOut)
            {
                [(NSMutableURLRequest *)self.urlRequest setTimeoutInterval:self.requestTimeOut];
            }
                
            if( _connection )
            {
                //cancel any pending connection 
                [self cleanup];
            }
            [[NetworkStatusManager sharedNetworkStatusManager] addToActiveConnections];
            _connection = [[NSURLConnection alloc] initWithRequest:self.urlRequest delegate:self];
            
        }
        else 
        {
            NSError *error = nil;//set No network connectivity in object.		
            NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kNoNetwork,kError, nil];
            error = [NSError errorWithDomain:@"TEST" code:5111 userInfo:userInfo];
            //[userInfo release];
            
            if([self.delegate respondsToSelector:@selector(didFailWithError:)])
            {
                [self.delegate didFailWithError:error]; //No Network connection
            }
        }        
	}
	@catch (NSException * exception) {
		TRC_DBG(@"%@",exception); 
	}
	
}

#pragma mark NSURLConnection delegate methods
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    @try {
        NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
        NSInteger statusCode = [httpResponse statusCode];
        TRC_DBG(@"%d",statusCode);
        //Lazly allocate the required buffer from http response 
        if( statusCode == 200 ) {
            
            int contentSize = [httpResponse expectedContentLength] > 0 ? [httpResponse expectedContentLength] : 0;
            //[_downloadedData release];
            self.downloadedData = nil;
            self.downloadedData = [[NSMutableData alloc] initWithCapacity:contentSize];
        } 
        else
        {
            [self cleanup];
            
            
            NSError *error = nil;//set No network connectivity in object.		
            NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kNoNetwork,kError, nil];
            error = [NSError errorWithDomain:@"TEST" code:5111 userInfo:userInfo];
            //[userInfo release];
            
            if([self.delegate respondsToSelector:@selector(didFailWithError:)])
            {
                [self.delegate didFailWithError:error];
            }
        }        
	}
	@catch (NSException * exception) {
		TRC_DBG(@"%@",exception); 
	}
    
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.downloadedData appendData:data]; 
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    @try {
        //[self.downloadedData release];
        _downloadedData = nil;
        [self cleanup];
        
        
        if([self.delegate respondsToSelector:@selector(didFailWithError:)])
        {
            [self.delegate didFailWithError:error];
        }        
	}
	@catch (NSException * exception) {
		TRC_DBG(@"%@",exception); 
	}
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    @try {
        [self cleanup];
        
        
        if([self.delegate respondsToSelector:@selector(didReceiveData:)])
        {            
            [self.delegate didReceiveData:self.downloadedData];
        }       
	}
	@catch (NSException * exception) {
         TRC_DBG(@"%@",exception); 
	}
}

- (BOOL)connection:(NSURLConnection *)connection canAuthenticateAgainstProtectionSpace:(NSURLProtectionSpace *)protectionSpace {
    TRC_DBG(@"canAuthenticateAgainstProtectionSpace");
    return [protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust];
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge: (NSURLAuthenticationChallenge *)challenge {  
    TRC_DBG(@"didReceiveAuthenticationChallenge");
    [challenge.sender continueWithoutCredentialForAuthenticationChallenge:challenge];
}

/*!
 @function      connectionTimeOut
 @abstract      denied log in request if server is not responding whithin 10 sec. 
 @discussion    denied log in request if server is not responding whithin 10 sec.
 @return        void
 */
- (void)connectionTimeOut
{
    @try {
        [self cleanup];
        
        NSError *error = nil;//set No network connectivity in object.		
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"TEST" code:5112 userInfo:userInfo];
        //[userInfo release];
        
        if([self.delegate respondsToSelector:@selector(didFailWithError:)])
        {
            [self.delegate didFailWithError:error];
        }      
	}
	@catch (NSException * exception) {
         TRC_DBG(@"%@",exception);
	}
}

@end