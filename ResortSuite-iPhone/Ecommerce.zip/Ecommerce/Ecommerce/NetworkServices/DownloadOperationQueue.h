/* 
 File: DownloadOperationQueue.h
 Abstract: This class is responsible for download content asynchronously.
 Author: Cybage Software Pvt. Ltd
 Created: 17/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>

/*!
@class			DownloadOperationQueue
@abstract		An queue to download content asynchronously.
@discussion		Class is used to queue the NSOpearations which will download contents from 
                server asynchronously.
*/

@interface DownloadOperationQueue : NSObject {

    @private
	NSOperationQueue  *_downloadOperationQueue;
	int				  _currentOperationsCount;
    int               _numOfConcurrentOperations;	
    
}

@property(nonatomic, strong) NSOperationQueue   *downloadOperationQueue;
@property(nonatomic, assign) int                currentOperationsCount;
@property(nonatomic, assign) int                numOfConcurrentOperations;

+ (DownloadOperationQueue*)sharedOprationQueue;

- (void)setNumOfConcurrentOperations:(int)concurrentOperations;
- (void)addOperation:(NSOperation*)operation;
- (void)cancelAllOperations;

@end
