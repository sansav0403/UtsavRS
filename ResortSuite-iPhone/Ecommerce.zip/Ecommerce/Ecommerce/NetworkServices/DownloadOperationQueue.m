/* 
 File: DownloadOperationQueue.m
 Abstract: This class is responsible for download content asynchronously.
 Author: Cybage Software Pvt. Ltd
 Created: 17/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import "DownloadOperationQueue.h"
#import "NetworkStatusManager.h"

const int defaultConcurrentOperations = 5;

//global instance of downloadQueue
static DownloadOperationQueue *operationQueue = nil;

@implementation DownloadOperationQueue

@synthesize downloadOperationQueue = _downloadOperationQueue;
@synthesize currentOperationsCount = _currentOperationsCount;
@synthesize numOfConcurrentOperations = _numOfConcurrentOperations;

/*!
 @function		sharedOprationQueue
 @abstract		gives shared instance of ImageDownloadQueue
 @discussion	This class will be singleton implemenation of DownloadOperationQueue.
 @param			none 
 @result		object of DownloadOperationQueue class.
 */
+ (DownloadOperationQueue*)sharedOprationQueue
{
    @try {
        if (operationQueue == nil) {
            
            operationQueue = [[super allocWithZone:NULL] init];
            operationQueue.downloadOperationQueue = [[NSOperationQueue alloc] init];
            [operationQueue.downloadOperationQueue setMaxConcurrentOperationCount:defaultConcurrentOperations];
        }
	}
	@catch (NSException * exception) {
		TRC_DBG(@"%@",exception);  
        operationQueue = nil;
	}
	return operationQueue; 
}

/*!
 @function		allocWithZone
 @abstract   
 @discussion 
 @param			zone	-	this zone which is NSZone object.
 @result		returns self.
 */
+ (id)allocWithZone:(NSZone *)zone
{
    return [self sharedOprationQueue];
}

/*!
 @function		copyWithZone
 @abstract   
 @discussion 
 @param			zone	-	this zone which is NSZone object.
 @result		returns self.
 */
- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

/*!
 @function		setNumOfConcurrentDownloads
 @abstract		set the concurrent download number.
 @discussion	Using this fucntion, can control number of concurrent downloads. 
 @param			count of concurrentDownloads 
 @result		void
 */
-(void)setNumOfConcurrentOperations:(int)concurrentOperations
{
    @try {
         [operationQueue.downloadOperationQueue setMaxConcurrentOperationCount:concurrentOperations ? concurrentOperations : defaultConcurrentOperations];        
	}
	@catch (NSException * exception) {
		TRC_DBG(@"%@",exception);  
	}
   
}

/*!
 @function		addOperation
 @abstract		Adds opeartion in operation queue.
 @discussion	This function adds image download operation in operation queue.
 @param			operation	-	this is NSOperation object as parameter.
 @result		void
 */
- (void)addOperation:(NSOperation*)operation
{
	@try {
        //Bump the operation count by one
		++operationQueue.currentOperationsCount;
        //add the operation to queue
		[operationQueue.downloadOperationQueue addOperation:operation];
	}
	@catch (NSException * exception) {		
		TRC_DBG(@"%@",exception); 	
	}
}

/*!
 @function		cancelAllOperations
 @abstract		function cancles all outstanding operations.
 @discussion	This function cancels all outstanding opeations
 @param			none 
 @result		void
 */
- (void)cancelAllOperations
{
	@try {
        //Can all outstanding operations
		[operationQueue.downloadOperationQueue cancelAllOperations];        
	}
	@catch (NSException * exception) {
		TRC_DBG(@"%@",exception); 
	}
}

@end
