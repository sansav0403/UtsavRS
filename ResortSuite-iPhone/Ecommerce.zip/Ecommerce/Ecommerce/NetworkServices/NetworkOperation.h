/* 
 File: NetworkOperation.h
 Abstract: This class is responsible for web service asynchronous call operation.
 Author: Cybage Software Pvt. Ltd
 Created: 17/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>


/*!
 @class         NetworkOperation
 @abstract      This class is an operation for web service call.  
 @discussion    This class has the web service asynchronous call operation.
 */
@interface NetworkOperation : NSOperation {
    
    @private
    //---Remote data access---
	NSURLRequest        *_urlRequest;
	NSURLConnection		*_connection;
    NSMutableData		*_remoteData;
	NSError*			_connectionError;
	
	BOOL				executing;
	BOOL				finished;	
	NSUInteger			_contentSize;
}

@property(nonatomic, strong) NSURLRequest                *urlRequest;
@property(nonatomic, strong, readonly) NSURLConnection	*connection;
@property(nonatomic, strong, readonly) NSMutableData     *remoteData;
@property(nonatomic, readonly) NSError                   *error;
@property(nonatomic, assign) NSUInteger                  contentSize;

- (id)initWithUrlRequest:(NSURLRequest*)requestUrl;
- (id)initWithURLString:(NSString*)requestUrl;
@end
