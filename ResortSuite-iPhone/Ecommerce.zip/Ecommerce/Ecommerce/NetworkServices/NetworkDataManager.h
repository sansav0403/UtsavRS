/* 
 File: NetworkDataManager.h
 Abstract: This class is responsible for the web service request response handler.
 Author: Cybage Software Pvt. Ltd
 Created: 17/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>

@protocol NetworkDataManagerDelegate <NSObject>

- (void)didReceiveData:(NSData*)data;
- (void)didFailWithError:(NSError*)error;

@end

/*!
 @class         NetworkDataManager
 @abstract      This class is class for the web service request response handler.  
 @discussion    This class handles HTTP calls. It also handles networks errors.
 */
@interface NetworkDataManager : NSObject{
    
    @private
	id<NetworkDataManagerDelegate>  _delegate;
	NSURLConnection         *_connection;
    NSMutableData           *_downloadedData;
	NSURLRequest            *_urlRequest;
    int                     _requestTimeOut;
}

@property (nonatomic, strong) id <NetworkDataManagerDelegate>   delegate;
@property (nonatomic, strong, readonly) NSURLConnection *connection;
@property (nonatomic, strong, readwrite) NSMutableData   *downloadedData;
@property (nonatomic, strong) NSURLRequest              *urlRequest;
@property (nonatomic, assign) int                       requestTimeOut; 

- (void)initWithUrlRequest:(NSURLRequest*)requestUrl delegate:(id)remoteDelegate;
- (void)makeRequest:(NSURLRequest*)requestUrl;

@end
