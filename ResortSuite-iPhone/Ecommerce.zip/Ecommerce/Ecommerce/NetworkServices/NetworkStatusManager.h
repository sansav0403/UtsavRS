/* 
 File: NetworkStatusManager.h
 Abstract: This class is responsible to get the current network status.
 Author: Cybage Software Pvt. Ltd
 Created: 17/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>

@class Reachability;


typedef enum {
     kNetworkNotAvailable
    ,kWiFi
    ,kWWAN // WWAN - wireless wide area network
}NetworkState;

/*!
 @class         NetworkStatusManager
 @abstract      This class is implemented to get the current network status.  
 @discussion    This class is implemented to get the current network status.
 */
@interface NetworkStatusManager : NSObject {

    int             _activeConnections;
	NetworkState    _reachableState;	
    Reachability    *internetReach;
    Reachability    *wifiReach;
}

@property(nonatomic,assign)	NetworkState reachableState;
@property(assign)           int activeConnections;

+ (id)sharedNetworkStatusManager;
- (bool)isReachable;

//Start listening for reachability notifications on the current run loop
- (BOOL)startNetworkStatusNotifier;
- (void)stopNetworkStatusNotifier;

- (void)releaseFromActiveConnections;
- (void)addToActiveConnections;

@end
