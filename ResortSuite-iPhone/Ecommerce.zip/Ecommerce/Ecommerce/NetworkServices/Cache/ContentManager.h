/* 
 File: ContentManager.h
 Abstract: This class is responsible for downloading content for caching.
 Author: Cybage Software Pvt. Ltd
 Created: 25/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "NetworkOperation.h"

@protocol ContentManagerDelegate <NSObject>

- (void)handleData:(id)data  resourceURL:(NSString*)urlString returnError:(NSError*)error;

@end

@interface ContentManager : NSObject {
    __unsafe_unretained id <ContentManagerDelegate> _delegate;
}
@property (nonatomic, assign) id <ContentManagerDelegate> delegate;

- (void)contentUrl:(NSString*)urlString;

@end
