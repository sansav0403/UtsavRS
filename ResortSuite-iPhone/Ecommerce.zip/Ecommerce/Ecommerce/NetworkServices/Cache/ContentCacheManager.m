/* 
 File: ContentCacheManager.m
 Abstract: This class is responsible for managing caching data.
 Author: Cybage Software Pvt. Ltd
 Created: 25/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import "ContentCacheManager.h"

#define RESOURCE_DIRECTORY_PATH @"782_ResourceCache_123"
#define KRemovableCacheSize 200

//204800 KB = 200 MB * 1024 KB
const long  long MAX_CACHE_SIZE = 204800;
static ContentCacheManager* contentCacheManager = nil;

@interface ContentCacheManager(private)

- (NSString*)pathForResource:(NSString*)urlString;
- (NSString*)nameForResource:(NSString*)urlString;;
- (BOOL)removeResourceWithPath:(NSString*)resourcePath;
- (BOOL)createFolderWithPath:(NSString*)folderPath;
- (BOOL)saveResource:(NSString*)urlString data:(NSData*)fileData;
- (NSData*)resourceDataWithPath:(NSString*)resourcePath;
- (NSString*)documentDirectoryPath;
- (void)clearAllExceedingCacheSize:(NSUInteger)size ;
@end

@implementation ContentCacheManager
@synthesize resourcePathCache = _resourcePathCache;

/*!
 @function		sharedOprationQueue
 @abstract		gives shared instance of ImageDownloadQueue
 @discussion	This class will be singleton implemenation of DownloadOperationQueue.
 @param			none 
 @result		object of DownloadOperationQueue class.
 */
+ (ContentCacheManager*)sharedContentCacheManager
{
    @try {
        if (contentCacheManager == nil) {            
            contentCacheManager = [[super allocWithZone:NULL] init];
            contentCacheManager.resourcePathCache = [[NSMutableDictionary alloc] initWithCapacity:0];
            [contentCacheManager createResourceDirectory];
        }
	}
	@catch (NSException * exception) {
		TRC_DBG(@"%@",exception);  
        contentCacheManager = nil;
	}
	return contentCacheManager; 
}

/*!
 @function	 createResourceDirectory
 @abstract   create resource directory in document folder
 @discussion create resource directory in document folder
 @param      
 @result     void
 */
#pragma mark - PUBLIC METHODS
- (void)createResourceDirectory
{
    //form directory path using document directory
    NSString *folderPath = [NSString stringWithFormat:@"%@/%@",[self documentDirectoryPath],RESOURCE_DIRECTORY_PATH];
    //create folder
    [self createFolderWithPath:folderPath];
}

/*!
 @function	 createResourceDirectory
 @abstract   create resource directory in document folder
 @discussion create resource directory in document folder
 @param      
 @result     void
 */
- (id)resourceWithUrl:(NSString*)urlString viewControllername:(NSString*)className
{
    @synchronized(self)
    {
        //Get mapped file name for URL
        NSString *resourcePath = [self pathForResource:urlString];
        id fileData = nil;
        if(resourcePath)
        {
            //return the data of the file
            fileData = [self resourceDataWithPath:resourcePath];
            //file is not present physically so remove mapping from resourcePathCache
            
            NSURL *resourceURL = [NSURL URLWithString:urlString];
            NSString *pathExtention = [resourceURL pathExtension];
            TRC_DBG(@"pathExtention == %@", pathExtention);
            if([pathExtention isEqualToString:@"png"] || [pathExtention isEqualToString:@"jpg"]
               || [pathExtention isEqualToString:@"jpeg"] || [pathExtention isEqualToString:@"bmp"]
               || [pathExtention isEqualToString:@"gif"])
            {
                fileData = [UIImage imageWithData:fileData];
            }
            //audio and video return NSData no need of conversion
            if(!fileData)
            {
                [self.resourcePathCache removeObjectForKey:urlString];
            }
        }
        return fileData;
    }
}

/*!
 @function	 updateResourceCache
 @abstract   update resource cache in dictionary and save to resource folder
 @discussion 
 @param      urlString amd resourceData
 @result     void
 */
- (void)updateResourceCache:(NSString*)urlString resource:(NSData*)resourceData
{
    [self clearAllExceedingCacheSize:KRemovableCacheSize];
    //Generate the Unique name for file keeping extention in consideration like png, mp3 , jpg and so on.
    NSString *uniqueFileName =[self nameForResource:urlString];
    
    //Update the resource path cache
    [self.resourcePathCache setObject:uniqueFileName forKey:urlString];

    //resourcePath = documentDirectory/ResourceFolderName/uniqueFileName
    NSString *resourcePath = [NSString stringWithFormat:@"%@/%@/%@",[self documentDirectoryPath],RESOURCE_DIRECTORY_PATH, uniqueFileName];
    //Save resource file on disk
    [self saveResource:resourcePath data:resourceData];
}

/*!
 @function	 removeResource
 @abstract   delete file from resource directory
 @discussion 
 @param      urlString
 @result     void
 */
- (void)removeResource:(NSString*) urlString
{
    //Get mapped file name for URL
    NSString *resourceFileName = [[[ContentCacheManager sharedContentCacheManager] resourcePathCache] objectForKey:urlString];
    
    //remove resource mapping from resource path cache
    [self.resourcePathCache removeObjectForKey:urlString];
    
    //resourcePath = documentDirectory/ResourceFolderName/resourceFileName
    NSString *resourcePath = [NSString stringWithFormat:@"%@/%@/%@",[self documentDirectoryPath],RESOURCE_DIRECTORY_PATH, resourceFileName];
    //remove the resource from disk
    [self removeResourceWithPath:resourcePath];
}

/*!
 @function	 clearCache
 @abstract   delete resource directory
 @discussion 
 @param      
 @result     void
 */
- (void)clearCache
{
    //clear resourcePathCache 
    [self.resourcePathCache removeAllObjects];
    
    //directoryPath = documentDirectory/ResourceFolderName
    NSString *directoryPath = [NSString stringWithFormat:@"%@/%@",[self documentDirectoryPath],RESOURCE_DIRECTORY_PATH];
    [self removeResourceWithPath:directoryPath];
    
    //Create resource directory
    [self createResourceDirectory];
}

#pragma mark - PRIVATE METHODS
/*!
 @function	 pathForResource
 @abstract   resource path of cache resource
 @discussion 
 @param      urlString
 @result     void
 */
- (NSString*)pathForResource:(NSString*)urlString
{
    //This will return path for the url in the resourcePathCache else return nil
    NSString *resourceName = [contentCacheManager.resourcePathCache objectForKey:urlString];
    NSString *resourcePath = nil;
    if(resourceName)
    {
        //resourcePath = documentDirectory/ResourceFolderName/fileName
        resourcePath = [NSString stringWithFormat:@"%@/%@/%@",[self documentDirectoryPath],RESOURCE_DIRECTORY_PATH, resourceName];
    }
    return resourcePath;
}

/*!
 @function	 nameForResource
 @abstract   generate unique name for file
 @discussion 
 @param      urlString
 @result     void
 */
- (NSString*)nameForResource:(NSString*)urlString
{
    //Create and return unique id name 
    CFUUIDRef theUUID = CFUUIDCreate(NULL);
	CFStringRef string = CFUUIDCreateString(NULL, theUUID);
	CFRelease(theUUID);
    
    NSString *uniqueName = (__bridge_transfer NSString *)string;
    //Extract the file extention
    NSURL *resourceURL = [NSURL URLWithString:urlString];
    NSString *pathExtention = [resourceURL pathExtension];

    //resourceName = uniqueName.pathExtention
    NSString *resourceName = [NSString stringWithFormat:@"%@.%@",uniqueName,pathExtention];
	//[(__bridge_transfer NSString*)string release];
    return resourceName;
}

/*!
 @function	 removeResourceWithPath
 @abstract   remove reource file from disk
 @discussion 
 @param      resourcePath - file path on disk
 @result     void
 */
- (BOOL)removeResourceWithPath:(NSString*)resourcePath
{
    NSError *error = nil;
    //Remove the resource from resource
    NSFileManager *fileManager = [NSFileManager defaultManager];
    [fileManager removeItemAtPath:resourcePath error:&error];
    if(error)
    {
        TRC_DBG(@"Error - %@", [error description]);
    }
    
    return error?TRUE:FALSE;
}

/*!
 @function	 createFolderWithPath
 @abstract   create folder 
 @discussion 
 @param      folderPath - folder path on disk
 @result     BOOL
 */
- (BOOL)createFolderWithPath:(NSString*)folderPath
{
    NSError *error = nil;
    //Create directory
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL aBool = [fileManager createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:&error];
    if(error)
    {
        TRC_DBG(@"Error - %@", [error description]);
    }
    
    return aBool;
}

/*!
 @function	 saveResource
 @abstract   save resource on disk 
 @discussion 
 @param      pathString - file path on disk 
             data - data to store
 @result     BOOL
 */
- (BOOL)saveResource:(NSString*)pathString data:(NSData*)fileData
{
    //NSData is used for writing file on disk
    return [fileData writeToFile:pathString atomically:NO];
}

/*!
 @function	 resourceDataWithPath
 @abstract   get the data for file
 @discussion 
 @param      resourcePath - file path on disk
 @result     data - file data
 */
- (NSData*)resourceDataWithPath:(NSString*)resourcePath
{
    //return the binary data of file
    NSData *data = [NSData dataWithContentsOfFile:resourcePath];
    return data;
}

/*!
 @function	 documentDirectoryPath
 @abstract   return document directory 
 @discussion 
 @param      folderPath - folder path on disk
 @result     void
 */

- (NSString*)documentDirectoryPath
{
    //Get the documentDirectoryPath
    NSArray *directoryPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); 
    
    return [directoryPath objectAtIndex:0];
}

/*!
 @function	 clearAllExceedingCacheSize
 @abstract   return document directoryclear cache if resource folder exceeding the specified size 
 @discussion 
 @param      size - max cache size in KB
 @result     void
 */
- (void)clearAllExceedingCacheSize:(NSUInteger)size 
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if(fileManager)
    {
        NSString *directoryPath = [NSString stringWithFormat:@"%@/%@",[self documentDirectoryPath],RESOURCE_DIRECTORY_PATH];
        NSError *error = nil;
        NSDictionary *dictonary = [fileManager attributesOfItemAtPath:directoryPath error:&error];

        NSUInteger sizeKB =  [[dictonary valueForKey:NSFileSize] longLongValue];
       if(sizeKB >= MAX_CACHE_SIZE)
       {
           [self clearCache];
       }
        
    }
}

#pragma mark - SINGLETON IMPLEMENTATION

/*!
 @function		allocWithZone
 @abstract   
 @discussion 
 @param			zone	-	this zone which is NSZone object.
 @result		returns self.
 */
+ (id)allocWithZone:(NSZone *)zone
{
    return [self sharedContentCacheManager];
}

/*!
 @function		copyWithZone
 @abstract   
 @discussion 
 @param			zone	-	this zone which is NSZone object.
 @result		returns self.
 */
- (id)copyWithZone:(NSZone *)zone
{
    return self;
}

/*!
 @function		retain
 @abstract   
 @discussion 
 @param			none 
 @result		id which self pointer
 */
/*- (id)retain
{
    return self;
}*/

/*!
 @function		retainCount
 @abstract		denotes an object that cannot be released
 @discussion	denotes an object that cannot be released
 @param			none 
 @result		integer value having retiain count.
 */
/*- (NSUInteger)retainCount
{
    return NSUIntegerMax;  //denotes an object that cannot be released
}*/

/*!
 @function		release
 @abstract		
 @discussion	
 @param			none 
 @result		void
 */
/*- (oneway void)release
{
    //do nothing
}*/

/*!
 @function		autorelease
 @abstract		
 @discussion	
 @param			none 
 @result		returns self pointer.
 */
/*- (id)autorelease
{
    return self;
}*/

@end
