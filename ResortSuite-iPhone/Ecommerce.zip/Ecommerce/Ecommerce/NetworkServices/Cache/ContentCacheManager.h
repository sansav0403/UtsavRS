/* 
 File: ContentCacheManager.h
 Abstract: This class is responsible for managing caching data.
 Author: Cybage Software Pvt. Ltd
 Created: 25/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>


@interface ContentCacheManager : NSObject {
     NSMutableDictionary   *_resourcePathCache;
}
@property (nonatomic, retain) NSMutableDictionary *resourcePathCache;
+ (ContentCacheManager*)sharedContentCacheManager;

- (void)createResourceDirectory;
- (id)resourceWithUrl:(NSString*)urlString viewControllername:(NSString*)className;
- (void)updateResourceCache:(NSString*)urlString resource:(NSData*)resourceData;
- (void)removeResource:(NSString*)urlString;
- (void)clearCache;

@end
