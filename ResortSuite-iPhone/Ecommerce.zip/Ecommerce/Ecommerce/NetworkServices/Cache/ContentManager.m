/* 
 File: ContentManager.m
 Abstract: This class is responsible for downloading content for caching.
 Author: Cybage Software Pvt. Ltd
 Created: 25/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import "ContentManager.h"
#import "ContentCacheManager.h"
#import "DownloadOperationQueue.h"
#import "Common.h"

@interface ContentManager ()
@property(nonatomic,retain) NetworkOperation *networkOperation;
@end

@implementation ContentManager
@synthesize delegate = _delegate;
@synthesize networkOperation;

/*!
 @function	 contentUrl
 @abstract   ask contentcachemanager if resource is cached else create network operation for download
 @discussion if cached return cached resource else download new
 @param      urlString - url string
 @result     void
 */
- (void)contentUrl:(NSString*) urlString
{
    id data = [[ContentCacheManager sharedContentCacheManager] resourceWithUrl:urlString viewControllername:nil];
    if(!data)
    {
        //Call operation
        self.networkOperation = [[NetworkOperation alloc] initWithURLString:urlString];
        [self.networkOperation addObserver:self forKeyPath:kIsFinishedkey options:NSKeyValueObservingOptionNew context:NULL];
        [[DownloadOperationQueue sharedOprationQueue] addOperation:self.networkOperation];
    }
    else if([self.delegate respondsToSelector:@selector(handleData:resourceURL:returnError:)])
    {
        [self.delegate handleData:data resourceURL:urlString returnError:nil];
    }
}

/*!
 @function	 observeValueForKeyPath
 @abstract   RemoteDataOperation keyValue callback
 @discussion RemoteDataOperation keyValue callback
 @param      
 @result     void
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
	@try {
		NetworkOperation *currentNetworkOperation = (NetworkOperation*)object;
		[currentNetworkOperation removeObserver:self forKeyPath:kIsFinishedkey];
		
        //if there is an error set default image else set image data received from server
        if( [currentNetworkOperation error] ) 
		{
			//Error handling
            if([self.delegate respondsToSelector:@selector(handleData:resourceURL:returnError:)])
            {
                [self.delegate handleData:nil resourceURL:[[currentNetworkOperation.urlRequest URL] absoluteString] 
                              returnError:[currentNetworkOperation error]];
            }
		} 
		else
		{
            //update cache
            NSString *urlString = [[currentNetworkOperation.urlRequest URL] absoluteString];
            [[ContentCacheManager sharedContentCacheManager] updateResourceCache:urlString 
                                                                        resource:currentNetworkOperation.remoteData] ;
            
            //if image send the uiimage in id else send plan nsdata
            id fileData = currentNetworkOperation.remoteData;
            NSURL *resourceURL = [NSURL URLWithString:urlString];
            NSString *pathExtention = [resourceURL pathExtension];
            if([pathExtention isEqualToString:@"png"] || [pathExtention isEqualToString:@"jpg"]
               || [pathExtention isEqualToString:@"jpeg"] || [pathExtention isEqualToString:@"bmp"]
               || [pathExtention isEqualToString:@"gif"])
            {
                fileData = [UIImage imageWithData:currentNetworkOperation.remoteData];
            }
            
            //send data to requester
			if([self.delegate respondsToSelector:@selector(handleData:resourceURL:returnError:)])
            {
                [self.delegate handleData:fileData resourceURL:urlString returnError:nil];
            }            
		}
        
        //release memory
		if( currentNetworkOperation == self.networkOperation ) {
			self.networkOperation =  nil;
		}
	}
	@catch (NSException * e) {
		TRC_DBG(@"%@", [e reason]);
	}
}

@end
