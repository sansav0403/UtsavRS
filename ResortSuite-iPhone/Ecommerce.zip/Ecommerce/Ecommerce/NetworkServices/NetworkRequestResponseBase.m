/* 
 File: NetworkRequestResponseBase.m
 Abstract: This class is base for all the request response handler classes.
 Author: Cybage Software Pvt. Ltd
 Created: 17/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import "NetworkRequestResponseBase.h"
#import "Common.h"
@implementation NetworkRequestResponseBase

@synthesize  delegate =_delegate;
@synthesize netDataManager = _netDataManager;

/*!
 @function      init
 @abstract      initialise the remote data
 @discussion    initialise the remote data to handle the asynchronous server handling.
 @param         void
 @result        void
 */
- (id)init
{
	if((self = [super init]))
	{
		_netDataManager = [[NetworkDataManager alloc]init];
		[self.netDataManager setDelegate:self];
		return self;
	}
	return nil;
}

/*!
 @function      initinitWithURL
 @abstract      initialise with serve url and create request 
 @discussion    initialise the remote data to handle the asynchronous server handling.
 @param         serverUrl - server url 
 @result        void
 */
- (id)initWithURL:(NSURL*)urlToGetData callback:(id)remoteDelegate
{
	if((self = [super init]))
	{
        self.delegate = remoteDelegate;
        if(_netDataManager)
        {
            _netDataManager = [[NetworkDataManager alloc]init];
		}
        [self.netDataManager setDelegate:self];

        NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:urlToGetData];
        [theRequest setHTTPMethod:kGet];			
        
        [self.netDataManager makeRequest:theRequest];
        return self;
	}
	return nil;
}

/*!
 @function      createRequest
 @abstract      abstract implementation
 @discussion    abstract method implemented by the child classes.
 @param         void
 @result        void
 */
- (void)createRequest
{
	//Create NSUrl and make request
}


#pragma mark RemoteDataDelegate delegate methods
/*!
 @function      checkForErrors
 @abstract      This function check the custom errors.
 @discussion    This function check the custom errors.
 @param         void
 @result        return YES
 */
- (BOOL)checkForErrors:(NSData*)data
{
    BOOL retValue = FALSE;
    NSError *error = nil;
    
    if (error) { 
        //Update the caller For error otherwise handleReceivedData will update the caller
        //for parsing success.
        if([self.delegate respondsToSelector:@selector(parseComplete:)])
        {
            [self.delegate parseComplete:error];
        }
    }
    return retValue;
}

/*!
 @function      didFailWithError
 @abstract      delegate implementation
 @discussion    NetworkDataManagerDelegate method to handle the server or parsing error and 
                pass it on to the actula caller object.
 @param         NSError - Error for parsing or from the server side will be handle by this
                delegate method.
 @result        void
 */
- (void)didFailWithError:(NSError*)error
{
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
}

/*!
 @function		didReceiveData
 @abstract		response data of network call.
 @discussion	response data of network call.
 @param			data - response data
 @result		void
 */
- (void)didReceiveData:(NSData*)data
{
    //Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:nil];
	}
}



@end