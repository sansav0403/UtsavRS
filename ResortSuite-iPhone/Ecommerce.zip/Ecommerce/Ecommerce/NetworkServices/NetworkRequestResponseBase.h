/* 
 File: NetworkRequestResponseBase.h
 Abstract: This class is base for all the request response handler classes.
 Author: Cybage Software Pvt. Ltd
 Created: 17/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "NetworkDataManager.h"

@protocol NetworkRequestResponseBaseDelegate <NSObject>

- (void)parseComplete:(NSError*)error;

@end

/*!
 @class         NetworkRequestResponseBase
 @abstract      This class is base class for all the request response handler classes.  
 @discussion    This class has the Remote Data initialization which help to create an web
                service object to deals with the server.
 */

@interface NetworkRequestResponseBase : NSObject <NetworkDataManagerDelegate> {
	__unsafe_unretained id<NetworkRequestResponseBaseDelegate>     _delegate;
	NetworkDataManager                          *_netDataManager;
}

@property (nonatomic, assign) id <NetworkRequestResponseBaseDelegate>   delegate;
@property (nonatomic, strong) NetworkDataManager                         *netDataManager;

- (id)initWithURL:(NSURL*)urlToGetData callback:(id)remoteDelegate;
- (void)createRequest;
- (BOOL)checkForErrors:(NSData*)data;


@end
