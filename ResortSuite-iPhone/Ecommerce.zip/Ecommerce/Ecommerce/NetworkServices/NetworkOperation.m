/* 
 File: NetworkOperation.m
 Abstract: This class is responsible for web service asynchronous call operation.
 Author: Cybage Software Pvt. Ltd
 Created: 17/01/12.
 Modified: 01/03/12
 Version: 1.0 
 */

#import "NetworkOperation.h"
#import "NetworkStatusManager.h"
#import "Common.h"

/*!
 @class         NetworkOperation (Private)
 @abstract      This category is to create and private method for the NetworkOperation.  
 @discussion    This category will extend the functionality of the NetworkOperation.
 */
@interface NetworkOperation (Private)
- (void)done;
@end

@implementation NetworkOperation (Private)

/*!
 @function      done
 @abstract      private method to change the status of operation
 @discussion    This method is just for convenience. It cancels the URL connection 
                if it still exists and finishes up the operation.
 @param         void
 @result        void
 */
- (void)done
{
	@try {
        
        //Cancel and release the connection
		[_connection cancel];
		//[_connection release];
		_connection = nil;
		
		//Release from active connections
        [[NetworkStatusManager sharedNetworkStatusManager] releaseFromActiveConnections];
		
		//Alert observers that connection is finished using KVO
		[self willChangeValueForKey:kIsExecutingkey];
		[self willChangeValueForKey:kIsFinishedkey];
		executing = NO;
		finished  = YES;
		[self didChangeValueForKey:kIsFinishedkey];
		[self didChangeValueForKey:kIsExecutingkey];
	}
	@catch (NSException * exception) {
         TRC_DBG(@"%@",exception);  
	}	
}

@end

@implementation NetworkOperation

@synthesize urlRequest          = _urlRequest;
@synthesize connection          = _connection;
@synthesize remoteData          = _remoteData;
@synthesize error               = _connectionError;
@synthesize contentSize         = _contentSize;

#pragma mark -
#pragma mark Initialization & Memory Management
- (id)init {
	return [self initWithUrlRequest:nil ];
}

/*!
 @function      initWithUrlRequest
 @abstract      initialize the url request object and take the ownership for the same.
 @discussion    initialize the url request object and take the ownership for the same.
 @param         NSURLRequest
 @result        return the NetworkOperation object
 */
- (id)initWithUrlRequest:(NSURLRequest*)requestUrl 
{
	if( (self = [super init]) ) {
        self.urlRequest = requestUrl;
        _remoteData = nil;
        _connectionError = nil;
  	}
	return self;
}

- (id)initWithURLString:(NSString*)requestUrl
{
    if( (self = [super init]) ) {
        NSURLRequest *urlRequest = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:requestUrl]];
        self.urlRequest = urlRequest;
        //[urlRequest release];
        _remoteData = nil;
        _connectionError = nil;
  	}
	return self;
}


#pragma mark -
#pragma mark Start & Utility Methods
/*!
 @function      start
 @abstract      initialize the url request.
 @discussion    initialize the url request and add it to run loop and start the operation.
 @param         void
 @result        void
 */
- (void)start
{
	@try
	{
		// Ensure this operation is not being restarted and that it has not been cancelled
		if( finished || [self isCancelled] ) { [self done]; return; }
		
		// From this point on, the operation is officially executing--remember, isExecuting
		// needs to be KVO compliant!
		[self willChangeValueForKey:kIsExecutingkey];
		executing = YES;
		[self didChangeValueForKey:kIsExecutingkey];
        
		// Create the NSURLConnection--this could have been done in init, but we delayed 
		// until this operation is started by queue. This prevents the connection to be established in case the operation
        // was never enqueued or was cancelled before starting
		_connection = [[NSURLConnection alloc] initWithRequest:_urlRequest delegate:self startImmediately:NO];
		
        //Add this connection to active connections
        [[NetworkStatusManager sharedNetworkStatusManager] addToActiveConnections];
        
        //Schecule the connection to run in the main runloop
		[self.connection scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSDefaultRunLoopMode];
		
		[self.connection start];	
	}
	@catch (NSException * exception) {
         TRC_DBG(@"%@",exception); 
	}
}

#pragma mark -
#pragma mark Overrides
/*!
 @function      isConcurrent
 @abstract      operation is concurrent.
 @discussion    operation is concurrent.
 @param         void
 @result        BOOL
 */
- (BOOL)isConcurrent
{
	return YES;
}

/*!
 @function      isExecuting
 @abstract      return the current status of operation.
 @discussion    operation is currently execution.
 @param         void
 @result        BOOL
 */
- (BOOL)isExecuting
{
	return executing;
}

/*!
 @function      isFinished
 @abstract      return the finish status of operation.
 @discussion    operation is finished execution.
 @param         void
 @result        BOOL
 */
- (BOOL)isFinished
{
	return finished;
}

/*!
 @function      cancel
 @abstract      cancel the current operation.
 @discussion    cancel the current operation and set the status as well
 @param         void
 @result        void
 */
- (void)cancel
{
	[super cancel];
	[self done];
}

#pragma mark -
#pragma mark Delegate Methods for NSURLConnection

//When data starts streaming in from the web service, the connection:didReceiveResponse: method will be called 
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response 
{
    @try {
        NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
        NSInteger statusCode = [httpResponse statusCode];
        
        //Lazly allocate the required buffer from http response 
        if( statusCode == 200 ) {
            
            self.contentSize = [httpResponse expectedContentLength] > 0 ? [httpResponse expectedContentLength] : 0;
            _remoteData = [[NSMutableData alloc] initWithCapacity:self.contentSize];
        } 
        else
        {
            _connectionError = nil;
            
            NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:[NSHTTPURLResponse localizedStringForStatusCode:statusCode],  nil];
            
            NSError *error = [NSError errorWithDomain:@"TEST" code:5111 userInfo:userInfo];
            _connectionError = error;
            
            [self done];
        }      
	}
	@catch (NSException * exception) {
         TRC_DBG(@"%@",exception); 
	}	
}

//As the data progressively comes in from the web service, the connection:didReceiveData: method will be called repeated
//use this method to append the data received to the webData object:
- (void)connection:(NSURLConnection *)connection 
	didReceiveData:(NSData *) data 
{
	@synchronized(self)
	{
		if( data == nil )
		{
			_remoteData = nil;
		}
		else {
			[_remoteData appendData:data];
		}
	}

}

//If there is an error during the transmission, the connection:didFailWithError: method will be called:
- (void)connection:(NSURLConnection *)connection 
  didFailWithError:(NSError *)error 
{
	@try {
        //Retain the error object for further assesment by caller
		//[_connectionError release];
        _connectionError = nil;
        
        _connectionError = error;
        
        //Release half cooked data
        //[_remoteData release];
        _remoteData = nil;
        
        //Close remote connection and update KVO
		[self done];
        
	} @catch (NSException * exception) {
       TRC_DBG(@"%@",exception);  	
	}
}

//When the connection has finished and succeeded in downloading the response, 
//the connectionDidFinishLoading: method will be called:
- (void)connectionDidFinishLoading:(NSURLConnection *)connection 
{
	[self done];  
}

- (void)connection:(NSURLConnection *)connection didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge
{
    @try {
        //Received authentication challenge
        [[challenge sender] cancelAuthenticationChallenge:challenge];
        //[_remoteData release];
        _remoteData = nil;
        [self done];        
	}
	@catch (NSException * exception) {
        TRC_DBG(@"%@",exception);  
	}
}

@end
