/* 
 File: HelpAndFAQsReqResHandler.h
 Abstract: This class is responsible set and get the FAQ question lis and resp data.
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 28/03/12
 Modified: 02/04/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>

/*!
 @class       HelpAndFAQsReqResHandler
 @abstract    This class contains Help and FAQ data
 @discussion  This class contains Help and FAQ data
 */
@interface HelpAndFAQsReqResHandler : NSObject
{
    NSArray             *_helpAndFAQsList;
    NSMutableDictionary *_helpAndFAQsDictionary;
}

- (void)setHelpAndFAQsMainList;
- (NSArray*)getHelpAndFAQsMainList;
- (void)setHelpAndFAQsSubList:(NSString*) qID;
- (NSArray*)getHelpAndFAQsSubList:(NSString*) qID;
- (NSString*)getHelpAndFAQsDetailsData:(NSString*) qMainID :(NSString*) qSubID;

@end
