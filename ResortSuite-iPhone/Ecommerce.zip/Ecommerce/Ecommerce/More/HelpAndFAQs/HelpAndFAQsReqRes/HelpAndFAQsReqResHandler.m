/* 
 File: HelpAndFAQsReqResHandler.h
 Abstract: This class is responsible set and get the FAQ question lis and resp data.
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 28/03/12
 Modified: 02/04/12
 Version: 1.0 
 */

#import "HelpAndFAQsReqResHandler.h"
#import "HelpAndFaqCommon.h"

@implementation HelpAndFAQsReqResHandler

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

/*!
 @function		setHelpAndFAQsMainList
 @abstract		set the Main FAQ list
 @discussion    set the Main FAQ list
 @param			-
 @return        -
 */
- (void)setHelpAndFAQsMainList
{
    if (_helpAndFAQsDictionary) {
        _helpAndFAQsDictionary = nil;
    }
    _helpAndFAQsDictionary = [NSMutableDictionary dictionary];    
    NSArray* helpAndFAQsMainList = [NSArray arrayWithObjects:kHelpAndFaqQuestionOne,kHelpAndFaqQuestionTwo,kHelpAndFaqQuestionThree,kHelpAndFaqQuestionFour,nil];    
    [_helpAndFAQsDictionary setObject:helpAndFAQsMainList forKey:HelpAndFaqKeyForListOne];
}


/*!
 @function		getHelpAndFAQsMainList
 @abstract		get the Main FAQ list
 @discussion    get the Main FAQ list
 @param			-
 @return        NSArray - Array list of the main FAQ list
 */
- (NSArray*)getHelpAndFAQsMainList
{
    if (_helpAndFAQsList) {
        _helpAndFAQsList = nil;
    }
    _helpAndFAQsList = [_helpAndFAQsDictionary objectForKey:HelpAndFaqKeyForListOne];  
    return _helpAndFAQsList;
}


/*!
 @function		setHelpAndFAQsSubList
 @abstract		set the Sub question FAQ list wrt main FAQ list
 @discussion    set the Sub question FAQ list wrt main FAQ list
 @param			-
 @return        -
 */
- (void)setHelpAndFAQsSubList:(NSString*) qID
{
    if (_helpAndFAQsDictionary) {
        _helpAndFAQsDictionary = nil;
    }
    _helpAndFAQsDictionary = [NSMutableDictionary dictionary];
    NSArray* helpAndFAQsSubList;
    switch ([qID intValue]) {
        case 1:
            helpAndFAQsSubList = [NSArray arrayWithObjects:kHelpAndFaqQueOneSubQueOne,kHelpAndFaqQueOneSubQueTwo,kHelpAndFaqQueOneSubQueThree,nil];      
            [_helpAndFAQsDictionary setObject:helpAndFAQsSubList forKey:qID];
            break;
        
        case 2:
            helpAndFAQsSubList = [NSArray arrayWithObjects:kHelpAndFaqQueTwoSubQueOne,kHelpAndFaqQueTwoSubQueTwo,kHelpAndFaqQueTwoSubQueThree,nil]; 
            [_helpAndFAQsDictionary setObject:helpAndFAQsSubList forKey:qID];
            break;
            
        case 3:
            helpAndFAQsSubList = [NSArray arrayWithObjects:kHelpAndFaqQueThreeSubQueOne,kHelpAndFaqQueThreeSubQueTwo,kHelpAndFaqQueThreeSubQueThree,nil]; 
            [_helpAndFAQsDictionary setObject:helpAndFAQsSubList forKey:qID];
            break;
            
        case 4:
            helpAndFAQsSubList = [NSArray arrayWithObjects:kHelpAndFaqQueFourSubQueOne,kHelpAndFaqQueFourSubQueTwo,kHelpAndFaqQueFourSubQueThree,nil]; 
            [_helpAndFAQsDictionary setObject:helpAndFAQsSubList forKey:qID];
            break;
        default:
            break;
    }
}

/*!
 @function		getHelpAndFAQsSubList
 @abstract		get the Sub question FAQ list wrt main FAQ list
 @discussion    get the Sub question FAQ list wrt main FAQ list
 @param			-
 @return        NSArray - Array list of the main FAQ list
 */
- (NSArray*)getHelpAndFAQsSubList:(NSString*) qID
{
    if (_helpAndFAQsList) {
        _helpAndFAQsList = nil;
    }
    _helpAndFAQsList = [_helpAndFAQsDictionary objectForKey:qID];  
    return _helpAndFAQsList;
}

/*!
 @function		getHelpAndFAQsDetailsData
 @abstract		get the Details of FAQ WRT Sub question FAQ and Main FAQ list
 @discussion    get the Details of FAQ WRT Sub question FAQ and Main FAQ list
 @param			-
 @return        NSString - Details of the FAQ
 */
- (NSString*)getHelpAndFAQsDetailsData:(NSString*) qMainID :(NSString*) qSubID
{
    NSString* retData = [[NSString alloc] init];
    
    switch ([qMainID intValue]) {
        case 1:
            switch ([qSubID intValue]) {
                case 1:
                    retData = kHelpAndFaqQueOneSubQueOneDetails;
                    break;
                    
                case 2:
                    retData = kHelpAndFaqQueOneSubQueTwoDetails;
                    break;    
                
                case 3:
                    retData = kHelpAndFaqQueOneSubQueThreeDetails;
                    break;
                default:
                    break;
            } 
            break;
            
        case 2:
            switch ([qSubID intValue]) {
                case 1:
                    retData = kHelpAndFaqQueTwoSubQueOneDetails;
                    break;
                    
                case 2:
                    retData = kHelpAndFaqQueTwoSubQueTwoDetails;
                    break;    
                    
                case 3:
                    retData = kHelpAndFaqQueTwoSubQueThreeDetails;
                    break;
                default:
                    break;
            } 
            break;
            
        case 3:
            switch ([qSubID intValue]) {
                case 1:
                    retData = kHelpAndFaqQueThreeSubQueOneDetails;
                    break;
                    
                case 2:
                    retData = kHelpAndFaqQueThreeSubQueTwoDetails;
                    break;    
                    
                case 3:
                    retData = kHelpAndFaqQueThreeSubQueThreeDetails;
                    break;
                default:
                    break;
            } 
            break;
            
        case 4:
            switch ([qSubID intValue]) {
                case 1:
                    retData = kHelpAndFaqQueFourSubQueOneDetails;
                    break;
                    
                case 2:
                    retData = kHelpAndFaqQueFourSubQueTwoDetails;
                    break;    
                    
                case 3:
                    retData = kHelpAndFaqQueFourSubQueThreeDetails;
                    break;
                default:
                    break;
            } 
            break;
        default:
            break;
    }
    return retData;
}

@end
