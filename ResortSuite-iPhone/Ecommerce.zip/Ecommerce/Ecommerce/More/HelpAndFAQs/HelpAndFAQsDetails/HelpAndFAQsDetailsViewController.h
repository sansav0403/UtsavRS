/* 
 File: HelpAndFAQsDetailsViewController.h
 Abstract: This class is responsible to show details of the FAQ.
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 28/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>

@interface HelpAndFAQsDetailsViewController : UIViewController


@property(nonatomic, strong) IBOutlet UITextView *txtView;
@property(nonatomic, strong) NSString *mainQueID;
@property(nonatomic, strong) NSString *subQueID;

@end
