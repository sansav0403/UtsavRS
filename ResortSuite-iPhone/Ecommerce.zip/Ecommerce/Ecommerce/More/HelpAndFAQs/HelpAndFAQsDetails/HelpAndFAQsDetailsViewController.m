/* 
 File: HelpAndFAQsDetailsViewController.h
 Abstract: This class is responsible to show details of the FAQ.
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 28/03/12
 Version: 1.0 
 */

#import "HelpAndFAQsDetailsViewController.h"
#import "HelpAndFAQsReqResHandler.h"

@implementation HelpAndFAQsDetailsViewController
@synthesize txtView = _txtView;
@synthesize mainQueID;
@synthesize subQueID;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Get the FAQ details form the handler
    HelpAndFAQsReqResHandler* handler = [[HelpAndFAQsReqResHandler alloc] init];
    
    [self.txtView setText:[handler getHelpAndFAQsDetailsData:self.mainQueID  :self.subQueID]];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
