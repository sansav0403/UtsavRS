/* 
 File: HelpAndFAQsViewController.h
 Abstract: This class is responsible to show the Help and FAQs.
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 28/03/12
 Modified: 02/04/12
 Version: 1.0 
*/

#import <UIKit/UIKit.h>

@interface HelpAndFAQsViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>
{
    NSArray *_helpAndFAQsList;
}

- (int)heightOfCellWithTitle:(NSString*)titleText;
- (UIFont*)titleTextFont;
- (void)showHelpAndFAQsListView:(NSString*) qID;

@end
