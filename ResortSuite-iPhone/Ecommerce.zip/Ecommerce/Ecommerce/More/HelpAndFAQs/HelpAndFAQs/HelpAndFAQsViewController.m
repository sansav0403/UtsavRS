/* 
 File: HelpAndFAQsViewController.m
 Abstract: This class is responsible to show the Help and FAQs.
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 28/03/12
 Version: 1.0 
 */

#import "HelpAndFAQsViewController.h"
#import "CartViewController.h"
#import "FavoriteViewController.h"
#import "HelpAndFAQsListViewController.h"
#import "HelpAndFAQsReqResHandler.h"
#import "HelpAndFaqCommon.h"

@implementation HelpAndFAQsViewController
static UIFont *titleFont;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = kHelpAndFAQsTitle;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (_helpAndFAQsList) {
        _helpAndFAQsList = nil;
    }
    //get the FAQ data from the handler
    HelpAndFAQsReqResHandler* handler = [[HelpAndFAQsReqResHandler alloc] init];
    [handler setHelpAndFAQsMainList];
    _helpAndFAQsList = [handler getHelpAndFAQsMainList];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -- TableView Delegate and datasource methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return NUMBEROFSECTIONS;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_helpAndFAQsList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString* moreIdentifier = kHelpAndFAQsCellIdentifier;
  
    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:moreIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:moreIdentifier];
    }
    [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    cell.textLabel.text = [_helpAndFAQsList objectAtIndex:indexPath.row];
    cell.textLabel.numberOfLines = 5; 
    cell.textLabel.font = [self titleTextFont];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:
(NSIndexPath *)indexPath
{ 
    NSString *title = [_helpAndFAQsList objectAtIndex:indexPath.row];     
    int height = 15 + [self heightOfCellWithTitle:title];
    return (height < CONST_Cell_height ? CONST_Cell_height : height);
}

/*!
 @function		titleTextFont
 @abstract		get current system font.
 @discussion    get current system font.
 @param			
 @return        UIFont - current system font
 */
- (UIFont*)titleTextFont{ 
    if (!titleFont) 
        titleFont = [UIFont systemFontOfSize:CONST_textLabelFontSize]; 
    return titleFont;
}

/*!
 @function		heightOfCellWithTitle
 @abstract		return the height of cell.
 @discussion    calculate the height of the cell deppending on the cell text.
 @param			NSString - cell text
 @return        int - height of the cell
 */
- (int)heightOfCellWithTitle:(NSString*)titleText
{ 
    CGSize titleSize = {0, 0}; 
    
    if (titleText && ![titleText isEqualToString:@""])
        titleSize = [titleText sizeWithFont:[self titleTextFont] constrainedToSize:CGSizeMake(CONST_Cell_width, CONST_Cell_Max_height)         
                              lineBreakMode:UILineBreakModeWordWrap];
    
    return titleSize.height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
    switch (indexPath.row) {
        case 0:
        {
            [self showHelpAndFAQsListView:QUE_ID_ONE];
            break;
        }
        
        case 1:
        {
            [self showHelpAndFAQsListView:QUE_ID_TWO];
            break;
        }   
        
        case 2:
        {
            [self showHelpAndFAQsListView:QUE_ID_THREE];
            break;
        } 
         
        case 3:
        {
            [self showHelpAndFAQsListView:QUE_ID_FOUR];
            break;
        } 
            
        default:
            break;
    }
}

/*!
 @function		showHelpAndFAQsListView
 @abstract		Launch the HelpAndFAQsListView.
 @discussion    Launch the HelpAndFAQsListView.
 @param			NSString - question ID
 @return        
 */
- (void)showHelpAndFAQsListView:(NSString*) qID
{
    HelpAndFAQsListViewController* cartViewController = [[HelpAndFAQsListViewController alloc]initWithNibName:kHelpAndFAQsListViewControllerNibName bundle:[NSBundle mainBundle]];
    cartViewController.queID = qID;
    [self.navigationController pushViewController:cartViewController animated:YES];
}

@end
