/* 
 File: HelpAndFaqCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for Help and FAQ module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

//Request Handlers
#define HelpAndFaqKeyForListOne @"HelpAndFAQsList"
#define kHelpAndFAQsCellIdentifier      @"helpAndFAQsIdentifier"
#define kHelpAndFAQsListCellIdentifier  @"helpAndFAQsListIdentifier"

#define kHelpAndFAQsTitle               NSLocalizedString(@"Help & FAQs", @"")

//Help And FAQs List-1
#define kHelpAndFaqQuestionOne                  @"About Order"
#define kHelpAndFaqQuestionTwo                  @"My Account and My Orders"
#define kHelpAndFaqQuestionThree                @"Shopping"
#define kHelpAndFaqQuestionFour                 @"Shipping And Delivery"

//Help And FAQs List Qustion One's sub question
#define kHelpAndFaqQueOneSubQueOne              @"What is an order number?"
#define kHelpAndFaqQueOneSubQueTwo              @"How do I check the status of my order"
#define kHelpAndFaqQueOneSubQueThree            @"What happen to my order invoice if the item purchased is not available"

//Help And FAQs List Qustion Twos's sub question
#define kHelpAndFaqQueTwoSubQueOne              @"What is My Account?"
#define kHelpAndFaqQueTwoSubQueTwo              @"How do I know my order has been confirmed?"
#define kHelpAndFaqQueTwoSubQueThree            @"Is it possible to order a product that is 'Out of Stock'?"

//Help And FAQs List Qustion Three's sub question
#define kHelpAndFaqQueThreeSubQueOne              @"Why are there varying prices for the same titled book?"
#define kHelpAndFaqQueThreeSubQueTwo              @"Is it necessary to have a Account to shop?"
#define kHelpAndFaqQueThreeSubQueThree            @"How are items packaged?"

//Help And FAQs List Qustion Four's sub question
#define kHelpAndFaqQueFourSubQueOne              @"How much are the delivery charges?"
#define kHelpAndFaqQueFourSubQueTwo              @"What about warranty and hidden costs (sales tax, octroi etc.)?"
#define kHelpAndFaqQueFourSubQueThree            @"Why does the estimated delivery time vary from product to product?"

//Help And FAQs List Qustion One's sub question details
#define kHelpAndFaqQueOneSubQueOneDetails              @"An Order number is used to reference your order by our ordering syste. It you have lost your order number and want to retrieve it please call us at 1-800-913-6119 or 1-800-214-4489 (then press 2) and provide us with your order date and the full anme you used in the billing section (not ship to section) of the checkout page when you made your purchase."
#define kHelpAndFaqQueOneSubQueTwoDetails              @"To check the order status please call us at 1-800-214-4489 then press 9 and enter your order number"
#define kHelpAndFaqQueOneSubQueThreeDetails            @"If order purchased is not available then order invoice get cancelled and the amount paid to purchase the order get revert back in your account in 4 working days."

//Help And FAQs List Qustion Twos's sub question Details
#define kHelpAndFaqQueTwoSubQueOneDetails              @"You can view and update your account details through 'More' --> 'Account Info'"
#define kHelpAndFaqQueTwoSubQueTwoDetails              @"Once your payment has been successfully made, your order is processed internally (and immediately). Will send a confirmation mail for your order, to the email address associated with your order/account. In this mail you will be provided with a unique Order ID (eg. OD01202130213) for your reference with our customer service team, a listing of the item/s you have ordered and an expected time of delivery."
#define kHelpAndFaqQueTwoSubQueThreeDetails            @"Unfortunately, we do not have these products available for sale."

//Help And FAQs List Qustion Three's sub question Details
#define kHelpAndFaqQueThreeSubQueOneDetails              @"Offers various editions of the same titled book. Some editions might be collector's first/earlier prints. Some editions might be hardcover, while some might be paperback - as mentioned on the product page. Some editions might be re-published/printed within India, while some editions may be imported. We mention the various editions and alternative prices available for a particular title on the respective product pages under 'Other Editions'."
#define kHelpAndFaqQueThreeSubQueTwoDetails              @"While it is not necessary to have a Account to shop and purchase items, it is certainly recommended to have one. You can shop by providing just your email ID."
#define kHelpAndFaqQueThreeSubQueThreeDetails            @"All items are carefully packaged at our warehouses - as to avoid any form of damage. We ensure the package is water proof with plastic wrap and fragile (electronic) items are safely secured with bubble wrap."

//Help And FAQs List Qustion Four's sub question Details
#define kHelpAndFaqQueFourSubQueOneDetails              @"We provides free delivery on all items if your total order amount is Rs. 200/- or more. Otherwise Rs. 30/- is charged as delivery charges."
#define kHelpAndFaqQueFourSubQueTwoDetails              @"There are no extra taxes, hidden costs or additional shipping charges. The  mentioned price is the final price. What you see is what you pay. Our prices are all inclusive. All taxes are included with the list prices."
#define kHelpAndFaqQueFourSubQueThreeDetails            @"Items which are labeled 'In Stock' on their respective product pages, are stocked in our various warehouses and usually takes 2-3 business days to reach our customers. Items which we will need to procure or import, are labeled 'Imported' on their respective product pages - the delivery of these items can vary between 2 and 4 weeks. Products which you can pre-book, and are labeled as 'Forthcoming' are dispatched on the release date of the particular product - release dates are mentioned on the product page."


//nib names
#define kHelpAndFAQsListViewControllerNibName             @"HelpAndFAQsListViewController"
#define kHelpAndFAQsDetailsViewController             @"HelpAndFAQsDetailsViewController"

//View Controllers
//For Cell
#define NUMBEROFSECTIONS 1
#define CONST_Cell_height 44.0f
#define CONST_Cell_width 270.0f
#define CONST_textLabelFontSize    15
#define CONST_Cell_Max_height 4000
#define k15Title        15
#define k5Title         5

//For Question IDs
#define QUE_ID_ONE      @"1"
#define QUE_ID_TWO      @"2"
#define QUE_ID_THREE    @"3"
#define QUE_ID_FOUR     @"4"

//For Cell
#define NUMBEROFSECTIONS 1
#define CONST_Cell_height1 54.0f
#define CONST_Cell_width 270.0f
#define CONST_textLabelFontSize    15

//For Sub-Question IDs
#define SUB_QUE_ID_ONE      @"1"
#define SUB_QUE_ID_TWO      @"2"
#define SUB_QUE_ID_THREE    @"3"
#define SUB_QUE_ID_FOUR     @"4"

#define kHelpAndFAQsTitle           NSLocalizedString(@"Help & FAQs", @"")

