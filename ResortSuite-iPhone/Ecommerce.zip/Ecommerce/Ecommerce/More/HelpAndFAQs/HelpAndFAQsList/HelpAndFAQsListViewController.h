/* 
 File: HelpAndFAQsListViewController.h
 Abstract: This class is responsible to show the Help and FAQs Sub question List.
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 28/03/12
 Version: 1.0 
*/

#import <UIKit/UIKit.h>

/*!
 @class       HelpAndFAQsViewController
 @abstract    This class contains Help and FAQ sub question List
 @discussion  This class contains Help and FAQ sub question List
 */
@interface HelpAndFAQsListViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>
{
    NSArray *_helpAndFAQsList;
}

@property(nonatomic, strong) NSString *queID;

- (int)heightOfCellWithTitle:(NSString*)titleText;
- (UIFont*)titleTextFont;
- (void)showHelpAndFAQsDetailsView:(NSString*) subQueID;

@end
