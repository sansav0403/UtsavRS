/* 
 File: ShippingBillingAddress.h
 Abstract: This is a base class for Shipping and Billing address information.
 Author: Cybage Software Pvt. Ltd
 Created: 17/05/12
 Modified: 17/05/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "Address.h"

@interface ShippingBillingAddress : Address

@property(nonatomic, strong) NSString   *firstName;
@property(nonatomic, strong) NSString   *lastName;
@property(nonatomic, strong) NSString   *company;
@property(nonatomic, strong) NSString   *parentId;

@end
