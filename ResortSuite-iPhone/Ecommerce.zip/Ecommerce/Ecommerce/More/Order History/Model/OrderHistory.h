/* 
 File: OrderHistory.h
 Abstract: This Model is the controller class for Order History.
 Author: Cybage Software Pvt. Ltd
 Created: 07/23/12
 Modified: 07/23/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "CartInfo.h"

@interface OrderHistory : CartInfo

@property(nonatomic, strong) NSString                  *orderId;
@property(nonatomic, strong) NSString                  *orderDate;
@property(nonatomic, strong) NSString                  *orderNumber;
@property(nonatomic, strong) NSString                  *orderStatus;
@property(nonatomic, strong) NSString                  *orderTotal;
@property(nonatomic, strong) NSString                  *totalQuantityOrdered;
@property(nonatomic, strong) NSString                  *deliveryDate;
@property(nonatomic, strong) NSMutableArray            *shipBillAddressArray;

@end
