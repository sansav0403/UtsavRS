/* 
 File: ShippingBillingAddress.m
 Abstract: This is a base class for Shipping and Billing address information.
 Author: Cybage Software Pvt. Ltd
 Created: 17/05/12
 Modified: 17/05/12
 Version: 1.0 
 */

#import "ShippingBillingAddress.h"

@implementation ShippingBillingAddress

@synthesize firstName = _firstName;
@synthesize lastName = _lastName;
@synthesize company = _company;
@synthesize parentId = _parentId;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
