/* 
 File: OrderHistory.m
 Abstract: This Model is the controller class for Order History.
 Author: Cybage Software Pvt. Ltd
 Created: 07/23/12
 Modified: 07/23/12
 Version: 1.0 
 */

#import "OrderHistory.h"

@implementation OrderHistory

@synthesize orderId = _orderId;
@synthesize orderDate = _orderDate;
@synthesize orderNumber = _orderNumber;
@synthesize orderStatus = _orderStatus;
@synthesize orderTotal = _orderTotal;
@synthesize deliveryDate = _deliveryDate;
@synthesize shipBillAddressArray = _shipBillAddressArray;
@synthesize totalQuantityOrdered = _totalQuantityOrdered;  

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        self.shipBillAddressArray = [[NSMutableArray alloc]init];
    }
    
    return self;
}

@end
