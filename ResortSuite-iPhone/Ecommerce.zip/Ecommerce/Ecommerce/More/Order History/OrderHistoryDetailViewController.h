/* 
 File: OrderHistoryDetailViewController.h
 Abstract: This is a View Controoler class for order history detail.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "OrderHistory.h"
#import "OrderHistoryReqResHandler.h"

@interface OrderHistoryDetailViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,NetworkRequestResponseBaseDelegate>
{
    OrderHistory                *_orderHistory;
    OrderHistoryReqResHandler   *_orderHistoryReqResHandler;
}

@property(nonatomic, strong) NSString               *orderHistoryId;
@property(nonatomic, weak) IBOutlet UITableView     *orderHistoryDetailTableView;

@end
