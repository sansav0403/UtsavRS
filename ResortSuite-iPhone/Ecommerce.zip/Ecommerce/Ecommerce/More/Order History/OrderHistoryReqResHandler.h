/* 
 File: OrderHistoryReqResHandler.h
 Abstract: This is a request handler class for Order History Module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "NetworkRequestResponseBase.h"
#import "OrderHistory.h"

typedef enum {
    kOrderHistoryListRquest,
    kOrderHistoryDetailsRequest
}OrderHistoryHandlerRequestState;


@interface OrderHistoryReqResHandler : NetworkRequestResponseBase

@property(nonatomic, strong) NSString             *sessionId;
@property(nonatomic, strong) NSMutableArray       *orderHistoryListArray;
@property(nonatomic, strong) NSString             *orderId;
@property(nonatomic, strong) OrderHistory         *orderHistoryModel;
@property(nonatomic)   OrderHistoryHandlerRequestState  requestState;

- (void) orderHistoryList:(NSMutableArray*)orderListArray;
- (void) orderDetailForOrderId:(NSString* )orderHistoryId orderHistory:(OrderHistory*)orderHistory;
- (void)requestWithSoapMessage:(NSString *)soapMsg; 
- (void) didReceiveData:(NSData*)data;

@end
