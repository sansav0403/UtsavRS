/* 
 File: OrderHistoryDetailViewController.m
 Abstract: This is a View Controoler class for order history detail.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "OrderHistoryDetailViewController.h"
#import "OrderHistoryDetailTopCustomCell.h"
#import "OrderHistorySummaryCell.h"
#import "OrderHistoryDetailShippingCustomCell.h"
#import "CartListCustomCell.h"
#import "OrderHistoryCommon.h"
#import "ShippingBillingAddress.h"


@implementation OrderHistoryDetailViewController
@synthesize orderHistoryId = _orderHistoryId;
@synthesize orderHistoryDetailTableView = _orderHistoryDetailTableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = kOrderHistoryDetailTitle;
    
    // Do any additional setup after loading the view from its nib.
    if (_orderHistory) {
        _orderHistory = nil;
    }
    _orderHistory = [[OrderHistory alloc] init];
    _orderHistoryReqResHandler = [[OrderHistoryReqResHandler alloc]init];
    
    //get the product details from the server
    [_orderHistoryReqResHandler setDelegate:self];
    [_orderHistoryReqResHandler orderDetailForOrderId:self.orderHistoryId orderHistory:_orderHistory];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_orderHistoryReqResHandler setDelegate:nil];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark -- TableView Delegate and Datasource methods
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == kSection0) 
    {
        static NSString * CellIdentifier = kOrderHistoryDetailTopCustomCell;
        
        OrderHistoryDetailTopCustomCell* cell = (OrderHistoryDetailTopCustomCell* )[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil) {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell = (OrderHistoryDetailTopCustomCell *)[nib objectAtIndex:0];        
        } 
        
        cell.orderNumberLabelDet.text = _orderHistory.orderId;
        cell.orderDateLabelDet.text = _orderHistory.orderDate;
        cell.orderTotalLabelDet.text = _orderHistory.orderTotal;
        cell.orderStatusLabelDet.text = _orderHistory.orderStatus;
        return cell;
    }
    else if (indexPath.section == kSection1) 
    {
        if ( indexPath.row < [_orderHistory.productArray count]) 
        {
            static NSString * CellIdentifier1 = kCartListCustomCell;
            
            CartListCustomCell* cell = (CartListCustomCell* )[tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
            
            if (cell == nil) {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:CellIdentifier1 owner:self options:nil];
                cell = (CartListCustomCell *)[nib objectAtIndex:0];        
            } 
            
            CartList *cartList = [_orderHistory.productArray objectAtIndex:indexPath.row];
            [cartList setDelegate:cell];
            [cell setCartListData:cartList];
            
             //Code to set the image                        
             if(!cartList.imageUrl)
             {
                 [cartList imageUrlForProduct];
             }
            
            return cell;
        }
        else
        {
            static NSString * CellIdentifier = kOrderHistorySummaryCell;
            
            OrderHistorySummaryCell* cell = (OrderHistorySummaryCell* )[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            
            if (cell == nil) {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
                cell = (OrderHistorySummaryCell *)[nib objectAtIndex:0];        
            } 
            
            cell.orderNumber.text = _orderHistory.orderId;
            cell.shippingPrice.text = _orderHistory.shippingAmount;
            cell.total.text = _orderHistory.orderTotal;
            return cell;
        }
        
    }
    else if (indexPath.section == kSection2)
    {
        static NSString * CellIdentifier = kOrderHistoryDetailShippingCustomCell;
        
        OrderHistoryDetailShippingCustomCell* cell = (OrderHistoryDetailShippingCustomCell* )[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        
        if (cell == nil) {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
            cell = (OrderHistoryDetailShippingCustomCell *)[nib objectAtIndex:0];        
        } 
        
        ShippingBillingAddress *shipBillAddress = nil;
        for (int addressCount = 0; addressCount < [_orderHistory.shipBillAddressArray count]; addressCount++) {
             shipBillAddress = [_orderHistory.shipBillAddressArray objectAtIndex:addressCount];           
            NSString *shippingTitle = kShippingTitle;
            
            if ([shipBillAddress.addressType isEqualToString:shippingTitle]) {
                cell.shippingLine1.text = shipBillAddress.company;
                cell.shippingLine2.text = [NSString stringWithFormat:@"%@, %@, %@",shipBillAddress.street, shipBillAddress.city, shipBillAddress.region];
            }
        }
        
        cell.deliveryDate.text = _orderHistory.deliveryDate;
        return cell;
    }
        else
            return nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == kSection1) {
        return kOrderHistoryDetailSummary;
    }
    if (section == kSection2) {
        return kOrderHistoryDetailShippingAddress;
    }
    else
        return nil;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == kSection0) {
        return kRowsInsection0;
    }
    if (section == kSection1) {
        return [_orderHistory.productArray count] + 1;
    }
    if (section == kSection2) {
        return kRowsInsection1;
    }
    else
        return 0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return kNumberOfSectionsForDetailPage;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == kSection0) 
    {
        return kRowHeightSection0;
    } 
    else if (indexPath.section == kSection1) 
    {
        if ([_orderHistory.productArray count] > indexPath.row) {
            return kRowHeightSection1;
        }
        else
        {
           return kRowHeightSection0; 
        }
        
    } 
    else if (indexPath.section == kSection2)
    {
        return kRowHeightSection2;
    }    
    else
        return kRowHeightDefault;
}


#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) {
        TRC_DBG(@"fail to load data from URL");
    }
    else
    {
       //Reload data
        [self.orderHistoryDetailTableView reloadData];
    }        
}

@end
