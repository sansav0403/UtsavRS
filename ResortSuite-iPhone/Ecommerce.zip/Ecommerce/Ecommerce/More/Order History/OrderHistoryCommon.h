/* 
 File: OrderHistoryCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for Order History module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

//OrderHistoryViewController
#define kBlackViewFrame  CGRectMake(0, 0, 320, 480)
#define kBlackViewAlpha 0.5
#define kDatePickerNavBarFrame CGRectMake(0, 226, 320, 44)
#define kPickerViewFrame CGRectMake(0,0,320,480)
#define kPickerDoneButtonFrame CGRectMake(9, 8, 48, 28)
#define kPickerCancelButtonFrame CGRectMake(255, 8, 55, 28)
#define kDatePickerFrame CGRectMake(0,270,320,175)
#define kDateFormatter @"yyyy-dd-MMM"
#define kDoneButtonTitle @"Done"
#define kCancelButtonTitle @"Cancel"
#define kOrderHistoryListCustomCell @"OrderHistoryListCustomCell"
#define kOrderHistoryDetailViewController  @"OrderHistoryDetailViewController"
#define kNumberOfSections   1
#define k0Title             0
#define k1Title             1
#define k2Title             2
#define k60Title             60

#define kShippingTitle      @"shipping"
#define kBillingTitle       @"billing"

#define kWarningTitle         NSLocalizedString(@"Warning",@"")
#define kDateWarningMsgTitle  NSLocalizedString(@"From_Date_should_be_prior_to_To_Date",@"") 

//Order History Request Response Handler
#define kServerUrl                  @"http://172.27.47.116"
#define kGet                        @"GET"
#define kOrderHistoryDetailsAPI     @"sales_order.info" //@"OrderHistoryDetail.xml"
#define kOrderHistoryListAPI        @"sales_order.list" //@"OrderHistoryList.xml"

//Order History
#define kOrderHistoryXMLTag         @"Order"
#define kOrderIdXMLTag              @"increment_id" //@"id"
#define kOrderGrandTotalXMLTag      @"grand_total"
#define kOrderShippingAmountXMLTag  @"shipping_amount"
#define kOrderShippingDescription   @"shipping_description"
#define kOrderQtyOrderedXMLTag      @"total_qty_ordered"
#define kOrderSubTotalXMLTag        @"subtotal"
#define kOrderCurrencyXMLTag        @"base_currency_code"
#define kOrderDateXMLTag            @"created_at"
#define kOrderNumberXMLTag          @"OrderNumber"
#define kOrderStatusXMLTag          @"status"
#define kIdXMLTag                   @"id"
#define kOrderShippingAddressXMLTag @"shipping_address"
#define kOrderBillingAddressXMLTag  @"billing_address"
#define kOrderedQuantityXMLTag      @"qty_ordered"
#define kOrderRowTotalyXMLTag       @"row_total"

//Order History Detail Page

#define kOrderHistoryDetailSummary              @"Summary"

#define kOrderHistoryDetailXMLTag               @"Order"
#define kOrderHistoryDetailOrderNumberXMLTag    @"OrderNumber"
#define kOrderHistoryDetailOrderDateXMLTag      @"OrderDate"
#define kOrderHistoryDetailTotalXMLTag          @"Total"
#define kOrderHistoryDetailStatusXMLTag         @"Status"
#define kOrderHistoryDetailSummaryXMLTag        @"Summary"
#define kOrderHistoryDetailSummary              @"Summary"


#define kOrderHistoryDetailXMLTag               @"Order"
#define kOrderHistoryDetailOrderNumberXMLTag    @"OrderNumber"
#define kOrderHistoryDetailOrderDateXMLTag      @"OrderDate"
#define kOrderHistoryDetailTotalXMLTag          @"Total"
#define kOrderHistoryDetailStatusXMLTag         @"Status"
#define kOrderHistoryDetailSummaryXMLTag        @"Summary"
#define kOrderHistoryDetailProdArrayXMLTag      @"ProductArray"


#define kOrderHistoryDetailShippingAddress      @"ShippingAddress"
#define kOrderHistoryDetailShippingline1XMLTag  @"line1"
#define kOrderHistoryDetailShippingline2XMLTag  @"line2"

#define kOrderHistoryDetailProductXMLTag            @"Product"
#define kOrderHistoryDetailProdNameXMLTag           @"Name"
#define kOrderHistoryDetailProdQuantityXMLTag       @"Quantity"
#define kOrderHistoryDetailProdShippingXMLTag       @"Shipping"
#define kOrderHistoryDetailProdWarrantyXMLTag       @"Warranty"
#define kOrderHistoryDetailProdPriceXMLTag          @"Price"
#define kOrderHistoryDetailProdPriceCurrencyXMLTag  @"currency"
#define kOrderHistoryDetailProdImageUrlXMLTag       @"ImageUrl"

#define kOrderHistoryDetailDeliveryDateXMLTag       @"DeliveryDate"

#define kOrderHistoryDetailShippingXMLTag           @"Shipping"
#define kOrderHistoryDetailShippingline1XMLTag      @"line1"
#define kOrderHistoryDetailShippingline2XMLTag      @"line2"

//Detail Page
#define kOrderHistoryDetailTitle                    @"Order History Details"
#define kOrderHistoryDetailTopCustomCell            @"OrderHistoryDetailTopCustomCell"
#define kCartListCustomCell                         @"CartListCustomCell"
#define kOrderHistorySummaryCell                    @"OrderHistorySummaryCell"
#define kOrderHistoryDetailShippingCustomCell       @"OrderHistoryDetailShippingCustomCell"
#define kRowsInsection0 1
#define kRowsInsection1 1
#define kNumberOfSectionsForDetailPage 3
#define kSection0 0
#define kSection1 1
#define kSection2 2
#define kRowHeightSection0 95.0
#define kRowHeightSection1 85.0
#define kRowHeightSection2 100.0
#define kRowHeightDefault 44.0










