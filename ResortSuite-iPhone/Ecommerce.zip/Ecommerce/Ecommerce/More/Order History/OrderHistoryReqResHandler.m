/* 
 File: OrderHistoryReqResHandler.h
 Abstract: This is a request handler class for Order History Module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "OrderHistoryReqResHandler.h"
#import "OrderHistoryXMLParser.h"
#import "OrderHistoryCommon.h"
#import "Common.h"
#import "UserExtended.h"

@implementation OrderHistoryReqResHandler
@synthesize sessionId = _sessionId;
@synthesize orderId = _orderId;;
@synthesize orderHistoryListArray = _orderHistoryListArray;
@synthesize orderHistoryModel = _orderHistoryModel;
@synthesize requestState;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        UserExtended *userExt = [UserExtended sharedUserExteded];
        self.sessionId = userExt.sessionId;
    }
    
    return self;
}


/*!
 @function		orderHistoryList
 @abstract		get order History list information.
 @discussion    parse order list.
 @param			orderListA - result will be return in this array 
 */
- (void)orderHistoryList:(NSMutableArray*)orderListArray
{
    self.orderHistoryListArray = orderListArray;
    self.requestState = kOrderHistoryListRquest;
        
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:anyType\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kOrderHistoryListAPI,nil];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}


/*!
 @function		orderDetailForOrderId
 @abstract		get order History Detail.
 @discussion    parse order history.
 @param			orderHistoryId - orderHistory,result will be returned in this model object 
 */
- (void) orderDetailForOrderId:(NSString* )orderHistoryId orderHistory:(OrderHistory *)orderHistory
{
    self.orderId = orderHistoryId;
    TRC_DBG(@"sales.orderID =%@",self.orderId);
    self.orderHistoryModel = orderHistory;
    
    self.requestState = kOrderHistoryDetailsRequest;
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:int\">%d</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kOrderHistoryDetailsAPI,[self.orderId intValue]];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		requestWithSoapMessage
 @abstract		request to server with soap request object.
 @discussion	request to server with soap request object.
 @param			soapMsg - soap message 
 @result		void
 */
- (void)requestWithSoapMessage:(NSString *)soapMsg 
{
    //create a url load request
    NSURL *url = [NSURL URLWithString: kMagentoServerUrl];
    NSMutableURLRequest *req = nil;
    req = [NSMutableURLRequest requestWithURL:url];
    
    //populate the request object with the various headers,
    //such as Content-Type, SOAPAction, and Content-Length. You also set the HTTP method and HTTP body:
    NSString *msgLength = nil;
    msgLength = [NSString stringWithFormat:@"%d", [soapMsg length]];    
    [req addValue:kContentTypeValue  forHTTPHeaderField:kContentType];
    [req addValue:kAcceptEncodingValue  forHTTPHeaderField:kAcceptEncoding];
    [req addValue:kUserAgentValue  forHTTPHeaderField:kUserAgent];
    [req addValue:kHostValue forHTTPHeaderField:kHost];    
    [req addValue:kSoapActionValue forHTTPHeaderField:kSoapAction];
    [req addValue:msgLength forHTTPHeaderField:kContentLength];
    [req setHTTPMethod:kPost];
    [req setHTTPBody:[soapMsg dataUsingEncoding:NSUTF8StringEncoding]];
    
    [self.netDataManager makeRequest:req];
}

#pragma mark -- Delegate method called when we recieve the data.
- (void)didReceiveData:(NSData*)data
{
    //NSString* newStr = [NSString stringWithUTF8String:[data bytes]];
    //TRC_DBG(@"NSData = %@",newStr);
    OrderHistoryXMLParser *orderHistoryXMLParser = [[OrderHistoryXMLParser alloc]init];
    
    switch (self.requestState) 
    {
        case kOrderHistoryListRquest:
        {
            [orderHistoryXMLParser parseXMLDataForOrderHistory:(NSData *)data orderHistoryList:self.orderHistoryListArray];
            TRC_DBG(@"Cart Count count=%d",[self.orderHistoryListArray count]);
            break;
        }
            
        case kOrderHistoryDetailsRequest:
        {
            [orderHistoryXMLParser parseXMLDataForOrderHistoryDetails:data orderId: self.orderId orderHistoryModel:self.orderHistoryModel];
            break;
        }
        default:
            break;
    }
    //Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:nil];
	}
    
}

@end
