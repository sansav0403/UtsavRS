/* 
 File: OrderHistoryXMLParser.h
 Abstract: This is a xml parser class for Order History Module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "OrderHistory.h"
#import "XMLParser.h"
#import "ShippingBillingAddress.h"

@interface OrderHistoryXMLParser : XMLParser

@property(nonatomic, strong) OrderHistory *orderHistoryModel;
@property(nonatomic, strong) NSMutableArray *orderHistoryArray;

- (void) parseXMLDataForOrderHistory:(NSData *)data orderHistoryList:(NSMutableArray *)orderHistoryList;

- (void)parseXMLDataForOrderHistoryDetails:(NSData *)dataToBeParsed orderId:(NSString *)orderId orderHistoryModel:(OrderHistory *)orderHistory;

- (void)addressData:(NSMutableDictionary *)addressDic;

@end
