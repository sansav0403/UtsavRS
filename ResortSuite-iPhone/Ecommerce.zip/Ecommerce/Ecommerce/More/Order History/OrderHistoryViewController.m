/* 
 File: OrderHistoryViewController.h
 Abstract: This class is the controller class for Order History.
 Author: Cybage Software Pvt. Ltd
 Created: 07/23/12
 Modified: 07/23/12
 Version: 1.0 
 */

#import "OrderHistoryViewController.h"
#import "EcommerceAppDelegate.h"
#import "OrderHistoryListCustomCell.h"
#import "OrderHistoryDetailViewController.h"
#import "OrderHistoryCommon.h"
#import "Common.h"
#import "Message.h"

@implementation OrderHistoryViewController
@synthesize orderHistoryTableView = _orderHistoryTableView;
@synthesize toDateButton = _toDateButton;
@synthesize fromDateButton = _fromDateButton;
@synthesize toDate = _toDate;
@synthesize fromDate = _fromDate;
@synthesize orderHistoryArray = _orderHistoryArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    //Initially set the toDate and the fromDate as current date and one month prior to current date.
    self.title = kOrderHistoryTitle;
    //from Date
    NSDate *today = [[NSDate alloc] init];
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    [offsetComponents setMonth:-k1Title]; // note that setting it to -1
    NSDate *oneMonthPrior = [gregorian dateByAddingComponents:offsetComponents toDate:today options:k0Title];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:kDateFormatter]; 
    self.fromDate = [formatter stringFromDate:oneMonthPrior];
    [self.fromDateButton setTitle:self.fromDate forState:UIControlStateNormal];
    [self.fromDateButton setTitle:self.fromDate forState:UIControlStateHighlighted];
    
    //to date
    self.toDate = [formatter stringFromDate:[NSDate date]];
    [self.toDateButton setTitle:self.toDate forState:UIControlStateNormal];
    [self.toDateButton setTitle:self.toDate forState:UIControlStateHighlighted];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*!
 @function      toButtonClicked
 @abstract      date picker for toDate
 @discussion    date 
 @param         nil 
 @result        void
 */
- (IBAction)toButtonClicked:(id)sender
{
    _toFrom = 1;
    [self showDatePicker:(UIButton*)sender];
}


/*!
 @function      fromButtonClicked
 @abstract      date picker for fromDate
 @discussion    date 
 @param         nil 
 @result        void
 */
- (IBAction)fromButtonClicked:(id)sender
{
    _toFrom = 2;
    [self showDatePicker:(id)sender]; 
}

/*!
 @function      showDatePicker
 @abstract      displays date picker on the screen
 @discussion    date 
 @param         sender 
 @result        void
 */
- (void)showDatePicker:(id)sender
{
    _blackView = [[UIView alloc]initWithFrame:kBlackViewFrame];
    [_blackView setBackgroundColor:[UIColor blackColor]];
    [_blackView setAlpha:kBlackViewAlpha];
    EcommerceAppDelegate* appDelegate = (EcommerceAppDelegate*)[[UIApplication sharedApplication] delegate];
    [appDelegate.window addSubview:_blackView];
    
    _pickerView = [[UIView alloc]initWithFrame:kPickerViewFrame]; 
    [_pickerView setBackgroundColor:[UIColor clearColor]];
    UINavigationBar* navBar = [[UINavigationBar alloc]initWithFrame:kDatePickerNavBarFrame];
    navBar.tintColor = [UIColor blackColor];
    
    //Add done and cancel button on the navBar
    UIButton* doneButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    doneButton.titleLabel.textColor = [UIColor blackColor];
    [doneButton setTitle:kDoneButtonTitle forState:UIControlStateNormal];
    doneButton.frame = kPickerDoneButtonFrame;
    [doneButton addTarget:self action:@selector(datePickerDone) forControlEvents:UIControlEventTouchUpInside];
    [navBar addSubview:doneButton];
    
    UIButton* cancelButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    cancelButton.titleLabel.textColor = [UIColor blackColor];
    [cancelButton setTitle:kCancelButtonTitle forState:UIControlStateNormal];
    cancelButton.frame = kPickerCancelButtonFrame;
    [cancelButton addTarget:self action:@selector(datePickerCancel) forControlEvents:UIControlEventTouchUpInside];
    [navBar addSubview:cancelButton];
    
    _datePicker = [[UIDatePicker alloc] initWithFrame:kDatePickerFrame];
    _datePicker.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    [_datePicker setDatePickerMode:UIDatePickerModeDate];
    
    [_datePicker addTarget:self
                   action:@selector(getDateValue)
          forControlEvents:UIControlEventValueChanged];
    
    [_pickerView addSubview:navBar];
    [_pickerView addSubview:_datePicker];
    [appDelegate.window addSubview:_pickerView];

}

/*!
 @function      getDateValue
 @abstract      This method will automatically set the date value whenever the picker is updated
 @discussion    This method will automatically set the date value whenever the picker is updated 
 @result        void
 */
- (void) getDateValue
{
    
}

/*!
 @function      datePickerCancel
 @abstract      selector method for cancel button on the date picker view.
 @discussion    date 
 @param         nil 
 @result        void
 */
 - (void) datePickerCancel
{
    [_pickerView removeFromSuperview];
    [_blackView removeFromSuperview];
}

/*!
 @function      datePickerDone
 @abstract      selector method for done button on the date picker view. Updates the date also.
 @discussion    date 
 @param         nil 
 @result        void
 */
- (void)datePickerDone
{
    if (_toFrom == 1) {
        //toDate
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:kDateFormatter]; 
        self.toDate = [formatter stringFromDate:_datePicker.date];
        [self.toDateButton setTitle:self.toDate forState:UIControlStateNormal];
        [self.toDateButton setTitle:self.toDate forState:UIControlStateHighlighted];
        TRC_DBG(@"toDate:%@",self.toDate);
    }
    if (_toFrom == 2) {
        //from date
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:kDateFormatter]; 
        self.fromDate = [formatter stringFromDate:_datePicker.date];
        [self.fromDateButton setTitle:self.fromDate forState:UIControlStateNormal];
        [self.fromDateButton setTitle:self.fromDate forState:UIControlStateHighlighted];
        TRC_DBG(@"toDate:%@",self.fromDate);
    }
    [_pickerView removeFromSuperview];
    [_blackView removeFromSuperview];
}


/*!
 @function      getOrderHistoryDetails
 @abstract      Action Method to get the order history details.
 @discussion    Order History 
 @param         sender 
 @result        void
 */
- (IBAction)getOrderHistoryDetails:(id)sender
{
    //Check if the from date is less than todate.
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:kDateFormatter];
    
    NSDate *tDate = [formatter dateFromString:self.toDate];
    
    NSDate *fDate = [formatter dateFromString:self.fromDate];
    
    int intervall = (int) [tDate timeIntervalSinceDate: fDate] / k60Title;
    
    //If yes, go ahead, otherwise show an alert view.
    if (intervall > k0Title) 
    {
        TRC_DBG(@"Show the data");
        //Call the webservices.
        [self getOrderList];        
    }
    else
    {
        [Message showOKOnly:kWarningTitle alertMessage:kDateWarningMsgTitle setDelegate:nil];
        return;
    }
}


/*!
 @function      getOrderList
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void) getOrderList
{
    if (_orderHistoryReqResHandler){
        [_orderHistoryReqResHandler setDelegate:nil];
    }
    _orderHistoryReqResHandler = [[OrderHistoryReqResHandler alloc]init];
    
    //get the order history from the server
	if(self.orderHistoryArray)
	{
        self.orderHistoryArray = nil;
	}
    self.orderHistoryArray = [[NSMutableArray alloc] init];	
    [_orderHistoryReqResHandler setDelegate:self];
    [_orderHistoryReqResHandler orderHistoryList:self.orderHistoryArray];
}

- (void)parseComplete:(NSError*)error
{
    if (error) {
        TRC_DBG(@"fail to load data from URL");
    }
    else{
        TRC_DBG(@"orderHistory count in VC =%d",[self.orderHistoryArray count]);
        [self.orderHistoryTableView reloadData];
    }        
}

#pragma mark -- TableView Delegate and datasource methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	// Number of sections is the number of regions
	return kNumberOfSections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.orderHistoryArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = kOrderHistoryListCustomCell;
    
    OrderHistoryListCustomCell* cell = (OrderHistoryListCustomCell* )[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell = (OrderHistoryListCustomCell *)[nib objectAtIndex:0];        
    } 
    
    [cell setOrderData:[self.orderHistoryArray objectAtIndex:indexPath.row]];

    return cell;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.orderHistoryTableView deselectRowAtIndexPath:indexPath animated:YES];
    
    OrderHistoryDetailViewController* orderHistoryDetailViewController = [[OrderHistoryDetailViewController alloc]initWithNibName:kOrderHistoryDetailViewController bundle:[NSBundle mainBundle]];
    
    orderHistoryDetailViewController.orderHistoryId = [[self.orderHistoryArray objectAtIndex:indexPath.row] orderId];
    
    [self.navigationController pushViewController:orderHistoryDetailViewController animated:YES];    
}

@end
