/* 
 File: OrderHistoryXMLParser.m
 Abstract: This is a xml parser class for Order History Module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "OrderHistoryXMLParser.h"
#import "CXMLDocument.h"
#import "CXMLElement.h"
#import "CartList.h"
#import "OrderHistoryCommon.h"
#import "Common.h"

@implementation OrderHistoryXMLParser

@synthesize orderHistoryArray = _orderHistoryArray;
@synthesize orderHistoryModel = _orderHistoryModel;

/*!
 @function		parseXMLDataForOrderHistory
 @abstract		This function requests for order History list on canis server.
 @discussion	This function requests for order history list on canis server.
 @param			data - orderHistory List Array.
 @param			orderHistoryList - return order history array.
 @result		void
 */
- (void) parseXMLDataForOrderHistory:(NSData *)data orderHistoryList:(NSMutableArray *)orderHistoryList
{
    self.orderHistoryArray = orderHistoryList;
    
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:data];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        OrderHistory *orderHistory = [[OrderHistory alloc] init];
        
        orderHistory.orderId = [item valueForKey:kOrderIdXMLTag];
        TRC_DBG(@"orderHistoryModel.orderId = %@",orderHistory.orderId);
        
        orderHistory.orderDate = [item valueForKey:kOrderDateXMLTag];
        TRC_DBG(@"orderHistoryModel.orderDate = %@",orderHistory.orderDate);
        
        /*orderHistory.orderNumber = [item valueForKey:kOrderNumberXMLTag];
        TRC_DBG(@"orderHistoryModel.orderNumber = %@",orderHistory.orderNumber);*/
        
        orderHistory.orderStatus = [item valueForKey:kOrderStatusXMLTag];
        TRC_DBG(@"orderHistoryModel.orderStatus = %@",orderHistory.orderStatus);
        
        orderHistory.currency = [item valueForKey:kOrderCurrencyXMLTag];
        TRC_DBG(@"orderHistoryModel.currency = %@",orderHistory.currency);
        
        orderHistory.orderTotal = [item valueForKey:kOrderGrandTotalXMLTag];
        TRC_DBG(@"orderHistoryModel.orderStatus = %@",orderHistory.orderStatus);
       
        orderHistory.shippingAmount = [item valueForKey:kOrderShippingAmountXMLTag];
        TRC_DBG(@"orderHistoryModel.orderStatus = %@",orderHistory.orderStatus);
        
        orderHistory.shippingDescription = [item valueForKey:kOrderShippingDescription];
        TRC_DBG(@"orderHistoryModel.orderStatus = %@",orderHistory.orderStatus);
        
        orderHistory.totalQuantityOrdered = [item valueForKey:kOrderQtyOrderedXMLTag];
        TRC_DBG(@"orderHistoryModel.orderStatus = %@",orderHistory.orderStatus);
        
        [self.orderHistoryArray addObject:orderHistory];
    }
 
}


/*!
 @function		parseXMLDataForOrderHistoryDetails
 @abstract		This function requests for order History details on canis server.
 @discussion	This function requests for order History details on canis server.
 @param			itemId - product id.
 @param			cartListExtended - return product object.
 @result		void
 */
- (void)parseXMLDataForOrderHistoryDetails:(NSData *)dataToBeParsed orderId:(NSString *)orderId orderHistoryModel:(OrderHistory *)orderHistory
{
    self.orderHistoryModel = orderHistory;
    
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    
    //searching for piglet nodes
    NSString *tagName = kItem; 
    
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    
    for (CXMLElement *node in nodes) 
    {
        //parse each item node 
        item = [self parseKeyValueFromItemNode:node itemDictionary:item];
    }
    
    TRC_DBG(@"item =%@",item);
     
    self.orderHistoryModel.orderId = [item valueForKey:kOrderIdXMLTag];
    TRC_DBG(@"orderHistoryModel.orderId = %@",self.orderHistoryModel.orderId);
    
    self.orderHistoryModel.orderDate = [item valueForKey:kOrderDateXMLTag];
    TRC_DBG(@"orderHistoryModel.orderDate = %@",self.orderHistoryModel.orderDate);
    
    self.orderHistoryModel.orderStatus = [item valueForKey:kOrderStatusXMLTag];
    TRC_DBG(@"orderHistoryModel.orderStatus = %@",self.orderHistoryModel.orderStatus);
    
    self.orderHistoryModel.currency = [item valueForKey:kOrderCurrencyXMLTag];
    TRC_DBG(@"orderHistoryModel.currency = %@",self.orderHistoryModel.currency);
    
    self.orderHistoryModel.orderTotal = [item valueForKey:kOrderGrandTotalXMLTag];
    TRC_DBG(@"orderHistoryModel.orderStatus = %@",self.orderHistoryModel.orderStatus);
    
    self.orderHistoryModel.shippingAmount = [item valueForKey:kOrderShippingAmountXMLTag];
    TRC_DBG(@"orderHistoryModel.orderStatus = %@",self.orderHistoryModel.orderStatus);
    
    self.orderHistoryModel.shippingDescription = [item valueForKey:kOrderShippingDescription];
    TRC_DBG(@"orderHistoryModel.orderStatus = %@",self.orderHistoryModel.orderStatus);
    
    self.orderHistoryModel.totalQuantityOrdered = [item valueForKey:kOrderQtyOrderedXMLTag];
    TRC_DBG(@"orderHistoryModel.orderStatus = %@",self.orderHistoryModel.orderStatus);
    
    //parse Shipping and billing address into address array
    [self addressData:[item objectForKey:kOrderShippingAddressXMLTag]];
    [self addressData:[item objectForKey:kOrderBillingAddressXMLTag]];
    
    //Parse product's list array withing order
    NSMutableDictionary *itemDictionaryArray = [item objectForKey:kItems];
    
    for(NSMutableDictionary *itemDic in itemDictionaryArray)
    {        
        CartList *cartProduct = [[CartList alloc] init];
        
        cartProduct.productId = [itemDic valueForKey:kProductIdXMLTag];
        TRC_DBG(@"self.cartInfo.productId=%@",cartProduct.productId);
        
        cartProduct.sku = [itemDic valueForKey:kProductSkuXMLTag];
        TRC_DBG(@"self.cartInfo.sku=%@",cartProduct.sku);
        
        cartProduct.quantity = [itemDic valueForKey:kOrderedQuantityXMLTag];
        TRC_DBG(@"self.cartInfo.quantity=%@",cartProduct.quantity);
        
        cartProduct.price = [itemDic valueForKey:kProductPriceXMLTag];
        TRC_DBG(@"self.cartInfo.price=%@",cartProduct.price);
        
        cartProduct.rowTotal = [itemDic valueForKey:kOrderRowTotalyXMLTag];
        TRC_DBG(@"self.cartInfo.price=%@",cartProduct.rowTotal);
        
        [self.orderHistoryModel.productArray addObject:cartProduct];
    }
}

/*!
 @function		addressData
 @abstract		This function parse shipping and billing address object.
 @discussion	This function parse shipping and billing address object.
 @param			addressDic - address dictionary of address.
 @result		void
 */
- (void)addressData:(NSMutableDictionary *)addressDic
{
    ShippingBillingAddress *shipBilladdress = [[ShippingBillingAddress alloc]init];
    
    shipBilladdress.addressId = [addressDic valueForKey:kAddressIdXMLTag];
    
    shipBilladdress.addressType = [addressDic valueForKey:kAddressTypeXMLTag];
    
    shipBilladdress.city = [addressDic valueForKey:kCityXMLTag];
    
    shipBilladdress.street = [addressDic valueForKey:kStreetXMLTag];

    shipBilladdress.postCode = [addressDic valueForKey:kPostCodeXMLTag];

    shipBilladdress.region = [addressDic valueForKey:kRegionXMLTag];
    
    shipBilladdress.countryId = [addressDic valueForKey:kCountryIdXMLTag];
    
    shipBilladdress.company = [addressDic valueForKey:kCompanyXMLTag];
    
    shipBilladdress.firstName = [addressDic valueForKey:kFirstNameXMLTag];
    
    shipBilladdress.lastName = [addressDic valueForKey:kLastNameXMLTag];
    
    shipBilladdress.telephone = [addressDic valueForKey:kTelephoneXMLTag];
    
    shipBilladdress.fax = [addressDic valueForKey:kFaxXMLTag];
    
    shipBilladdress.parentId = [addressDic valueForKey:kParentIdXMLTag];
    
    [self.orderHistoryModel.shipBillAddressArray addObject:shipBilladdress];
}

@end
