/* 
 File: OrderHistoryViewController.h
 Abstract: This class is the controller class for Order History.
 Author: Cybage Software Pvt. Ltd
 Created: 07/23/12
 Modified: 07/23/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "OrderHistoryReqResHandler.h"


@interface OrderHistoryViewController : UIViewController <UITableViewDelegate, UITableViewDataSource,NetworkRequestResponseBaseDelegate>
{
    int                         _toFrom;
    UIDatePicker                *_datePicker;
    UIView                      *_pickerView;
    UIView                      *_blackView;
    OrderHistoryReqResHandler   *_orderHistoryReqResHandler;
}

@property(nonatomic, strong) IBOutlet UITableView   *orderHistoryTableView;
@property(nonatomic, strong) IBOutlet UIButton      *fromDateButton;
@property(nonatomic, strong) IBOutlet UIButton      *toDateButton;
@property(nonatomic, strong) NSString               *toDate;
@property(nonatomic, strong) NSString               *fromDate;
@property(nonatomic, strong) NSMutableArray         *orderHistoryArray;

- (IBAction)toButtonClicked:(id)sender;
- (IBAction)fromButtonClicked:(id)sender;
- (IBAction)getOrderHistoryDetails:(id)sender;
- (void) showDatePicker:(id)sender;
- (void) getOrderList;

@end
