/* 
 File: OrderHistoryDetailShippingCustomCell.m
 Abstract: This is a custom cell class for displaying order history details in the order history module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "OrderHistoryDetailShippingCustomCell.h"

@implementation OrderHistoryDetailShippingCustomCell
@synthesize shippingLine1 = _shippingLine1;
@synthesize shippingLine2 = _shippingLine2;
@synthesize deliveryDate = _deliveryDate;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
