/* 
 File: OrderHistoryDetailTopCustomCell.h
 Abstract: This is a custom cell class for displaying order history details in the order history module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>

@interface OrderHistoryDetailTopCustomCell : UITableViewCell


@property(nonatomic, strong) IBOutlet UILabel *orderNumberLabelDet;
@property(nonatomic, strong) IBOutlet UILabel *orderDateLabelDet;
@property(nonatomic, strong) IBOutlet UILabel *orderTotalLabelDet;
@property(nonatomic, strong) IBOutlet UILabel *orderStatusLabelDet;

@end
