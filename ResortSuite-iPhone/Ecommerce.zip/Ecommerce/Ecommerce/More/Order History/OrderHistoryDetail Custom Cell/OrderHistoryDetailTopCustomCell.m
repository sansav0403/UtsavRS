/* 
 File: OrderHistoryDetailTopCustomCell.m
 Abstract: This is a custom cell class for displaying order history details in the order history module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "OrderHistoryDetailTopCustomCell.h"

@implementation OrderHistoryDetailTopCustomCell

@synthesize orderDateLabelDet = _orderDateLabelDet;
@synthesize orderTotalLabelDet = _orderTotalLabelDet;
@synthesize orderNumberLabelDet = _orderNumberLabelDet;
@synthesize orderStatusLabelDet = _orderStatusLabelDet;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
