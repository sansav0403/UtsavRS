/* 
 File: OrderHistorySummaryCell.m
 Abstract: This is a custom cell class for displaying order history summary in the order history module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "OrderHistorySummaryCell.h"

@implementation OrderHistorySummaryCell
@synthesize total = _total;
@synthesize orderNumber = _orderNumber;
@synthesize salesTax = _salesTax;
@synthesize shippingPrice = _shippingPrice;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
