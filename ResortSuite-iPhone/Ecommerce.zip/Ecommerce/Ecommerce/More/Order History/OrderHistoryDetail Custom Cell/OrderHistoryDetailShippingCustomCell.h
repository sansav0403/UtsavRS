/* 
 File: OrderHistoryDetailShippingCustomCell.h
 Abstract: This is a custom cell class for displaying order history details in the order history module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>

@interface OrderHistoryDetailShippingCustomCell : UITableViewCell


@property(nonatomic, weak) IBOutlet UILabel *shippingLine1;
@property(nonatomic, weak) IBOutlet UILabel *shippingLine2;
@property(nonatomic, weak) IBOutlet UILabel *deliveryDate;

@end
