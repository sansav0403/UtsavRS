/* 
 File: OrderHistorySummaryCell.h
 Abstract: This is a custom cell class for displaying order history summary in the order history module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>

@interface OrderHistorySummaryCell : UITableViewCell

@property(nonatomic ,weak) IBOutlet UILabel *orderNumber;
@property(nonatomic ,weak) IBOutlet UILabel *salesTax;
@property(nonatomic ,weak) IBOutlet UILabel *shippingPrice;
@property(nonatomic ,weak) IBOutlet UILabel *total;

@end
