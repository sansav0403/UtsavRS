/* 
 File: OrderHistoryListCustomCell.m
 Abstract: This is a custom cell class for displaying order history list in the order history module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "OrderHistoryListCustomCell.h"
#import "OrderHistoryCommon.h"
#import "Common.h"

@implementation OrderHistoryListCustomCell
@synthesize orderDateLabel = _orderDateLabel;
@synthesize orderNumberLabel = _orderNumberLabel;
@synthesize orderStatusLabel = _orderStatusLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setOrderData
 @abstract      set cart List details to cell.
 @discussion    set cart List details to cell.
 @param         orderHistory - Order of which details need to set to cell.
 @result        void
 */
- (void)setOrderData:(OrderHistory*)orderHistory
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
 
    [formatter setDateFormat:kDateFormateWithTime]; 
    
    TRC_DBG(@"orderDate = %@",orderHistory.orderDate);
    
    NSDate *orderDt = [formatter dateFromString:orderHistory.orderDate];
    TRC_DBG(@"orderDt Obj%@",orderDt);

    [formatter setDateFormat:kDateFormateWithoutTime]; 

    TRC_DBG(@"stringFromDate =%@",[formatter stringFromDate:orderDt]);
    
    NSString *orderTotalAmt = nil;
    NSString *currencyUSD = kUSDTitle;
    if ([orderHistory.currency isEqualToString:currencyUSD]) {
        orderTotalAmt = [NSString stringWithFormat:@"$ %@",orderHistory.orderTotal];
    }
    self.orderDateLabel.text = [formatter stringFromDate:orderDt];
    self.orderNumberLabel.text = orderTotalAmt;
    self.orderStatusLabel.text = orderHistory.orderStatus;
    
    self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
}

@end
