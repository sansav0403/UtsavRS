/* 
 File: OrderHistoryListCustomCell.h
 Abstract: This is a custom cell class for displaying order history list in the order history module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "OrderHistory.h"

@interface OrderHistoryListCustomCell : UITableViewCell

@property(nonatomic, strong) IBOutlet UILabel *orderDateLabel;
@property(nonatomic, strong) IBOutlet UILabel *orderNumberLabel;
@property(nonatomic, strong) IBOutlet UILabel *orderStatusLabel;

- (void)setOrderData:(OrderHistory*)orderHistory;

@end
