/* 
 File: MoreViewController.m
 Abstract: This class is responsible for product order related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 06/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

#import "MoreViewController.h"
#import "CartViewController.h"
#import "FavoriteViewController.h"
#import "HelpAndFAQsViewController.h"
#import "AccountInfoViewController.h"
#import "FeedbackViewController.h"
#import "ContactUsViewController.h"
#import "OrderHistoryViewController.h"
#import "Common.h"


@implementation MoreViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = kMoreTitle;
        self.tabBarItem.image = [UIImage imageNamed:kPlaceOrderTBarItemImg];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (_moreList) {
        _moreList = nil;
    }

    _moreList = [NSArray arrayWithObjects:kCartTitle,kFavoritesTitle,kOrderHistoryTitle,kAccountInfoTitle,kFeedbackTitle,kContactUsTitle,kHelpAndFAQsTitle, nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -- TableView Delegate and datasource methods

- (NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return NUMBEROFSECTIONS;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_moreList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString* moreIdentifier = kMoreCellIdentifier;
  
    UITableViewCell *cell = (UITableViewCell*)[tableView dequeueReusableCellWithIdentifier:moreIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:moreIdentifier];
    }
    [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    cell.textLabel.text = [_moreList objectAtIndex:indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
{
     [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.row) {
        case 0:
            //Cart
        {
            CartViewController* cartViewController = [[CartViewController alloc]initWithNibName:kCartViewController bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:cartViewController animated:YES];
            break;
        }
            
        case 1:
            //Favorite
        {
            FavoriteViewController* favoriteViewController = [[FavoriteViewController alloc]initWithNibName:kFavoriteViewController bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:favoriteViewController animated:YES];
            break;
        }   
            
        case 2:
        {
            //Order History
            OrderHistoryViewController* orderHistoryViewController = [[OrderHistoryViewController alloc]initWithNibName:kOrderHistoryViewController bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:orderHistoryViewController animated:YES];
            break;
        }
            
        case 3:
            //Account Info
        {
            AccountInfoViewController* accountInfoViewController = [[AccountInfoViewController alloc]initWithNibName:kAccountInfoViewController bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:accountInfoViewController animated:YES];
            break;
        }   
            
        case 4:
            //Feedback
        {
            FeedbackViewController* feedbackViewController = [[FeedbackViewController alloc]initWithNibName:kFeedbackViewController bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:feedbackViewController animated:YES];
            break;
        }  
            
        case 5:
            //Contact US
        {
            ContactUsViewController* contactUsViewController = [[ContactUsViewController alloc]initWithNibName:kContactUsViewController bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:contactUsViewController animated:YES];
            break;
        }
            
        case 6:
            //Help and FAQs
        {
            HelpAndFAQsViewController* helpAndFAQsViewController = [[HelpAndFAQsViewController alloc]initWithNibName:kHelpAndFAQsViewController bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:helpAndFAQsViewController animated:YES];
            break;
        }
                    
        default:
            break;
    }
}

@end
