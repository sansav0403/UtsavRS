/* 
 File: AccountInfoViewController.h
 Abstract: This class is responsible to view/edit the Account information 
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 29/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>

/*!
 @class       AccountInfoViewController
 @abstract    Contains user Account information.
 @discussion  This class contains user Account information.
 */
@interface AccountInfoViewController : UIViewController<UITextFieldDelegate>

@property(nonatomic,strong) IBOutlet UITextField    *txtFieldName;
@property(nonatomic,strong) IBOutlet UITextField    *txtFieldEmail;

- (IBAction)saveAccountInfo:(id)sender;
- (BOOL)validateTextFields;
- (void)animateTextField:(UITextField *)textField up:(BOOL)up;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;
- (BOOL)emailValidate:(NSString *)email;

@end
