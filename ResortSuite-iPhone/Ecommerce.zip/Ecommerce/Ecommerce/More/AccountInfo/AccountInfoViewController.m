/* 
 File: AccountInfoViewController.m
 Abstract: This class is responsible to view/edit the Account information 
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 29/03/12
 Version: 1.0 
 */

#import "AccountInfoViewController.h"
#import "EcommerceAppDelegate.h"
#import "AccountInfoCommon.h"

@implementation AccountInfoViewController
@synthesize txtFieldName = _txtFieldName;
@synthesize txtFieldEmail = _txtFieldEmail;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = kAccountInfoTitle;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //get the Account name and email id from Keychain
    EcommerceAppDelegate *appDelegate = (EcommerceAppDelegate *)[[UIApplication sharedApplication] delegate];    
    [self.txtFieldName setText:[appDelegate.keychainItemWrapper objectForKey:(__bridge id)kSecAttrAccount]];
    [self.txtFieldEmail setText:[appDelegate.keychainItemWrapper objectForKey:(__bridge id)kSecAttrLabel]];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark  - Action Methods
/*!
 @method			saveAccountInfo
 @abstract			save user account information
 @discussion		save user account information
 */
- (IBAction)saveAccountInfo:(id)sender
{
    [self.txtFieldName resignFirstResponder];
    [self.txtFieldEmail resignFirstResponder];

    if ([self validateTextFields]) {
        [self showAlertView:kAppTitle alertMessage:kMessageSuccess setDelegate:nil];
        
        //save these fileds in Keychain
        EcommerceAppDelegate *appDelegate = (EcommerceAppDelegate *)[[UIApplication sharedApplication] delegate]; 
        [appDelegate.keychainItemWrapper setObject:self.txtFieldName.text forKey:(__bridge id)kSecAttrAccount];
        [appDelegate.keychainItemWrapper setObject:self.txtFieldEmail.text forKey:(__bridge id)kSecAttrLabel];
    }
}

#pragma mark - move the view upwards
/*!
 @function			textFieldShouldReturn
 @abstract			delegate for textField 
 @discussion		discard the keyboard when tap on return button of keyboard
 @param				textField - selected textField 
 @result			will return YES 
 */
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

/*!
 @function			textFieldShouldBeginEditing
 @abstract			delegate for textField 
 @discussion		check if the view is already animated if not then set active field's for animation
 @param				textField - selected textField 
 @result			will return YES 
 */
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextField: textField up: YES];
}

/*!
 @function			textFieldDidEndEditing
 @abstract			delegate for textField 
 @discussion		check if the view is already animated if not then set active field's for animation
 @param				textField - selected textField 
 @result			will return YES 
 */

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self animateTextField: textField up: NO];    
}

/*!
 @function      animateTextField
 @abstract      animate view
 @discussion    animate the view when launch the Keybord
 @param         textField - textFiled object
 up - moving direction
 @result        void
 */
- (void)animateTextField:(UITextField *)textField up:(BOOL)up
{
    const int movementDistance = 30;
    const float movementDuration = 0.3f;
    
    int movement = (up ? -movementDistance : movementDistance);
    
    [UIView beginAnimations: @"anim" context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration: movementDuration];
    self.view.frame = CGRectOffset(self.view.frame, 0, movement);
    [UIView commitAnimations];
}

/*!
 @function           validateTextFields
 @abstract           validate all text fields
 @discussion         validate all text fields
 @param              none
 @result             will return YES is all textField comply the business rule else NO
 */
- (BOOL)validateTextFields
{
	// Check all fields are filled
	if ([self.txtFieldName.text length]<=0 || [self.txtFieldEmail.text length]<=0 )
    {
		[self showAlertView:kAppTitle alertMessage:kErrMessageBlank setDelegate:nil];
		return NO;
	}
	
	// check is email valid
	if (![self emailValidate:self.txtFieldEmail.text]) 
	{
		[self showAlertView:kAppTitle alertMessage:kEmailInvalidDescription setDelegate:nil];
		return NO;
	}
	
	return YES;
}

/*!
 @function		emailValidate
 @abstract		email Validation
 @discussion		validate the email text entered by user.
 checks if ".,@" are present or not.
 checks for domain name should not contain two adjacent dot "." etc 
 @param			email - text entered by user
 @result			will retun the bool value for success or faliure of validation 
 */

- (BOOL)emailValidate:(NSString *)email
{
	//Based on the string below	
	//Quick return if @ Or . not in the string
	if([email rangeOfString:@"@"].location==NSNotFound || [email rangeOfString:@"."].location==NSNotFound)
		return NO;
	
	//Break email address into its components
	NSString *accountName=[email substringToIndex: [email rangeOfString:@"@"].location];
	email=[email substringFromIndex:[email rangeOfString:@"@"].location+1];
    
	if ( [[email componentsSeparatedByString:@"."] count] > 3)
	{
		return NO;
	}
	//‚Äô.‚Äô not present in substring
	if([email rangeOfString:@"."].location==NSNotFound)
		return NO;
	NSString *domainName=[email substringToIndex:[email rangeOfString:@"."].location];
	NSString *subDomain=[email substringFromIndex:[email rangeOfString:@"."].location+1];
	
	if ([subDomain rangeOfString:@"."].location != NSNotFound)
	{
		NSString *firstCharacterOFsubDomain =[subDomain substringToIndex:[subDomain rangeOfString:@"."].location+1];
		NSString *lastCharacterOFsubDomain=[subDomain substringFromIndex:[subDomain rangeOfString:@"."].location+1];
        
		if ([firstCharacterOFsubDomain  isEqualToString:@"."] || [lastCharacterOFsubDomain isEqualToString:@""]) 
		{
			return NO;
		}
	}
	
	//username, domainname and subdomain name should not contain the following charters below
	//filter for user name
	NSString *unWantedInUName = @"~!@#$^&*()={}[]|;‚Äô:\"<>,?/`";
	//filter for domain
	NSString *unWantedInDomain = @" ~!@#$%^&*()={}[]|;‚Äô:\"<>,+?/`";
	//filter for subdomain
	NSString *unWantedInSub = @"`~!@#$%^&*()={}[]:\";‚Äô<>,?/1234567890";
	
	//subdomain should not be less that 2 and not greater 6
	if(!(subDomain.length>=2 && subDomain.length<=6)) return NO;
	
	if([accountName isEqualToString:@""] || 
	   [accountName rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:unWantedInUName]].location!=NSNotFound || [domainName isEqualToString:@""] || [domainName rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:unWantedInDomain]].location!=NSNotFound || [subDomain isEqualToString:@""] || [subDomain rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:unWantedInSub]].location!=NSNotFound)
		return NO;
	
	return YES;
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function			showAlertView
 @abstract			Common method to display alert message 
 @discussion		Common method to display alert message 
 @param				alertTitle - Title for AlertView
 alertMessage - Message description for AlertView		
 @result			void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
	[alert show];
}

@end
