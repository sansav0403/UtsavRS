/* 
 File: AccountInfoCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for account module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */


//AccountInfoViewController
#define kAccountInfoTitle               NSLocalizedString(@"Account Info", @"")
#define kAppTitle                       NSLocalizedString(@"E-Commerce", @"")
#define kMessageSuccess                 NSLocalizedString(@"Account information saved successfully.", @"")
#define kErrMessageBlank                NSLocalizedString(@"User name or Email can not be blank.", @"")
#define kEmailInvalidDescription        NSLocalizedString(@"Please enter valid Email-Id", @"")
#define kButtonOk                       NSLocalizedString(@"Ok", @"")