/* 
 File: MoreViewController.h
 Abstract: This class is responsible for product order related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 06/03/12
 Modified: 07/03/12
 Version: 1.0 
*/

#import <UIKit/UIKit.h>
#import "CartReqResHandler.h"

@interface MoreViewController : UIViewController <UITableViewDelegate,UITableViewDataSource>
{
    NSArray *_moreList;
}

@end
