/* 
 File: CartListXMLParser.m
 Abstract: This is a xml parser class for Cart List Module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 07/05/12
 Version: 1.0 
 */

#import "CartListXMLParser.h"
#import "CXMLDocument.h"
#import "CXMLElement.h"
#import "CartCommon.h"
#import "Common.h"

@implementation CartListXMLParser
@synthesize cartInfo = _cartInfo;
@synthesize cartProductDetail = _cartProductDetail;
@synthesize cartProductList = _cartProductList;

/*!
 @function		parseXMLDataForCartId
 @abstract		This function parse xml data for cart id.
 @discussion	This function parse xml data for cart id.
 @param			data - NSData to be parsed.
 @result		void
 */
- (NSString *)parseXMLDataForCartId:(NSData *)data
{        
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:data options:0 error:nil];
    
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kCartCallReturnXMLTag; 
    NSString * value = nil;
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    for (CXMLElement *node in nodes) {
        
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        
            //  common procedure: dictionary with keys/values from XML node
            [item setObject:[node stringValue] forKey:[node name]];
            
            value = [[node stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            TRC_DBG(@"Value is : %@", value);
            
            if ([value length] != 0){
                [item setObject:[node stringValue] forKey:[node localName]];
            }
    }
    return value;
}

/*!
 @function		parseXMLDataForCartList
 @abstract		This function parse xml data for cart list.
 @discussion	This function parse xml data for cart list.
 @param			dataToBeParsed - NSData to be parsed.
 @param			cartListArray - return array of cartList objects.
 @result		void
 */
- (void)parseXMLDataForCartList:(NSData *)dataToBeParsed cartProductList:(NSMutableArray*)cartProdList
{
    self.cartProductList = cartProdList;
     
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {        
        CartList *cartProduct = [[CartList alloc] init];
        
        cartProduct.productId = [item valueForKey:kProductIdXMLTag];
        
        cartProduct.sku = [item valueForKey:kProductSkuXMLTag];
        
        [self.cartProductList addObject:cartProduct];
    }
}

/*!
 @function		parseXMLDataForCartInfo
 @abstract		This function parse xml data for cart info.
 @discussion	This function parse xml data for cart info.
 @param			dataToBeParsed - NSData to be parsed.
 @param			cartInfo - return cartInfo object.
 @result		void
 */
- (void)parseXMLDataForCartInfo:(NSData *)dataToBeParsed cartInfo:(CartInfo*)cartInfoData
{
    self.cartInfo = cartInfoData;
         
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
     
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kItem; 

    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    
    for (CXMLElement *node in nodes) 
    {
        //[self parseRecursiveXMLDataIntoDictionary:node];
        item = [self parseKeyValueFromItemNode:node itemDictionary:item];
    }
     
    TRC_DBG(@"item =%@",item);
    self.cartInfo.currency = [item valueForKey:kCartGlobalCurrencyXMLTag];
    TRC_DBG(@"self.cartInfo.currency=%@",[item valueForKey:kCartGlobalCurrencyXMLTag]);
    TRC_DBG(@"self.cartInfo.currency=%@",self.cartInfo.currency );
     
    NSMutableDictionary *shippingDic = [item objectForKey:kShippingDictionary];
    TRC_DBG(@"shippingDic =%@",shippingDic);
    
    self.cartInfo.subTotal = [shippingDic valueForKey:kCartSubTotalXMLTag];
    TRC_DBG(@"self.cartInfo.subTotal=%@",[shippingDic valueForKey:kCartSubTotalXMLTag]);
    
    self.cartInfo.grandTotal = [shippingDic valueForKey:kCartGrandTotalXMLTag];
    TRC_DBG(@"self.cartInfo.grandTotal=%@",[shippingDic valueForKey:kCartGrandTotalXMLTag]);
    
    self.cartInfo.shippingAmount = [shippingDic valueForKey:kCartShippingAmountXMLTag];
    TRC_DBG(@"self.cartInfo.shippingAmount=%@",[shippingDic valueForKey:kCartShippingAmountXMLTag]);
    
    self.cartInfo.shippingDescription = [shippingDic valueForKey:kCartShippingDescriptionXMLTag];
    TRC_DBG(@"self.cartInfo.des=%@",[item valueForKey:kCartShippingDescriptionXMLTag]);
    
    // parsed for product list in Cart
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *itemDic in dictionaryArray)
    {        
        CartList *cartProduct = [[CartList alloc] init];
        
        cartProduct.productId = [itemDic valueForKey:kProductIdXMLTag];
        TRC_DBG(@"self.cartInfo.productId=%@",cartProduct.productId);
        
        cartProduct.sku = [itemDic valueForKey:kProductSkuXMLTag];
        TRC_DBG(@"self.cartInfo.sku=%@",cartProduct.sku);
        
        cartProduct.quantity = [itemDic valueForKey:kProductQuantityXMLTag];
        TRC_DBG(@"self.cartInfo.quantity=%@",cartProduct.quantity);

        cartProduct.price = [itemDic valueForKey:kProductPriceXMLTag];
        TRC_DBG(@"self.cartInfo.price=%@",cartProduct.price);

        cartProduct.rowTotal = [itemDic valueForKey:kCartRowTotalXMLTag];
        TRC_DBG(@"self.cartInfo.price=%@",cartProduct.rowTotal);
        
        [self.cartInfo.productArray addObject:cartProduct];
    }
}

/*!
 @function		parseXMLDataForProductDetails
 @abstract		This function requests for cartList product details on canis server.
 @discussion	This function requests for cartList product details on canis server.
 @param			itemId - product id.
 @param			cartListExtended - return product object.
 @result		void
 */
- (void)parseXMLDataForProductDetails:(NSData *)dataToBeParsed productId:(NSString *)productId cartProduct:(CartList *)cartListProduct
{
    self.cartProductDetail = cartListProduct;
    TRC_DBG(@"pID =%@",productId);
    
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kItem; 
    //NSString *tagName = @"SOAP-ENV:Body";
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    TRC_DBG(@"item cnt = %d",[nodes count]);
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    for (CXMLElement *node in nodes) 
    {
        NSString *keyString = nil;
        id valueString = nil;
        
        for(int keyValueCounter = 0; keyValueCounter < [node childCount]; keyValueCounter++)
        {
            CXMLElement *itemChildNode = (CXMLElement*)[node childAtIndex:keyValueCounter];
            TRC_DBG(@"name = %@",[itemChildNode name]);
            TRC_DBG(@"stringValue = %@",[itemChildNode stringValue]);
            TRC_DBG(@"localName = %@",[itemChildNode localName]);
            
            NSString * value = [[itemChildNode stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            NSString *keyTag = kKey;
            NSString *valueTag = kValue;
            
            if ([[itemChildNode name] isEqualToString:keyTag])
            {                                       
                if ([value length] != 0)
                {
                    keyString = [itemChildNode stringValue];
                }
            }
            else if([[itemChildNode name] isEqualToString:valueTag]) 
            {
                NSArray *arrayOfAttribute = [itemChildNode attributes];
                NSString *strValue = nil;
                NSString *strName = nil;
                
                // read attribute values
                for (NSInteger i = 0; i < [arrayOfAttribute count]; i++) {
                    strValue=[[arrayOfAttribute objectAtIndex:i] stringValue];
                    strName=[[arrayOfAttribute objectAtIndex:i] name];
                    
                    TRC_DBG(@"strValue =%@",strValue);
                    TRC_DBG(@"strName =%@",strName);
                    NSString *soapArrayString = kSoapArray;
                    
                    if(strValue && strName && [strValue isEqualToString:soapArrayString])
                    {
                        valueString = [[NSMutableArray alloc] init];
                        
                        for(int valueCounter = 0; valueCounter < [itemChildNode childCount]; valueCounter++)
                        {
                            CXMLElement *valueChildNode = (CXMLElement*)[itemChildNode childAtIndex:valueCounter];
                            [valueString addObject:[valueChildNode stringValue]]; 
                        }
                    }
                    else
                    {
                        if ([value length] != 0)
                        {
                            valueString = [itemChildNode stringValue];
                        }
                    }
                }
            }
        }
        if (valueString && keyString){
            [item setObject:valueString forKey:keyString];
        }
    }
    
    // To be done
    //Add entities into product table for manu. & exp. date
    
    self.cartProductDetail.productId = [item valueForKey:kProductIdXMLTag];
    
    self.cartProductDetail.name = [item valueForKey:kProductNameXMLTag];
    
    self.cartProductDetail.model = [item valueForKey:kProductModelXMLTag];
    
    //self.cartProductDetail.manufacture = [item valueForKey:kProductManufactureXMLTag];
    
    self.cartProductDetail.manufacturingDate = [item valueForKey:kProductCreatedXMLTag];
    
    self.cartProductDetail.dimension = [item valueForKey:kProductDimensionXMLTag];
    
    TRC_DBG(@"man Date=%@",self.cartProductDetail.manufacturingDate);
    //self.cartProductDetail.expiryDate = [item valueForKey:kExpDateXMLTag];
    
    self.cartProductDetail.description = [item valueForKey:kProductDescriptionXMLTag];
    
    self.cartProductDetail.imageUrl = [item valueForKey:kImageUrlXMLTag]; 
}

/*!
 @function		parseXMLDataForProductImage
 @abstract		This function parse xml data for product image.
 @discussion	This function parse xml data for product image.
 @param			dataToBeParsed - NSData to be parsed.
 @param			cartListProduct - cart product objects.
 @result		void
 */
- (void)parseXMLDataForProductImage:(NSData *)dataToBeParsed cartProduct:(CartList *)cartListProduct
{
    self.cartProductDetail = cartListProduct;
    TRC_DBG(@"imageUrlNSData = %@",[NSString stringWithUTF8String:[dataToBeParsed bytes]]);    
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        self.cartProductDetail.imageUrl = [item valueForKey:kProductImageUrlXMlTag];
        TRC_DBG(@"url =%@",self.cartProductDetail.imageUrl);
    }
}

/*!
 @function		parseXMLDataForAddProductToCart
 @abstract		This function requests for product to add into cart server.
 @discussion	This function requests for product to add into cart server.
 @param			dataToBeParsed - data to be parsed.
 @result		NSString - return True or False
 */
- (NSString*)parseXMLDataForAddProductToCart:(NSData *)dataToBeParsed 
{
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kCartCallReturnXMLTag; 
    NSString * value = nil;
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    for (CXMLElement *node in nodes) {
        
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];

        //  common procedure: dictionary with keys/values from XML node
        [item setObject:[node stringValue] forKey:[node name]];
        
        value = [[node stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        TRC_DBG(@"Value is : %@", value);
        
        if ([value length] != 0){
            [item setObject:[node stringValue] forKey:[node localName]];
        }
    }
    return value;
}

@end
