/* 
 File: CartCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for Cart module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

//API
#define kCartCreateAPI                  @"cart.create"
#define kCartProductAddAPI              @"cart_product.add"
#define kCartProductListAPI             @"cart_product.list"
#define kCartInfoAPI                    @"cart.info"
#define kCartListAPI                    @"CartList.xml"
#define kCartProductDetailsAPI          @"product.info"//@"CartProductDetail.xml"
#define kCartProductImageAPI            @"product_attribute_media.list"
#define kSetCustomerApi                 @"cart_customer.set"
#define kSetCustomerAddressApi          @"cart_customer.addresses"
#define kSetShippingMethodApi           @"cart_shipping.method"
#define kSetPaymentMethodApi            @"cart_payment.method"
#define kCreatOrderApi                  @"cart.order"
#define kCartRemoveProductApi           @"cart_product.remove"

//Reqest Handler
#define kStoreViewCode              @"default"

//Cart View Controller
#define kNumberOfSectionForCartList 1
#define kCellHeight 85.0
#define kInitialValue 0
#define kCellIdentifier             @"CartListCustomCell"
#define kCartProductDetail          @"CartProductDetail"

#define kGet                        @"GET"

//Alert Message
#define kOrderSuccessMsg                            NSLocalizedString(@"Order_placed_successfully", @"")

#define kProductDeleteFromCartSuccessMsg            NSLocalizedString(@"Product_deleted_form_cart_successfully", @"")

#define kFinalOrderVerifyMsg            NSLocalizedString(@"Please_verify_final_order", @"")

#define kPlacingOrderMsg                            NSLocalizedString(@"Placing_order", @"")

#define kSetShippingMsg                             NSLocalizedString(@"Setting_payment_method_to_cart", @"")

#define kSetPaymentMsg                              NSLocalizedString(@"Setting_shipping_method_to_cart", @"")

#define kSetCustomerAddressMsg                      NSLocalizedString(@"Setting_customer_address_to_cart", @"")

#define kSetCustomerMsg                             NSLocalizedString(@"Setting_customer_to_cart", @"")


//Cart List
#define kShippingPriceTitle             NSLocalizedString(@"Shipping_Price", @"")
#define kSubTotalTitle                  NSLocalizedString(@"Sub_Total", @"")
#define kTotalTitle                     NSLocalizedString(@"Total", @"")
#define kCheckOutBtnTitle               NSLocalizedString(@"Check_Out", @"")
#define kPlaceOrderBtnTitle             NSLocalizedString(@"Place_Order", @"")

//XML Tag
#define kCartProductXMLTag              @"Product";
#define kCartProductIdXMLTag            @"id"
#define kCartProductNameXMLTag          @"Name"
#define kCartProductQuantityXMLTag      @"Quantity"
#define kShippingXMLTag                 @"Shipping"
#define kWarrantyXMLTag                 @"Warranty"
#define kCartProductPriceXMLTag         @"Price"
#define kCartProductImageURLXMLTag      @"ImageUrl"
#define kCartListCurrencyXMLTag         @"currency"
#define kCartCallReturnXMLTag           @"callReturn"

//Cart Detail
#define kCartProductNumberXMLTag        @"Number"
#define kCartProductModelNumberXMLTag   @"ModelNumber"
#define kCartProductMfgDateXMLTag       @"MfgDate"
#define kCartProductExpDateXMLTag       @"ExpDate"
#define kCartProductDescXMLTag          @"Description"
#define kCartProductImageURLXMLTag      @"ImageUrl"
#define kIdXMLTag                       @"id"
#define kCartGlobalCurrencyXMLTag       @"global_currency_code" 
#define kCartBaseCostXMLTag             @"base_cost"
#define kCartGrandTotalXMLTag           @"grand_total"
#define kCartSubTotalXMLTag             @"subtotal"
#define kCartRowTotalXMLTag             @"row_total" 
#define kCartShippingDescriptionXMLTag  @"shipping_description" 
#define kCartShippingAmountXMLTag       @"shipping_amount" 
#define kCallReturn                     @"callReturn"
#define kShippingDictionary             @"shipping_address"

//Cart Product Detail
#define kProductDetailsTitle        NSLocalizedString(@"Product_Details", @"")
#define kProductDetailsTitle        NSLocalizedString(@"Product_Details", @"")
#define kProductNumber              NSLocalizedString(@"Product_Number", @"")
#define kModelNumber                NSLocalizedString(@"Model_Number", @"")
#define kManufacturingDate          NSLocalizedString(@"Manufacturing_Date", @"")
#define kExpiryDate                 NSLocalizedString(@"Expiry_Date", @"")
#define kDescription                NSLocalizedString(@"Description", @"")

#define kProductImageCell               @"ProductImageCell"
#define kProductDetailCell              @"ProductDetailCell"
#define kProductDetailDescriptionCell   @"ProductDetailDesrciptionCell"
#define kPriceInfoTitle                 NSLocalizedString(@"Price_Info", @"")

#define kNumberOfSections 1
#define kNumberOfRows 7
#define kImageRowHeight 255.0
#define kDescriptionRowHeigth 100
#define kNormalRowHeigth 44

#define k0Title         0
#define k1Title         1
#define k5Title         5

