/* 
 File: CartList.h
 Abstract: This is a modal class for products in the cart List.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "Product.h"

@interface CartList : Product


@property(nonatomic, strong) NSString    *price;
@property(nonatomic, strong) NSString    *warrantyPrice;
@property(nonatomic, strong) NSString    *productNumber;
@property(nonatomic, strong) NSString    *modelNumber;
@property(nonatomic, strong) NSString    *manufacturingDate;
@property(nonatomic, strong) NSString    *expiryDate; 
@property(nonatomic, strong) NSString    *rowTotal;
 
@end
