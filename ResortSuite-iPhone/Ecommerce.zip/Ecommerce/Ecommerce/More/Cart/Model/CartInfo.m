//
//  CartInfo.m
//  Ecommerce
//
//  Created by sandeep on 14/05/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "CartInfo.h"

@implementation CartInfo
@synthesize productArray = _productArray;
@synthesize shippingAmount = _shippingAmount;
@synthesize shippingDescription = _shippingDescription;
@synthesize grandTotal = _grandTotal;
@synthesize subTotal = _subTotal;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        _productArray = [[NSMutableArray alloc] init];
    }
    
    return self;
}

@end
