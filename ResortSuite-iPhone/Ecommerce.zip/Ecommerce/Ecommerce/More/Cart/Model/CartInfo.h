/* 
 File: CartInfo.h
 Abstract: This is a modal class for detail info of the cart.
 Author: Cybage Software Pvt. Ltd
 Created: 14/05/12
 Modified: 14/05/12
 Version: 1.0 
*/

#import <Foundation/Foundation.h>
#import "Product.h"

@interface CartInfo : Product

@property(nonatomic, strong) NSMutableArray *productArray;
@property(nonatomic, strong) NSString    *shippingAmount;
@property(nonatomic, strong) NSString    *shippingDescription;
@property(nonatomic, strong) NSString    *grandTotal;
@property(nonatomic, strong) NSString    *subTotal;

@end
