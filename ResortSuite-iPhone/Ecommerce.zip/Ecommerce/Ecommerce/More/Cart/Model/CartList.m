/* 
 File: CartList.m
 Abstract: This is a modal class for products in the cart List.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "CartList.h"

@implementation CartList

@synthesize price = _price;
@synthesize warrantyPrice = _warrantyPrice;
@synthesize productNumber = _productNumber;
@synthesize modelNumber = _modelNumber;
@synthesize manufacturingDate = _manufacturingDate;
@synthesize expiryDate = _expiryDate;
@synthesize rowTotal = _rowTotal;


@end
