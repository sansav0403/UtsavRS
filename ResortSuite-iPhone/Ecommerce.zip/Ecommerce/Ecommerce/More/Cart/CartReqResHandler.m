/* 
 File: CartReqResHandler.h
 Abstract: This is a request handler class for Cart List Module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "CartReqResHandler.h"
#import "CartListXMLParser.h"
#import "CartCommon.h"
#import "Common.h"
#import "UserExtended.h"
#import "CartInfo.h"

@implementation CartReqResHandler
@synthesize cartInfo =_cartInfo;
@synthesize cartList = _cartList;
@synthesize sessionId = _sessionId;
@synthesize product = _product;
@synthesize cartId = _cartId;
@synthesize productId = _productId;
@synthesize cartListArray = _cartListArray;
@synthesize requestState = _requestState;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        UserExtended *userExtended = [UserExtended sharedUserExteded];
        self.sessionId = userExtended.sessionId;
        //userExtended.cartId = @"52";
        self.cartId = userExtended.cartId;
    }
    
    return self;
}

/*!
 @function		addToCart
 @abstract		Add a product to cart
 @discussion    Add a product to cart
 */
- (void)addToCart:(Product *)product
{
    self.product = product;
    
    //create a new cart
    if (self.cartId)
    {
        [self addProductToCart];
    }
    else{
        [self createCart];
    }
}

/*!
 @function		createCart
 @abstract		create a new cart
 @discussion    create a new cart
 */
- (void)createCart
{
    self.requestState = kCartCreateRequest;
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:anyType\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kCartCreateAPI,kStoreViewCode];
        
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		addProductToCart
 @abstract		create a new cart
 @discussion    create a new cart
 @param         product - product to add into cart
 */
- (void)addProductToCart
{
    self.requestState = kCartProductAddRequest;
    
    TRC_DBG(@"self.product.actualPrice=%@",self.product.actualPrice);
    TRC_DBG(@"_pro.offerPrice=%@",self.product.offerPrice);
    NSString *price = nil;
    if (self.product.offerPrice) {
        price = self.product.offerPrice;
    }
    else if(self.product.actualPrice){
        price = self.product.actualPrice;
    }
    
    NSString *argsValue = nil;
    NSString *orderedQty = nil;
    if (self.product.orderedQuantity) {
        orderedQty = self.product.orderedQuantity;
    }
    else{
        orderedQty = @"1";
    }
    argsValue = [NSString stringWithFormat:@"<item xsi:type=\"xsd:int\">%d</item><item SOAP-ENC:arrayType=\"ns2:Map[1]\" xsi:type=\"SOAP-ENC:Array\"><item xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">product_id</key><value xsi:type=\"xsd:string\">%@</value></item><item><key xsi:type=\"xsd:string\">sku</key><value xsi:type=\"xsd:string\">%@</value></item><item><key xsi:type=\"xsd:string\">qty</key><value xsi:type=\"xsd:string\">%@</value></item><item><key xsi:type=\"xsd:string\">price</key><value xsi:type=\"xsd:string\">%@</value></item></item></item>",[self.cartId intValue],self.product.productId,self.product.sku,orderedQty,price];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"xsd:ur-type[2]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kCartProductAddAPI,argsValue];
        
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		cartDataList
 @abstract		get product list information.
 @discussion    parse product list.
 @param			cartListArr - result will be return in this array 
 */
- (void)cartDataList:(NSArray*)cartListArr
{
    self.cartListArray = cartListArr;
    self.requestState = kCartListRquest;
    
    NSString *argsValue = nil;
    argsValue = [NSString stringWithFormat:@"<item xsi:type=\"xsd:int\">%d</item>",[self.cartId intValue]];
    NSString *storeViewCode = nil;
    storeViewCode  = @"default";
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"xsd:int[1]\" xsi:type=\"SOAP-ENC:Array\">%@</args><param3 xsi:type=\"xsd:string\">%@</param3></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kCartProductListAPI,argsValue,storeViewCode];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		cartDetailInfo
 @abstract		get cart detail information.
 @discussion    parse cart detail.
 @param			cartInfo - result will be return in this cartInfo object 
 */
- (void)cartDetailInfo:(CartInfo*)cartInfoData
{
    self.cartInfo = cartInfoData;
    self.requestState =  kCartInfoRequest;

    NSString *argsValue = nil;
    argsValue = [NSString stringWithFormat:@"<item xsi:type=\"xsd:int\">%d</item>",[self.cartId intValue]];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"xsd:int[1]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kCartInfoAPI,argsValue];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		removeProductFromCart
 @abstract		remove product from cart
 @discussion    remove product from cart
 @param			productId - id of product to be removed 
 */
- (void)removeProductFromCart:(NSString *)productId
{
    self.requestState =  kCartRemoveProduct;

    NSString *argsValue = nil;
    argsValue = [NSString stringWithFormat:@"<item xsi:type=\"xsd:int\">%d</item><item SOAP-ENC:arrayType=\"ns2:Map[1]\" xsi:type=\"SOAP-ENC:Array\"><item xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">product_id</key><value xsi:type=\"xsd:string\">%@</value></item></item></item>",[self.cartId intValue],productId];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"xsd:ur-type[2]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kCartRemoveProductApi,argsValue];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		cartSetCustomer
 @abstract		set customer information to cart.
 @discussion    set customer information to cart.
 */
- (void)cartSetCustomer
{
    self.requestState =  kCartSetCustomer;
    NSString *argsValue = nil;
    argsValue = [NSString stringWithFormat:@"<item xsi:type=\"xsd:int\">%@</item><item xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">firstname</key><value xsi:type=\"xsd:string\">John</value></item><item><key xsi:type=\"xsd:string\">lastname</key><value xsi:type=\"xsd:string\">Doe</value></item><item><key xsi:type=\"xsd:string\">email</key><value xsi:type=\"xsd:string\">johndoe@gmail.com</value></item><item><key xsi:type=\"xsd:string\">website_id</key><value xsi:type=\"xsd:string\">0</value></item><item><key xsi:type=\"xsd:string\">store_id</key><value xsi:type=\"xsd:string\">0</value></item><item><key xsi:type=\"xsd:string\">mode</key><value xsi:type=\"xsd:string\">guest</value></item></item>",self.cartId];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"xsd:ur-type[2]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kSetCustomerApi,argsValue];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		cartSetCustomerAddress
 @abstract		set customer address information to cart.
 @discussion    set customer address information to cart.
 */
- (void)cartSetCustomerAddress
{
    self.requestState =  kCartSetCustomerAddress;
    NSString *argsValue = nil;
    argsValue = [NSString stringWithFormat:@"<item xsi:type=\"xsd:int\">%@</item><item SOAP-ENC:arrayType=\"ns2:Map[2]\" xsi:type=\"SOAP-ENC:Array\"><item xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">mode</key><value xsi:type=\"xsd:string\">shipping</value></item><item><key xsi:type=\"xsd:string\">firstname</key><value xsi:type=\"xsd:string\">John</value></item><item><key xsi:type=\"xsd:string\">lastname</key><value xsi:type=\"xsd:string\">Doe</value></item><item><key xsi:type=\"xsd:string\">company</key><value xsi:type=\"xsd:string\">testCompanyShipping</value></item><item><key xsi:type=\"xsd:string\">street</key><value xsi:type=\"xsd:string\">tesStreetshipping</value></item><item><key xsi:type=\"xsd:string\">city</key><value xsi:type=\"xsd:string\">testCityshipping</value></item><item><key xsi:type=\"xsd:string\">region</key><value xsi:type=\"xsd:string\">testRegionshipping</value></item><item><key xsi:type=\"xsd:string\">postcode</key><value xsi:type=\"xsd:string\">testPostcodeshipping</value></item><item><key xsi:type=\"xsd:string\">country_id</key><value xsi:type=\"xsd:string\">IN</value></item><item><key xsi:type=\"xsd:string\">telephone</key><value xsi:type=\"xsd:string\">0123456789</value></item><item><key xsi:type=\"xsd:string\">fax</key><value xsi:type=\"xsd:string\">0123456789</value></item><item><key xsi:type=\"xsd:string\">is_default_shipping</key><value xsi:type=\"xsd:int\">0</value></item><item><key xsi:type=\"xsd:string\">is_default_billing</key><value xsi:type=\"xsd:int\">0</value></item></item><item xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">mode</key><value xsi:type=\"xsd:string\">billing</value></item><item><key xsi:type=\"xsd:string\">firstname</key><value xsi:type=\"xsd:string\">John</value></item><item><key xsi:type=\"xsd:string\">lastname</key><value xsi:type=\"xsd:string\">Doe</value></item><item><key xsi:type=\"xsd:string\">company</key><value xsi:type=\"xsd:string\">testCompanyBilling</value></item><item><key xsi:type=\"xsd:string\">street</key><value xsi:type=\"xsd:string\">testStreetBilling</value></item><item><key xsi:type=\"xsd:string\">city</key><value xsi:type=\"xsd:string\">testCityBilling</value></item><item><key xsi:type=\"xsd:string\">region</key><value xsi:type=\"xsd:string\">testRegionBilling</value></item><item><key xsi:type=\"xsd:string\">postcode</key><value xsi:type=\"xsd:string\">testPostcodeBilling</value></item><item><key xsi:type=\"xsd:string\">country_id</key><value xsi:type=\"xsd:string\">IN</value></item><item><key xsi:type=\"xsd:string\">telephone</key><value xsi:type=\"xsd:string\">0123456789</value></item><item><key xsi:type=\"xsd:string\">fax</key><value xsi:type=\"xsd:string\">0123456789</value></item><item><key xsi:type=\"xsd:string\">is_default_shipping</key><value xsi:type=\"xsd:int\">0</value></item><item><key xsi:type=\"xsd:string\">is_default_billing</key><value xsi:type=\"xsd:int\">0</value></item></item></item>",self.cartId];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"xsd:ur-type[2]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kSetCustomerAddressApi,argsValue];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		cartSetShippingMethod
 @abstract		set shipping method to cart.
 @discussion    set shipping method to cart.
 */
- (void)cartSetShippingMethod
{
    self.requestState =  kCartSetShippingMethod;
    NSString *argsValue = [NSString stringWithFormat:@"<item xsi:type=\"xsd:int\">%@</item><item xsi:type=\"xsd:string\">flatrate_flatrate</item>",self.cartId];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"xsd:ur-type[2]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kSetShippingMethodApi,argsValue];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		cartSetPaymentMethod
 @abstract		set payment method to cart.
 @discussion    set payment method to cart.
 */
- (void)cartSetPaymentMethod
{
    self.requestState =  kCartSetPaymentMethod;
    NSString *argsValue = [NSString stringWithFormat:@"<item xsi:type=\"xsd:int\">%@</item><item xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">method</key><value xsi:type=\"xsd:string\">checkmo</value></item></item>",self.cartId];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"xsd:ur-type[2]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kSetPaymentMethodApi,argsValue];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		cartPlaceOrder
 @abstract		place order for cart.
 @discussion    place order for cart.
 */
- (void)cartPlaceOrder
{
    self.requestState =  KCartCreateOrder;
    NSString *argsValue = [NSString stringWithFormat:@"<item xsi:type=\"xsd:int\">%@</item><item SOAP-ENC:arrayType=\"xsd:string[1]\" xsi:type=\"SOAP-ENC:Array\"><item xsi:type=\"xsd:string\">default</item></item>",self.cartId];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"xsd:ur-type[2]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kCreatOrderApi,argsValue];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		productDetailsDataForProductId
 @abstract		get Cart Product information.
 @discussion    parse product detail.
 @param			cartModel - result will be return in this model object 
 */
- (void)productDetailsDataForProductId:(NSString *)cartProductId cartList:(CartList *)cartModel
{
    self.productId = cartProductId;
    self.cartList = cartModel;
    self.requestState = kCartProdDetailsRequest;
    
    //Magento APi call
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:anyType\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kCartProductDetailsAPI,self.productId];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		productImageForProductId
 @abstract		request for product,s image to server.
 @discussion    request for product,s image to server.
 @param			productId - productId of requested product details
 productSearch - result will be return in this productsearch object 
 */
- (void)productImageForProductId:(NSString *)cartProductId cartList:(CartList *)cartModel
{
    self.productId = cartProductId;
    self.cartList = cartModel;
    self.requestState = kCartProductImageRequest;
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:anyType\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kCartProductImageAPI,self.productId];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		requestWithSoapMessage
 @abstract		request to server with soap request object.
 @discussion	request to server with soap request object.
 @param			soapMsg - soap message 
 @result		void
 */
- (void)requestWithSoapMessage:(NSString *)soapMsg 
{
    //create a url load request
    NSURL *url = [NSURL URLWithString: kMagentoServerUrl];
    NSMutableURLRequest *req = nil;
    req = [NSMutableURLRequest requestWithURL:url];
    
    //populate the request object with the various headers,
    //such as Content-Type, SOAPAction, and Content-Length. You also set the HTTP method and HTTP body:
    NSString *msgLength = nil;
    msgLength = [NSString stringWithFormat:@"%d", [soapMsg length]];    
    [req addValue:kContentTypeValue  forHTTPHeaderField:kContentType];
    [req addValue:kAcceptEncodingValue  forHTTPHeaderField:kAcceptEncoding];
    [req addValue:kUserAgentValue  forHTTPHeaderField:kUserAgent];
    [req addValue:kHostValue forHTTPHeaderField:kHost];    
    [req addValue:kSoapActionValue forHTTPHeaderField:kSoapAction];
    [req addValue:msgLength forHTTPHeaderField:kContentLength];
    [req setHTTPMethod:kPost];
    [req setHTTPBody:[soapMsg dataUsingEncoding:NSUTF8StringEncoding]];
    
    [self.netDataManager makeRequest:req];
}

#pragma mark -- Delegate method called when we recieve the data.
- (void)didReceiveData:(NSData*)data
{
    NSString* newStr = [NSString stringWithUTF8String:[data bytes]];
    TRC_DBG(@"NSData = %@",newStr);

    CartListXMLParser *cartXMLParser = [[CartListXMLParser alloc]init];
    NSError *error = nil;
    switch (self.requestState) 
    {
        case kCartCreateRequest:{
            NSString *cartId = [cartXMLParser parseXMLDataForCartId:(NSData *)data];
            
            TRC_DBG(@"cartId = %@",self.cartId);
            if (cartId) {
                UserExtended *userExtended = [UserExtended sharedUserExteded];
                userExtended.cartId = cartId;
                self.cartId = cartId;
                [self cartSetCustomer];
                return;
            }
            else{
                error = [cartXMLParser parseXMLDataForFaultReturn:data];
            }
        }
            break;
        case kCartListRquest:{
            [cartXMLParser parseXMLDataForCartList:(NSData *)data cartProductList:(NSMutableArray*)self.cartListArray];
            TRC_DBG(@"Cart Count count=%d",[self.cartListArray count]);
        }
            break;
        case kCartInfoRequest:{
            [cartXMLParser parseXMLDataForCartInfo:data cartInfo:self.cartInfo];
            //TRC_DBG(@"Cart info =%d",[self.cart count]);
        }
            break;
        case kCartProdDetailsRequest:{
            [cartXMLParser parseXMLDataForProductDetails:data productId:self.productId cartProduct:self.cartList];
            
            [self productImageForProductId:self.productId cartList:self.cartList];
            TRC_DBG(@"Product Detail = %@",self.cartList);
        }
            break;
        case kCartProductImageRequest:{
            [cartXMLParser parseXMLDataForProductImage:data cartProduct:self.cartList];
        }
            break;
        case kCartProductAddRequest:{
            error = [cartXMLParser parseXMLDataForBoolReturn:data];
        }
            break;
        case kCartSetCustomer:{
            TRC_DBG(@"kCartSetCustomer ");
            error = [cartXMLParser parseXMLDataForBoolReturn:data];
            if (!error) {
                [self cartSetCustomerAddress];
                 return;
            }
        }
            break;
        case kCartSetCustomerAddress:{
            error = [cartXMLParser parseXMLDataForBoolReturn:data];
             TRC_DBG(@"kCartSetCustomerAddress ");
            if (!error) {
                [self addProductToCart];
                return;
            }
        }
            break;
        case kCartSetShippingMethod:{
            error = [cartXMLParser parseXMLDataForBoolReturn:data];
             TRC_DBG(@"kCartSetShippingMethod");
        }
            break;
        case kCartSetPaymentMethod:{
            error = [cartXMLParser parseXMLDataForBoolReturn:data];
            TRC_DBG(@"kCartSetPaymentMethod ");
        }
            break;
        case KCartCreateOrder:{
            NSString *orderId = [cartXMLParser parseXMLDataForCartId:(NSData *)data];
            
            TRC_DBG(@"orderId = %@",orderId);
            if (!orderId) {
                error = [cartXMLParser parseXMLDataForFaultReturn:data];
            }
            TRC_DBG(@"KCartCreateOrder");
        }
            break;
        case kCartRemoveProduct:{
            error = [cartXMLParser parseXMLDataForBoolReturn:data];
            TRC_DBG(@"KCartRemoveProduct");
        }
            break;
        default:
            break;
    }
    //Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:error];
	}
     
}


@end
