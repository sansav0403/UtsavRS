/* 
 File: CartViewController.h
 Abstract: This class is responsible for cart related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 07/23/12
 Modified: 07/23/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "CartReqResHandler.h"
#import "CartList.h"
#import "CartInfo.h"

typedef enum {
    kCartRequestNone,
    kCartDetailInfoRequest,
    kCartSetCustomerRequest,
    kCartSetCustomerAddressRequest,
    kCartSetShippingMethodRequest,
    kCartSetPaymentMethodRequest,
    KCartCreateOrderRequest,
    kCartRemoveProductRequest
}CartRequestState;

@interface CartViewController : UIViewController <UITableViewDataSource,UITableViewDelegate,NetworkRequestResponseBaseDelegate>


@property(nonatomic, weak) IBOutlet UITableView              *cartTbl;
@property(nonatomic, weak) IBOutlet UILabel                  *subTotalLbl;
@property(nonatomic, weak) IBOutlet UILabel                  *subTotal;
@property(nonatomic, weak) IBOutlet UILabel                  *shippingPriceLbl;
@property(nonatomic, weak) IBOutlet UILabel                  *shippingPrice;
@property(nonatomic, weak) IBOutlet UILabel                  *warrantyPrice;
@property(nonatomic, weak) IBOutlet UILabel                  *totalPriceLbl;
@property(nonatomic, weak) IBOutlet UILabel                  *totalPrice;
@property(nonatomic, weak) IBOutlet UIButton                 *checkOutBtn;
@property(nonatomic, weak) IBOutlet UIView                   *overlayView;
@property(nonatomic, weak) IBOutlet UILabel                  *cartRequestStatusMsg;
@property(nonatomic, weak) IBOutlet UIActivityIndicatorView  *activityIndicator;

@property(nonatomic, strong) CartInfo                          *cartInfo;
@property(nonatomic, strong) CartList                          *cartProduct;
@property(nonatomic, strong) CartReqResHandler                 *cartReqResHandler;
@property(nonatomic) CartRequestState                          cartRequestState;

- (void)initLocalizedString;
- (void)shippingPriceHidden:(BOOL)boolean;
- (void)cartListDetails;
- (void)updatePriceLabels;
- (IBAction)checkOut:(id)sender;

@end
