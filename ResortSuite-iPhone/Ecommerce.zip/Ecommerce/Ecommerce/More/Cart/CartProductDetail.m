/* 
 File: CartProductDetail.m
 Abstract: This is a xml parser class for Cart List Module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "CartProductDetail.h"
#import "ProductDetailCell.h"
#import "ProductDetailImageCell.h"
#import "ProductDetailDescriptionCell.h"
#import "CartCommon.h"
#import "Common.h"

@implementation CartProductDetail
@synthesize cartProductDetailTable = _cartProductDetailTable;
@synthesize cartProductId = _cartProductId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setTitle:kProductDetailsTitle];
    
    if (_cartModel) {
        _cartModel = nil;
    }
    _cartModel = [[CartList alloc] init];
    _cartReqResHandler = [[CartReqResHandler alloc]init];
    
    //get the product details from the server
    [_cartReqResHandler setDelegate:self];
    [_cartReqResHandler productDetailsDataForProductId:self.cartProductId cartList:_cartModel];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_cartReqResHandler setDelegate:nil];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return kNumberOfSections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return kNumberOfRows;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == k0Title)
    {
        return kImageRowHeight;
    } 
    else if (indexPath.row == k5Title)
    {
        return kDescriptionRowHeigth;
    } 
    else 
    {
        return kNormalRowHeigth;
    }    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *imageIdentifier = kProductImageCell;
    static NSString *detailsIdentifier = kProductDetailCell;
    static NSString *detailDescriptionIdentifier = kProductDetailDescriptionCell;
    
    ProductDetailCell *cell = (ProductDetailCell*)[tableView dequeueReusableCellWithIdentifier:detailsIdentifier];
    if (cell == nil) {
        cell = [[ProductDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailsIdentifier];
    }
    [cell setAccessoryType:UITableViewCellAccessoryNone];
    
    // Configure the cell...
    NSString *labelKey = nil;
    NSString *labelValue = nil;
    
    switch (indexPath.row)
    {
        case 0:
        {
            ProductDetailImageCell *cell = (ProductDetailImageCell*)[tableView dequeueReusableCellWithIdentifier:imageIdentifier];
            if (cell == nil) {
                cell = [[ProductDetailImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:imageIdentifier];
            }
            if (!_cartModel.image) {
                [_cartModel setDelegate:cell];
                [_cartModel startDownload];
            }
            [cell setProductImage:_cartModel];
            return cell;
        }
            break;
        case 1:
        {
            labelKey = kName;
            labelValue = _cartModel.name;
        }
            break;
        case 2:
        {
            labelKey = kModel;
            labelValue = _cartModel.model;
        }
            break;
        case 3:
        {
            labelKey = kManufacturingDate;
            labelValue = _cartModel.manufacturingDate;
        }
            break;
        case 4:
        {
            labelKey = kDimension;
            labelValue = _cartModel.dimension;
        }
            break;
        case 5:
        {
            ProductDetailDescriptionCell *cell = (ProductDetailDescriptionCell*)[tableView dequeueReusableCellWithIdentifier:detailDescriptionIdentifier];
            if (cell == nil) {
                cell = [[ProductDetailDescriptionCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailDescriptionIdentifier];
            }
            //set product's description data
            labelKey = kDescription;
            labelValue = _cartModel.description;
            [cell setProductData:labelKey labelValue:labelValue];
            return cell;
        }
            break;
        case 6:
        {
            labelKey = kPriceInfoTitle;
            if (_cartModel.price) {
                NSString* str = [NSString stringWithFormat:@"%@ %@",_cartModel.currency,_cartModel.price];
                labelValue = str;
            }
            
        }
            break;

        default:
            break;
    }
    [cell setProductData:labelKey labelValue:labelValue];
    return cell;
}




#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) 
    {
        TRC_DBG(@"fail to load data from URL");
    }
    else
    {
        [self.cartProductDetailTable reloadData];
    }        
}

@end
