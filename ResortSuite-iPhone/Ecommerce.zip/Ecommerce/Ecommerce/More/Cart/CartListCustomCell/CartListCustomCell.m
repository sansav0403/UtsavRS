/* 
 File: CartListCustomCell.M
 Abstract: This is a custom cell class for displaying products in the cart List.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "CartListCustomCell.h"

@implementation CartListCustomCell

@synthesize cartListModel = _cartListModel;
@synthesize quantity = _quantity;
@synthesize shippingPrice = _shippingPrice;
@synthesize warrantyPrice = _warrantyPrice;
@synthesize price = _price;
@synthesize cartListImageView = _cartListImageViewS;
@synthesize productName = _productName;
@synthesize activityIndicatorView = _activityIndicatorView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setCartListData
 @abstract      set cart List details to cell.
 @discussion    set cart List details to cell.
 @param         CartList - cartList of which details need to set to cell.
 int - cell index
 @result        void
 */
- (void)setCartListData:(CartList*)cartList
{
    self.cartListModel = cartList;
    self.productName.text = [self.cartListModel sku];
    self.price.text = [self.cartListModel price];
    self.shippingPrice.text = [self.cartListModel rowTotal];
    self.warrantyPrice.text = [self.cartListModel warrantyPrice];
    self.quantity.text = [self.cartListModel quantity];
       
    [self.cartListImageView setImage:nil];
    if(self.cartListModel.image)
    {
        [self.cartListImageView setImage:self.cartListModel.image];
        [self.activityIndicatorView stopAnimating];
    }
}


#pragma mark - Product image data DELEGETE
/*!
 @function      didReceivedData
 @abstract      set product details to cell.
 @discussion    set product details to cell.
 @param         Product - product of which details need to set to cell.
                int - cell index
 @result        void
 */
- (void)didReceivedData:(id)imgData urlString:(NSString *)urlString
{
    TRC_DBG(@"%@", urlString );
    
    if([urlString isEqualToString:self.cartListModel.imageUrl])
    {
        [self.cartListImageView setImage:imgData];
        [self.activityIndicatorView stopAnimating];
    }
    TRC_DBG(@"%@", self.cartListModel.imageUrl);
    
}


@end
