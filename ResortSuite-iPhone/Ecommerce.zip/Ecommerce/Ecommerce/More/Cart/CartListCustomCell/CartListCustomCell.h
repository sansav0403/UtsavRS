/* 
 File: CartListCustomCell.h
 Abstract: This is a custom cell class for displaying products in the cart List.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "CartList.h"
#import "ProductCell.h"

@interface CartListCustomCell : ProductCell<ProductImageDataDelegate>

@property(nonatomic, strong) CartList *cartListModel;
@property(nonatomic, weak) IBOutlet UIImageView                *cartListImageView;
@property(nonatomic, weak) IBOutlet UIActivityIndicatorView    *activityIndicatorView;
@property(nonatomic, weak) IBOutlet UILabel                    *shippingPrice;
@property(nonatomic, weak) IBOutlet UILabel                    *productName;
@property(nonatomic, weak) IBOutlet UILabel                    *warrantyPrice;
@property(nonatomic, weak) IBOutlet UILabel                    *quantity;
@property(nonatomic, weak) IBOutlet UILabel                    *price;

- (void)setCartListData:(CartList*)cartList;

@end
