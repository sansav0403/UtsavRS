/* 
 File: CartViewController.m
 Abstract: This class is responsible for cart related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 07/23/12
 Modified: 05/24/12
 Version: 1.0 
 */

#import "CartViewController.h"
#import "CartListCustomCell.h"
#import "CartProductDetail.h"
#import "Message.h"
#import "CartCommon.h"
#import "Common.h"


@implementation CartViewController

@synthesize cartInfo = _cartInfo;
@synthesize cartProduct =_cartProduct;
@synthesize cartTbl = _cartTbl;
@synthesize shippingPriceLbl = _shippingPriceLbl;
@synthesize shippingPrice = _shippingPrice;
@synthesize warrantyPrice = _warrantyPrice;
@synthesize subTotalLbl = _subTotalLbl;
@synthesize subTotal = _subTotal;
@synthesize totalPriceLbl = _totalPriceLbl;
@synthesize totalPrice = _totalPrice;
@synthesize checkOutBtn = _checkOutBtn;
@synthesize cartRequestState = _cartRequestState;
@synthesize cartReqResHandler = _cartReqResHandler;
@synthesize overlayView = _overlayView;
@synthesize cartRequestStatusMsg = _cartRequestStatusMsg;
@synthesize activityIndicator = _activityIndicator;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.cartReqResHandler = [[CartReqResHandler alloc]init];
        self.cartProduct = [[CartList alloc]init];
        self.cartRequestState = kCartRequestNone;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = kCartTitle;
    
    [self initLocalizedString];
    [self shippingPriceHidden:TRUE];
    [self cartListDetails];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.cartReqResHandler setDelegate:nil];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*!
 @function      initLocalizedString
 @abstract      set localizable string to view
 @discussion    set localizable string to view 
 @result        void
 */
- (void)initLocalizedString
{    
    [self.subTotalLbl setText:kSubTotalTitle];
    [self.shippingPriceLbl setText:kShippingPriceTitle];
    [self.totalPriceLbl setText:kTotalTitle];
    [self.checkOutBtn setTitle:kPlaceOrderBtnTitle forState:UIControlStateNormal];
    [self.checkOutBtn setTag:k0Title];
}

/*!
 @function      shippingPriceHidden
 @abstract      hidden or disable shipping price
 @discussion    hidden or disable shipping price 
 @param         boolean - TRUE or False   
 @result        void
 */
- (void)shippingPriceHidden:(BOOL)boolean
{
    [self.shippingPriceLbl setHidden:boolean];
    [self.shippingPrice setHidden:boolean];
}

/*!
 @function      cartListDetails
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)cartListDetails
{
    if (self.cartReqResHandler){
        [self.cartReqResHandler setDelegate:nil];
    }
    [self.cartReqResHandler setDelegate:self];
    
    if(self.cartInfo){
        self.cartInfo = nil;
    }
    self.cartInfo = [[CartInfo alloc] init];
    
    //call for cart details
    self.cartRequestState = kCartDetailInfoRequest;
    [self.cartReqResHandler cartDetailInfo:self.cartInfo];
}

/*!
 @function      updatePriceLabels
 @abstract      Sets the value of the price Labels
 @discussion    Sets the value of the price Labels 
 @param         nil 
 @result        void
 */
- (void)updatePriceLabels
{
    NSString *shippingPrice = nil;
    NSString *subTotal = nil;
    NSString *grandTotal = nil;
    NSString *usd = kUSDTitle;
    
    if ([self.cartInfo.currency isEqualToString:usd]) {
          shippingPrice = [NSString stringWithFormat:@"$ %@",self.cartInfo.shippingAmount];
          subTotal = [NSString stringWithFormat:@"$ %@",self.cartInfo.subTotal];
          grandTotal = [NSString stringWithFormat:@"$ %@",self.cartInfo.grandTotal];
    }
    else{
        shippingPrice = self.cartInfo.shippingAmount;
        subTotal = self.cartInfo.subTotal;
        grandTotal = self.cartInfo.grandTotal;
    }
    if (self.cartInfo.shippingAmount) {
        self.shippingPrice.text = shippingPrice;
    }
    if (self.cartInfo.subTotal) {
        self.subTotal.text = subTotal;
    }
    //self.warrantyPrice.text = [NSString stringWithFormat:@"$ %d",warrantyPriceValue];
    if (self.cartInfo.grandTotal) {
        self.totalPrice.text = grandTotal;
    }
    
}
//Delegate method

#pragma mark -- TableView Delegate and datasource methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	// Number of sections is the number of regions
	return kNumberOfSectionForCartList;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.cartInfo.productArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = kCellIdentifier;
    
    CartListCustomCell* cell = (CartListCustomCell* )[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:CellIdentifier owner:self options:nil];
        cell = (CartListCustomCell *)[nib objectAtIndex:0];        
    } 
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    
    self.cartProduct = [self.cartInfo.productArray objectAtIndex:indexPath.row];
    [self.cartProduct setDelegate:cell];
    [cell setCartListData:self.cartProduct];

    //Code to set the image
    if(!self.cartProduct.imageUrl)
    {
        [self.cartProduct imageUrlForProduct];
    }
    
    return cell;
}

- (float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kCellHeight;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    return YES;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //add code here for when you hit delete
        self.cartProduct = [self.cartInfo.productArray objectAtIndex:indexPath.row];
        self.cartRequestState = kCartRemoveProductRequest;
        [self.cartReqResHandler setDelegate:self];
        [self.cartReqResHandler removeProductFromCart:self.cartProduct.productId];
        
        [self.view addSubview:self.overlayView];
        [self.activityIndicator startAnimating];
        [self.cartRequestStatusMsg setText:@""];
    }    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //extract the selected product for details
    CartList* cartProductSelected = [self.cartInfo.productArray objectAtIndex:indexPath.row];
    
    CartProductDetail *cartProductDetail = [[CartProductDetail alloc] initWithNibName:kCartProductDetail bundle:[NSBundle mainBundle]];
    cartProductDetail.cartProductId = cartProductSelected.productId;
    
    [self.navigationController pushViewController:cartProductDetail animated:YES];
    cartProductDetail = nil;
}

/*!
 @function      checkOut
 @abstract      place the order for cart
 @discussion    place the order for cart 
 @param         nil 
 */
- (IBAction)checkOut:(id)sender
{
    [self shippingPriceHidden:FALSE];
    if([sender tag] == k0Title)
    {
        self.cartRequestState = kCartSetShippingMethodRequest;
        [self.cartReqResHandler cartSetShippingMethod];
        [self.view addSubview:self.overlayView];
        [self.activityIndicator startAnimating];
        [self.cartRequestStatusMsg setText:kSetShippingMsg];
        
    }else if([sender tag] == k1Title){
        self.cartRequestState = KCartCreateOrderRequest;
        [self.cartReqResHandler cartPlaceOrder];
        [self.view addSubview:self.overlayView];
        [self.activityIndicator startAnimating];
        [self.cartRequestStatusMsg setText:kPlacingOrderMsg];
    }
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animate
{
    [super setEditing:editing animated:animate];
    if(editing)
    {
        TRC_DBG(@"editMode on");
    }
    else
    {
        TRC_DBG(@"Done leave editmode");
    }
}
#pragma mark - Parse delegate 

/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) {
        TRC_DBG(@"fail to load data from URL");        
        [self.activityIndicator stopAnimating];
        [self.overlayView removeFromSuperview];
        
        [Message showOKOnly:[error localizedDescription] alertMessage:nil setDelegate:nil];
    }
    else{
        TRC_DBG(@"Pass to load data from URL");
        
        switch (self.cartRequestState) {
            case kCartDetailInfoRequest:
            {
                [self.cartTbl reloadData];
                [self updatePriceLabels];
            }
                break;
            case kCartSetShippingMethodRequest:
            {
                [self.cartRequestStatusMsg setText:kSetPaymentMsg];
                self.cartRequestState = kCartSetPaymentMethodRequest;
                [self.cartReqResHandler cartSetPaymentMethod];
            }
                break;
            case kCartSetPaymentMethodRequest:
            {
                //remove indicator
                [self.activityIndicator stopAnimating];
                [self.overlayView removeFromSuperview];
                
                [self cartListDetails];
                [self.checkOutBtn setTitle:kCheckOutBtnTitle forState:UIControlStateNormal];
                [self.checkOutBtn setTag:k1Title];
                
                [Message showOKOnly:kFinalOrderVerifyMsg alertMessage:nil setDelegate:nil];
            }
                break;
            case KCartCreateOrderRequest:
            {
                //remove indicator
                [self.activityIndicator stopAnimating];
                [self.overlayView removeFromSuperview];
                
                [Message showOKOnly:kOrderSuccessMsg alertMessage:nil setDelegate:nil];
            }
                break;
            case kCartRemoveProductRequest:
            {
                [self.activityIndicator stopAnimating];
                [self.overlayView removeFromSuperview];
            
                [Message showOKOnly:kProductDeleteFromCartSuccessMsg alertMessage:nil setDelegate:nil];
                [self cartListDetails];
            }
            default:
                break;
        }
    }        
}


@end
