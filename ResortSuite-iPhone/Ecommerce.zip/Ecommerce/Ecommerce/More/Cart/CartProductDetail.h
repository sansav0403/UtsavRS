/* 
 File: CartProductDetail.h
 Abstract: This is a view controller class for Cart Product Detail class.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "CartList.h"
#import "CartReqResHandler.h"


/*!
 @class       CartProductDetail
 @abstract    Cart Detail class.
 @discussion  CartList Detail Parser  class.
 */
@interface CartProductDetail : UIViewController<UITableViewDataSource,UITableViewDelegate,NetworkRequestResponseBaseDelegate>
{
    CartList            *_cartModel;
    CartReqResHandler   *_cartReqResHandler;
}

@property(nonatomic, strong) NSString               *cartProductId;
@property(nonatomic, strong) IBOutlet UITableView   *cartProductDetailTable;

@end
