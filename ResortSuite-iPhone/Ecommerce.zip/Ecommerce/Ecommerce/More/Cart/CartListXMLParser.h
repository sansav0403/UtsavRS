/* 
 File: CartListXMLParser.h
 Abstract: This is a xml parser class for Cart List Module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "CartList.h"
#import "XMLParser.h"
#import "CartInfo.h"

/*!
 @class       CartListXMLParser
 @abstract    Request Handler class.
 @discussion  CartList XML Parser  class.
 */

@interface CartListXMLParser : XMLParser

@property (nonatomic, strong) CartInfo *cartInfo;
@property (nonatomic, strong) CartList *cartProductDetail;
@property (nonatomic, strong) NSMutableArray *cartProductList;


- (void)parseXMLDataForCartList:(NSData *)dataToBeParsed cartProductList:(NSMutableArray*)cartProdList;
- (void)parseXMLDataForCartInfo:(NSData *)dataToBeParsed cartInfo:(CartInfo*)cartInfoData;
- (void)parseXMLDataForProductDetails:(NSData *)dataToBeParsed productId:(NSString *)productId cartProduct:(CartList *)cartListProduct;
- (void)parseXMLDataForProductImage:(NSData *)dataToBeParsed cartProduct:(CartList *)cartListProduct;

- (NSString *)parseXMLDataForCartId:(NSData *)data;
- (NSString*)parseXMLDataForAddProductToCart:(NSData *)dataToBeParsed; 

@end
