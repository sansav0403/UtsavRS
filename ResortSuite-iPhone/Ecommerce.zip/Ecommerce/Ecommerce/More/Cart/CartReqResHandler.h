/* 
 File: CartReqResHandler.h
 Abstract: This is a request handler class for Cart List Module.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "NetworkRequestResponseBase.h"
#import "CartList.h"
#import "CartInfo.h"


/*!
 @class       CartReqResHandler
 @abstract    Request Handler class.
 @discussion  CartList Request Handler  class.
 */

typedef enum {
    kCartCreateRequest,
    kCartProductAddRequest,
    kCartInfoRequest,
    kCartListRquest,
    kCartProdDetailsRequest,
    kCartProductImageRequest,
    kCartSetCustomer,
    kCartSetCustomerAddress,
    kCartSetShippingMethod,
    kCartSetPaymentMethod,
    kCartRemoveProduct,
    KCartCreateOrder
}CartHandlerRequestState;

@interface CartReqResHandler : NetworkRequestResponseBase


@property(nonatomic, strong) NSArray            *cartListArray;
@property(nonatomic, strong) NSString           *sessionId;
@property(nonatomic, strong) NSString           *cartId;
@property(nonatomic, strong) NSString           *productId;
@property(nonatomic, strong) Product            *product;
@property(nonatomic, strong) CartInfo           *cartInfo;
@property(nonatomic, strong) CartList           *cartList;
@property(nonatomic)   CartHandlerRequestState  requestState;

- (void)createCart;
- (void)addToCart:(Product *)product;
- (void)addProductToCart;
- (void)cartDetailInfo:(CartInfo*)cartInfoData;
- (void)cartDataList:(NSArray*)cartListArr;
- (void)productDetailsDataForProductId:(NSString *)cartProductId cartList:(CartList *)cartModel;
- (void)productImageForProductId:(NSString *)cartProductId cartList:(CartList *)cartModel;

//Below methods are requires to place order
- (void)cartSetCustomer;
- (void)cartSetCustomerAddress;
- (void)cartSetShippingMethod;
- (void)cartSetPaymentMethod;
- (void)cartPlaceOrder;
- (void)removeProductFromCart:(NSString *)productId;

- (void)requestWithSoapMessage:(NSString *)soapMsg;
- (void)didReceiveData:(NSData*)data;

//To be done
//Remove Cart when logout

@end
