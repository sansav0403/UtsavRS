//
//  MoreCommon.m
//  Ecommerce
//
//  Created by Basant Sarda on 4/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MoreCommon.h"

@implementation MoreCommon

@end
