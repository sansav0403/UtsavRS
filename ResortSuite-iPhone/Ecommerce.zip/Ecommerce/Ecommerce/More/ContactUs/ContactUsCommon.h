/* 
 File: ContactUsCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for Contact Us module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

//For email
#define kContactNumber      @"tel:912066041700"
#define kEmailSubject       @"ECommerce info"
#define kEmailReceipient    @"pranayu@cybage.com"
#define kEmailBody          @"Hi, this is mail from iPhone Ecommerce."
//For Email delegate
#define kEmailCancelled     @"Email cancelled"
#define kEmailSaved         @"Email saved successfully"
#define kEmailSent          @"Email sent successfully"
#define kEmailSendingFailed @"Email sending failed"
#define kEmailNotSent       @"Email not sent"
//For TextView
#define kCornerRadius   7.0;

#define kContactUsTitle             NSLocalizedString(@"Contact Us", @"")
#define kAppTitle                       NSLocalizedString(@"E-Commerce", @"")
#define kErrEmail                       NSLocalizedString(@"Please configure your iPhone mails", @"")
#define kButtonOk                       NSLocalizedString(@"Ok", @"")

