/* 
 File: ContactUsViewController.m
 Abstract: This class is responsible to show the conatct details
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 29/03/12
 Version: 1.0 
 */

#import "ContactUsViewController.h"
#import "QuartzCore/QuartzCore.h"
#import "ContactUsCommon.h"
#import "Message.h"


@implementation ContactUsViewController
@synthesize txtViewContactInfo = _txtViewContactInfo;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = kContactUsTitle;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //set the corner to textview
    self.txtViewContactInfo.layer.cornerRadius = kCornerRadius;
    self.txtViewContactInfo.clipsToBounds = YES;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self setTxtViewContactInfo:nil];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark  - Action Methods
/*!
 @method			makeCall
 @abstract			make a call to given number
 @discussion		This method is used to make a call
 */
- (IBAction)makeCall:(id)sender
{
    NSURL *phoneNumber = [[NSURL alloc] initWithString:kContactNumber];
    [[UIApplication sharedApplication] openURL: phoneNumber];
}

/*!
 @method			launchEmail
 @abstract			launch email composer
 @discussion		This method is used to launch the Email composer
 */
- (IBAction)launchEmail:(id)sender
{
    if ([MFMailComposeViewController canSendMail]) {
        MFMailComposeViewController *mailPicker = [[MFMailComposeViewController alloc] init];
        mailPicker.mailComposeDelegate = self;
        [mailPicker setSubject:kEmailSubject];
    
        // Set up recipients
        NSArray *toRecipients = [NSArray arrayWithObject:kEmailReceipient];
        [mailPicker setToRecipients:toRecipients];
    
        // Set the Email Body
        NSString *emailBody = kEmailBody;
        [mailPicker setMessageBody:emailBody isHTML:NO];
    
        [self presentModalViewController:mailPicker animated:YES];
    } else {
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:kErrEmail delegate:nil cancelButtonTitle:nil otherButtonTitles:kButtonOk, nil];
        [alert show];

    }
}

#pragma mark - delegate methos for MFMailComposeViewController
/*!
 @function			mailComposeController
 @abstract			delegate for MFMailComposeViewController 
 @discussion		This method getting called on mail operation 
 @param				result - return result  
 @result			- 
 */
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    NSString* msgStr = nil;
    // Notifies users about errors associated with the interface
    switch (result)
    {
        case MFMailComposeResultCancelled:
            msgStr = kEmailCancelled;
            break;
        case MFMailComposeResultSaved:
            msgStr = kEmailSaved;
            break;
        case MFMailComposeResultSent:
            msgStr = kEmailSent;
            break;
        case MFMailComposeResultFailed:
            msgStr = kEmailSendingFailed;
            break;
        default:
            msgStr = kEmailNotSent;
            break;
    }
    [self dismissModalViewControllerAnimated:YES];
    
    //show the alert
    [Message showOKOnly:kAppTitle alertMessage:msgStr setDelegate:nil];
}

@end
