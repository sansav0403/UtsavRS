/* 
 File: ContactUsViewController.h
 Abstract: This class is responsible to show the conatct details
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 29/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

/*!
 @class       ContactUsViewController
 @abstract    Contains contact information.
 @discussion  This class show the conatct information.
 */
@interface ContactUsViewController : UIViewController<MFMailComposeViewControllerDelegate> 

@property(nonatomic, weak) IBOutlet UITextView *txtViewContactInfo;

- (IBAction)makeCall:(id)sender;
- (IBAction)launchEmail:(id)sender;

@end
