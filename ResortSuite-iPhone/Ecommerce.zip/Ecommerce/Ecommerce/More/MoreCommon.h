//
//  MoreCommon.h
//  Ecommerce
//
//  Created by Basant Sarda on 4/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MoreCommon : NSObject

@end
