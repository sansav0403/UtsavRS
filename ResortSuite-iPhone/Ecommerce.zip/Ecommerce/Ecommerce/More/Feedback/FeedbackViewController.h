/* 
 File: FeedbackViewController.h
 Abstract: This class is responsible to submit the feedback
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 29/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>

/*!
 @class       FeedbackViewController
 @abstract    Submitt the feedback.
 @discussion  This class is used to submit the feedback information
 */
@interface FeedbackViewController : UIViewController<UITextViewDelegate>

@property(nonatomic, strong) IBOutlet UITextView *txtViewComment;

- (IBAction)submitComments:(id)sender;

@end
