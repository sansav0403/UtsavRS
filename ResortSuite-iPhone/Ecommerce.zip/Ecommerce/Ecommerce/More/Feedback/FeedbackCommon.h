/* 
 File: ContactUsCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for Contact Us module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

//For TextView
#define kCornerRadius   7.0

#define kFeedbackTitle              NSLocalizedString(@"Feedback", @"")
#define kFeedbackSuccessMsg             NSLocalizedString(@"Feedback submitted successfully.", @"")
#define kFeedbackErrMessageBlank        NSLocalizedString(@"Please enter feedback.", @"")
#define kButtonOk                       NSLocalizedString(@"Ok", @"")
#define kAppTitle                       NSLocalizedString(@"E-Commerce", @"")


