/* 
 File: FeedbackViewController.m
 Abstract: This class is responsible to submit the feedback
 Author: Cybage Software Pvt. Ltd
 Created By: Pranay Urkude
 Created: 29/03/12
 Version: 1.0 
 */

#import "FeedbackViewController.h"
#import "QuartzCore/QuartzCore.h"
#import "FeedbackCommon.h"


@implementation FeedbackViewController
@synthesize txtViewComment = _txtViewComment;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = kFeedbackTitle;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //set the corner to textview
    self.txtViewComment.layer.cornerRadius = kCornerRadius;
    self.txtViewComment.clipsToBounds = YES;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark  - Action Methods
/*!
 @method			submitComments
 @abstract			submitt feedback
 @discussion		Used to submit the feedback
 */
- (IBAction)submitComments:(id)sender
{
    [self.txtViewComment resignFirstResponder];
    if ([self.txtViewComment text].length <= 0){
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:kFeedbackErrMessageBlank delegate:nil cancelButtonTitle:nil otherButtonTitles:kButtonOk, nil];
        [alert show];
    } else {
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:kAppTitle message:kFeedbackSuccessMsg delegate:nil cancelButtonTitle:nil otherButtonTitles:kButtonOk, nil];
        [alert show];
    }
}

#pragma mark  - Delegate Method for UITextView
/*!
 @function          shouldChangeTextInRange
 @abstract          delegate for textView 
 @discussion        Called when text written in TextView
 @param             text - text of the textView 
 @result            BOOL 
 */
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range 
 replacementText:(NSString *)text
{
    // Any new character added is passed in as the "text" parameter
    if ([text isEqualToString:@"\n"]) {
        // Be sure to test for equality using the "isEqualToString" message
        [textView resignFirstResponder];
        
        // Return FALSE so that the final '\n' character doesn't get added
        return FALSE;
    }
    // For any other character return TRUE so that the text gets added to the view
    return TRUE;
}

@end
