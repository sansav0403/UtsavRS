/* 
 File: EcommerceAppDelegate.m
 Abstract: This class is responsible for launching and shutdown operation for application.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
*/

#import "EcommerceAppDelegate.h"

#import "ProductSearchViewController.h"
#import "PriceInfoSearchViewController.h"
#import "AvailabilitySearchViewController.h"
#import "PlaceOrderSearchViewController.h"
#import "MoreViewController.h"
#import "NetworkStatusManager.h"
#import "Common.h"

#define kKeychainIdentifier         @"ECOMMERCE"
#define kKeychainAccessGroup        @"VF6FJJHG2K.com.cybage.com"

@implementation EcommerceAppDelegate

@synthesize window = _window;
@synthesize tabBarController = _tabBarController;
@synthesize loginViewController = _loginViewController;
@synthesize navigationController = _navigationController;
@synthesize keychainItemWrapper=_keychainItemWrapper;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [[NetworkStatusManager sharedNetworkStatusManager] startNetworkStatusNotifier];
    
    //Temporary : login to get session Id
    LoginReqResHandler *loginReqResHandler = nil;
    loginReqResHandler = [[LoginReqResHandler alloc] init];
    [loginReqResHandler login:kUserName apiKey:kApiKey];
    
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
   
    //For Keychain
    self.keychainItemWrapper = [[KeychainItemWrapper alloc] initWithIdentifier:kKeychainIdentifier accessGroup:kKeychainAccessGroup];    
    
    //Redirect to login page
    //[self redirectToLoginView];
    
    //initialize tabBar with ViewControllers
    [self initTabBarController];
    
    self.window.rootViewController = self.tabBarController;
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}

/*
// Optional UITabBarControllerDelegate method.
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
}
*/

/*
// Optional UITabBarControllerDelegate method.
- (void)tabBarController:(UITabBarController *)tabBarController didEndCustomizingViewControllers:(NSArray *)viewControllers changed:(BOOL)changed
{
}
*/

/*!
 @function		initTabBarController
 @abstract		load viewControllers to TabBar
 @discussion	load viewControllers to TabBar
 @result		void
 */
- (void)initTabBarController
{
    //Initialize navigationcontrollers with rootViewController
    UIViewController *productSearchVC = [[ProductSearchViewController alloc] initWithNibName:kProductSearchVCNib bundle:nil];
    UINavigationController *productSearchNC = [[UINavigationController alloc]initWithRootViewController:productSearchVC];
    
    UIViewController *priceInfoSearchVC = [[PriceInfoSearchViewController alloc] initWithNibName:kPriceInfoSearchVCNib bundle:nil];
    UINavigationController *priceInfoSearchNC = [[UINavigationController alloc]initWithRootViewController:priceInfoSearchVC];
    
    UIViewController *availabilitySearchVC = [[AvailabilitySearchViewController alloc] initWithNibName:kAvailabilitySearchVCNib bundle:nil];
    UINavigationController *availabilitySearchNC = [[UINavigationController alloc]initWithRootViewController:availabilitySearchVC];
    
    UIViewController *placeOrderSearchVC = [[PlaceOrderSearchViewController alloc] initWithNibName:kPlaceOrderSearchVCNib bundle:nil];
    UINavigationController *placeOrderSearchNC = [[UINavigationController alloc]initWithRootViewController:placeOrderSearchVC];
    
    UIViewController *moreVC = [[MoreViewController alloc] initWithNibName:kMoreVCNib bundle:nil];
    UINavigationController *moreNC = [[UINavigationController alloc]initWithRootViewController:moreVC];
    
    // Set navigation controller to tabBatController
    self.tabBarController = [[UITabBarController alloc] init];
    self.tabBarController.viewControllers = [NSArray arrayWithObjects:productSearchNC, priceInfoSearchNC,availabilitySearchNC,placeOrderSearchNC,moreNC, nil];
}

/*
 @function      redirectToLoginView
 @abstract      redirecting to login page
 @discussion    redirecting to login page
 @param         none
 @result        void
 */
- (void)redirectToLoginView
{
	if (_tabBarController)
	{
		[_tabBarController.view removeFromSuperview];
	}
	self.loginViewController = [[LoginViewController alloc] initWithNibName:kLoginViewControllerVCNib bundle:[NSBundle mainBundle]];
    [self.loginViewController setDelegate:self];
	
	self.navigationController = [[UINavigationController alloc] initWithRootViewController:self.loginViewController];
	[self.navigationController setNavigationBarHidden:YES];
	
    self.window.rootViewController = self.navigationController; 
}

/*
 @function      redirectToTabBar
 @abstract      redirecting to TabBar 
 @discussion    redirecting to TabBar
 @param         none
 @result        void
 */
- (void)redirectToTabBar
{
	if (_loginViewController)
	{
		[_loginViewController.view removeFromSuperview];
	}
	
    //load TabBarController with ViewControllers
	[self initTabBarController];
    
	//[self.window addSubview:self.navigationController.view];
    self.window.rootViewController = self.tabBarController; 
}

#pragma mark - Login status delegate
/*!
 @function		loginStatusDelegate
 @abstract		delgate for login result
 @discussion	checks if login is done successfully then redirecting to Home page.
 @param			aStatus - bool value to check if login done successfully or not
 @result		void
 */
- (void)loginStatusDelegate:(BOOL)aStatus
{
    if (aStatus) {
        [self redirectToTabBar];
    } else {
        [self handleLogOut];
		[self redirectToLoginView];
    }
}

/*!
 @function		handleLogOut
 @abstract		Set each viewController in tabbar to its root viewcontroller
 @discussion	when logout forn user profile set each viewController in tabbar to its 
 root viewcontroller.
 @param			aStatus - bool value to check if login done successfully or not
 @result		void
 */
- (void)handleLogOut
{     
    // clear session
    //[Session clear];
    
    //Set all Tab navigation controller on root.
    for (UINavigationController *viewController in self.tabBarController.viewControllers) {
        
        [viewController popToRootViewControllerAnimated:NO];
    }
} 

@end
