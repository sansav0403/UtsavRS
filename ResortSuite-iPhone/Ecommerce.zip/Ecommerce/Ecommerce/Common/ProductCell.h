/* 
 File: ProductCell.h
 Abstract: This is a base class for display product related information.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
*/

#import <UIKit/UIKit.h>

/*!
 @class       ProductCell
 @abstract    Contains Product custom cell information.
 @discussion  Holds Product custom cell information.
 */
@interface ProductCell : UITableViewCell
{
    UILabel                 *productTitleLbl;
    UILabel                 *productDescriptionLbl;
    UIImageView             *productImageView;
    UIActivityIndicatorView *activityIndicatorView;
}

@end
