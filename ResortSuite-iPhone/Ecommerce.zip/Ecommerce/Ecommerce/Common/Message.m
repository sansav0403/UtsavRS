//
//  Message.m
//  Canis
//
//  Created by Yifeng Jiang on 10/26/11.
//  Copyright 2011 Rakuten, Inc. All rights reserved.
//

#import "Message.h"
#import "Common.h"

@implementation Message

/*!
 @function		showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
 alertMessage - Message description for AlertView		
 @result			void
 */
+ (void)showOKOnly:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
	[alert show];
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function		showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
 alertMessage - Message description for AlertView		
 @result		void
 */
+ (void)showYesNo:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kNoTitle otherButtonTitles:kYesTitle, nil];
	[alert show];
}

@end
