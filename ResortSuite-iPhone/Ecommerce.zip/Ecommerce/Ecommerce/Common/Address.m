//
/* 
 File: Address.m
 Abstract: This is a base class for address information.
 Author: Cybage Software Pvt. Ltd
 Created: 17/05/12
 Modified: 17/05/12
 Version: 1.0 
 */

#import "Address.h"

@implementation Address
@synthesize addressId = _addressId;
@synthesize addressType = _addressType;
@synthesize city = _city;
@synthesize street = _street;
@synthesize postCode = _postCode;
@synthesize region = _region;
@synthesize countryId = _countryId;
@synthesize telephone = _telephone;
@synthesize fax = _fax;;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}


@end
