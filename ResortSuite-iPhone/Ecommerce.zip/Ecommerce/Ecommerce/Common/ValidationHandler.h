/* 
 File: ValidationHandler.h
 Abstract: This is a base class for display product related information.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
*/

#import <Foundation/Foundation.h>

/*!
    @class       ValidationHandler
    @abstract    handles the validation
    @discussion  handles the various validation for textFields
*/
@interface ValidationHandler : NSObject 
{

}

+ (BOOL)checkSpaceOrNewLineCharacter:(NSString *)inputString;
+ (NSString *)trimCurrentString:(NSString *)string;

@end
