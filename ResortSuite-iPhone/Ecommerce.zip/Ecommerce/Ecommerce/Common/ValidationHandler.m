/* 
 File: ValidationHandler.h
 Abstract: This is a base class for display product related information.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "ValidationHandler.h"

@implementation ValidationHandler

/*!
 @function		trimCurrentString
 @abstract		trim string by removing space at the end 
 @discussion	trim string by removing space at the end 
 @param			string - Which needs to trim
 @result		NSString - will return trimmed string
 */
+ (NSString *)trimCurrentString:(NSString *)givenString
{
    @try {
        return (givenString)?([givenString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]]) : givenString;
    }
    @catch (NSException *exception) {
        return givenString;
    }
}

/*!
 @function		checkSpaceOrNewLineCharacter
 @abstract		check space or newLineCharacter from string
 @discussion	check space or newLineCharacter from string
 @param			string - Which needs to check for space and newLineCharacter
 @result		BOOL - will retun the bool value for success or faliure of validation
 */
+ (BOOL)checkSpaceOrNewLineCharacter:(NSString *)inputString
{
    @try {
        NSString* postText = inputString;
        
        if(postText)
        {
            if([postText length] == 0) return NO;
            
            NSString *spaceRegex = @"\\s{1,}";            
            NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", spaceRegex];
            
            if (![phoneTest evaluateWithObject:postText])
            {
                return YES;
            }  
        }
        return NO;
    }
    @catch (NSException *exception) {
        return NO;
    }
}

@end