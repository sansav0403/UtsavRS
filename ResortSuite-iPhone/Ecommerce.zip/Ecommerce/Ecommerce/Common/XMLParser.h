/* 
 File: XMLParser.h
 Abstract: This is a base class for parsing xml data.
 Author: Cybage Software Pvt. Ltd
 Created: 13/03/12
 Modified: 15/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "CXMLDocument.h"
#import "CXMLElement.h"

@protocol XMLParserDelegate <NSObject>

- (void)xmlParseComplete:(NSError*)error;

@end

@interface XMLParser : NSObject

- (NSArray *)parseXMLDataIntoDictionary:(NSData *)dataToBeParsed;
- (NSMutableDictionary *)parseRecursiveXMLDataIntoDictionary:(CXMLElement *)rootNode;
- (NSMutableDictionary *)parseKeyValueFromItemNode:(CXMLElement *)itemNode itemDictionary:(NSMutableDictionary *)item;
- (NSError *)parseXMLDataForBoolReturn:(NSData *)dataToBeParsed;
- (NSError *)parseXMLDataForFaultReturn:(NSData *)dataToBeParsed;

@end
