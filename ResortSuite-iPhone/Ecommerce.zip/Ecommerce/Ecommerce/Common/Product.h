/* 
 File: Product.h
 Abstract: This is a base class for E-Commerce product related information.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "ContentManager.h"
#import "NetworkRequestResponseBase.h"

@protocol ProductImageDataDelegate <NSObject>
- (void)didReceivedData:(id)imgData urlString:(NSString*)urlString;

@end

/*!
 @class       Product
 @abstract    E-Commerce Product information.
 @discussion  This Product modal class contains product information and can be used by other
              modal classes.
 */
@interface Product : NSObject<ContentManagerDelegate,NetworkRequestResponseBaseDelegate>
{
    ContentManager  *contentManager;
}

@property(nonatomic, weak) id<ProductImageDataDelegate>     delegate;
@property(nonatomic, strong) NSString                       *productId;
@property(nonatomic, strong) NSString                       *name;
@property(nonatomic, strong) NSString                       *sku;
@property(nonatomic, strong) NSString                       *type;
@property(nonatomic, strong) NSString                       *description;
@property(nonatomic, strong) NSString                       *imageUrl;
@property(nonatomic, strong) UIImage                        *image;
@property(nonatomic, strong) NSArray                        *categotryIds;
@property(nonatomic, strong) NSString                       *model;
@property(nonatomic, strong) NSString                       *dimension;
@property(nonatomic, strong) NSString                       *quantity;
@property(nonatomic, strong) NSString                       *orderedQuantity;
@property(nonatomic, strong) NSString                       *actualPrice;
@property(nonatomic, strong) NSString                       *offerPrice;
@property(nonatomic, strong) NSString                       *currency;

- (void)imageUrlForProduct;
- (void)startDownload;
- (void)parseComplete:(NSError*)error;

@end
