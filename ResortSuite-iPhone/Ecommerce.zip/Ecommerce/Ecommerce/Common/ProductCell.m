/* 
 File: ProductCell.m
 Abstract: This is a base class for display product related information.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
*/

#import "ProductCell.h"

#define kProductTitleLblFrame CGRectMake(100, 0, 200, 40)
#define kProductDescriptionLblFrame CGRectMake(100, 22, 200, 80)
#define kProductImageViewFrame CGRectMake(10, 1, 80, 80)
#define kActivityIndicatorViewFrame CGRectMake(30, 30, 20, 20)
#define kProductLblFontSize 14

@implementation ProductCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        productTitleLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [productTitleLbl setBackgroundColor:[UIColor clearColor]];
        [productTitleLbl setTextColor:[UIColor redColor]];
        [productTitleLbl setFont:[UIFont boldSystemFontOfSize:kProductLblFontSize]];

        productDescriptionLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [productDescriptionLbl setBackgroundColor:[UIColor clearColor]];
        [productDescriptionLbl setFont:[UIFont systemFontOfSize:kProductLblFontSize]];
        [productDescriptionLbl setLineBreakMode:UILineBreakModeWordWrap];
        [productDescriptionLbl setNumberOfLines:2];
        
        productImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        [productImageView setContentMode:UIViewContentModeScaleAspectFit];
        [productImageView setBackgroundColor:[UIColor clearColor]];
        
        activityIndicatorView = [[UIActivityIndicatorView alloc] initWithFrame:CGRectZero];
        [activityIndicatorView setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleGray];
        
        [productImageView addSubview:activityIndicatorView];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        //set frame for the title
        frame = kProductTitleLblFrame;
        [productTitleLbl setFrame:frame];
        
        frame = kProductDescriptionLblFrame;
        [productDescriptionLbl setFrame:frame];
        
        frame = kProductImageViewFrame;
        [productImageView setFrame:frame];
        
        frame = kActivityIndicatorViewFrame;
        [activityIndicatorView setFrame:frame];
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}


@end
