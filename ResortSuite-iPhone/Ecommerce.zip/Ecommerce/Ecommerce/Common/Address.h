/* 
 File: Address.h
 Abstract: This is a base class for address information.
 Author: Cybage Software Pvt. Ltd
 Created: 17/05/12
 Modified: 17/05/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>

@interface Address : NSObject

@property(nonatomic, strong) NSString   *addressId;
@property(nonatomic, strong) NSString   *addressType;
@property(nonatomic, strong) NSString   *city;
@property(nonatomic, strong) NSString   *street;
@property(nonatomic, strong) NSString   *postCode;
@property(nonatomic, strong) NSString   *region;
@property(nonatomic, strong) NSString   *countryId;
@property(nonatomic, strong) NSString   *telephone;
@property(nonatomic, strong) NSString   *fax;

@end
