//
//  Message.h
//  Canis
//
//  Created by Yifeng Jiang on 10/26/11.
//  Copyright 2011 Rakuten, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Message : NSObject
{
    
}

+ (void)showOKOnly:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;
+ (void)showYesNo:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;

@end
