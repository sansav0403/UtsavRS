/* 
 File: XMLParser.m
 Abstract: This is a base class for parsing xml data.
 Author: Cybage Software Pvt. Ltd
 Created: 13/03/12
 Modified: 15/03/12
 Version: 1.0 
*/

#import "XMLParser.h"
#import "Common.h"

@implementation XMLParser

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

/*!
 @function		parseXMLDataIntoDictionary
 @abstract		This function parse xml data and returns array of dictionary.
 @discussion	This function parse xml data and returns array of dictionary.
 @param			dataToBeParsed - NSData to be parsed.
 @result		NSArray - returns array of dictionary.
 */
- (NSArray *)parseXMLDataIntoDictionary:(NSData *)dataToBeParsed 
{  
    NSMutableArray *dictionaryArray = [[NSMutableArray alloc] init];
    
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    
    //  searching for piglet nodes
    NSString *tagName = kItem; 
    
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    TRC_DBG(@"item cnt = %d",[nodes count]);
    for (CXMLElement *node in nodes) 
    {
        if ([[[node childAtIndex:0] name] isEqualToString:tagName])
        {            
            NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
            for(int counter = 0; counter < [node childCount]; counter++) 
            {
                CXMLElement *itemNode = (CXMLElement*)[node childAtIndex:counter];
                
                NSString *keyString = nil;
                id valueString = nil;
                
                for(int keyValueCounter = 0; keyValueCounter < [itemNode childCount]; keyValueCounter++)
                {
                    CXMLElement *itemChildNode = (CXMLElement*)[itemNode childAtIndex:keyValueCounter];
                    TRC_DBG(@"name = %@",[itemChildNode name]);
                    TRC_DBG(@"stringValue = %@",[itemChildNode stringValue]);
                    TRC_DBG(@"localName = %@",[itemChildNode localName]);
                    
                    NSString * value = [[itemChildNode stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    
                    NSString *keyTag = kKey;
                    NSString *valueTag = kValue;
                    
                    if ([[itemChildNode name] isEqualToString:keyTag])
                    {                                       
                        if ([value length] != 0)
                        {
                            keyString = [itemChildNode stringValue];
                        }
                    }
                    else if([[itemChildNode name] isEqualToString:valueTag]) 
                    {
                        NSArray *arrayOfAttribute = [itemChildNode attributes];
                        NSString *strValue = nil;
                        NSString *strName = nil;
                        
                        // read attribute values
                        for (NSInteger i = 0; i < [arrayOfAttribute count]; i++) {
                            strValue=[[arrayOfAttribute objectAtIndex:i] stringValue];
                            strName=[[arrayOfAttribute objectAtIndex:i] name];
                            
                            TRC_DBG(@"strValue =%@",strValue);
                            TRC_DBG(@"strName =%@",strName);
                            NSString *soapArrayString = kSoapArray;
                            
                            if(strValue && strName && [strValue isEqualToString:soapArrayString])
                            {
                                valueString = [[NSMutableArray alloc] init];
                                
                                for(int valueCounter = 0; valueCounter < [itemChildNode childCount]; valueCounter++)
                                {
                                    CXMLElement *valueChildNode = (CXMLElement*)[itemChildNode childAtIndex:valueCounter];
                                    [valueString addObject:[valueChildNode stringValue]]; 
                                }
                            }
                            else
                            {
                                //if ([value length] != 0)
                                //{
                                    valueString = [itemChildNode stringValue];
                                //}
                            }
                        }
                    }
                }
                [item setObject:valueString forKey:keyString];
            } 
            [dictionaryArray addObject:item];
        }
    }
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        TRC_DBG(@"Product count = %d",[dictionaryArray count]);        
        TRC_DBG(@"product_id = %@",[item valueForKey:@"product_id"]);
        TRC_DBG(@"sku = %@",[item valueForKey:@"sku"]);
        TRC_DBG(@"name = %@",[item valueForKey:@"name"]);
        TRC_DBG(@"type = %@",[item valueForKey:@"type"]);
        //NSArray *category_array = [item objectForKey:@"category_ids"];
        //TRC_DBG(@"categoty_array = %@",category_array);
        
        TRC_DBG(@"------------------------------------------------ ");
    }
    
    return  dictionaryArray;
}

/*!
 @function		parseRecursiveXMLDataIntoDictionary
 @abstract		This function parse xml data and returns array of dictionary.
 @discussion	This function parse xml data and returns array of dictionary.
 @param			dataToBeParsed - NSData to be parsed.
 @result		NSArray - returns array of dictionary.
 */
- (NSMutableDictionary *)parseRecursiveXMLDataIntoDictionary:(CXMLElement *)rootNode
{
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    
    for (int nodeChildCounter = 0; nodeChildCounter < [rootNode childCount]; nodeChildCounter++) {
        
        CXMLElement *rootChildNode = (CXMLElement*)[rootNode childAtIndex:nodeChildCounter];
        
        item = [self parseKeyValueFromItemNode:rootChildNode itemDictionary:item];
    }
    return item;
}

/*!
 @function		parseKeyValueFromItemNode
 @abstract		This function parse xml data from Item node with Key value child node and returns array of dictionary.
 @discussion	This function parse xml data from Item node with Key value child node and returns array of dictionary.
 @param			dataToBeParsed - NSData to be parsed.
 @result		NSArray - returns array of dictionary.
 */
- (NSMutableDictionary *)parseKeyValueFromItemNode:(CXMLElement *)itemNode itemDictionary:(NSMutableDictionary *)item
{
    NSString *keyString = nil;
    id valueString = nil;
    
    for(int keyValueCounter = 0; keyValueCounter < [itemNode childCount]; keyValueCounter++)
    {
        CXMLElement *itemChildNode = (CXMLElement*)[itemNode childAtIndex:keyValueCounter];
        TRC_DBG(@"name = %@",[itemChildNode name]);
        TRC_DBG(@"stringValue = %@",[itemChildNode stringValue]);
        TRC_DBG(@"localName = %@",[itemChildNode localName]);
        
        NSString * value = [[itemChildNode stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

        NSString *keyTag = kKey;
        NSString *valueTag = kValue;
        
        if ([[itemChildNode name] isEqualToString:keyTag])
        {                                       
            if ([value length] != 0)
            {
                keyString = [itemChildNode stringValue];
            }
        }
        else if([[itemChildNode name] isEqualToString:valueTag]) 
        {
            NSArray *arrayOfAttribute = [itemChildNode attributes];
            NSString *strValue = nil;
            NSString *strName = nil;
            
            // read attribute values
            for (NSInteger i = 0; i < [arrayOfAttribute count]; i++) {
                strValue=[[arrayOfAttribute objectAtIndex:i] stringValue];
                strName=[[arrayOfAttribute objectAtIndex:i] name];
                
                TRC_DBG(@"strValue =%@",strValue);
                TRC_DBG(@"strName =%@",strName);
                NSString *soapArrayString = kSoapArray;
                NSString *ns2MapString = kNS2Map;
                
                if(strValue && strName && [strValue isEqualToString:soapArrayString])
                {
                    valueString = [[NSMutableArray alloc] init];
                    
                    for(int valueCounter = 0; valueCounter < [itemChildNode childCount]; valueCounter++)
                    {
                        CXMLElement *valueChildNode = (CXMLElement*)[itemChildNode childAtIndex:valueCounter];
                        
                        NSMutableDictionary *item = [self parseRecursiveXMLDataIntoDictionary:valueChildNode];
                        [valueString addObject:item];
                    }
                }
                else if(strValue && strName && [strValue isEqualToString:ns2MapString])
                {
                    valueString = [[NSMutableDictionary alloc] init];
                    
                    for(int valueCounter = 0; valueCounter < [itemChildNode childCount]; valueCounter++)
                    {
                        valueString = [self parseKeyValueFromItemNode:(CXMLElement*)[itemChildNode childAtIndex:valueCounter] itemDictionary:valueString];
                    }                    
                }
                else
                {
                    if ([value length] != 0)
                    {
                        valueString = [itemChildNode stringValue];
                    }
                }
            }
        }
    }
    if (valueString && keyString){
        [item setObject:valueString forKey:keyString];
    }
    
    return item;
}

/*!
 @function		parseXMLDataForBoolReturn
 @abstract		This function parse data for boolean return value.
 @discussion	This function returns nil if success else NSError object.
 @param			dataToBeParsed - data to be parsed.
 @result		NSError - return nil or server NSError object 
 */
- (NSError *)parseXMLDataForBoolReturn:(NSData *)dataToBeParsed 
{
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kCallReturnXMLTag; 
    NSString * value = nil;
    NSError *error = nil;
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    for (CXMLElement *node in nodes) {
        
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        
        //  common procedure: dictionary with keys/values from XML node
        [item setObject:[node stringValue] forKey:[node name]];
        
        value = [[node stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        TRC_DBG(@"Value is : %@", value);
        
        if ([value length] != 0){
            [item setObject:[node stringValue] forKey:[node localName]];
        }
    }
    
    NSString *trueString = kTrueTitle;
    
    if (![value isEqualToString:trueString]) {
        error = [self parseXMLDataForFaultReturn:dataToBeParsed];
    }
    return error;
}

/*!
 @function		parseXMLDataForFaultReturn
 @abstract		This function parse data for fault tag return value.
 @discussion	This function returns fault string.
 @param			dataToBeParsed - data to be parsed.
 @result		NSError - returns error object 
 */
- (NSError *)parseXMLDataForFaultReturn:(NSData *)dataToBeParsed 
{
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kFaultStringXMLTag; 
    NSString * value = nil;
    NSError *error = nil;
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    for (CXMLElement *node in nodes) {
        
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        
        //  common procedure: dictionary with keys/values from XML node
        [item setObject:[node stringValue] forKey:[node name]];
        
        value = [[node stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        TRC_DBG(@"Value is : %@", value);
        
        if ([value length] != 0){
            [item setObject:[node stringValue] forKey:[node localName]];
        }
    }
    
    NSString *errorDescription = value;
    
    NSMutableDictionary *errorDetail = [NSMutableDictionary dictionary];
    [errorDetail setValue:errorDescription forKey:NSLocalizedDescriptionKey];
    
    error = [NSError errorWithDomain:kEcommerce code:[kErrorCommonCode intValue] userInfo:errorDetail];
    
    return error;
}

@end
