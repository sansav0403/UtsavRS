/* 
 File: ProductSearchViewController.h
 Abstract: This class is responsible for product search related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

#import "Product.h"
#import "ProductSearchReqResHandler.h"

@implementation Product
@synthesize productId = _productId;
@synthesize name = _name;
@synthesize sku = _sku;
@synthesize type = _type;
@synthesize description = _description;
@synthesize imageUrl = _imageUrl;
@synthesize image = _image;
@synthesize categotryIds = _categotryIds;
@synthesize model = _model;
@synthesize dimension = _dimension;
@synthesize quantity = _quantity;
@synthesize orderedQuantity = _orderedQuantity;
@synthesize actualPrice = _actualPrice;
@synthesize offerPrice = _offerPrice;
@synthesize currency =_currency;
@synthesize delegate = _delegate;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        self.categotryIds = [[NSArray alloc] init];
    }
    
    return self;
}

/*!
 @function      startDownload
 @abstract      request product image
 @discussion    request product image
 @result        void
 */
- (void)startDownload
{
    if (self.imageUrl) {
        contentManager = [[ContentManager alloc] init];
        [contentManager setDelegate:self];
        [contentManager contentUrl:self.imageUrl];
    }
}

#pragma - CACHE MANAGER DELEGATE METHOD
/*!
 @function      handleData
 @abstract      response of data parsed for image
 @discussion    response of data parsed for imaage
 @param         resourceURL - url of requested image data
                returnError - nil if parsing success else NSError object
 @result        void
 */
- (void)handleData:(id)data resourceURL:(NSString*)urlString returnError:(NSError*)error
{
    if([self.delegate respondsToSelector:@selector(didReceivedData:urlString:)])
    {
        self.image = data;
        [self.delegate didReceivedData:data urlString:self.imageUrl];
    }
}

/*
 @function      imageUrlForProduct
 @abstract      request product image url
 @discussion    request product image url
 @result        void
 */
- (void)imageUrlForProduct
{    
    ProductSearchReqResHandler *productResReqHandler = nil;
    productResReqHandler = [[ProductSearchReqResHandler alloc] init];
    [productResReqHandler setDelegate:self];
    [productResReqHandler productImageUrlForProductId:self.productId product:self];
}

#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) {
        //TRC_DBG(@"fail to load data from URL");
    }
    else{
        //TRC_DBG(@"Pass to load data from URL");
        TRC_DBG(@"self.imageURL =%@",self.imageUrl);
        if (self.imageUrl) {
            [self startDownload];
        }
        else
        {
            if([self.delegate respondsToSelector:@selector(didReceivedData:urlString:)])
            {
                self.image = nil;
                [self.delegate didReceivedData:nil urlString:nil];
            }
        }
    }        
}

- (void)dealloc
{
    self.delegate = nil;
}

@end

