/* 
 File: Common.h
 Abstract: This class is contains E-Commerce aplication macros and constants for image names and ui text.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
*/

#ifndef Ecommerce_Common_h
#define Ecommerce_Common_h

#endif

//User Credentials
#define kUserName                   @"sandeep"
#define kApiKey                     @"sandeep"

// Images
#define kPriceInfoTBarItemImg           @"first.png"
#define kAvailabilityTBarItemImg        @"second.png"
#define kPlaceOrderTBarItemImg          @"couponsTBar.png"
#define kNoImage                        @"Noimages.png"

// View(Xib) Names
#define kLoginViewControllerVCNib       @"LoginViewController"
#define kProductSearchVCNib             @"ProductSearchViewController"
#define kPriceInfoSearchVCNib           @"PriceInfoSearchViewController"
#define kAvailabilitySearchVCNib        @"AvailabilitySearchViewController"
#define kPlaceOrderSearchVCNib          @"PlaceOrderSearchViewController"
#define kMoreVCNib                      @"MoreViewController"

// Button Titles
#define kButtonOk                   NSLocalizedString(@"Ok", @"")
#define kNoTitle                    NSLocalizedString(@"No", @"")
#define kYesTitle                   NSLocalizedString(@"Yes", @"")
#define kAddToCartButtonTitle       NSLocalizedString(@"Add_To_Cart", @"")
#define kAddToFavoriteButtonTitle   NSLocalizedString(@"Add_To_Favorite", @"")

// ViewControllers
#define kHelpAndFAQsViewController  @"HelpAndFAQsViewController"
#define kContactUsViewController    @"ContactUsViewController"
#define kFeedbackViewController     @"FeedbackViewController"
#define kAccountInfoViewController  @"AccountInfoViewController"
#define kOrderHistoryViewController @"OrderHistoryViewController"
#define kFavoriteViewController     @"FavoriteViewController"
#define kCartViewController         @"CartViewController"

// Others
#define kEcommerce                      @"Ecommerce"
#define kErrorCommonCode                @"100"
#define kNoNetwork                      @"No Network"
#define kError                          @"error"
#define kServerError                    @"Server error"

#define kGet                                    @"GET"
#define kIsFinishedkey                          @"isFinished"
#define kIsExecutingkey                         @"isExecuting"
#define kUSDTitle                               @"USD"
#define kDateFormateWithTime                    @"yyyy-MM-dd HH:mm:ss"
#define kDateFormateWithoutTime                 @"yyyy-MM-dd"

#define kProductAddedToCartSuccessfulMessage    NSLocalizedString(@"Product_added_to_cart_successfully", @"")
#define kMaxAvailableQty                        NSLocalizedString(@"Max_available_Qty", @"")

// server 
#define kMagentoServerUrl               @"http://172.27.47.87/magento/index.php/api/soap/index/HTTP/1.1"
//#define kServerUrl                      @"http://172.27.47.116"
#define kPost                           @"POST"
#define kGet                            @"GET"
#define kApplicationFormEncoded         @"application/x-www-form-urlencoded"
#define	kContentType                    @"Content-Type"
#define	kContentTypeValue               @"text/xml;charset=UTF-8"
#define kAcceptEncoding                 @"Accept-Encoding"
#define kAcceptEncodingValue            @"gzip,deflate"
#define kUserAgent                      @"User-Agent"
#define kUserAgentValue                 @"Jakarta Commons-HttpClient/3.1"
#define kHost                           @"Host"
#define kHostValue                      @"172.27.47.87"
#define kSoapAction                     @"SOAPAction"
#define kSoapActionValue                @"urn:Mage_Api_Model_Server_HandlerAction"
#define kContentLength                  @"Content-Length"

// xml parsing tags
#define kItem                           @"item"
#define kItems                          @"items"
#define kKey                            @"key"
#define kValue                          @"value"
#define kSoapArray                      @"SOAP-ENC:Array"
#define kNS2Map                         @"ns2:Map"

#define kCallReturnXMLTag               @"callReturn"
#define kFaultStringXMLTag              @"faultstring"
#define kTrueTitle                      @"true"

#define kProductIdXMLTag              @"product_id"
#define kProductSkuXMLTag             @"sku"
#define kProductNameXMLTag            @"name"
#define kProductTypeXMLTag            @"type"
#define kProductQuantityXMLTag        @"qty"
#define kProductCategoryIdXMLTag      @"category_ids"
#define kProductDescriptionXMLTag     @"description"
#define kProductManufactureXMLTag     @"manufacture"
#define kProductCreatedXMLTag         @"created_at"
#define kProductModelXMLTag           @"model"
#define kProductDimensionXMLTag       @"dimension"
#define kProductImageUrlXMlTag        @"url" 
#define kProductPriceXMLTag           @"price"
#define kProductMinimalPriceXMLTag    @"minimal_price"

#define kProductXMLTag                  @"Product";
#define kImageUrlXMLTag                 @"ImageUrl"

#define kName                       NSLocalizedString(@"Name", @"")
#define kModel                      NSLocalizedString(@"Model", @"")
#define kManufacturingDate          NSLocalizedString(@"Manufacturing_Date", @"")
#define kDimension                  NSLocalizedString(@"Dimension", @"")
#define kDescription                NSLocalizedString(@"Description", @"")
#define kPriceInfoTitle             NSLocalizedString(@"Price_Info", @"")
#define kAvailableTitle             NSLocalizedString(@"Available", @"")
#define kavailableTitle             NSLocalizedString(@"available", @"")

#define kAddressIdXMLTag            @"address_id"
#define kAddressTypeXMLTag          @"address_type"
#define kCityXMLTag                 @"city"
#define kCompanyXMLTag              @"company"
#define kCountryIdXMLTag            @"country_id"
#define kFaxXMLTag                  @"fax"
#define kFirstNameXMLTag            @"firstname"
#define kLastNameXMLTag             @"lastname"
#define kParentIdXMLTag             @"parent_id"
#define kPostCodeXMLTag             @"postcode"
#define kRegionXMLTag               @"region"
#define kStreetXMLTag               @"street"
#define kTelephoneXMLTag            @"telephone"

// MoreVeiwController
#define kMoreTitle            NSLocalizedString(@"More", @"")
#define kCartTitle            NSLocalizedString(@"Cart", @"")
#define kFavoritesTitle       NSLocalizedString(@"Favorites", @"")
#define kOrderHistoryTitle    NSLocalizedString(@"Order_History", @"")
#define kAccountInfoTitle     NSLocalizedString(@"Account_Info", @"")
#define kFeedbackTitle        NSLocalizedString(@"Feedback", @"")
#define kContactUsTitle       NSLocalizedString(@"Contact_Us", @"")
#define kHelpAndFAQsTitle     NSLocalizedString(@"Help_&_FAQs", @"")

#define NUMBEROFSECTIONS 1
#define kPlaceOrderTBarItemImg          @"couponsTBar.png"
#define kMoreCellIdentifier             @"moreIdentifier"










