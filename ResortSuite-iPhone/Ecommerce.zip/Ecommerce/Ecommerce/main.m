/* 
 File: main.m
 Abstract: This class is responsible for initializing application.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "EcommerceAppDelegate.h"

int main(int argc, char *argv[])
{
    int retVal = 0;
    @autoreleasepool {
        retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([EcommerceAppDelegate class]));
    }
    return retVal;
}
