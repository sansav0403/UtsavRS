/* 
 File: AvailabilityDetailsViewController.h
 Abstract: This class is responsible for product availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "AvailabilityReqResHandler.h"

typedef enum {
    kAvailabilityRquestNone,
    kAvailabilityStockRquest,
    kAvailabilityAddToCartRequest,
}AvailabilityRequestState;

@interface AvailabilityDetailsViewController : UIViewController<NetworkRequestResponseBaseDelegate,ProductImageDataDelegate,UITextFieldDelegate>
{
    AvailabilityReqResHandler *_availabilityReqResHandler;
}

@property(nonatomic, weak) IBOutlet UILabel                 *productName;
@property(nonatomic, weak) IBOutlet UILabel                 *availabelQuantity;
@property(nonatomic, weak) IBOutlet UIImageView             *productImageView;
@property(nonatomic, weak) IBOutlet UILabel                 *actualPriceLbl;
@property(nonatomic, weak) IBOutlet UILabel                 *actualPrice;
@property(nonatomic, weak) IBOutlet UILabel                 *offerPriceLbl;
@property(nonatomic, weak) IBOutlet UILabel                 *offerPrice;
@property(nonatomic, weak) IBOutlet UILabel                 *shippingCharges;
@property(nonatomic, weak) IBOutlet UILabel                 *shippingDuration;
@property(nonatomic, weak) IBOutlet UIButton                *addToCartBtn;
@property(nonatomic, weak) IBOutlet UIButton                *addToFavoritesBtn;
@property(nonatomic, weak) IBOutlet UIButton                *placeOrderBtn;
@property(nonatomic, weak) IBOutlet UIActivityIndicatorView *activityIndicator;
@property(nonatomic, weak) IBOutlet UIActivityIndicatorView *addCartActIndicator;
@property(nonatomic, strong) UITextField                    *txtQuantity;

@property(nonatomic, strong) NSString                       *productsku;
@property(nonatomic, strong) Availability                   *availability;
@property(nonatomic)   AvailabilityRequestState             requestState;

- (void)show;
- (void)popupViewForQuantity;

- (IBAction)addToCart:(id)sender;

@end
