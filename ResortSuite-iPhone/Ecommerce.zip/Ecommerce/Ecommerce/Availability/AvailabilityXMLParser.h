/* 
 File: AvailabilityXMLParser.h
 Abstract: This class is responsible for product availability response parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
*/

#import <Foundation/Foundation.h>
#import "Availability.h"
#import "XMLParser.h"

@interface AvailabilityXMLParser : XMLParser

@property(nonatomic, strong) Availability   *availability;
@property(nonatomic, strong) NSArray        *availabilitySearchList;

- (void)parseXMLDataForAvailabilitySearch:(NSData *)dataToBeParsed productSearchList:(NSArray *)productSearchList;
- (void)parseXMLDataForAvailabilityProductDetails:(NSData *)dataToBeParsed availability:(Availability *)availabilityData;
- (void)parseXMLDataForProductImage:(NSData *)dataToBeParsed availability:(Availability *)availabilityData;

@end
