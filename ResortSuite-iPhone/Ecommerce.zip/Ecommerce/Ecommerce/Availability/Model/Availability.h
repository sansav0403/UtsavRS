/* 
 File: Availability.h
 Abstract: This class is responsible for product availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "Product.h"

@interface Availability : Product

@property(nonatomic, strong) NSString    *actualPrice;
@property(nonatomic, strong) NSString    *offerPrice;
@property(nonatomic, strong) NSString    *currency;
@property(nonatomic, strong) NSString    *quantity;
@property(nonatomic, strong) NSString    *shippingCharges;
@property(nonatomic, strong) NSString    *shippingDuration;
@property(nonatomic, strong) NSString    *inStock;

@end
