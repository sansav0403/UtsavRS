/* 
 File: Availability.m
 Abstract: This class is responsible for product availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
 */

#import "Availability.h"

@implementation Availability
@synthesize actualPrice = _actualPrice;
@synthesize offerPrice = _offerPrice;
@synthesize currency = _currency;
@synthesize quantity = _quantity;
@synthesize shippingCharges = _shippingCharges;
@synthesize shippingDuration = _shippingDuration;
@synthesize inStock = _inStock;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}


@end
