/* 
 File: AvailabilityXMLParser.m
 Abstract: This class is responsible for product availability response parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
 */

#import "AvailabilityXMLParser.h"
#import "CXMLDocument.h"
#import "CXMLElement.h"
#import "AvailabilityCommon.h"
#import "Common.h"

@implementation AvailabilityXMLParser
@synthesize availability = _availability;
@synthesize availabilitySearchList = _availabilitySearchList;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

/*!
 @function		parseXMLDataForAvailabilitySearch
 @abstract		This function parse xml data for product list.
 @discussion	This function parse xml data for product list.
 @param			dataToBeParsed - NSData to be parsed.
 @param			productSearchList - return array of product objects.
 @result		void
 */
- (void)parseXMLDataForAvailabilitySearch:(NSData *)dataToBeParsed productSearchList:(NSArray *)productSearchList
{
    self.availabilitySearchList = productSearchList;
        
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        Availability *availabilityObj = [[Availability alloc] init];
        
        availabilityObj.productId = [item valueForKey:kProductIdXMLTag];
        TRC_DBG(@"availabilityObj.productId =%@",availabilityObj.productId);
        
        availabilityObj.name = [item valueForKey:kProductNameXMLTag];
        TRC_DBG(@"availabilityObj.name =%@",availabilityObj.name);
        
        availabilityObj.sku = [item valueForKey:kProductSkuXMLTag];
        TRC_DBG(@"availabilityObj.actualPrice =%@",availabilityObj.actualPrice);
        
        availabilityObj.type = [item valueForKey:kProductTypeXMLTag];
        TRC_DBG(@"availabilityObj.currency =%@",availabilityObj.currency);
        
        availabilityObj.categotryIds = [item valueForKey:kProductCategoryIdXMLTag];
        TRC_DBG(@"availabilityObj.quantity =%@",availabilityObj.quantity);
        
        availabilityObj.actualPrice = [item valueForKey:kProductPriceXMLTag];
        TRC_DBG(@"availabilityObj.actualPrice =%@",availabilityObj.actualPrice);
        
        availabilityObj.offerPrice = [item valueForKey:kProductMinimalPriceXMLTag];
        TRC_DBG(@"availabilityObj.offerPrice =%@",availabilityObj.offerPrice);
        
        [(NSMutableArray *)_availabilitySearchList addObject:availabilityObj];
    }
    
    //  and we print our results    
    TRC_DBG(@"Array :::: %@", self.availabilitySearchList);
    TRC_DBG(@"Array count:::: %d", [self.availabilitySearchList count]);
}

/*!
 @function		parseXMLDataForAvailabilityProductDetails
 @abstract		This function requests for product details on canis server.
 @discussion	This function requests for product details on canis server.
 @param			productId - product id.
 @param			availabilityData - return product extended object.
 @result		void
 */
- (void)parseXMLDataForAvailabilityProductDetails:(NSData *)dataToBeParsed availability:(Availability *)availabilityData
{
    self.availability = availabilityData;
 
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {        
        self.availability.productId = [item valueForKey:kProductIdXMLTag];
                
        self.availability.sku = [item valueForKey:kProductSkuXMLTag];
        
        self.availability.quantity = [item valueForKey:kProductQuantityXMLTag];
        TRC_DBG(@"self.avail.quantity =%@", self.availability.quantity);
        self.availability.inStock = [item valueForKey:kProductIsInStockXMLTag];
    }
}

/*!
 @function		parseXMLDataForProductImage
 @abstract		This function parse xml data for product list.
 @discussion	This function parse xml data for product list.
 @param			dataToBeParsed - NSData to be parsed.
 @param			availability - return array of product objects.
 @result		void
 */
- (void)parseXMLDataForProductImage:(NSData *)dataToBeParsed availability:(Availability *)availabilityData
{
    self.availability = availabilityData;
    
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        self.availability.imageUrl = [item valueForKey:kProductImageUrlXMlTag];
        TRC_DBG(@"url =%@",self.availability.imageUrl);
    }
}

@end
