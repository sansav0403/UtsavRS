/* 
 File: AvailabilityReqResHandler.h
 Abstract: This class is responsible for product availability request and response operation from server.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
*/

#import <Foundation/Foundation.h>
#import "NetworkRequestResponseBase.h"
#import "Availability.h"

typedef enum {
    kAvailabilityListRquest,
    kAvailabilityDetailsRequest,
    kAvailabilityImageRequest
}AvailabilityHandlerRequestState;

@interface AvailabilityReqResHandler : NetworkRequestResponseBase

@property(nonatomic, strong) NSArray                         *productSearchArr;
@property(nonatomic, strong) NSString                        *productId;
@property(nonatomic, strong) NSString                        *sessionId;
@property(nonatomic, strong) NSString                        *productSku;
@property(nonatomic, strong) Availability                    *availability;
@property(nonatomic)   AvailabilityHandlerRequestState       requestState;

- (void)productAvailabilityDataList:(NSArray*)productSearchDataList searchAttribute:(NSString *)attribute searchKeyword:(NSString *)searchKeyword;
- (void)productImageForProductId:(NSString *)productId availability:(Availability *)availabilityData;
- (void)requestWithSoapMessage:(NSString *)soapMsg;
- (void)productStockDetailsDataForProductSku:(NSString *)productsku availabilityData:(Availability *)availabilityData;

@end
