/* 
 File: AvailabilitySearchViewController.m
 Abstract: This class is responsible for product availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 06/03/12
 Modified: 29/03/12
 Version: 1.0 
*/

#import "AvailabilitySearchViewController.h"
#import "AvailabilityDetailsViewController.h"
#import "AvailabilityListCell.h"
#import "ValidationHandler.h"
#import "AvailabilityCommon.h"
#import "Common.h"

#define kNumberOfSection    1

@implementation AvailabilitySearchViewController
@synthesize productTbl = _productTbl, searchBar=_searchBar, productArray=_productArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = kAvailabilityTitle;
        self.tabBarItem.image = [UIImage imageNamed:kAvailabilityTBarItemImg];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    [self setProductTbl:nil];
    [self setSearchBar:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark -
#pragma mark Table view datasource and delegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	// Number of sections is the number of regions
	return kNumberOfSection;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section 
{	
    return [self.productArray count]; 
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
    static NSString *identifier = kAvailabilityListCell;
    AvailabilityListCell *cell = (AvailabilityListCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil)
    {
        // Load the top-level objects from the custom cell XIB.
        NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:identifier owner:self options:nil];
        
        // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
        cell = [topLevelObjects objectAtIndex:0];
    }
    
    Availability *availability = [self.productArray objectAtIndex:indexPath.row];
    [availability setDelegate:cell];
    [cell setProductData:availability];
    
    if(!availability.imageUrl)
    {
        [availability imageUrlForProduct];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    /*
	 To conform to the Human Interface Guidelines, selections should not be persistent --
	 deselect the row after it has been selected.
	 */
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //extract the selected product for details
    Availability *availabilityObj = [self.productArray objectAtIndex:indexPath.row];
    
    AvailabilityDetailsViewController *availabilityDetailsVC = [[AvailabilityDetailsViewController alloc] initWithNibName:@"AvailabilityDetailsViewController" bundle:[NSBundle mainBundle]];
    availabilityDetailsVC.availability.productId = availabilityObj.productId;
    availabilityDetailsVC.productsku = availabilityObj.sku;
    availabilityDetailsVC.availability.name = availabilityObj.name;
    availabilityDetailsVC.availability.actualPrice = availabilityObj.actualPrice;
    availabilityDetailsVC.availability.offerPrice = availabilityObj.offerPrice;
    
    [self.navigationController pushViewController:availabilityDetailsVC animated:YES];
}

#pragma mark - SearchBarDelegate
// return NO to not become first responder
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)aSearchBar
{
    return YES;
}

- (BOOL)searchBar:(UISearchBar *)aSearchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
	if ([aSearchBar.text isEqualToString:@" "] && [aSearchBar.text length]==1)
	{ 
		aSearchBar.text = @"";
		return NO;
	}
	return YES;
}

// called when keyboard search button pressed
- (void)searchBarSearchButtonClicked:(UISearchBar *)aSearchBar
{
    TRC_DBG(@"Search with keyword %@",aSearchBar.text);
    [aSearchBar resignFirstResponder];
    
    aSearchBar.text = [ValidationHandler trimCurrentString:aSearchBar.text];
    if([ValidationHandler checkSpaceOrNewLineCharacter:aSearchBar.text])
    {
        [aSearchBar resignFirstResponder];
        if([aSearchBar.text length])
        {
            [self searchProduct];
        }
    }
}

/*!
 @function      searchProduct
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)searchProduct
{
    if (_availabilityReqResHandler){
        [_availabilityReqResHandler setDelegate:nil];
    }
    _availabilityReqResHandler = [[AvailabilityReqResHandler alloc]init];
    //get the product list from the server
	if(self.productArray)
	{
        self.productArray = nil;
	}
    self.productArray = [[NSMutableArray alloc] init];	
    [_availabilityReqResHandler setDelegate:self];
    [_availabilityReqResHandler productAvailabilityDataList:self.productArray searchAttribute:kProductNameXMLTag searchKeyword:self.searchBar.text];
}

#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) {
        TRC_DBG(@"fail to load data from URL");
    }
    else{
        TRC_DBG(@"Pass to load data from URL");
        TRC_DBG(@"ProSearchArray count in VC =%d",[self.productArray count]);
        [self.productTbl reloadData];
    }        
}

@end
