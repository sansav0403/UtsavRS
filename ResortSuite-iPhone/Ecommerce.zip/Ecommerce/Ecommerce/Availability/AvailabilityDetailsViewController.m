/* 
 File: AvailabilityDetailsViewController.m
 Abstract: This class is responsible for product availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
*/

#import "AvailabilityDetailsViewController.h"
#import "ContentManager.h"
#import "Logger.h"
#import "AvailabilityCommon.h"
#import "Message.h"
#import "CartReqResHandler.h"
#import "Common.h"

@implementation AvailabilityDetailsViewController

@synthesize productName, availabelQuantity, productImageView, actualPriceLbl, actualPrice;
@synthesize offerPriceLbl, offerPrice, shippingCharges, shippingDuration, addToCartBtn;
@synthesize addToFavoritesBtn, placeOrderBtn, activityIndicator,txtQuantity,addCartActIndicator;
@synthesize productsku = _productsku;
@synthesize availability = _availability;
@synthesize requestState = _requestState;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.availability = [[Availability alloc] init];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    /*if (self.availability) {
        self.availability = nil;
    }
    self.availability = [[Availability alloc] init];*/
    _availabilityReqResHandler = [[AvailabilityReqResHandler alloc]init];
    
    //get the product list from the server
    [_availabilityReqResHandler setDelegate:self];
    
    TRC_DBG(@"sku =%@",self.productsku);
    
    self.requestState = kAvailabilityStockRquest;
    
    [_availabilityReqResHandler productStockDetailsDataForProductSku:self.productsku availabilityData:self.availability];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
        
    [self setProductName:nil];
    [self setAvailabelQuantity:nil];
    [self setProductImageView:nil];
    [self setActualPrice:nil];
    [self setActualPriceLbl:nil];
    [self setOfferPriceLbl:nil];
    [self setOfferPrice:nil];
    [self setShippingCharges:nil];
    [self setShippingDuration:nil];
    [self setAddToCartBtn:nil];
    [self setAddToFavoritesBtn:nil];
    [self setPlaceOrderBtn:nil];
    [self setActivityIndicator:nil];
    [self setAddCartActIndicator:nil];
    [self setTxtQuantity:nil];
    
    self.productsku = nil;
    self.availability = nil;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_availabilityReqResHandler setDelegate:nil];
    self.requestState = kAvailabilityRquestNone;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [txtQuantity resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *textFiledValue = nil;
    
    if (textField.text) {
        textFiledValue = [textField.text stringByAppendingFormat:@"%@",string];
    }else{
        textFiledValue = string;
    }       
    
    if ([textFiledValue floatValue]>[self.availability.quantity floatValue]) {
        return NO;
    }
    return YES;
}

#pragma mark - show  
/*!
 @function      show
 @abstract      show data on  view
 @discussion    show data on  view 
 @result        void
 */
- (void)show
{
    NSString *availableQuantity = nil; 
    NSString *actual = nil;
    NSString *offer = nil;
    
    [self setTitle:self.availability.name];
    TRC_DBG(@"self.instock =%@",self.availability.inStock);
    
    if ([self.availability.inStock intValue] && self.availability.quantity) {
        availableQuantity = [NSString stringWithFormat:@"%@ %@",self.availability.quantity,kavailableTitle];
        [self.availabelQuantity setTextColor:[UIColor blueColor]];
    }
    else {
        availableQuantity = kOutOfStockTitle;
        [self.availabelQuantity setTextColor:[UIColor redColor]];
    }        
  
    if (self.availability.actualPrice) {
        self.availability.currency = kUSDTitle;
        actual = [NSString stringWithFormat:@"%@ %@",self.availability.actualPrice,self.availability.currency];
        [self.actualPrice setHidden:FALSE];
        [self.actualPriceLbl setHidden:FALSE];
    }
    else{
        [self.actualPrice setHidden:TRUE];
        [self.actualPriceLbl setHidden:TRUE];
    }
    
    if (self.availability.offerPrice) {
        self.availability.currency = kUSDTitle;
        offer = [NSString stringWithFormat:@"%@ %@",self.availability.offerPrice,self.availability.currency];
        [self.offerPrice setHidden:FALSE];
        [self.offerPriceLbl setHidden:FALSE];
    }
    else{
        [self.offerPrice setHidden:TRUE];
        [self.offerPriceLbl setHidden:TRUE];
    }
    
    [self.productName setText:self.availability.sku];
    [self.availabelQuantity setText:availableQuantity];
    [self.actualPrice setText:actual];
    [self.offerPrice setText:offer];
    [self.shippingCharges setText:self.availability.shippingCharges];
    [self.shippingDuration setText:self.availability.shippingDuration];
    [self.addToCartBtn setTitle:kAddToCartButtonTitle forState:UIControlStateNormal];
    [self.addToFavoritesBtn setTitle:kAddToFavoriteButtonTitle forState:UIControlStateNormal];
    [self.placeOrderBtn setTitle:kPlaceOrderTitle forState:UIControlStateNormal];
    
    if (self.availability.image) {
        [self.productImageView setImage:self.availability.image];
    }
    else{
        if (self.availability.imageUrl)
        {
            [self.availability setDelegate:self];
            [self.availability startDownload];
        }
        else{
            [activityIndicator setHidden:FALSE];
            [activityIndicator startAnimating];
        }
    }
}

/*!
 @method        addToCart
 @abstract      add product to cart action 
 @discussion    add product to cart action
 */
- (IBAction)addToCart:(id)sender
{
    [self popupViewForQuantity];
}

/*!
 @method        popupViewForQuantity
 @abstract      add quantity to cart  
 @discussion    add quantity to cart 
 */
- (void)popupViewForQuantity
{
    NSString *availableMsg =kMaxAvailableQty;
    NSString *alertMessage = [NSString stringWithFormat:@"%@ %d",availableMsg,[self.availability.quantity intValue]];
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:alertMessage message:@"" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Add",nil];    
    
    txtQuantity = [[UITextField alloc] initWithFrame:CGRectMake(20, 36, 240, 22)];
    
    //txtUserName.tag = 3;
    txtQuantity.borderStyle = UITextBorderStyleBezel;
    txtQuantity.textColor = [UIColor blackColor];
    txtQuantity.backgroundColor = [UIColor whiteColor];
    txtQuantity.font = [UIFont systemFontOfSize:12.0];
    txtQuantity.placeholder = @"Enter Quantity";
    [txtQuantity setKeyboardType:UIKeyboardTypeNumberPad];
    [txtQuantity setDelegate:self];
    [alertView addSubview:txtQuantity];
    
    [alertView show];
}

- (void) alertView:(UIAlertView *)alert clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1)
    {
        //add clicked
        if ([txtQuantity.text length]) {
            self.availability.orderedQuantity = txtQuantity.text;
            self.requestState = kAvailabilityAddToCartRequest;
            CartReqResHandler *cartReqResHandler = [[CartReqResHandler alloc]init];
            [cartReqResHandler setDelegate:self];
            [cartReqResHandler addToCart:self.availability];
            
            //start activity indicator
            [addCartActIndicator setHidden:FALSE];
            [addCartActIndicator startAnimating];
        }
    }
    else
    {
        // Cancel pushed
        TRC_DBG(@"cancel clicked");
        
    }
}

#pragma mark - Product image data DELEGETE
/*!
 @function      didReceivedData
 @abstract      set product image data to cell.
 @discussion    set product image data to cell.
 @param         imgData - product image data to set on cell.
 urlString - image url path
 @result        void
 */
- (void)didReceivedData:(id)imgData urlString:(NSString *)urlString
{
    TRC_DBG(@"%@", urlString );
   if(imgData)
    {
        [self.productImageView setImage:imgData];
        [activityIndicator  stopAnimating];
        [activityIndicator setHidden:TRUE];
    }
    TRC_DBG(@"%@", self.availability.imageUrl );
}

#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    [addCartActIndicator stopAnimating];
    [addCartActIndicator setHidden:TRUE];
    if (error) {
        TRC_DBG(@"fail to load data from URL");
        [Message showOKOnly:[error localizedDescription] alertMessage:nil setDelegate:nil];
    }
    else{
        TRC_DBG(@"Pass to load data from URL");
        TRC_DBG(@"ProductSearch =%@",self.availability);
        
        switch (self.requestState) {
            case kAvailabilityStockRquest:
            {
                [self show];
            }
                break;
            case kAvailabilityAddToCartRequest:
            {
                [Message showOKOnly:nil alertMessage:kProductAddedToCartSuccessfulMessage setDelegate:nil];
            }
                break;
            default:
                break;
        }
    }        
}

@end
