/* 
 File: AvailabilityCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for availability module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

//Availablity List Cell
#define kPriceTitle                     NSLocalizedString(@"Price", @"")

//AvailabilitySearchViewController
#define kAvailabilityTitle              NSLocalizedString(@"Availability", @"")
#define kAvailabilityTBarItemImg        @"second.png"
#define kAvailabilityListCell           @"AvailabilityListCell"
#define kOutOfStockTitle                NSLocalizedString(@"Out_Of_Stock", @"")

//AvailabilityDetailsViewController
#define kPlaceOrderTitle            NSLocalizedString(@"Place_Order", @"")
#define kButtonOk                   NSLocalizedString(@"Ok", @"")

//AvailabilityReqResHandler
#define kAvailabilityListAPI            @"AvailabilityList.xml"
#define kAvailabilityDetailsAPI         @"product_stock.list" 
#define kProductAvailabilityListAPI     @"product.list"
#define kProductAvailabilityImageAPI    @"product_attribute_media.list"

#define kGet                            @"GET"
//Availability XMLTags
#define kIdXMLTag                       @"id"
#define kNameXMLTag                     @"Name"
#define kPriceXMLTag                    @"Price"
#define kQuantityXMLTag                 @"Quantity"
#define kCurrencyXMLTag                 @"currency"
#define kActualPriceXMLTag              @"ActualPrice"
#define kOfferPriceXMLTag               @"OfferPrice"
#define kShippingChargesXMLTag          @"ShippingCharges"
#define kShippingDurationXMLTag         @"ShippingDuration"
#define kThumbImgUrlXMLTag              @"ThumbImgUrl"
#define kImageUrlXMLTag                 @"ImageUrl"
#define kProductIsInStockXMLTag         @"is_in_stock"







