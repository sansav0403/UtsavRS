/* 
 File: AvailabilitySearchViewController.h
 Abstract: This class is responsible for product availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 06/03/12
 Modified: 29/03/12
 Version: 1.0 
*/

#import <UIKit/UIKit.h>
#import "AvailabilityReqResHandler.h"

@interface AvailabilitySearchViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,NetworkRequestResponseBaseDelegate>
{
    AvailabilityReqResHandler  *_availabilityReqResHandler;
}

@property(nonatomic, weak) IBOutlet UITableView   *productTbl;
@property(nonatomic, weak) IBOutlet UISearchBar   *searchBar;
@property(nonatomic, strong) NSArray              *productArray;

- (void)searchProduct;
- (void)parseComplete:(NSError*)error;

@end
