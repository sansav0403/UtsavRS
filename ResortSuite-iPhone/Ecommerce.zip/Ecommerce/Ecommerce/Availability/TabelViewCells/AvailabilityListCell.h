/* 
 File: AvailabilityListCell.h
 Abstract: This class is responsible for product availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "Availability.h"

@interface AvailabilityListCell : UITableViewCell<ProductImageDataDelegate>

@property(nonatomic, weak) IBOutlet UIImageView               *productImgView;
@property(nonatomic, weak) IBOutlet UIActivityIndicatorView   *activityIndicatorView;
@property(nonatomic, weak) IBOutlet UILabel                   *productName;
@property(nonatomic, weak) IBOutlet UILabel                   *productPriceLbl;
@property(nonatomic, weak) IBOutlet UILabel                   *productPrice;
@property(nonatomic, weak) IBOutlet UILabel                   *productQuantityLbl;
@property(nonatomic, weak) IBOutlet UILabel                   *productQuantity;
@property(nonatomic, strong) Availability                     *availability;

- (void)setProductData:(Availability *)availabilityData;

@end
