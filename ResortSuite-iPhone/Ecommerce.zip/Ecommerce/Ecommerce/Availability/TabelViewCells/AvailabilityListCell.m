/* 
 File: AvailabilityListCell.m
 Abstract: This class is responsible for product availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 29/03/12
 Modified: 29/03/12
 Version: 1.0 
 */

#import "AvailabilityListCell.h"
#import "AvailabilityCommon.h"
#import "Common.h"


@implementation AvailabilityListCell
@synthesize availability;
@synthesize productImgView, activityIndicatorView, productName, productPriceLbl, productPrice, productQuantityLbl, productQuantity;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductData
 @abstract      set product details to cell.
 @discussion    set product details to cell.
 @param         ProductSearchData - product of which details need to set to cell.
 int - cell index
 @result        void
 */
- (void)setProductData:(Availability *)availabilityData
{
    self.availability = availabilityData;
    
    //[self.productPriceLbl setText:kPriceTitle];
    //[self.productQuantityLbl setText:kAvailableTitle];
    
    //NSString *price = [NSString stringWithFormat:@"%@ %@",self.availability.actualPrice,self.availability.currency];
    
    [self.productName setText:self.availability.name];
    //[self.productPrice setText:price];
    [self.productQuantity setText:self.availability.sku];
    
    //image 
    if(self.availability.image)
    {
        [productImgView setImage:self.availability.image];
        [activityIndicatorView stopAnimating];
        [activityIndicatorView removeFromSuperview];
    }
    else
    {
        [activityIndicatorView startAnimating];
    }
}

#pragma mark - Product image data DELEGETE
/*!
 @function      didReceivedData
 @abstract      set product image to cell.
 @discussion    set product image to cell.
 @param         imgData - product image need to set on cell.
                urlString - map image data with object of product
 @result        void
 */
- (void)didReceivedData:(id)imgData urlString:(NSString *)urlString
{
    [activityIndicatorView stopAnimating];
    [activityIndicatorView removeFromSuperview];
    TRC_DBG(@"%@", urlString );
    if (imgData && [urlString isEqualToString:self.availability.imageUrl]) {
        [productImgView setImage:imgData];
    }
    else{
        [productImgView setImage:[UIImage imageNamed:kNoImage]];
    }
    TRC_DBG(@"%@", self.availability.imageUrl );
}


@end
