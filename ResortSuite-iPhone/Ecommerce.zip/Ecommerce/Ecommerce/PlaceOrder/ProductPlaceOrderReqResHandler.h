/* 
 File: ProductPlaceOrderReqResHandler.h
 Abstract: This class is responsible for product order related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "NetworkRequestResponseBase.h"
#import "ProductInfo.h"

typedef enum {
    kProductInfoListRquest,
    kProductInfoDetailsRequest
}ProductInfoHandlerRequestState;

@interface ProductPlaceOrderReqResHandler : NetworkRequestResponseBase

@property(nonatomic, strong) NSArray                     *productInfoArr;
@property(nonatomic, strong) NSString                    *productId;
@property(nonatomic, strong) NSString                    *sessionId;
@property(nonatomic, strong) ProductInfo                 *productInfo;
@property (nonatomic)   ProductInfoHandlerRequestState   requestState;

- (void)productInfoDataList:(NSArray*)productInfoDataList
            searchAttribute:(NSString *)attribute searchKeyword:(NSString *)searchKeyword;
- (void)productDetailsDataForProductId:(NSString *)currentProductId productInfo:(ProductInfo *)productInfoData;
- (void)requestWithSoapMessage:(NSString *)soapMsg;
- (void)didReceiveData:(NSData*)data;

@end
