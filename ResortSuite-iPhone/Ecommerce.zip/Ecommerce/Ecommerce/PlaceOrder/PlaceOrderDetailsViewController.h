/* 
 File: PlaceOrderDetailsViewController.m
 Abstract: This class is responsible for product order related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 03/04/12
 Modified: 03/04/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "ProductInfo.h"
#import "ProductPlaceOrderReqResHandler.h"

@interface PlaceOrderDetailsViewController : UIViewController<NetworkRequestResponseBaseDelegate,ProductImageDataDelegate>
{
    float       _currentPrice;
    UIButton    *_doneButton;
    ProductPlaceOrderReqResHandler *_productPlaceOrderReqResHandler;
}

@property(nonatomic, weak) IBOutlet UILabel       *productName;
@property(nonatomic, weak) IBOutlet UILabel       *quantityLbl;
@property(nonatomic, weak) IBOutlet UITextField   *quantity;
@property(nonatomic, weak) IBOutlet UILabel       *availabelQuantity;
@property(nonatomic, weak) IBOutlet UIImageView   *productImageView;
@property(nonatomic, weak) IBOutlet UILabel       *actualPriceLbl;
@property(nonatomic, weak) IBOutlet UILabel       *actualPrice;
@property(nonatomic, weak) IBOutlet UILabel       *offerPriceLbl;
@property(nonatomic, weak) IBOutlet UILabel       *offerPrice;
@property(nonatomic, weak) IBOutlet UILabel       *shippingCharges;
@property(nonatomic, weak) IBOutlet UILabel       *shippingDuration;
@property(nonatomic, weak) IBOutlet UILabel       *totalLbl;
@property(nonatomic, weak) IBOutlet UILabel       *total;
@property(nonatomic, weak) IBOutlet UIButton      *checkOutBtn;

@property(nonatomic, strong) NSString             *productId;
@property(nonatomic, strong) ProductInfo          *productInfo;
@property(nonatomic, strong) NSString             *productsku;

- (void)show;
- (IBAction)doneButton:(id)sender;
- (float)totalAmount:(float)productQuantity price:(float)price;

@end
