/* 
 File: PlaceOrderCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for place order module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

//PlaceOrderSearchViewController
#define kPlaceOrderTBarItemImg          @"couponsTBar.png"
#define kPlaceOrderTitle                NSLocalizedString(@"Place_Order", @"")
#define kProductInfoOrderCell           @"ProductInfoOrderCell_iphone"


//ProductPlaceOrderReqResHandler
#define kProductInfoListAPI             @"ProductInfo.xml"
#define kServerUrl                      @"http://172.27.47.116"
#define kGet                            @"GET"
#define kProductInfoDetailsAPI          @"ProductInfoDetails.xml"
#define kProductPlaceOrderListAPI       @"product.list"

//ProductInfoXMLParser
#define kIdXMLTag                       @"id"
#define kNameXMLTag                     @"Name"
#define kThumbImgUrlXMLTag              @"ThumbImgUrl"
#define kPriceXMLTag                    @"Price"
#define kCurrencyXMLTag                 @"currency"
#define kActualPriceXMLTag              @"ActualPrice"
#define kOfferPriceXMLTag               @"OfferPrice"
#define kQuantityXMLTag                 @"Quantity"
#define kShippingChargesXMLTag          @"ShippingCharges"
#define kShippingDurationXMLTag         @"ShippingDuration"
#define kAvailableQtyXMLTag             @"AvailabelQuantity" 
#define kImageUrlXMLTag                 @"ImageUrl"

//PlaceOrderDetailsViewController
#define kCheckOut                       NSLocalizedString(@"Check_Out", @"")
#define kTotal                          NSLocalizedString(@"Total", @"")
