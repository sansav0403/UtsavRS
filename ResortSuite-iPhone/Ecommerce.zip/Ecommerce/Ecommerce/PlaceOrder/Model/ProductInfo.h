/* 
 File: ProductInfo.h
 Abstract: This class is responsible for product related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "Availability.h"

@interface ProductInfo : Availability

@property(nonatomic, strong) NSString    *availableQuantity;
@property(nonatomic, strong) NSString    *totalAmount;

@end
