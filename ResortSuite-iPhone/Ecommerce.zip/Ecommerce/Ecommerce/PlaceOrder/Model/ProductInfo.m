/* 
 File: ProductInfo.m
 Abstract: This class is responsible for product related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import "ProductInfo.h"

@implementation ProductInfo
@synthesize availableQuantity = _availableQuantity;
@synthesize totalAmount = _totalAmount;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end