/* 
 File: ProductPlaceOrderReqResHandler.m
 Abstract: This class is responsible for product order related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import "ProductPlaceOrderReqResHandler.h"
#import "ProductInfoXMLParser.h"
#import "PlaceOrderCommon.h"
#import "UserExtended.h"
#import "Common.h"

@implementation ProductPlaceOrderReqResHandler
@synthesize productId = _productId;
@synthesize sessionId = _sessionId;
@synthesize productInfo = _productInfo;
@synthesize productInfoArr = _productInfoArr;
@synthesize requestState = _requestState;;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        UserExtended *userExtended = [UserExtended sharedUserExteded];
        self.sessionId = userExtended.sessionId;
    }
    
    return self;
}

/*!
 @function		productPriceInfoDataList
 @abstract		get product price and offers list information.
 @discussion    parse productPrice and offers list.
 @param			productPriceInfohDataList - result will be return in this array 
                searchAttribute - attribute on which filter will apply
                searchKeyword - kewyword to search product
 */
- (void)productInfoDataList:(NSArray*)productInfoDataList
            searchAttribute:(NSString *)attribute searchKeyword:(NSString *)searchKeyword
{
    self.productInfoArr = productInfoDataList;
    self.requestState = kProductInfoListRquest;
    
    //Magento Api Call Request
    searchKeyword = [searchKeyword stringByAppendingString:@"%"];
    
    NSString *argsValue = nil;
    argsValue = [NSString stringWithFormat:@"<item xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">%@</key><value xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">like</key><value xsi:type=\"xsd:string\">%@</value></item></value></item></item>",attribute,searchKeyword];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"ns2:Map[1]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kProductPlaceOrderListAPI,argsValue];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		productDetailsDataForProductId
 @abstract		request product details to server.
 @discussion    request product details to server.
 @param			productId - productId of requested product details
                ProductInfo - result will be return in this ProductInfo object 
 */
- (void)productDetailsDataForProductId:(NSString *)currentProductId productInfo:(ProductInfo *)productInfoData
{
    self.productId = currentProductId;
    self.productInfo = productInfoData;
    self.requestState = kProductInfoDetailsRequest;
    
    NSString *queryString = [NSString stringWithFormat:@"%@/%@",kServerUrl,kProductInfoDetailsAPI]; 
    TRC_DBG(@"qString = %@",queryString);
	NSURL* webUrl = [NSURL URLWithString:queryString];  
    
    NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:webUrl];
    [urlRequest setHTTPMethod:kGet];			
    
    [self.netDataManager makeRequest:urlRequest];
}

/*!
 @function		requestWithSoapMessage
 @abstract		request to server with soap request object.
 @discussion	request to server with soap request object.
 @param			soapMsg - soap message 
 soapAction - soap action
 httpMethod - httpMethod
 @result		void
 */
- (void)requestWithSoapMessage:(NSString *)soapMsg 
{
    //create a url load request
    NSURL *url = [NSURL URLWithString: kMagentoServerUrl];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    
    //populate the request object with the various headers,
    //such as Content-Type, SOAPAction, and Content-Length. You also set the HTTP method and HTTP body:
    NSString *msgLength = nil;
    msgLength = [NSString stringWithFormat:@"%d", [soapMsg length]];    
    [req addValue:kContentTypeValue  forHTTPHeaderField:kContentType];
    [req addValue:kAcceptEncodingValue  forHTTPHeaderField:kAcceptEncoding];
    [req addValue:kUserAgentValue  forHTTPHeaderField:kUserAgent];
    [req addValue:kHostValue forHTTPHeaderField:kHost];    
    [req addValue:kSoapActionValue forHTTPHeaderField:kSoapAction];
    [req addValue:msgLength forHTTPHeaderField:kContentLength];
    [req setHTTPMethod:kPost];
    [req setHTTPBody:[soapMsg dataUsingEncoding:NSUTF8StringEncoding]];
    
    [self.netDataManager makeRequest:req];
}

/*!
 @function		didReceiveData
 @abstract		response data of network call.
 @discussion	response data of network call.
 @param			data - response data
 @result		void
 */
- (void)didReceiveData:(NSData*)data
{
    TRC_DBG(@"Data received");
    ProductInfoXMLParser *productInfoXMLParser = [[ProductInfoXMLParser alloc]init];
    
    switch (self.requestState) {
        case kProductInfoListRquest:{
            // parse xml data 
            [productInfoXMLParser parseXMLDataForProductInfo:data productInfoList:self.productInfoArr];
            TRC_DBG(@"prodcuPriceInfo count=%d",[self.productInfoArr count]);
        }break;
        case kProductInfoDetailsRequest:{
            [productInfoXMLParser parseXMLDataForProductDetails:data productId:self.productId productInfo:self.productInfo];
        }break;
        default:
            break;
    }
    
    //Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:nil];
	}
}
@end
