/* 
 File: PlaceOrderDetailsViewController.m
 Abstract: This class is responsible for product order related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 03/04/12
 Modified: 03/04/12
 Version: 1.0 
*/

#import "PlaceOrderDetailsViewController.h"
#import "ProductPlaceOrderReqResHandler.h"
#import "PlaceOrderCommon.h"
#import "Common.h"

@implementation PlaceOrderDetailsViewController
@synthesize productName, quantityLbl, quantity, availabelQuantity, productImageView;
@synthesize actualPriceLbl, actualPrice, offerPriceLbl, offerPrice;
@synthesize shippingCharges, shippingDuration;
@synthesize totalLbl, total, checkOutBtn;
@synthesize productId = _productId;
@synthesize productInfo = _productInfo;
@synthesize productsku = _productsku;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    // add observer for keyboard notifications
    [[NSNotificationCenter defaultCenter] addObserver:self 
                                             selector:@selector(keyboardDidShow:) 
                                                 name:UIKeyboardDidShowNotification 
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self 
                                             selector:@selector(keyboardWillHide:) 
                                                 name:UIKeyboardWillHideNotification 
                                               object:nil];
    
    //get the data from server
    if (self.productInfo) {
        self.productInfo = nil;
    }
    self.productInfo = [[ProductInfo alloc] init];
    _productPlaceOrderReqResHandler = [[ProductPlaceOrderReqResHandler alloc]init];
    
    //get the product list from the server
    [_productPlaceOrderReqResHandler setDelegate:self];
    
    [_productPlaceOrderReqResHandler productDetailsDataForProductId:self.productId productInfo:self.productInfo];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    // remove delegates
    //[_productPlaceOrderReqResHandler setDelegate:nil];
    
    // remove observer    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_productPlaceOrderReqResHandler setDelegate:nil];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma Keyboard delegate methods
- (void)keyboardDidShow:(NSNotification *)note {  
    _doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _doneButton.frame = CGRectMake(0, 427, 106, 53);
    _doneButton.adjustsImageWhenHighlighted = NO;
    [_doneButton setBackgroundColor:[UIColor clearColor]];
    [_doneButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [_doneButton setTitle:@"DONE" forState:UIControlStateNormal];
    [_doneButton addTarget:self action:@selector(doneButton:) forControlEvents:UIControlEventTouchUpInside];
    
    // locate keyboard view 
    UIWindow* tempWindow = [[[UIApplication sharedApplication] windows] objectAtIndex:1]; 
    [tempWindow addSubview:_doneButton];
}

- (void)keyboardWillHide:(NSNotification *)note 
{ 
    [_doneButton removeFromSuperview];
}
    
#pragma TextField Delegate methods

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.quantity resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *textFiledValue = nil;
 
    if (textField.text) {
        textFiledValue = [textField.text stringByAppendingFormat:@"%@",string];
    }else{
        textFiledValue = string;
    }       

    if ([textFiledValue floatValue]>[self.productInfo.availableQuantity floatValue]) {
        return NO;
    }
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    float totalAmt = [self totalAmount:[textField.text floatValue] price:_currentPrice];
    [self.total setText:[NSString stringWithFormat:@"%0.2f %@",totalAmt,self.productInfo.currency]];
}

/*!
 @function      doneButton
 @abstract      disappear keyboard
 @discussion    disappear keyboard 
 @result        void
 */
- (IBAction)doneButton:(id)sender
{
    [self.quantity resignFirstResponder];
}

/*!
 @function      totalAmount
 @abstract      calculates the total amount
 @discussion    calculates the total amount 
 @param         productQuantity - number of product ordered 
                price - current price of product 
 @result        float - returns the total amount
 */
- (float)totalAmount:(float)productQuantity price:(float)price
{
    return (productQuantity * price);
     
}

#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) {
        TRC_DBG(@"fail to load data from URL");
    }
    else{
        TRC_DBG(@"Pass to load data from URL");
        TRC_DBG(@"ProductSearch =%@",self.productInfo);
        [self show];
    }        
}

#pragma mark - show  
/*!
 @function      show
 @abstract      show data on  view
 @discussion    show data on  view 
 @result        void
 */
- (void)show
{
    self.title = self.productInfo.name;
    
    NSString *availableQuantity = nil;
    NSString *actual = nil;
    NSString *offer = nil;
    
    if (self.productInfo.availableQuantity) {
         availableQuantity = [NSString stringWithFormat:@"%@ %@",self.productInfo.availableQuantity, kavailableTitle];
    }
    
    if(self.productInfo.actualPrice){
        actual = [NSString stringWithFormat:@"%@ %@",self.productInfo.actualPrice,self.productInfo.currency];
    }
   
    if(self.productInfo.offerPrice){
        offer = [NSString stringWithFormat:@"%@ %@",self.productInfo.offerPrice,self.productInfo.currency];
    }
    
    [self.productName setText:self.productInfo.name];
    [self.availabelQuantity setText:availableQuantity];
    [self.actualPrice setText:actual];
    [self.offerPrice setText:offer];
    [self.shippingCharges setText:self.productInfo.shippingCharges];
    [self.shippingDuration setText:self.productInfo.shippingDuration];
    [self.totalLbl setText:kTotal];
    [self.checkOutBtn setTitle:kCheckOut forState:UIControlStateNormal];
   
    //Download image for product
    if (self.productInfo.imageUrl){
        //[self startDownload];
        [self.productInfo setDelegate:self];
        [self.productInfo startDownload];
    }
    
    //set current price for product
    if (self.offerPrice) {
        _currentPrice = [self.productInfo.offerPrice floatValue];
    }else
    {
        _currentPrice = [self.productInfo.actualPrice floatValue];
    }
}

#pragma mark - Product image data DELEGETE
/*!
 @function      didReceivedData
 @abstract      set product image data to cell.
 @discussion    set product image data to cell.
 @param         imgData - product image data to set on cell.
                urlString - image url path
 @result        void
 */
- (void)didReceivedData:(id)imgData urlString:(NSString *)urlString
{
    TRC_DBG(@"%@", urlString );
    if([urlString isEqualToString:self.productInfo.imageUrl])
    {
        [self.productImageView setImage:imgData];
    }
    TRC_DBG(@"%@", self.productInfo.imageUrl );
    
}

@end
