/* 
 File: ProductInfoXMLParser.m
 Abstract: This class is responsible for product order related xml Parsing operation.
 Author: Cybage Software Pvt. Ltd
 Created: 27/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import "ProductInfoXMLParser.h"
#import "CXMLDocument.h"
#import "CXMLElement.h"
#import "ProductInfo.h"
#import "PlaceOrderCommon.h"
#import "Common.h"


@implementation ProductInfoXMLParser
@synthesize productInfo = _productInfo;
@synthesize productInfoList = _productInfoList;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

/*!
 @function		parseXMLDataForProductPriceInfo
 @abstract		This function parse xml data for product price info list.
 @discussion	This function parse xml data for product price info list.
 @param			dataToBeParsed - NSData to be parsed.
 @param			productPriceInfoList - return array of product objects.
 @result		void
 */
- (void)parseXMLDataForProductInfo:(NSData *)dataToBeParsed productInfoList:(NSArray*)productInfoList
{
    self.productInfoList = productInfoList;
    
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        ProductInfo *productInfoObj = [[ProductInfo alloc] init];
        
        productInfoObj.productId = [item valueForKey:kProductIdXMLTag];
        TRC_DBG(@"availabilityObj.productId =%@",productInfoObj.productId);
        
        productInfoObj.name = [item valueForKey:kProductNameXMLTag];
        TRC_DBG(@"availabilityObj.name =%@",productInfoObj.name);
        
        productInfoObj.sku = [item valueForKey:kProductSkuXMLTag];
        TRC_DBG(@"availabilityObj.actualPrice =%@",productInfoObj.actualPrice);
        
        productInfoObj.type = [item valueForKey:kProductTypeXMLTag];
        TRC_DBG(@"availabilityObj.currency =%@",productInfoObj.currency);
        
        productInfoObj.categotryIds = [item valueForKey:kProductCategoryIdXMLTag];
        TRC_DBG(@"availabilityObj.quantity =%@",productInfoObj.quantity);
        
        [(NSMutableArray *)self.productInfoList addObject:productInfoObj];
    }
}

/*!
 @function		parseXMLDataForProductDetails
 @abstract		This function requests for product details on canis server.
 @discussion	This function requests for product details on canis server.
 @param			productId - product id.
 @param			productInfoData - return product extended object.
 @result		void
 */
- (void)parseXMLDataForProductDetails:(NSData *)dataToBeParsed productId:(NSString *)productId productInfo:(ProductInfo *)productInfoData
{
    self.productInfo = productInfoData;
    TRC_DBG(@"pID =%@",productId);
    NSMutableArray *dictionaryArray = [[NSMutableArray alloc] init];
    
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
    //  searching for piglet nodes
    NSString *tagName = kProductXMLTag; 
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    
    for (CXMLElement *node in nodes) {
        
        NSArray *arAttr=[node attributes];
        NSString *strValue = nil;
        NSString *strName = nil;
        
        NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
        
        // read attribute value
        for (NSInteger i = 0; i < [arAttr count]; i++) {
            strValue=[[arAttr objectAtIndex:i] stringValue];
            strName=[[arAttr objectAtIndex:i] name];
            if(strValue && strName){
                TRC_DBG(@"strVal =%@",strValue);
                TRC_DBG(@"strName =%@",strName);
                [item setValue:strValue forKey:strName];
            }
        }
        if ([strName isEqualToString:kIdXMLTag] && [strValue isEqualToString:productId]){
            for(int counter = 0; counter < [node childCount]; counter++) {
                
                //-----Read attribute for child node (currency)--------------
                CXMLNode *childNode = [node childAtIndex:counter];
                // process to read element attributes 
                if([childNode isMemberOfClass:[CXMLElement class]])
                {
                    CXMLElement *childNode2=(CXMLElement*)childNode;
                    NSArray *arAttr=[childNode2 attributes];
                    for (int i=0; i<[arAttr count]; i++) 
                    {
                        strName=[[arAttr objectAtIndex:i] name];
                        strValue=[[arAttr objectAtIndex:i] stringValue];
                        if(strName && strValue)
                        {
                            [item setValue:strValue forKey:strName];
                        }
                    }
                }
                //-----------------------------------------------------------
                //  common procedure: dictionary with keys/values from XML node
                [item setObject:[childNode stringValue] forKey:[childNode name]];
                
                NSString * value = [[childNode stringValue] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                //TRC_DBG(@"Value is : %@", value);
                
                if ([value length] != 0){
                    [item setObject:[childNode stringValue] forKey:[childNode localName]];
                }
            } 
            [dictionaryArray addObject:item];
            break;
        }
    }    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        self.productInfo.productId = [item valueForKey:kIdXMLTag];
        TRC_DBG(@"productInfo.productId =%@",self.productInfo.productId);
        
        self.productInfo.name = [item valueForKey:kNameXMLTag];
        TRC_DBG(@"productInfo.name =%@",self.productInfo.name);
        
        self.productInfo.availableQuantity = [item valueForKey:kAvailableQtyXMLTag];
        TRC_DBG(@"productInfo.quantity =%@",self.productInfo.quantity);
        
        self.productInfo.actualPrice = [item valueForKey:kActualPriceXMLTag];
        TRC_DBG(@"productInfo.actualPrice =%@",self.productInfo.actualPrice);
        
        self.productInfo.offerPrice = [item valueForKey:kOfferPriceXMLTag];
        TRC_DBG(@"productInfo.offerPrice =%@",self.productInfo.offerPrice);
        
        self.productInfo.currency = [item valueForKey:kCurrencyXMLTag];
        TRC_DBG(@"productInfo.currency =%@",self.productInfo.currency);
        
        self.productInfo.shippingCharges = [item valueForKey:kShippingChargesXMLTag];
        TRC_DBG(@"productInfo.shippingCharges =%@",self.productInfo.shippingCharges);
        
        self.productInfo.shippingDuration = [item valueForKey:kShippingDurationXMLTag];
        TRC_DBG(@"productInfo.shippingDuration =%@",self.productInfo.shippingDuration);
        
        self.productInfo.imageUrl = [item valueForKey:kImageUrlXMLTag];
        TRC_DBG(@"productInfo.imageUrl =%@",self.productInfo.imageUrl);
        
    }
}

@end
