/* 
 File: ProductInfoXMLParser.h
 Abstract: This class is responsible for product order related xml Parsing operation.
 Author: Cybage Software Pvt. Ltd
 Created: 27/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "ProductInfo.h"
#import "XMLParser.h"

@interface ProductInfoXMLParser : XMLParser

@property(nonatomic, strong) ProductInfo *productInfo;
@property(nonatomic, strong) NSArray     *productInfoList;

- (void)parseXMLDataForProductInfo:(NSData *)dataToBeParsed productInfoList:(NSArray*)productInfoList;
- (void)parseXMLDataForProductDetails:(NSData *)dataToBeParsed productId:(NSString *)productId productInfo:(ProductInfo *)productInfoData;

@end
