/* 
 File: ProductInfoOrderCell.m
 Abstract: This class is responsible for product related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import "ProductInfoOrderCell.h"
#import "Common.h"

@implementation ProductInfoOrderCell
@synthesize productInfo = _productInfo;
@synthesize productImage = _productImage;
@synthesize productName = _productName;
@synthesize productPrice = _productPrice;
@synthesize productQuantity = _productQuantity;
@synthesize activityIndicatorView = _activityIndicatorView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductData
 @abstract      set product details to cell.
 @discussion    set product details to cell.
 @param         productPriceInfoData - product price info which details need to set to cell.
 @result        void
 */
- (void)setProductData:(ProductInfo*)productInfoData
{
    self.productInfo = productInfoData;
    [self.productImage setImage:nil];
    [self.productName setText:self.productInfo .name];
    //[productPrice setText:self.productInfo.sku];
    TRC_DBG(@"Product Price: %@",self.productInfo.actualPrice);
    [self.productQuantity setText:self.productInfo.sku];
    
    //image 
    if(self.productInfo.image)
    {
        [self.productImage setImage:self.productInfo.image];
        [self.activityIndicatorView stopAnimating];
    }
    else
    {
        [self.activityIndicatorView startAnimating];
    }
}

#pragma mark - Product image data DELEGETE
/*!
 @function      didReceivedData
 @abstract      set product image data to cell.
 @discussion    set product image data to cell.
 @param         imgData - product image data to set on cell.
                urlString - image url path
 @result        void
 */
- (void)didReceivedData:(id)imgData urlString:(NSString *)urlString
{
    [self.activityIndicatorView stopAnimating];
    //[self.activityIndicatorView removeFromSuperview];
    TRC_DBG(@"%@", urlString );
    if (imgData && [urlString isEqualToString:self.productInfo.imageUrl]) {
        [self.productImage setImage:imgData];
    }
    else{
        [self.productImage setImage:[UIImage imageNamed:kNoImage]];
    }
    TRC_DBG(@"%@", self.productInfo.imageUrl );
}


@end
