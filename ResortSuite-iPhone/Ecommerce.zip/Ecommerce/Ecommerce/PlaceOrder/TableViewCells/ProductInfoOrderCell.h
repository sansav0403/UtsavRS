/* 
 File: ProductInfoOrderCell.h
 Abstract: This class is responsible for product related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 26/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "ProductInfo.h"

@interface ProductInfoOrderCell : UITableViewCell <ProductImageDataDelegate>

@property (nonatomic, weak) IBOutlet UIImageView                *productImage;
@property (nonatomic, weak) IBOutlet UILabel                    *productName;
@property (nonatomic, weak) IBOutlet UILabel                    *productPrice;
@property (nonatomic, weak) IBOutlet UILabel                    *productQuantity;
@property (nonatomic, weak) IBOutlet UIActivityIndicatorView    *activityIndicatorView;

@property(nonatomic, strong) ProductInfo            *productInfo;

- (void)setProductData:(ProductInfo*)productInfoData;

@end
