/* 
 File: ProductPriceInfoDetailsViewController.h
 Abstract: This class is responsible for product price details related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 23/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "ProductPriceInfo.h"
#import "ProductPriceInfoReqResHandler.h"
#import "ProductSearchReqResHandler.h"

typedef enum {
    kProductPriceInfoRequestNone,
    kProductPriceInfoRequestDetail,
    kProductPriceInfoRequestAddoToCart
}ProductPriceInfoRequestState;

@interface ProductPriceInfoDetailsViewController : UIViewController<NetworkRequestResponseBaseDelegate>
{
    ProductPriceInfo                *_productPriceInfo;
    ProductPriceInfoReqResHandler   *_productPriceInfoReqResHandler;
    ProductSearchReqResHandler      *_productSearchReqResHandler;
}

@property(nonatomic, weak) IBOutlet UIButton        *addToCart;
@property(nonatomic, weak) IBOutlet UIButton        *addToFavorites;
@property(nonatomic, weak) IBOutlet UITableView     *productPriceInfoDetailsTableView;
@property(nonatomic, strong) NSString               *productId; 
@property(nonatomic) ProductPriceInfoRequestState   requestState;

- (IBAction)addToCart:(id)sender;

@end
