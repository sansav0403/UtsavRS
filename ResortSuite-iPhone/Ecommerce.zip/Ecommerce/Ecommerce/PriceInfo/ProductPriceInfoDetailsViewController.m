/* 
 File: ProductPriceInfoDetailsViewController.m
 Abstract: This class is responsible for product price details related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 23/03/12
 Modified: 27/03/12
 Version: 1.0 
*/

#import "ProductPriceInfoDetailsViewController.h"
#import "ProductPriceInfoCell.h"
#import "ProductPriceInfoAvailabilityCell.h"
#import "ProductPriceInfoReviewCell.h"
#import "ProductDetailImageCell.h"
#import "AvailabilityDetailsViewController.h"
#import "PriceInfoCommon.h"
#import "Common.h"
#import "Message.h"
#import "CartReqResHandler.h"
        

@implementation ProductPriceInfoDetailsViewController

@synthesize productPriceInfoDetailsTableView = _productPriceInfoDetailsTableView;
@synthesize productId = _productId;
@synthesize addToCart = _addToCart;
@synthesize addToFavorites = _addToFavorites;
@synthesize requestState = _requestState;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = kPriceInfoDetailsTitle;
        self.requestState = kProductPriceInfoRequestNone;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    //set localized text
    [self.addToCart setTitle:kAddToCartButtonTitle forState:UIControlStateNormal];
    [self.addToFavorites setTitle:kAddToFavoriteButtonTitle forState:UIControlStateNormal];
    
    if (_productPriceInfo) {
        _productPriceInfo = nil;
    }
    _productPriceInfo = [[ProductPriceInfo alloc] init];
    _productPriceInfoReqResHandler = [[ProductPriceInfoReqResHandler alloc]init];
    
    [_productPriceInfoReqResHandler setDelegate:self];
    
    _productPriceInfo.productId = self.productId;

    //get the product details from the server
    self.requestState = kProductPriceInfoRequestDetail;
    [_productPriceInfoReqResHandler productPriceInfoDetailsDataForProductId:self.productId productPriceInfo:_productPriceInfo];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    self.addToCart = nil;
    self.addToFavorites = nil;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.requestState = kProductPriceInfoRequestNone;
    [_productPriceInfoReqResHandler setDelegate:nil];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return kNumberOfOfSections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return ([_productPriceInfo.reviewArr count] + 3);
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == kImageCell) {
        // image
        return kHeightForImageCell;
    } else if (indexPath.row == kAvailabilityCell || indexPath.row == kPriceDetailsCell) {
        // price & availability 
        return kHeightForAvailabilityCell;
    } else {
        //review
        return kHeightForOtherCell;
    }    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *imageIdentifier = kProductImageCell;
    static NSString *priceIdentifier = kProductPriceInfoCell;
    static NSString *availabilityIdentifier = kProductAvailabilityCell;
    static NSString *reviewDescriptionIdentifier = kProductReviewDescriptionCell;
    
    ProductPriceInfoReviewCell *cell = (ProductPriceInfoReviewCell*)[tableView dequeueReusableCellWithIdentifier:reviewDescriptionIdentifier];
    if (cell == nil) {
        // Load the top-level objects from the custom cell XIB.
        NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:reviewDescriptionIdentifier owner:self options:nil];
        // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
        cell = [topLevelObjects objectAtIndex:0];
    }    
    switch (indexPath.row)
    {
        case kImageCell://Image Cell
        {
            ProductDetailImageCell *cell = (ProductDetailImageCell*)[tableView dequeueReusableCellWithIdentifier:imageIdentifier];
            if (cell == nil) {
                cell = [[ProductDetailImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:imageIdentifier];
            }
            if (!_productPriceInfo.image) {
                [_productPriceInfo setDelegate:cell];
                [_productPriceInfo startDownload];
            }
            [cell setProductImage:_productPriceInfo];
            return cell;
        }
            break;
        case kPriceDetailsCell://Price Details Cell
        {
            ProductPriceInfoCell *cell = (ProductPriceInfoCell*)[tableView dequeueReusableCellWithIdentifier:priceIdentifier];
            if (cell == nil) {
                // Load the top-level objects from the custom cell XIB.
                NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:priceIdentifier owner:self options:nil];
                // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
                cell = [topLevelObjects objectAtIndex:0];
            }
            [cell setProductPriceInfoData:_productPriceInfo];
            return cell;
        }
            break;
        case kAvailabilityCell: // Availability Cell
        {
            ProductPriceInfoAvailabilityCell *cell = (ProductPriceInfoAvailabilityCell*)[tableView dequeueReusableCellWithIdentifier:availabilityIdentifier];
            if (cell == nil) {
                // Load the top-level objects from the custom cell XIB.
                NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:availabilityIdentifier owner:self options:nil];
                // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
                cell = [topLevelObjects objectAtIndex:0];

            }
            [cell setProductPriceInfoData];
            return cell;
        }
            break;
        default://Review details cells
        {
            Review *review = [_productPriceInfo.reviewArr objectAtIndex:(indexPath.row -3)];
            [cell setProductPriceInfoReviewData:review];
        }
            break;
    }    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == kAvailabilityCell){
        AvailabilityDetailsViewController *availabilityDetailsVC = [[AvailabilityDetailsViewController alloc]init];
        availabilityDetailsVC.productsku = _productPriceInfo.sku;
        availabilityDetailsVC.availability.name = _productPriceInfo.name;
        availabilityDetailsVC.availability.image = _productPriceInfo.image;
        availabilityDetailsVC.availability.actualPrice = _productPriceInfo.actualPrice;
        availabilityDetailsVC.availability.offerPrice = _productPriceInfo.offerPrice;
        
        [self.navigationController pushViewController:availabilityDetailsVC animated:YES];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

/*!
 @method        addToCart
 @abstract      add product to cart action 
 @discussion    add product to cart action
*/
- (IBAction)addToCart:(id)sender
{
    CartReqResHandler *cartReqResHandler = [[CartReqResHandler alloc]init];
    [cartReqResHandler setDelegate:self];
    self.requestState = kProductPriceInfoRequestAddoToCart;
    [cartReqResHandler addToCart:_productPriceInfo];
}

#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) {
        TRC_DBG(@"fail to load data from URL");
    }
    else{
        TRC_DBG(@"Pass to load data from URL");
        TRC_DBG(@"productPriceInfo =%@",_productPriceInfo.productId);
        
        switch (self.requestState) {
            case kProductPriceInfoRequestDetail:
            {
                [self.productPriceInfoDetailsTableView reloadData];
            }
                break;
            case kProductPriceInfoRequestAddoToCart:
            {
                [Message showOKOnly:nil alertMessage:kProductAddedToCartSuccessfulMessage setDelegate:nil];
            }
                break;    
            default:
                break;
        }
        
    }        
}

@end
