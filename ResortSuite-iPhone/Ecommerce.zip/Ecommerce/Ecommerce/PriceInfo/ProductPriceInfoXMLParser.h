/* 
 File: ProductPriceInfoXMLParser.h
 Abstract: This class is responsible for product price and offers related parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 22/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "ProductPriceInfo.h"
#import "XMLParser.h"

@interface ProductPriceInfoXMLParser : XMLParser

@property(nonatomic, strong) ProductPriceInfo    *productPriceInfo;
@property(nonatomic, strong) NSArray             *productPriceInfoList;

- (void)parseXMLDataForProductPriceInfo:(NSData *)dataToBeParsed productPriceInfoList:(NSArray*)productPriceInfoList;
- (void)parseXMLDataForProductImage:(NSData *)dataToBeParsed productPriceInfo:(ProductPriceInfo *)productPriceInfo;
- (void)parseXMLDataForProductPriceInfoDetails:(NSData *)dataToBeParsed productId:(NSString *)productId productPriceInfo:(ProductPriceInfo *)productPriceInfo;

@end
