/* 
 File: PriceInfoCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for Price Info module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
 */

//PriceInfo availability cell
#define kAvailabilityTitle          NSLocalizedString(@"Availability", @"")

//ProductPriceInfoListCell
#define kFontSize 12
#define kFontName @"Helvetica"
#define kproductImageViewFrame CGRectMake(10, 1, 80, 80)
#define kproductTitleLblFrame CGRectMake(100, 0, 140, 40)
#define kproductDescriptionLblFrame CGRectMake(100, 22, 140, 80)
#define kproductPriceLblFrame CGRectMake(240, 21, 50, 40)
#define kproductCurrencyLblFrame CGRectMake(290, 31, 20, 20)

//ProductPriceInfoCell
#define kActualPriceXMLTag    @"ActualPrice"
#define kOfferPriceXMLTag     @"OfferPrice"
#define kUSDCurrencySign      @"$"

//PriceInfoSearchViewController
#define kPriceInfoTitle                 NSLocalizedString(@"Price_Info", @"")
#define kPriceInfoDetailsTitle          NSLocalizedString(@"Price_Info_Details", @"")
#define kProductPriceInfoListCell       @"ProductPriceInfoListCell"
#define kProductPriceInfoDetailsVCNib   @"ProductPriceInfoDetailsViewController"
#define kPriceInfoTBarItemImg           @"first.png"

//ProductPriceInfoDetailsViewController
#define kImageCell                  0
#define kPriceDetailsCell           1
#define kAvailabilityCell           2
#define kHeightForImageCell         220
#define kHeightForAvailabilityCell  44
#define kHeightForOtherCell         150
#define kNumberOfOfSections         1

#define kProductImageCell               @"ProductImageCell"
#define kProductReviewDescriptionCell   @"ProductPriceInfoReviewCell"
#define kProductAvailabilityCell        @"ProductPriceInfoAvailabilityCell"
#define kProductPriceInfoCell           @"ProductPriceInfoCell"

//ProductPriceInfoReqResHandler
#define kServerUrl                      @"http://172.27.47.116"
#define kGet                            @"GET"
#define kProductPriceInfoListAPI        @"product.list"//@"ProductPriceInfoList.xml"
#define kProductPriceInfoDetailsAPI     @"product.info"//@"ProductPriceInfoDetails.xml"
#define kProductPriceInfoImageAPI       @"product_attribute_media.list"

//ProductPriceInfoXMLParser
#define kNameXMLTag           @"Name"
#define kDescriptionXMLTag    @"Description"
#define kThumbImgUrlXMLTag    @"ThumbImgUrl"
#define kPriceXMLTag          @"Price"
#define kActualPriceXMLTag    @"ActualPrice"
#define kOfferPriceXMLTag     @"OfferPrice"
#define kReviewArray          @"ReviewArray"
#define kCurrencyXMLTag       @"currency"
#define kReviewXMLTag         @"Review";
#define kReviewerNameXMLTag   @"ReviewerName";
#define kReviewDateXMLTag     @"ReviewDate";
#define kReviewRatingXMLTag   @"ReviewRating";
#define kCommentsXMLTag       @"Comments";
#define kImageUrlXMLTag       @"ImageUrl"
#define kOfferXMLTag          @"Offer"































