/* 
 File: Review.h
 Abstract: This class is responsible for product related review operation.
 Author: Cybage Software Pvt. Ltd
 Created: 27/03/12
 Modified: 27/03/12
 Version: 1.0 
*/

#import "Review.h"

@implementation Review
@synthesize reviewerName = _reviewerName;
@synthesize reviewDate = _reviewDate; 
@synthesize comments = _comments;
@synthesize reviewRating = _reviewRating;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
