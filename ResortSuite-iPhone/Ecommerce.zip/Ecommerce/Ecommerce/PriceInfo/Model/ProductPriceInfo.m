/* 
 File: ProductPriceInfo.m
 Abstract: This class to provide product price and offers related model class.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 22/03/12
 Version: 1.0 
*/

#import "ProductPriceInfo.h"

@implementation ProductPriceInfo
@synthesize actualPrice = _actualPrice;
@synthesize offerPrice = _offerPrice;
@synthesize offer = _offer;
@synthesize reviewRating = _reviewRating;
@synthesize reviewArr = _reviewArr; 

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
