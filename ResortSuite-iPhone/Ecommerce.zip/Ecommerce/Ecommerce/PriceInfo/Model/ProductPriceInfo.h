/* 
 File: ProductPriceInfo.h
 Abstract: This class is a product's price and offers related model class.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 22/03/12
 Version: 1.0 
*/

#import <Foundation/Foundation.h>
#import "Product.h"


@interface ProductPriceInfo : Product

@property(nonatomic, strong) NSString    *offer;
@property(nonatomic, strong) NSString    *reviewRating;
@property(nonatomic, strong) NSArray     *reviewArr;
 
@end
