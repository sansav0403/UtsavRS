/* 
 File: Review.h
 Abstract: This is model class for product related review.
 Author: Cybage Software Pvt. Ltd
 Created: 27/03/12
 Modified: 27/03/12
 Version: 1.0 
 */
#import <Foundation/Foundation.h>

@interface Review : NSObject

@property(nonatomic, strong) NSString     *reviewerName;
@property(nonatomic, strong) NSString     *reviewDate;
@property(nonatomic, strong) NSString     *comments;
@property(nonatomic, strong) NSString     *reviewRating;

@end
