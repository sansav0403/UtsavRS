/* 
 File: PriceInfoSearchViewController.m
 Abstract: This class is responsible for product price related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 23/03/12
 Version: 1.0 
*/

#import "PriceInfoSearchViewController.h"
#import "ValidationHandler.h"
#import "ProductPriceInfo.h"
#import "ProductPriceInfoListCell.h"
#import "ProductPriceInfoReqResHandler.h"
#import "ProductPriceInfoDetailsViewController.h"
#import "PriceInfoCommon.h"
#import "Common.h"

#define kNumberOfSection  1

@implementation PriceInfoSearchViewController
@synthesize productPriceInfoTbl = _productPriceInfoTbl;
@synthesize searchBar = _searchBar;
@synthesize productArray = _productArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = kPriceInfoTitle;
        self.tabBarItem.image = [UIImage imageNamed:kPriceInfoTBarItemImg];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    self.productPriceInfoTbl = nil;
    self.searchBar = nil;
    self.productArray = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark -
#pragma mark Table view datasource and delegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	return kNumberOfSection;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section 
{	
    return [self.productArray count]; 
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
    static NSString *identifier = kProductPriceInfoListCell;
    ProductPriceInfoListCell *cell = (ProductPriceInfoListCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil)
    {
        cell = [[ProductPriceInfoListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    ProductPriceInfo *ProductPriceInfo = [self.productArray objectAtIndex:indexPath.row];
    [ProductPriceInfo setDelegate:cell];
    [cell setProductData:ProductPriceInfo];
    
    if(!ProductPriceInfo.imageUrl)
    {
        [ProductPriceInfo imageUrlForProduct];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    /*
	 To conform to the Human Interface Guidelines, selections should not be persistent --
	 deselect the row after it has been selected.
	 */
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //extract the selected product for details
    ProductPriceInfo *ProductPriceInfo = [self.productArray objectAtIndex:indexPath.row];
    
    ProductPriceInfoDetailsViewController *productPriceInfoDetailsVC = [[ProductPriceInfoDetailsViewController alloc] initWithNibName:kProductPriceInfoDetailsVCNib bundle:[NSBundle mainBundle]];
    productPriceInfoDetailsVC.productId = ProductPriceInfo.productId;
    
    [self.navigationController pushViewController:productPriceInfoDetailsVC animated:YES];
}

#pragma mark - SearchBarDelegate

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)aSearchBar
{
    return YES;
}

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
	if ([searchBar.text isEqualToString:@" "] && [searchBar.text length]==1)
	{ 
		searchBar.text = @"";
		return NO;
	}
	return YES;
}

// called when keyboard search button pressed
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    TRC_DBG(@"Search with keyword %@",searchBar.text);
    [searchBar resignFirstResponder];
    
    searchBar.text = [ValidationHandler trimCurrentString:searchBar.text];
    if([ValidationHandler checkSpaceOrNewLineCharacter:searchBar.text])
    {
        [searchBar resignFirstResponder];
        if([searchBar.text length])
        {
            [self productPriceInfoList];
        }
    }
}

/*!
 @function      productPriceInfoList
 @abstract      request server for product price & offers information
 @discussion    request server for product price & offers information 
 @result        void
 */
- (void)productPriceInfoList
{
    if (_productPriceInfoReqResHandler){
        [_productPriceInfoReqResHandler setDelegate:nil];
    }
    _productPriceInfoReqResHandler = [[ProductPriceInfoReqResHandler alloc]init];
    //get the product list from the server
	if(self.productArray)
	{
        self.productArray = nil;
	}
    self.productArray = [[NSMutableArray alloc] init];	
    [_productPriceInfoReqResHandler setDelegate:self];

    [_productPriceInfoReqResHandler productPriceInfoDataList:self.productArray searchAttribute:kProductNameXMLTag searchKeyword:self.searchBar.text];
}

#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) 
    {
        TRC_DBG(@"fail to load data from URL");
    }
    else
    {
        TRC_DBG(@"ProSearchArray count in VC =%d",[self.productArray count]);
        [self.productPriceInfoTbl reloadData];
    }        
}

@end
