/* 
 File: ProductPriceInfoReqResHandler.h
 Abstract: This class is responsible for product price and offers related request response operation.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 22/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "NetworkRequestResponseBase.h"
#import "ProductPriceInfo.h"

typedef enum {
    kProductPriceInfoListRquest,
    kProductPriceInfoImageRequest,
    kProductPriceInfoDetailsRequest
}ProductPriceInfoHandlerRequestState;

@interface ProductPriceInfoReqResHandler : NetworkRequestResponseBase

@property(nonatomic, strong) NSArray                         *productPriceInfoArr;
@property(nonatomic, strong) NSString                        *productId;
@property(nonatomic, strong) NSString                        *sessionId;
@property(nonatomic, strong) ProductPriceInfo                *productPriceInfo;
@property(nonatomic)   ProductPriceInfoHandlerRequestState   requestState;

- (void)productPriceInfoDataList:(NSArray*)productPriceInfohDataList searchAttribute:(NSString *)attribute searchKeyword:(NSString *)searchKeyword;
- (void)productImageForProductId:(NSString *)productId productPriceInfo:(ProductPriceInfo *)productPriceInfo;
- (void)productPriceInfoDetailsDataForProductId:(NSString *)productId productPriceInfo:(ProductPriceInfo *)productPriceInfo;
- (void)requestWithSoapMessage:(NSString *)soapMsg; 
- (void)didReceiveData:(NSData*)data;

@end
