//
/* 
 File: ProductPriceInfoReqResHandler.m
 Abstract: This class is responsible for product price and offers related request response  
 operation.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 22/03/12
 Version: 1.0 
 */
#import "ProductPriceInfoReqResHandler.h"
#import "ProductPriceInfoXMLParser.h"
#import "PriceInfoCommon.h"
#import "Common.h"
#import "UserExtended.h"

@implementation ProductPriceInfoReqResHandler

@synthesize productPriceInfoArr = _productPriceInfoArr;
@synthesize productId = _productId;
@synthesize sessionId = _sessionId;
@synthesize productPriceInfo = _productPriceInfo;
@synthesize requestState = _requestState;


- (id)init
{
    self = [super init];
    if (self) {
        UserExtended *userExtended = [UserExtended sharedUserExteded];
        self.sessionId = userExtended.sessionId;
    }
    
    return self;
}

/*!
 @function		productPriceInfoDataList
 @abstract		get product price and offers list information.
 @discussion    parse productPrice and offers list.
 @param			productPriceInfohDataList - result will be return in this array 
                searchAttribute - attribute on which filter will apply
                searchKeyword - kewyword to search product
 */
- (void)productPriceInfoDataList:(NSArray*)productPriceInfohDataList searchAttribute:(NSString *)attribute searchKeyword:(NSString *)searchKeyword
{
    self.productPriceInfoArr = productPriceInfohDataList;
    self.requestState = kProductPriceInfoListRquest;
    
    //Magento Api Call Request
    searchKeyword = [searchKeyword stringByAppendingString:@"%"];
    
    NSString *argsValue = [NSString stringWithFormat:@"<item xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">%@</key><value xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">like</key><value xsi:type=\"xsd:string\">%@</value></item></value></item></item>",attribute,searchKeyword];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"ns2:Map[1]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kProductPriceInfoListAPI,argsValue];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		productPriceInfoDetailsDataForProductId
 @abstract		request product details to server.
 @discussion    request product details to server.
 @param			productId - productId of requested product details
                productPriceInfo - result will be return in this productsearch object 
 */
- (void)productPriceInfoDetailsDataForProductId:(NSString *)productId productPriceInfo:(ProductPriceInfo *)productPriceInfo
{
    self.productId = productId;
    self.productPriceInfo = productPriceInfo;
    self.requestState = kProductPriceInfoDetailsRequest;
     
    //Magento Api Call Request
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:anyType\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kProductPriceInfoDetailsAPI,self.productId];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		productImageForProductId
 @abstract		request for product,s image to server.
 @discussion    request for product,s image to server.
 @param			productId - productId of requested product details
                productPrictInfo - result will be return in this object 
 */
- (void)productImageForProductId:(NSString *)productId productPriceInfo:(ProductPriceInfo *)productPriceInfo
{
    self.productId = productId;
    self.productPriceInfo = productPriceInfo;
    self.requestState = kProductPriceInfoImageRequest;
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:anyType\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kProductPriceInfoImageAPI,self.productId];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		requestWithSoapMessage
 @abstract		request to server with soap request object.
 @discussion	request to server with soap request object.
 @param			soapMsg - soap message 
                soapAction - soap action
                httpMethod - httpMethod
 @result		void
 */
- (void)requestWithSoapMessage:(NSString *)soapMsg 
{
    //create a url load request
    NSURL *url = [NSURL URLWithString: kMagentoServerUrl];
    NSMutableURLRequest *req = nil;
    req = [NSMutableURLRequest requestWithURL:url];
    
    //populate the request object with the various headers,
    //such as Content-Type, SOAPAction, and Content-Length. You also set the HTTP method and HTTP body:
    NSString *msgLength = nil;
    msgLength = [NSString stringWithFormat:@"%d", [soapMsg length]];    
    [req addValue:kContentTypeValue  forHTTPHeaderField:kContentType];
    [req addValue:kAcceptEncodingValue  forHTTPHeaderField:kAcceptEncoding];
    [req addValue:kUserAgentValue  forHTTPHeaderField:kUserAgent];
    [req addValue:kHostValue forHTTPHeaderField:kHost];    
    [req addValue:kSoapActionValue forHTTPHeaderField:kSoapAction];
    [req addValue:msgLength forHTTPHeaderField:kContentLength];
    [req setHTTPMethod:kPost];
    [req setHTTPBody:[soapMsg dataUsingEncoding:NSUTF8StringEncoding]];
    
    [self.netDataManager makeRequest:req];
}

/*!
 @function		didReceiveData
 @abstract		response data of network call.
 @discussion	response data of network call.
 @param			data - response data
 @result		void
 */
- (void)didReceiveData:(NSData*)data
{
    TRC_DBG(@"Data received");
    //NSString* newStr = [NSString stringWithUTF8String:[data bytes]];
    //TRC_DBG(@"NSData = %@",newStr);
    
    ProductPriceInfoXMLParser *productPriceInfoXMLParser = [[ProductPriceInfoXMLParser alloc]init];
    
    switch (self.requestState) {
        case kProductPriceInfoListRquest:
        {
            // parse xml data 
            [productPriceInfoXMLParser parseXMLDataForProductPriceInfo:data productPriceInfoList:_productPriceInfoArr];
            TRC_DBG(@"prodcuPriceInfo count=%d",[self.productPriceInfoArr count]);
        }
            break;
        case kProductPriceInfoDetailsRequest:
        {
            [self productImageForProductId:self.productId productPriceInfo:self.productPriceInfo];
            [productPriceInfoXMLParser parseXMLDataForProductPriceInfoDetails:data productId:self.productId productPriceInfo:self.productPriceInfo];
            TRC_DBG(@"productPriceInfoData = %@",self.productPriceInfo.productId);
        }
            break;
        case kProductPriceInfoImageRequest:
        {
            [productPriceInfoXMLParser parseXMLDataForProductImage:data productPriceInfo:self.productPriceInfo];
            TRC_DBG(@"prodcuSearchData = %@",self.productPriceInfo);
        }
            break;
        default:
            break;
    }
    
    //Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)]){
		[self.delegate parseComplete:nil];
	}
}

@end
