/* 
 File: ProductPriceInfoXMLParser.m
 Abstract: This class is responsible for product price and offers related parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 22/03/12
 Version: 1.0 
 */

#import "ProductPriceInfoXMLParser.h"
#import "CXMLDocument.h"
#import "CXMLElement.h"
#import "ProductPriceInfo.h"
#import "Review.h"
#import "PriceInfoCommon.h"
#import "ProductSearchCommon.h"
#import "Common.h"

@implementation ProductPriceInfoXMLParser

@synthesize productPriceInfoList = _productPriceInfoList;
@synthesize productPriceInfo = _productPriceInfo;


- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

/*!
 @function		parseXMLDataForProductPriceInfo
 @abstract		This function parse xml data for product price info list.
 @discussion	This function parse xml data for product price info list.
 @param			dataToBeParsed - NSData to be parsed.
 @param			productPriceInfoList - return array of product objects.
                searchAttribute - attribute on which filter will apply
                searchKeyword - kewyword to search product
 @result		void
 */
- (void)parseXMLDataForProductPriceInfo:(NSData *)dataToBeParsed productPriceInfoList:(NSArray*)productPriceInfoList
{
    self.productPriceInfoList = productPriceInfoList;
    
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        ProductPriceInfo *productPriceInfo = [[ProductPriceInfo alloc] init];
        
        productPriceInfo.productId = [item valueForKey:kProductIdXMLTag];
        
        productPriceInfo.name = [item valueForKey:kProductNameXMLTag];
        
        productPriceInfo.sku = [item valueForKey:kProductSkuXMLTag];
        
        productPriceInfo.type = [item valueForKey:kProductTypeXMLTag];
        
        productPriceInfo.categotryIds = [item valueForKey:kProductCategoryIdXMLTag];
                
        [(NSMutableArray *)_productPriceInfoList addObject:productPriceInfo]; 
    }
}

/*!
 @function		parseXMLDataForProductPriceInfoDetails
 @abstract		This function parse xml data for product price info details.
 @discussion	This function parse xml data for product price info details.
 @param			dataToBeParsed - data to be parsed
 @param			productPriceInfo - return product's extended object.
 @result		void
 */
- (void)parseXMLDataForProductPriceInfoDetails:(NSData *)dataToBeParsed productId:(NSString *)productId productPriceInfo:(ProductPriceInfo *)productPriceInfo;
{
    self.productPriceInfo = productPriceInfo;
    TRC_DBG(@"pID =%@",productId);
    
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
   
    //  searching for piglet nodes
    NSString *tagName = kItem; 

    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    TRC_DBG(@"item cnt = %d",[nodes count]);
    
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    for (CXMLElement *node in nodes) 
    {
        //parse each item node 
        item = [self parseKeyValueFromItemNode:node itemDictionary:item];
    }
    
    // To be done if possible
    //Add entities into product table for manu. & exp. date
    self.productPriceInfo.productId = [item valueForKey:kProductIdXMLTag];
    
    self.productPriceInfo.name = [item valueForKey:kProductNameXMLTag];
    
    self.productPriceInfo.sku = [item valueForKey:kProductSkuXMLTag];
    
    self.productPriceInfo.model = [item valueForKey:kProductModelXMLTag];
    
    self.productPriceInfo.actualPrice = [item valueForKey:kProductPriceXMLTag];
    
    self.productPriceInfo.offerPrice = [item valueForKey:kProductMinimalPriceXMLTag];
    
    self.productPriceInfo.dimension = [item valueForKey:kProductDimensionXMLTag];
    
    self.productPriceInfo.description = [item valueForKey:kProductDescriptionXMLTag];
    
    self.productPriceInfo.imageUrl = [item valueForKey:kImageUrlXMLTag];     
}

/*!
 @function		parseXMLDataForProductImage
 @abstract		This function parse xml data for product image.
 @discussion	This function parse xml data for product image.
 @param			dataToBeParsed - NSData to be parsed.
 @param			productSearchList - return array of product objects.
 @result		void
 */
- (void)parseXMLDataForProductImage:(NSData *)dataToBeParsed productPriceInfo:(ProductPriceInfo *)productPriceInfo
{
    self.productPriceInfo = productPriceInfo;
    
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        self.productPriceInfo.imageUrl = [item valueForKey:kProductImageUrlXMlTag];
        TRC_DBG(@"url =%@",self.productPriceInfo.imageUrl);
    }
}

@end
