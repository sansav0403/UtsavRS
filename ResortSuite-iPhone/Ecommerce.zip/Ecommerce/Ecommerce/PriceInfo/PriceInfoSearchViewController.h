/* 
 File: PriceInfoSearchViewController.h
 Abstract: This class is responsible for product price related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 23/03/12
 Version: 1.0 
*/

#import <UIKit/UIKit.h>
#import "ProductPriceInfo.h"
#import "ProductPriceInfoReqResHandler.h"
#import "ProductSearchReqResHandler.h"

@interface PriceInfoSearchViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,NetworkRequestResponseBaseDelegate>
{
    ProductPriceInfoReqResHandler   *_productPriceInfoReqResHandler;
}

@property(nonatomic, weak) IBOutlet UITableView        *productPriceInfoTbl;
@property(nonatomic, weak) IBOutlet UISearchBar        *searchBar;
@property(nonatomic, strong) NSArray                   *productArray;

- (void)productPriceInfoList;
- (void)parseComplete:(NSError*)error;

@end
