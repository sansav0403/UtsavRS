/* 
 File: ProductPriceInfoReviewCell.m
 Abstract: This class is responsible to display product's review related data.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import "ProductPriceInfoReviewCell.h"

@implementation ProductPriceInfoReviewCell
@synthesize reviewerNameAndDateLbl = _reviewerNameAndDateLbl;
@synthesize reviewRatingLbl = _reviewRatingLbl;
@synthesize reviewCommentsLbl = _reviewCommentsLbl;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductPriceInfoReviewData
 @abstract      set product price review details to cell.
 @discussion    set product price review details to cell.
 @param         productPriceInfoData - product price info which details need to set to cell.
 @result        void
 */
- (void)setProductPriceInfoReviewData:(Review *)reviewData
{
    NSString *nameAndDate = [NSString stringWithFormat:@"%@ , %@",reviewData.reviewerName,reviewData.reviewDate];
    [self.reviewerNameAndDateLbl setText:nameAndDate];
    [self.reviewCommentsLbl setText:reviewData.comments];
    [self.reviewRatingLbl setText:reviewData.reviewRating];
}

@end
