/* 
 File: ProductPriceInfoListCell.h
 Abstract: This custom class is responsible for product's price and offers related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 22/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "ProductCell.h"
#import "ProductPriceInfo.h"

@interface ProductPriceInfoListCell : ProductCell<ProductImageDataDelegate>
{
    UILabel             *_productPriceLbl;
    UILabel             *_productCurrencyLbl;
}

@property(nonatomic, strong) ProductPriceInfo    *productPriceInfo;

- (void)setProductData:(ProductPriceInfo*)productPriceInfoData;

@end
