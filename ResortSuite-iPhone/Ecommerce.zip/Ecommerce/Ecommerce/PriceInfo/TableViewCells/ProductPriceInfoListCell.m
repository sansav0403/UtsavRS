/* 
 File: ProductPriceInfoListCell.m
 Abstract: This class is responsible for product price and offers related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 22/03/12
 Modified: 22/03/12
 Version: 1.0 
 */

#import "ProductPriceInfoListCell.h"
#import "PriceInfoCommon.h"
#import "Common.h"

@implementation ProductPriceInfoListCell
@synthesize productPriceInfo = _productPriceInfo;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self.contentView addSubview:productTitleLbl];
        
        [self.contentView addSubview:productDescriptionLbl];
        
        [self.contentView addSubview:productImageView];
        
        _productPriceLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [_productPriceLbl setTextAlignment:UITextAlignmentRight];
        [_productPriceLbl setFont:[UIFont fontWithName:kFontName size:kFontSize]];
        [self.contentView addSubview:_productPriceLbl];
        
        _productCurrencyLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [_productCurrencyLbl setTextAlignment:UITextAlignmentLeft];
        [_productCurrencyLbl setFont:[UIFont fontWithName:kFontName size:kFontSize]];
        [_productCurrencyLbl setBackgroundColor:[UIColor clearColor]];
        [self.contentView addSubview:_productCurrencyLbl];
        
        [self setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        // set frame for image
        frame = kproductImageViewFrame;
        [productImageView setFrame:frame];
        
        //set frame for the title
        frame = kproductTitleLblFrame;
        [productTitleLbl setFrame:frame];

        // set frame for offer description        
        frame = kproductDescriptionLblFrame;
        [productDescriptionLbl setFrame:frame];
        
        //set frame for price
        frame = kproductPriceLblFrame;
        [_productPriceLbl setFrame:frame];
        
        //set frame for currency
        frame = kproductCurrencyLblFrame;
        [_productCurrencyLbl setFrame:frame];
        
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductData
 @abstract      set product details to cell.
 @discussion    set product details to cell.
 @param         productPriceInfoData - product price info which details need to set to cell.
                int - cell index
 @result        void
 */
- (void)setProductData:(ProductPriceInfo*)productPriceInfoData
{
    self.productPriceInfo = productPriceInfoData;
    [productImageView setImage:nil];
    
    [productTitleLbl setText:productPriceInfoData.name];
    [productDescriptionLbl setText:productPriceInfoData.sku];
    [_productPriceLbl setText:productPriceInfoData.type];
    //[_productCurrencyLbl setText:productPriceInfoData.currency];
    
    if(self.productPriceInfo.image)
    {
        [productImageView setImage:self.productPriceInfo.image];
        [activityIndicatorView stopAnimating];
    }
    else{
        [activityIndicatorView startAnimating];
    }
}

#pragma mark - Product image data DELEGETE
/*!
 @function      didReceivedData
 @abstract      set product image data to cell.
 @discussion    set product image data to cell.
 @param         imgData - product image data to set on cell.
                urlString - image url path
 @result        void
 */
- (void)didReceivedData:(id)imgData urlString:(NSString *)urlString
{
    [activityIndicatorView stopAnimating];
    [activityIndicatorView removeFromSuperview];
    TRC_DBG(@"%@", urlString );
    if (imgData && [urlString isEqualToString:self.productPriceInfo.imageUrl]) {
        [productImageView setImage:imgData];
    }
    else{
        [productImageView setImage:[UIImage imageNamed:kNoImage]];
    }
    TRC_DBG(@"%@", self.productPriceInfo.imageUrl );
}

@end
