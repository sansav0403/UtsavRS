/* 
 File: ProductPriceInfoReviewCell.h
 Abstract: This custom class is responsible to display product's review related data.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "Review.h"

@interface ProductPriceInfoReviewCell : UITableViewCell

@property(nonatomic, weak) IBOutlet UILabel    *reviewerNameAndDateLbl;
@property(nonatomic, weak) IBOutlet UILabel    *reviewRatingLbl;
@property(nonatomic, weak) IBOutlet UILabel    *reviewCommentsLbl;

- (void)setProductPriceInfoReviewData:(Review *)reviewData;

@end
