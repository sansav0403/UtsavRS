/* 
 File: ProductPriceInfoCell.h
 Abstract: This custom class is responsible to display product's actual and offer price details.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "ProductPriceInfo.h"

/*!
 @class       ProductPriceInfoCell
 @abstract    Custom Cell for ProductPriceInfoCell.
 @discussion  Custom Cell for ProductPriceInfoCell.
 */
@interface ProductPriceInfoCell : UITableViewCell

@property(nonatomic, weak) IBOutlet   UILabel *actualPriceLbl;
@property(nonatomic, weak) IBOutlet   UILabel *offerPriceLbl;

- (void)setProductPriceInfoData:(ProductPriceInfo*)productPriceInfoData;

@end
