/* 
 File: ProductPriceInfoCell.m
 Abstract: This class is responsible to display product's actual and offer price details.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import "ProductPriceInfoCell.h"
#import "PriceInfoCommon.h"

@implementation ProductPriceInfoCell
@synthesize actualPriceLbl = _actualPriceLbl;
@synthesize offerPriceLbl = _offerPriceLbl;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductPriceInfoData
 @abstract      set product price details to cell.
 @discussion    set product price details to cell.
 @param         productPriceInfoData - product price info which details need to set to cell.
 @result        void
 */
- (void)setProductPriceInfoData:(ProductPriceInfo*)productPriceInfoData
{
    productPriceInfoData.currency = kUSDCurrencySign;
    NSString *actualPrice = nil;
    NSString *offerPrice = nil;
    
    if (productPriceInfoData.actualPrice) {
        actualPrice = [NSString stringWithFormat:@"%@ : %@ %@",kActualPriceXMLTag,productPriceInfoData.actualPrice,productPriceInfoData.currency];
    }
    
    if(productPriceInfoData.offerPrice){
        offerPrice = [NSString stringWithFormat:@"%@ : %@ %@",kOfferPriceXMLTag,productPriceInfoData.offerPrice,productPriceInfoData.currency];
    }
    
    [self.actualPriceLbl setText:actualPrice];
    [self.offerPriceLbl setText:offerPrice];
}

@end
