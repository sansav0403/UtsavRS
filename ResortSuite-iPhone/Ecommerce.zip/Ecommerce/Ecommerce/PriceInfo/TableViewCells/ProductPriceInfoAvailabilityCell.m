/* 
 File: ProductPriceInfoAvailabilityCell.m
 Abstract: This class is responsible for product's availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import "ProductPriceInfoAvailabilityCell.h"
#import "PriceInfoCommon.h"

@implementation ProductPriceInfoAvailabilityCell
@synthesize availabilityLbl = _availabilityLbl;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductPriceInfoData
 @abstract      set product price details to cell.
 @discussion    set product price details to cell.
 @param         productPriceInfoData - product price info which details need to set to cell.
 @result        void
 */
- (void)setProductPriceInfoData
{
    [self.availabilityLbl setText:kAvailabilityTitle];
}
@end
