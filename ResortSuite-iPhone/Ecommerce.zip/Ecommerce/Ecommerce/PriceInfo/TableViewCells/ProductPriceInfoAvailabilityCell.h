/* 
 File: ProductPriceInfoAvailabilityCell.h
 Abstract: This custom class is responsible for product's availability related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 26/03/12
 Modified: 27/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>


@interface ProductPriceInfoAvailabilityCell : UITableViewCell

@property(nonatomic, weak) IBOutlet   UILabel *availabilityLbl;

- (void)setProductPriceInfoData;

@end
