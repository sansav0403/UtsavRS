/* 
 File: ProductSearchViewController.h
 Abstract: This class is responsible for product search related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
*/

#import <UIKit/UIKit.h>
#import "ProductSearch.h"
#import "ProductSearchReqResHandler.h"
#import "LoginReqResHandler.h"

@interface ProductSearchViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,NetworkRequestResponseBaseDelegate>
{
    ProductSearchReqResHandler  *_productSearchReqResHandler;
}

@property(nonatomic, weak) IBOutlet UITableView *productTbl;
@property(nonatomic, weak) IBOutlet UISearchBar *searchBar;
@property(nonatomic, strong) ProductSearch      *productSearch;
@property(nonatomic, strong) NSArray            *productArray;

- (void)searchProduct;
- (void)parseComplete:(NSError*)error;

@end
