/* 
 File: ProductDetailImageCell.h
 Abstract: This class is responsible for product's image related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 15/03/12
 Modified: 15/03/12
 Version: 1.0 
 */

#import <UIKit/UIKit.h>
#import "ProductCell.h"
#import "ProductSearch.h"

@interface ProductDetailImageCell : ProductCell<ProductImageDataDelegate>

@property(nonatomic, strong) ProductSearch   *productSearch;

- (void)setProductImage:(Product*)productSearchData;

@end
