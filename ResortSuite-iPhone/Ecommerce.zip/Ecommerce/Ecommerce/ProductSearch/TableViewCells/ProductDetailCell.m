/* 
 File: ProductDetailsCell.m
 Abstract: This class is responsible for product search related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 15/03/12
 Modified: 15/03/12
 Version: 1.0 
*/

#import "ProductDetailCell.h"
#import "ProductSearchCommon.h"

@implementation ProductDetailCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [productTitleLbl setBackgroundColor:[UIColor clearColor]];
        [productTitleLbl setTextColor:[UIColor darkGrayColor]];
        [productTitleLbl setFont:[UIFont boldSystemFontOfSize:kProductTitleFontSize]];
        [productTitleLbl setTextAlignment:UITextAlignmentLeft];
        [self.contentView addSubview:productTitleLbl];
        
        [productDescriptionLbl setTextColor:[UIColor blackColor]];
        [productDescriptionLbl setFont:[UIFont systemFontOfSize:kProductDescriptionFontSize]];
        [productDescriptionLbl setLineBreakMode:UILineBreakModeWordWrap];
        [productDescriptionLbl setNumberOfLines:2];
        [self.contentView addSubview:productDescriptionLbl];
        
        [self setAccessoryType:UITableViewCellAccessoryNone];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        //set frame for the title
        frame = kProductTitleFrame;
        [productTitleLbl setFrame:frame];
        
        frame = kProductDescriptionFrame;
        [productDescriptionLbl setFrame:frame];
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductData
 @abstract      set product details to cell.
 @discussion    set product details to cell.
 @param         labelKey - label key
                labelValue - label value
 @result        void
 */
- (void)setProductData:(NSString *)labelKey labelValue:(NSString *)labelValue
{    
    [productTitleLbl setText:labelKey];
    if (![labelValue isEqual:[NSNull null]]) 
    {
            [productDescriptionLbl setText:labelValue];
    }else{
            [productDescriptionLbl setText:@""];
    }
}

@end
