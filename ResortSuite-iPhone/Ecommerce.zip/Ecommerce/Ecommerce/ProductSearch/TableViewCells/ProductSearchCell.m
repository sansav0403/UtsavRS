/* 
 File: ProductSearchCell.h
 Abstract: This class is responsible for product search related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 09/03/12
 Modified: 09/03/12
 Version: 1.0 
 */

#import "ProductSearchCell.h"
#import "Common.h"

@implementation ProductSearchCell
@synthesize productSearch =_productSearch;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self.contentView addSubview:productTitleLbl];

        [self.contentView addSubview:productDescriptionLbl];

        [self.contentView addSubview:productImageView];
        
        [self setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductData
 @abstract      set product details to cell.
 @discussion    set product details to cell.
 @param         ProductSearchData - product of which details need to set to cell.
                int - cell index
 @result        void
 */
- (void)setProductData:(ProductSearch*)productSearchData
{
    self.productSearch = productSearchData;
    [productImageView setImage:nil];
    [productDescriptionLbl setText:productSearchData.sku];
    [productTitleLbl setText:productSearchData.name];
    
    //set image 
    if(self.productSearch.image)
    {
        [productImageView setImage:self.productSearch.image];
        [activityIndicatorView stopAnimating];
    }
    else
    {
        [activityIndicatorView startAnimating];
    }
}

#pragma mark - Product image data DELEGETE
/*!
 @function      setProductData
 @abstract      set product details to cell.
 @discussion    set product details to cell.
 @param         Product - product of which details need to set to cell.
                int - cell index
 @result        void
 */
- (void)didReceivedData:(id)imgData urlString:(NSString *)urlString
{
    [activityIndicatorView stopAnimating];
    [activityIndicatorView removeFromSuperview];
    TRC_DBG(@"%@", urlString );
    if (imgData && [urlString isEqualToString:self.productSearch.imageUrl]) {
        [productImageView setImage:imgData];
    }
    else{
        [productImageView setImage:[UIImage imageNamed:kNoImage]];
    }
    TRC_DBG(@"%@", self.productSearch.imageUrl );
}


@end
