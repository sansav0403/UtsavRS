/* 
 File: ProductDetailImageCell.m
 Abstract: This class is responsible for product's image related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 15/03/12
 Modified: 15/03/12
 Version: 1.0 
 */

#import "ProductDetailImageCell.h"
#import "ProductSearchCommon.h"


@implementation ProductDetailImageCell
@synthesize productSearch =_productSearch;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [productImageView setContentMode:UIViewContentModeScaleAspectFit];
        [self.contentView addSubview:productImageView];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        
        //set frame for the image
        frame = kProductImageViewFrame;
        [productImageView setFrame:frame];
        
        frame = kActivityIndicatorViewFrame;
        [activityIndicatorView setFrame:frame];
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductData
 @abstract      set product details to cell.
 @discussion    set product details to cell.
 @param         ProductSearchData - product of which details need to set to cell.
 @result        void
 */
- (void)setProductImage:(ProductSearch*)productSearchData
{
    self.productSearch = productSearchData;
    
    //set image 
    if(self.productSearch.image)
    {
        [productImageView setImage:self.productSearch.image];
        [activityIndicatorView stopAnimating];
    }
    else
    {
        [activityIndicatorView startAnimating];
    }
}                

#pragma mark - Product image data DELEGETE
/*!
 @function      didReceivedData
 @abstract      set product's image to cell.
 @discussion    set product's image to cell.
 @param         aData - product of which details need to set to cell.
                int - cell index
 @result        void
 */
- (void)didReceivedData:(id)imgData urlString:(NSString *)urlString
{
    TRC_DBG(@"%@", urlString );
    if([urlString isEqualToString:self.productSearch.imageUrl])
    {
        [productImageView setImage:imgData];
        [activityIndicatorView stopAnimating];
        [activityIndicatorView removeFromSuperview];
    }
}


@end
