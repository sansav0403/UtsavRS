/* 
 File: ProductDetailDescriptionCell.m
 Abstract: This class is responsible for product details related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 15/03/12
 Modified: 15/03/12
 Version: 1.0 
*/

#import "ProductDetailDescriptionCell.h"
#import "ValidationHandler.h"
#import "ProductSearchCommon.h"

@implementation ProductDetailDescriptionCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [productTitleLbl setBackgroundColor:[UIColor clearColor]];
        [productTitleLbl setTextColor:[UIColor darkGrayColor]];
        [productTitleLbl setFont:[UIFont boldSystemFontOfSize:kProductTitleFontSize]];
        [productTitleLbl setTextAlignment:UITextAlignmentCenter];
        [self.contentView addSubview:productTitleLbl];
        
        [productDescriptionLbl setBackgroundColor:[UIColor clearColor]];
        [productDescriptionLbl setTextColor:[UIColor blackColor]];
        [productDescriptionLbl setFont:[UIFont systemFontOfSize:kProductDescriptionFontSize]];
        [productDescriptionLbl setLineBreakMode:UILineBreakModeWordWrap];
        [productDescriptionLbl setNumberOfLines:4];
        [self.contentView addSubview:productDescriptionLbl];
        
        [self setAccessoryType:UITableViewCellAccessoryNone];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        //set frame for the title
        frame = kProductDetTitleFrame;
        [productTitleLbl setFrame:frame];
        
        frame = kProductDetDescriptionFrame;
        [productDescriptionLbl setFrame:frame];
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setProductData
 @abstract      set product details to cell.
 @discussion    set product details to cell.
 @param         labelKey - label key 
                labelValue - label value
 @result        void
 */
- (void)setProductData:(NSString *)labelKey labelValue:(NSString *)labelValue
{    
    labelValue = [labelValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    [productTitleLbl setText:labelKey];
    if (![labelValue isEqual:[NSNull null]]) 
    {
        [productDescriptionLbl setText:labelValue];
    }else{
        [productDescriptionLbl setText:@""];
    }
}

@end
