/* 
 File: ProductSearchCommon.h
 Abstract: This class is contains macros and constants for image names and ui text for Product search module.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
*/

typedef enum {
    kProductSearchListRquest,
    kProductDetailsRequest,
    kProductImageUrlRequest,
    kProductImageRequest
}ProductSearchHandlerRequestState;

#define kGet                        @"GET"

//Request Response Handler
#define kProductSearchAPI           @"product.list"//@"SearchProductList.xml"
#define kProductDetailsAPI          @"product.info"//@"ProductDetails.xml"
#define kProductImageAPI            @"product_attribute_media.list"

//View Controller
#define kNoOfSection    1
#define kSearchTitle                NSLocalizedString(@"Search", @"")
#define kSearchTBarItemImg          @"searchTBar.png"
#define kProductCell                @"ProductSearchCell"
#define kProductDetailsVCNib        @"ProductDetailsViewController"


//Parser File
#define kDescriptionXMLTag    @"Description"
#define kThumbImgUrlXMLTag    @"ThumbImgUrl"
#define kPriceXMLTag          @"Price"
#define kActualPriceXMLTag    @"ActualPrice"
#define kOfferPriceXMLTag     @"OfferPrice"
#define kOfferXMLTag          @"Offer"
#define kQuantityXMLTag       @"Quantity"
#define kCurrencyXMLTag       @"currency"

#define kNumberXMLTag        @"Number"
#define kModelXMLTag         @"model"
#define kMfgDateXMLTag       @"MfgDate"
#define kExpDateXMLTag       @"ExpDate"
#define kImageUrlXMLTag      @"ImageUrl"

//Details File
#define kNoOfSection    1
#define kNoOfRows       8
#define kImageCell          0
#define kDescriptionCell    5    
#define kHeightOfImageCell          220
#define KHeightOfDescriptionCell     120
#define kHeightOfOtherCell          44

#define kProductDetailsTitle           NSLocalizedString(@"Product_Details", @"")

#define kProductImageCell               @"ProductImageCell"
#define kProductDetailCell              @"ProductDetailCell"
#define kProductDetailDescriptionCell   @"ProductDetailDesrciptionCell"
#define kProductDetailsTitle            NSLocalizedString(@"Product_Details", @"")
#define kProductNumber                  NSLocalizedString(@"Product_Number", @"")
#define kExpiryDate                     NSLocalizedString(@"Expiry_Date", @"")
#define kAvailabilityTitle              NSLocalizedString(@"Availability", @"")

//Product Detail Cell
#define kProductTitleFontSize   14
#define kProductDescriptionFontSize 12
#define kProductTitleFrame CGRectMake(5, 5, 150, 40)
#define kProductDescriptionFrame CGRectMake(160, 5, 155, 40)


//Product DetailDesc Cell
#define kProductTitleFontSize   14
#define kProductDescriptionFontSize 12
#define kProductDetTitleFrame CGRectMake(0, 0, 320, 40)
#define kProductDetDescriptionFrame CGRectMake(5, 40, 310, 65)

//ProductDetailImage Cell
#define kProductImageViewFrame CGRectMake(10, 10, 300, 200)
#define kActivityIndicatorViewFrame CGRectMake(140,90, 20, 20)


