/* 
 File: ProductSearchReqResHandler.m
 Abstract: This class is responsible to requesting server for product search related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 14/03/12
 Modified: 14/03/12
 Version: 1.0 
 */

#import "ProductSearchReqResHandler.h"
#import "ProductSearchXMLParser.h"
#import "Common.h"
#import "UserExtended.h"

@implementation ProductSearchReqResHandler
@synthesize productSearchArr = _productSearchArr;
@synthesize productId = _productId;
@synthesize sessionId = _sessionId; 
@synthesize productSearch = _productSearch;
@synthesize requestState = _requestState;
@synthesize product = _product;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
        UserExtended *userExtended = [UserExtended sharedUserExteded];
        self.sessionId = userExtended.sessionId;
    }
    
    return self;
}

/*!
 @function		productDataList
 @abstract		get product list information.
 @discussion    parse product list.
 @param			productSearchDataList - result will be return in this array 
                searchAttribute - attribute on which filter will apply
                searchKeyword - kewyword to search product 
 */
- (void)productDataList:(NSArray*)productSearchDataList searchAttribute:(NSString *)attribute searchKeyword:(NSString *)searchKeyword
{
    self.productSearchArr = productSearchDataList;
    self.requestState = kProductSearchListRquest;
    
    searchKeyword = [searchKeyword stringByAppendingString:@"%"];
       
    NSString *argsValue = [NSString stringWithFormat:@"<item xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">%@</key><value xsi:type=\"ns2:Map\"><item><key xsi:type=\"xsd:string\">like</key><value xsi:type=\"xsd:string\">%@</value></item></value></item></item>",attribute,searchKeyword];
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:ns2=\"http://xml.apache.org/xml-soap\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args SOAP-ENC:arrayType=\"ns2:Map[1]\" xsi:type=\"SOAP-ENC:Array\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kProductSearchAPI,argsValue];
            
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		productDetailsDataForProductId
 @abstract		request product details to server.
 @discussion    request product details to server.
 @param			productId - productId of requested product details
                productSearch - result will be return in this productsearch object 
 */
- (void)productDetailsDataForProductId:(NSString *)productId productSearch:(ProductSearch *)productSearch
{
    self.productId = productId;
    self.productSearch = productSearch;
    self.requestState = kProductDetailsRequest;
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:anyType\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kProductDetailsAPI,self.productId];
        
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		productImageForProductId
 @abstract		request for product,s image to server.
 @discussion    request for product,s image to server.
 @param			productId - productId of requested product details
                productSearch - result will be return in this productsearch object 
 */
- (void)productImageForProductId:(NSString *)productId productSearch:(ProductSearch *)productSearch
{
    self.productId = productId;
    self.productSearch = productSearch;
    self.requestState = kProductImageRequest;
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:anyType\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kProductImageAPI,self.productId];
        
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		productImageUrlForProductId
 @abstract		request for product,s image url to server.
 @discussion    request for product,s image url to server.
 @param			productId - productId of requested product details
 productSearch - result will be return in this productsearch object 
 */
- (void)productImageUrlForProductId:(NSString *)productId product:(Product*)product
{
    self.productId = productId;
    self.product = product;
    self.requestState = kProductImageUrlRequest;
    
    NSString *soapMsg = nil;
    soapMsg = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"utf-8\"?><soapenv:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:Magento\"><soapenv:Header/><soapenv:Body><urn:call soapenv:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><sessionId xsi:type=\"xsd:string\">%@</sessionId><resourcePath xsi:type=\"xsd:string\">%@</resourcePath><args xsi:type=\"xsd:anyType\">%@</args></urn:call></soapenv:Body></soapenv:Envelope>",self.sessionId,kProductImageAPI,self.productId];
    
    // create and sent request
    [self requestWithSoapMessage:soapMsg];
}

/*!
 @function		requestWithSoapMessage
 @abstract		request to server with soap request object.
 @discussion	request to server with soap request object.
 @param			soapMsg - soap message 
                soapAction - soap action
                httpMethod - httpMethod
 @result		void
 */
- (void)requestWithSoapMessage:(NSString *)soapMsg 
{
    //create a url load request
    NSURL *url = [NSURL URLWithString: kMagentoServerUrl];
    NSMutableURLRequest *req = nil;
    req = [NSMutableURLRequest requestWithURL:url];
    
    //populate the request object with the various headers,
    //such as Content-Type, SOAPAction, and Content-Length. You also set the HTTP method and HTTP body:
    NSString *msgLength = nil;
    msgLength = [NSString stringWithFormat:@"%d", [soapMsg length]];    
    [req addValue:kContentTypeValue  forHTTPHeaderField:kContentType];
    [req addValue:kAcceptEncodingValue  forHTTPHeaderField:kAcceptEncoding];
    [req addValue:kUserAgentValue  forHTTPHeaderField:kUserAgent];
    [req addValue:kHostValue forHTTPHeaderField:kHost];    
    [req addValue:kSoapActionValue forHTTPHeaderField:kSoapAction];
    [req addValue:msgLength forHTTPHeaderField:kContentLength];
    [req setHTTPMethod:kPost];
    [req setHTTPBody:[soapMsg dataUsingEncoding:NSUTF8StringEncoding]];
    
    [self.netDataManager makeRequest:req];
}

/*!
 @function		didReceiveData
 @abstract		response data of network call.
 @discussion	response data of network call.
 @param			data - response data
 @result		void
 */
- (void)didReceiveData:(NSData*)data
{
    NSString* newStr = [NSString stringWithUTF8String:[data bytes]];
    TRC_DBG(@"NSData = %@",newStr);
    
    ProductSearchXMLParser *productSearchXMLParser = [[ProductSearchXMLParser alloc]init];
    
    switch (self.requestState) {
        case kProductSearchListRquest:
        {
            [productSearchXMLParser parseXMLDataForProductSearch:data productSearchList:_productSearchArr];
        }
            break;
        case kProductDetailsRequest:
        {
            [self productImageForProductId:self.productId productSearch:self.productSearch];
            
            [productSearchXMLParser parseXMLDataForProductDetails:data productId:self.productId  productSearch:self.productSearch];
        }
            break;
        case kProductImageRequest:
        {
            [productSearchXMLParser parseXMLDataForProductImage:data productSearch:self.productSearch];
        }
            break;              
        case kProductImageUrlRequest:
        {
            [productSearchXMLParser parseXMLDataForProductImage:data productSearch:(ProductSearch*)self.product];
        }
            break;
        default:
            break;
    }
    
    //Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)]){
		[self.delegate parseComplete:nil];
	}
}


@end