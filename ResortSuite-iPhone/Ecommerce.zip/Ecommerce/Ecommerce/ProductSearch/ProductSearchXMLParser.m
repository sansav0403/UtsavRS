/* 
 File: ProductSearchXMLParser.m
 Abstract: This class is responsible for product related xml parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 15/03/12
 Modified: 15/03/12
 Version: 1.0 
 */

#import "ProductSearchXMLParser.h"
#import "CXMLDocument.h"
#import "CXMLElement.h"
#import "ProductSearch.h"
#import "ProductSearchCommon.h"
#import "Common.h"

@implementation ProductSearchXMLParser

@synthesize product = _product;
@synthesize productSearchList = _productSearchList;
@synthesize productSearch = _productSearch;

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }

    return self;
}

/*!
 @function		parseXMLDataForProductSearch
 @abstract		This function parse xml data for product list.
 @discussion	This function parse xml data for product list.
 @param			dataToBeParsed - NSData to be parsed.
 @param			productSearchList - return array of product objects.
 @result		void
 */
- (void)parseXMLDataForProductSearch:(NSData *)dataToBeParsed productSearchList:(NSArray*)productSearchList
{
    self.productSearchList = productSearchList;
    
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        ProductSearch *productSearch = [[ProductSearch alloc] init];
        
        productSearch.productId = [item valueForKey:kProductIdXMLTag];
        
        productSearch.name = [item valueForKey:kProductNameXMLTag];
        
        productSearch.sku = [item valueForKey:kProductSkuXMLTag];
        
        productSearch.type = [item valueForKey:kProductTypeXMLTag];
        
        productSearch.categotryIds = [item valueForKey:kProductCategoryIdXMLTag];
        
        [(NSMutableArray *)_productSearchList addObject:productSearch];
    }
}

/*!
 @function		productDetailsWithItemId
 @abstract		This function requests for product details on canis server.
 @discussion	This function requests for product details on canis server.
 @param			itemId - product id.
 @param			productExtendedObj - return product object.
 @result		void
 */
- (void)parseXMLDataForProductDetails:(NSData *)dataToBeParsed productId:(NSString *)productId productSearch:(ProductSearch *)productSearch
{
    self.productSearch = productSearch;
    
    CXMLDocument *doc = [[CXMLDocument alloc] initWithData:dataToBeParsed options:0 error:nil];
    
    NSArray *nodes = NULL;
   
    //  searching for piglet nodes
    NSString *tagName = kItem; 
    
    nodes = [doc nodesForXPath:[NSString stringWithFormat:@"//%@",tagName] error:nil];
    TRC_DBG(@"item cnt = %d",[nodes count]);
        
    NSMutableDictionary *item = [[NSMutableDictionary alloc] init];
    
    for (CXMLElement *node in nodes) 
    {
        //parse each item node 
        item = [self parseKeyValueFromItemNode:node itemDictionary:item];
    }
    
    TRC_DBG(@"item =%@",item);
        
    // To be done
    //Add entities into product table for manu. & exp. date
    
        self.productSearch.productId = [item valueForKey:kProductIdXMLTag];    
    
        self.productSearch.name = [item valueForKey:kProductNameXMLTag];
        
        self.productSearch.sku = [item valueForKey:kProductSkuXMLTag];
    
        self.productSearch.model = [item valueForKey:kProductModelXMLTag];
        
        self.productSearch.manufacture = [item valueForKey:kProductManufactureXMLTag];

        self.productSearch.manufacturingDate = [item valueForKey:kProductCreatedXMLTag];
        
        self.productSearch.dimension = [item valueForKey:kProductDimensionXMLTag];
      
        TRC_DBG(@"man Date=%@",self.productSearch.manufacturingDate);
        
        self.productSearch.actualPrice = [item valueForKey:kProductPriceXMLTag];
    
        self.productSearch.offerPrice = [item valueForKey:kProductMinimalPriceXMLTag];
    
        self.productSearch.expiryDate = [item valueForKey:kExpDateXMLTag];
        
        self.productSearch.description = [item valueForKey:kProductDescriptionXMLTag];
        
        self.productSearch.imageUrl = [item valueForKey:kImageUrlXMLTag];        
}

/*!
 @function		parseXMLDataForProductSearch
 @abstract		This function parse xml data for product list.
 @discussion	This function parse xml data for product list.
 @param			dataToBeParsed - NSData to be parsed.
 @param			productSearchList - return array of product objects.
 @result		void
 */
- (void)parseXMLDataForProductImage:(NSData *)dataToBeParsed productSearch:(ProductSearch *)product
{
    self.product = product;
    TRC_DBG(@"imageUrlNSData = %@",[NSString stringWithUTF8String:[dataToBeParsed bytes]]);    
    NSArray *dictionaryArray = [self parseXMLDataIntoDictionary:dataToBeParsed];
    
    //parse from dictionary to model object
    for(NSMutableDictionary *item in dictionaryArray)
    {
        self.product.imageUrl = [item valueForKey:kProductImageUrlXMlTag];
        TRC_DBG(@"url =%@",self.product.imageUrl);
    }
}

@end