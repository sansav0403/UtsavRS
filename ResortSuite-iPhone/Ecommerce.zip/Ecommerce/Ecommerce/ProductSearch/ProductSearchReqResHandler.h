/* 
 File: ProductSearchReqResHandler.h
 Abstract: This class is responsible to requesting server for product search related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 14/03/12
 Modified: 14/03/12
 Version: 1.0 
*/

#import <Foundation/Foundation.h>
#import "NetworkRequestResponseBase.h"
#import "ProductSearch.h"
#import "ProductSearchCommon.h"


@interface ProductSearchReqResHandler : NetworkRequestResponseBase

@property(nonatomic, strong) NSArray                         *productSearchArr;
@property(nonatomic, strong) NSString                        *productId;
@property(nonatomic, strong) NSString                        *sessionId;
@property(nonatomic, strong) Product                         *product;
@property(nonatomic, strong) ProductSearch                   *productSearch;
@property(nonatomic)   ProductSearchHandlerRequestState      requestState;

- (void)productDataList:(NSArray*)productSearchDataList searchAttribute:(NSString *)attribute       searchKeyword:(NSString *)searchKeyword;
- (void)productDetailsDataForProductId:(NSString *)productId productSearch:(ProductSearch *)productSearch;
- (void)productImageForProductId:(NSString *)productId productSearch:(ProductSearch *)productSearch;
- (void)productImageUrlForProductId:(NSString *)productId product:(Product*)product;
- (void)requestWithSoapMessage:(NSString *)soapMsg;
- (void)didReceiveData:(NSData*)data;

@end
