/* 
 File: ProductDetailsViewController.h
 Abstract: This class is responsible for product details related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 16/03/12
 Modified: 16/03/12
 Version: 1.0 
*/

#import <UIKit/UIKit.h>
#import "ProductSearch.h"
#import "ProductSearchReqResHandler.h"

@interface ProductDetailsViewController : UITableViewController<NetworkRequestResponseBaseDelegate>
{
    ProductSearch               *_productSearch;
    ProductSearchReqResHandler  *_productSearchReqResHandler;
}

@property(nonatomic, strong) NSString        *productId;

@end
