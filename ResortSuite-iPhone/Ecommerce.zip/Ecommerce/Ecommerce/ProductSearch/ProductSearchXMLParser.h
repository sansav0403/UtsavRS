/* 
 File: ProductSearchXMLParser.h
 Abstract: This class is responsible for product related xml parsing.
 Author: Cybage Software Pvt. Ltd
 Created: 15/03/12
 Modified: 15/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "XMLParser.h"
#import "ProductSearch.h"


@interface ProductSearchXMLParser : XMLParser

@property(nonatomic, strong) Product         *product;
@property(nonatomic, strong) ProductSearch   *productSearch;
@property(nonatomic, strong) NSArray         *productSearchList;

- (void)parseXMLDataForProductSearch:(NSData *)dataToBeParsed productSearchList:(NSArray*)productSearchList;
- (void)parseXMLDataForProductDetails:(NSData *)dataToBeParsed productId:(NSString *)productId productSearch:(ProductSearch *)productSearch;
- (void)parseXMLDataForProductImage:(NSData *)dataToBeParsed productSearch:(ProductSearch *)productSearch;

@end
