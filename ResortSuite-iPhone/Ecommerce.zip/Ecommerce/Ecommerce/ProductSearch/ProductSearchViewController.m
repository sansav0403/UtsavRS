/* 
 File: ProductSearchViewController.m
 Abstract: This class is responsible for product search related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 07/03/12
 Modified: 07/03/12
 Version: 1.0 
*/

#import "ProductSearchViewController.h"
#import "ProductSearchCell.h"
#import "ValidationHandler.h"
#import "ProductDetailsViewController.h"
#import "ProductSearchCommon.h"
#import "Common.h"


@implementation ProductSearchViewController
@synthesize productTbl = _productTbl;
@synthesize searchBar = _searchBar;
@synthesize productArray = _productArray;
@synthesize productSearch = _productSearch;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = kSearchTitle;
        self.tabBarItem.image = [UIImage imageNamed:kSearchTBarItemImg];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    //set IBOutlet to nil
    self.productTbl = nil;
    self.searchBar = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark -
#pragma mark Table view datasource and delegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	return kNoOfSection;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section 
{	
    return [self.productArray count]; 
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
    static NSString *identifier = kProductCell;
    ProductSearchCell *cell = (ProductSearchCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil)
    {
        cell = [[ProductSearchCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    ProductSearch *productSearch = [self.productArray objectAtIndex:indexPath.row];
    [productSearch setDelegate:cell];
    [cell setProductData:productSearch];
   
    //get image Url and dowload image
    if (!productSearch.imageUrl) {
        [productSearch imageUrlForProduct];
    }
  
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    /*
	 To conform to the Human Interface Guidelines, selections should not be persistent --
	 deselect the row after it has been selected.
	 */
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //extract the selected product for details
    ProductSearch *productSearch = [self.productArray objectAtIndex:indexPath.row];
    
    ProductDetailsViewController *productDetailsVC = [[ProductDetailsViewController alloc] initWithNibName:kProductDetailsVCNib bundle:[NSBundle mainBundle]];
    productDetailsVC.productId = productSearch.productId;
    
    [self.navigationController pushViewController:productDetailsVC animated:YES];
}

#pragma mark - SearchBarDelegate
// return NO to not become first responder
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    return YES;
}

- (BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
	if ([searchBar.text isEqualToString:@" "] && [searchBar.text length]==1)
	{ 
		searchBar.text = @"";
		return NO;
	}
	return YES;
}

// called when keyboard search button pressed
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    TRC_DBG(@"Search with keyword %@",searchBar.text);
    [searchBar resignFirstResponder];
    
    searchBar.text = [ValidationHandler trimCurrentString:searchBar.text];
    if([ValidationHandler checkSpaceOrNewLineCharacter:searchBar.text])
    {
        [searchBar resignFirstResponder];
        if([searchBar.text length])
        {
            [self searchProduct];
        }
    }
}

/*!
 @function      searchProduct
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)searchProduct
{
    if (_productSearchReqResHandler){
        [_productSearchReqResHandler setDelegate:nil];
    }
    _productSearchReqResHandler = [[ProductSearchReqResHandler alloc]init];
    
    //get product list from the server
	if(self.productArray)
	{
        self.productArray = nil;
	}
    _productArray = [[NSMutableArray alloc] init];	
    [_productSearchReqResHandler setDelegate:self];
    [_productSearchReqResHandler productDataList:self.productArray searchAttribute:kProductNameXMLTag searchKeyword:self.searchBar.text];
}

#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) {
        TRC_DBG(@"fail to load data from URL");
    }
    else{
        TRC_DBG(@"Pass to load data from URL");
        TRC_DBG(@"ProSearchArray count in VC =%d",[self.productArray count]);
        [self.productTbl reloadData];
    }        
}


@end
