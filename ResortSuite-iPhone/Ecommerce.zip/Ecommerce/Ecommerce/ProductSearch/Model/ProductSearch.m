/* 
 File: ProductSearch.m
 Abstract: This class is responsible for product search related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 14/03/12
 Modified: 14/03/12
 Version: 1.0 
 */

#import "ProductSearch.h"

@implementation ProductSearch
@synthesize  productNumber = _productNumber;
@synthesize manufacture = _manufacture;
@synthesize  manufacturingDate =_manufacturingDate;
@synthesize  expiryDate = _expiryDate; 

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
