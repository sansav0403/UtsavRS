/* 
 File: ProductSearch.h
 Abstract: This class is responsible for product search related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 14/03/12
 Modified: 14/03/12
 Version: 1.0 
 */

#import <Foundation/Foundation.h>
#import "Product.h"

@interface ProductSearch : Product

@property(nonatomic, strong) NSString    *productNumber;
@property(nonatomic, strong) NSString    *manufacture;
@property(nonatomic, strong) NSString    *manufacturingDate;
@property(nonatomic, strong) NSString    *expiryDate; 

@end
