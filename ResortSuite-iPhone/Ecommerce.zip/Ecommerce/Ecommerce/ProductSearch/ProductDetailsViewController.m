/* 
 File: ProductDetailsViewController.m
 Abstract: This class is responsible for product details related operation.
 Author: Cybage Software Pvt. Ltd
 Created: 16/03/12
 Modified: 16/03/12
 Version: 1.0 
 */

#import "ProductDetailsViewController.h"
#import "ProductDetailImageCell.h"
#import "ProductDetailCell.h"
#import "ProductDetailDescriptionCell.h"
#import "ProductPriceInfoDetailsViewController.h"
#import "AvailabilityDetailsViewController.h"
#import "ProductSearchCommon.h"
#import "Common.h"


@implementation ProductDetailsViewController
@synthesize productId = _productId;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setTitle:kProductDetailsTitle];
    
    if (_productSearch) {
        _productSearch = nil;
    }
    _productSearch = [[ProductSearch alloc] init];

    //get the product list from the server
    _productSearchReqResHandler = [[ProductSearchReqResHandler alloc]init];
    [_productSearchReqResHandler setDelegate:self];
    [_productSearchReqResHandler productDetailsDataForProductId:self.productId productSearch:_productSearch];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_productSearchReqResHandler setDelegate:nil];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return kNoOfSection;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return kNoOfRows;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == kImageCell) {
        // image
        return kHeightOfImageCell;
    } else if (indexPath.row == kDescriptionCell) {
        // description 
        return KHeightOfDescriptionCell;
    } else {
        return kHeightOfOtherCell;
    }    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *imageIdentifier = kProductImageCell;
    static NSString *detailsIdentifier = kProductDetailCell;
    static NSString *detailDescriptionIdentifier = kProductDetailDescriptionCell;
    
    ProductDetailCell *cell = (ProductDetailCell*)[tableView dequeueReusableCellWithIdentifier:detailsIdentifier];
    if (cell == nil) {
        cell = [[ProductDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailsIdentifier];
    }
    [cell setAccessoryType:UITableViewCellAccessoryNone];

    // Configure the cell...
    NSString *labelKey = nil;
    NSString *labelValue = nil;
    
    switch (indexPath.row)
    {
        case 0://Image Cell
        {
            ProductDetailImageCell *cell = (ProductDetailImageCell*)[tableView dequeueReusableCellWithIdentifier:imageIdentifier];
            if (cell == nil) {
                cell = [[ProductDetailImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:imageIdentifier];
            }
            if (!_productSearch.image) {
                [_productSearch setDelegate:cell];
                [_productSearch startDownload];
            }
            [cell setProductImage:_productSearch];
            return cell;
        }
            break;
        case 1:
        {
            labelKey = kName;
            labelValue = _productSearch.name;
        }
            break;
        case 2:
        {
            labelKey = kModel;
            labelValue = _productSearch.model;
        }
            break;
        case 3:
        {
            labelKey = kManufacturingDate;
            labelValue = _productSearch.manufacturingDate;
        }
            break;
        case 4:
        {
            labelKey = kDimension;
            labelValue = _productSearch.dimension;
        }
            break;
        case 5://Description Cell
        {
             ProductDetailDescriptionCell *cell = (ProductDetailDescriptionCell*)[tableView dequeueReusableCellWithIdentifier:detailDescriptionIdentifier];
             if (cell == nil) {
             cell = [[ProductDetailDescriptionCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailDescriptionIdentifier];
             }
            //set product's description data
            labelKey = kDescription;
            labelValue = _productSearch.description;
            [cell setProductData:labelKey labelValue:labelValue];
            return cell;
        }
            break;
        case 6:
        {
            labelKey = kPriceInfoTitle;
            labelValue = nil;
            [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
        }
            break;
        case 7:
        {
            labelKey = kAvailabilityTitle;
            labelValue = nil;
            [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
        }
            break;    
        default:
            break;
    }
    [cell setProductData:labelKey labelValue:labelValue];
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row) {
        case 6:
        {
            ProductPriceInfoDetailsViewController *productPriceInfoDetailsVC = [[ProductPriceInfoDetailsViewController alloc] init];
            productPriceInfoDetailsVC.productId = self.productId;
            
            [self.navigationController pushViewController:productPriceInfoDetailsVC animated:YES];         
        }
            break;
        case 7:
        {
            AvailabilityDetailsViewController *availabilityDetailsVC = [[AvailabilityDetailsViewController alloc]init];
            availabilityDetailsVC.productsku = _productSearch.sku;
            availabilityDetailsVC.availability.name = _productSearch.name;
            availabilityDetailsVC.availability.image = _productSearch.image;
            availabilityDetailsVC.availability.actualPrice = _productSearch.actualPrice;
            availabilityDetailsVC.availability.offerPrice = _productSearch.offerPrice;
            
            [self.navigationController pushViewController:availabilityDetailsVC animated:YES];
        }
            break;    
        default:
            break;
    }
}

#pragma mark - Parse delegate 
/*!
 @function      parseComplete
 @abstract      response of data parsed
 @discussion    response of data parsed 
 @param         Error - nil if parsing success else NSError object 
 @result        void
 */
- (void)parseComplete:(NSError*)error
{
    if (error) {
        TRC_DBG(@"fail to load data from URL");
    }
    else{
        TRC_DBG(@"Pass to load data from URL");
        TRC_DBG(@"ProductSearch =%@",_productSearch);
        [self setTitle:_productSearch.name];
        [self.tableView reloadData];
    }        
}

@end
