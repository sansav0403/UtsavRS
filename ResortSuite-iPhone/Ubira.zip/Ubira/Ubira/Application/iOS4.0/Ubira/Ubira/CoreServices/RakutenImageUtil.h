//
//  RakutenImageHandler.h
//  RakutenLibrary
//
//  Created by [Cybage Team] on 29/08/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol RakutenImageUtilDelegate <NSObject>

- (void)didFinishImageProcessing:(UIImage*) image errorinfo:(NSError*) error;

@end
typedef enum
{
    kImageSourceCamera,
    kImageSourcePhotoLibrary,
    kImageSourcePhotoAlbum
} PickerImageSourceType;


/*!
 @class			RakutenImageUtil
 @abstract		This class provides utility functions of images.
 @discussion	This class is used to take picture from library, album and camera and will 
                scale that picture in size with proper ratio.
 */

@interface RakutenImageUtil : NSObject <UINavigationControllerDelegate,UIImagePickerControllerDelegate> {
    
    CGSize                              targetScaleSize;
    id<RakutenImageUtilDelegate>        _delegate;
}

@property (nonatomic, assign) id <RakutenImageUtilDelegate>  delegate;

- (BOOL)isCameraAvailable;
- (void)takePictureAndScale:(CGSize) scaleSize placeViewController:(UIViewController*) viewController imageSourceType:(PickerImageSourceType) sourceType;
- (void)takeScalePictureWithOverlayView:(CGSize) scaleSize placeViewController:(UIViewController*) viewController  cameraoverlayView:(UIView*) overlayView;
- (UIImage*)scaleImage:(UIImage*) imageSource scalingsize:(CGSize) scaleSize;
- (UIImage *)imageFromImage:(UIImage *)image inRect:(CGRect)rect;

@end
