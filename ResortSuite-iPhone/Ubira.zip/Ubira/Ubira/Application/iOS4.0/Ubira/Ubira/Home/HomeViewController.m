//
//  HomeViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "HomeViewController.h"
#import "StoreListViewController.h"
#import "UbiraAppDelegate.h"
#import "CoreDataApplicationStack.h"
#import "ImageDownloadQueue.h"
#import "OfferDetailsViewController.h"
#import "LocationManager.h"
#import "UserAnalytics.h"

@interface HomeViewController (PrivateMethods)
- (void)fetchNoticesOffers:(NSNotification*)aNotification;
@end

@implementation HomeViewController

@synthesize coverFlowHolderView;
@synthesize storeNameLbl,userNameLbl;
@synthesize offersForYouLbl,crunchBusterOfferLbl,noticesHeaderLbl,noticesLbl,noticesTextView,
            welcomeLbl;
@synthesize checkInBtn;
@synthesize noticeList = _noticeList;
@synthesize startDate = _startDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [coverFlowHolderView release];
    [coverFlowView release];
	[storeNameLbl release];
    [userNameLbl release];
	[offersForYouLbl release];
	[crunchBusterOfferLbl release];
	[noticesHeaderLbl release];
    [noticesLbl release];
    [checkInBtn release];
    [noticesTextView release];
    [welcomeLbl release];	
    
	[_noticeReqResHandler release]; 
	[_noticeList release];
    [_startDate release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
	// Starting the location monitoring
    [LocationManager sharedInstance];
	
    [[self.navigationController navigationBar] setTintColor:kSCNavigationBarTintColor];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
	[self setLocalizableText];
		
	// Listen the nofication when offer is selected from coverflow images. 

	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(detailsForSelectedOffer:) name:kOfferSelected object:nil];
    
    
    // Listen the nofication when region of checked in store is exited
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(regionMonitoringExited:) name:kRegionExitNotification object:nil];
	
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
	Store *sharedStore = [Store sharedStore];
	
	// If landing on this page after store is checkIn or newly added.
	if(sharedStore.storeId)
	{
		// Set up view 
		[self setUpViewFor:kCheckOutTag];		
	}
	else
	{
		// Set up view 
		[self setUpViewFor:kCheckInTag];
	}
    
    [self offersAndNotices];
    
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsHomeScreen startDate:self.startDate endDate:[NSDate date]];
}

- (void)viewDidUnload
{
	// RemoveObserver when page gets unload
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kOfferSelected object:nil]; 
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLocationServiceSuccess object:nil]; 
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kRegionExitNotification object:nil]; 
    
    [self setCoverFlowHolderView:nil];
    [self setStoreNameLbl:nil];
    [self setUserNameLbl:nil];
    [self setWelcomeLbl:nil];
    [self setOffersForYouLbl:nil];
    [self setCrunchBusterOfferLbl:nil];
    [self setNoticesHeaderLbl:nil];
    [self setNoticesLbl:nil];
    [self setNoticesTextView:nil];
    [self setCheckInBtn:nil];
    
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark 
#pragma mark Action Methods
/*!
 @method		checkInAction
 @abstract		redirect to StorList page
 @discussion	redirect to StorList page when tap checkIn button
*/
- (IBAction)checkInAction:(id)sender
{
	if ([sender tag] == kCheckOutTag)
	{
        // check out from store ( with stop region monitoring)
        [self checkOutFromStore];
	}
	else
	{
        StoreListViewController* storeListViewController = [[StoreListViewController alloc]init];
        [self.navigationController pushViewController:storeListViewController animated:YES];
        [storeListViewController release];
	}
}

/*!
 @function      regionMonitoringExited
 @abstract      delegate to cheking out form store while user moved to other location
 @discussion    delegate to cheking out form store while user moved to other location
 @param         aNotification - Notification object
 @result        void
 */
- (void)regionMonitoringExited:(NSNotification*)aNotification
{
    [self checkOutFromStore];
}

/*!
 @function      checkOutFormStore
 @abstract      checking out from store reset view 
 @discussion    checking out from store reset view 
 @param         none
 @result        void
 */
- (void)checkOutFromStore
{
    //Stop region monitoring for checkedin location(region)
    CLLocation *chedkedInLocation = [[LocationManager sharedInstance] currentLocation];
    
    CLLocationCoordinate2D coordinates = CLLocationCoordinate2DMake(chedkedInLocation.coordinate.latitude, chedkedInLocation.coordinate.longitude);
    
    CLRegion *checkedInRegion = [[CLRegion alloc] initCircularRegionWithCenter:coordinates radius:50 identifier:kCheckedInRegion];
    
    [[LocationManager sharedInstance] locationManagerStopMonitoringRegion:checkedInRegion];
     
    [checkedInRegion release];
    
    Store *sharedStore = [Store sharedStore];
    sharedStore.storeId = nil;
    
    [[NSNotificationCenter defaultCenter]postNotificationName:kCheckInCheckOutNotificationKey object:nil];
	
    // set up the view for CheckIn and get offers and notices
    [self setUpViewFor:kCheckInTag];
    [self offersAndNotices];
}

#pragma mark 
#pragma mark Other Methods

/*!
 @function      setLocalizableText
 @abstract      set localizable text 
 @discussion    set localizable text for UI
 @param         none
 @result        void
 */
- (void)setLocalizableText
{
	// set text for navigation title, buttons and textfield's placeholder text
    [self setTitle:kHomeTitle];
	[welcomeLbl setText:kWelcome];
	
	[self.offersForYouLbl setText:kOffersForYou];
	[self.crunchBusterOfferLbl setText:kCrunchBusterOffer];
	[self.noticesHeaderLbl setText:kNoticesHeaderText];
}

/*!
 @function      setUpViewFor
 @abstract      set up view for checkIn and CheckOut
 @discussion    set up view for checkIn and CheckOut
 @param         checkFlag - NSInteger to identified "1" as checkIn and "2" as checkOut
 @result        void
*/
- (void)setUpViewFor:(NSInteger)checkFlag
{
	if (checkFlag == kCheckInTag )
	{
		// show user name and welcome message
		userNameLbl.hidden = NO;
		welcomeLbl.hidden = NO; 
		
		// hide the store name which is checked in
		storeNameLbl.hidden = YES;
		[storeNameLbl setText:@""];
		
		// setCheckIn button title
		[checkInBtn setTitle:kCheckInButtonTitle forState:UIControlStateNormal];
		[checkInBtn setTag:kCheckInTag];
		
		// Display the user's name
		UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
		userNameLbl.text = userExtendedObj.name;
				
	}
	else
	{
		Store *sharedStore = [Store sharedStore];
		
		// hide user name and welcome message
		userNameLbl.hidden = YES;
		welcomeLbl.hidden = YES; 
		
		// show the store name which is checked in
		storeNameLbl.hidden = NO;
		[storeNameLbl setText:sharedStore.name];
		
		// setCheckIn button title
		[checkInBtn setTitle:[NSString stringWithFormat:@"%@ %@",kCheckOutButtonTitle,sharedStore.name] forState:UIControlStateNormal];
		[checkInBtn setTag:kCheckOutTag];		
	}

}

/*!
 @function      detailsForSelectedOffer
 @abstract      delegate to redirecing on OfferDetails Page
 @discussion    redirecing on OfferDetails Page when tapping any image
 @param         aNotification - Notification object
 @result        void
*/
- (void)detailsForSelectedOffer:(NSNotification*)aNotification
{
	NSDictionary *dictionaryObj = [aNotification userInfo]; 
	
	OfferDetailsViewController* offerDetailsObj = [[OfferDetailsViewController alloc] initWithNibName:@"OfferDetailsViewController" bundle:[NSBundle mainBundle] url:[dictionaryObj valueForKey:kSelectedOfferUrl]];
	[self.navigationController pushViewController:offerDetailsObj animated:YES];
	[offerDetailsObj release];
}

/*!
 @function      fetchNoticesOffers
 @abstract      This method will initialize notice request response handler
 @discussion    This method will ask notice request response handler to get the offers and notices
                from server
 @param         aNotification - Notification object
 @result        void
 */
//- (void)fetchNoticesOffers:(NSNotification*)aNotification
//{
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:kLocationServiceSuccess object:nil]; 
//    
//    NSError *error = [aNotification object];
//    if(error)
//    {
//        //Error to get the current location load the default offers and notices
//        TRC_DBG(@"Unable to get the location - get the offers only");
//    }
//    else
//    {
//        //Get the current user location load the location specific offers and notices
//        TRC_DBG(@"Current location is available get Notices and Offers");
//    }
//    
//	// Get offers and notices to display
//	[self offersAndNotices];
//}

/*!
 @function      offersAndNotices
 @abstract      getOffersAndNotices
 @discussion	getOffersAndNotices
 @param         none
 @result		void
*/
- (void)offersAndNotices
{
	//The offers for particuller storeId
	//User location is available get with lat lng based on the user location
	if (coverFlowView)
	{
		[coverFlowView removeFromSuperview];
        [coverFlowView release];
		coverFlowView = nil;
	}
	coverFlowView = [[AFOpenFlowView alloc] initWithFrame:self.coverFlowHolderView.bounds];
	[self.coverFlowHolderView addSubview:coverFlowView];

	//Get notices to be display 
	if (_noticeList)
	{
		[_noticeList release];
		_noticeList = nil;
	}
	_noticeList = [[NSMutableArray alloc] init];
	if (_noticeReqResHandler)
	{
		[_noticeReqResHandler release];
		_noticeReqResHandler =nil;
	}
	_noticeReqResHandler = [[NoticeReqResHandler alloc]init];
	_noticeReqResHandler.delegate = self;
	[_noticeReqResHandler noticeList:_noticeList];
    [_noticeList release];
}

#pragma mark - Parsing complete delegate
/*!
 @function		parseComplete
 @abstract		delegate on parse complete.
 @discussion	Take the action based on the parameter.
 @param			error - server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
    if(error)
    {
        TRC_ERR(@"%@",error)
		
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
		
		// Display the error message to user
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kUbiraTitle message:errorString delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
		[alert show];
		[alert release];
    }
    else
    {
		TRC_DBG(@"notice=============================================================")
		NSString *appendedDescription = nil;
		for(Notice *notice in _noticeList)
		{
			if (appendedDescription == nil)
			{
				appendedDescription = notice.description;
			}
			else
			{
				appendedDescription = [appendedDescription stringByAppendingFormat:@"\n %@",notice.description];	
			}
		}
		noticesTextView.text = nil;
		noticesTextView.text = appendedDescription;
    }
}

@end
