//
//  NoticeReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+HTML.h"
#import "RequestResponseBase.h"

/*!
    @class          NoticeReqResHandler
    @abstract       Handler the notice request response.
    @discussion     Create the required url request and respond to the caller.
 */
@interface NoticeReqResHandler : RequestResponseBase {

	NSArray *_noticeList;
}

@property (nonatomic,retain) NSArray    *noticeList;

- (void)noticeList:(NSArray*)noticesList;

@end
