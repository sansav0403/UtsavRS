//
//  StoreListViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Store.h"
#import "StoreReqResHandler.h"
#import "StoreCustomCell.h"

/*!
    @class			StoreListViewController
    @abstract		This class show the list of stores
    @discussion		This class show the list of stores for device's current location, if not
					avialable will display the default stores 
*/

@interface StoreListViewController : UIViewController <RequestResponseBaseDelegate,StoreCustomCellDelegate> 
{
	// IBOutlets
	IBOutlet UITableView				*storeListTblView;
	IBOutlet UIView						*activityIndicatorView;
	IBOutlet UIActivityIndicatorView	*spinner;
	
	// BOOL
	BOOL								ischeckInToStore;	
    // Others
	StoreReqResHandler					*_storeReqResHandler;	
	Store								*_store;
	
	NSArray								*_storeList;
	NSDate                              *_startDate;
}

@property (nonatomic, retain) IBOutlet UITableView				*storeListtblView;
@property (nonatomic, retain) IBOutlet UIView					*activityIndicatorView;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView	*spinner;
@property (nonatomic, retain) NSDate                            *startDate;
@property (nonatomic, retain) NSArray                           *storeList;
@property (nonatomic, retain) Store                             *store;

- (void)checkInActionDelegate:(Store *)aStore;
- (void)addStoreAction:(id)sender;
- (void)showActivityIndicator;
- (void)stopActivityIndicator;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage 
		  setDelegate:(id)currentDelegate 
	cancelButtonTitle:(NSString *)cancelButtonTitle
	 otherButtonTitle:(NSString *)otherButtonTitle;
//- (void)addRequireObservers;
//- (void)removeObservers;
- (void)fetchStoreList;
- (void)startMonitoringCurrentLoction;

@end
