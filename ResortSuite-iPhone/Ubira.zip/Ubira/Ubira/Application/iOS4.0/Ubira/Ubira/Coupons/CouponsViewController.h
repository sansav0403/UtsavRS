//
//  CouponsViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CouponReqResHandler.h"
#import "Store.h"

typedef enum
{
	kCouponFetchRequest,
	kCouponDeleteRequest
}CouponsRequestState;

/*!
 @class			CouponsViewController
 @abstract		This class hadles releated UI interaction functionality for coupons.
 @discussion	This class hadles releated UI interaction functionality for coupon details.
 */
@interface CouponsViewController : UIViewController<RequestResponseBaseDelegate> {
    CouponReqResHandler				*couponReqResHandler;
    NSArray							*couponsList;
	
	IBOutlet UITableView			*couponTbl;
	
	CouponsRequestState				couponsRequestState;
    NSDate                          *_startDate;
    
    UIActivityIndicatorView         *activityIndicator;
    IBOutlet UILabel                *NoCouponLbl;
    
    NSIndexPath                     *deleteCouponIndexPath;
    NSString                        *productid;
    Store                           *sharedStore; 
}
@property (nonatomic, retain) IBOutlet UITableView                  *couponTbl;
@property (nonatomic, retain) IBOutlet UILabel                      *NoCouponLbl;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView      *activityIndicator;
@property (nonatomic, retain) NSDate                                *startDate;
@property (nonatomic, retain) NSString                              *productid;

- (void)refreshData;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage 
		  setDelegate:(id)currentDelegate 
	cancelButtonTitle:(NSString *)cancelButtonTitle
	 otherButtonTitle:(NSString *)otherButtonTitle;

@end
