//
//  LoginViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ForgotPasswordViewController.h"
#import "RegisterViewController.h"
#import "LoginReqResHandler.h"
#import "UserExtended.h"

/*!
 @protocol      LoginViewControllerDelegate
 @abstract      delegate for login status
 @discussion    implement delegate for login status
*/
@protocol LoginViewControllerDelegate <NSObject>
- (void)loginStatusDelegate:(BOOL)aStatus;
@end

/*!
 @class         LoginViewController
 @abstract		This class hadles releated UI interaction functionality for login.
 @discussion	This class hadles all validations for email and password along with
				implementation of TextField and ReQuestResponseBase Delegate.
 */
@interface LoginViewController : UIViewController <UITextFieldDelegate, RequestResponseBaseDelegate>
{
	// IBOutlets
	IBOutlet UIImageView				*ubiraLogoImgView;
	IBOutlet UILabel					*rememberPasswordLbl;
	IBOutlet UILabel					*newUserLbl;
	IBOutlet UITextField				*emailTxtField;
    IBOutlet UITextField				*passwordTxtField;
	IBOutlet UIButton					*checkRememberPasswordBtn;
	IBOutlet UIButton					*loginBtn;
	IBOutlet UIButton					*forgotPasswordBtn;
	IBOutlet UIButton					*registerHereBtn;
	IBOutlet UIView						*activityIndicatorView; 
	IBOutlet UIActivityIndicatorView	*spinner;
	
	// BOOL
	BOOL								rememberPassword;
	
	// Delegates 
	id <LoginViewControllerDelegate>	_delegate;
	
	// ViewControllers
    ForgotPasswordViewController		*forgotPasswordViewController;
    RegisterViewController				*registerViewController;
	
	// Others
    NSDate                              *_startDate;
	LoginReqResHandler					*loginReqResHandler;
	UserExtended						*_userExtended;
    CGRect                              viewFrame;
}

@property (nonatomic,assign) id <LoginViewControllerDelegate>   delegate;
@property (nonatomic, retain) IBOutlet UIImageView				*ubiraLogoImgView;
@property (nonatomic, retain) IBOutlet UILabel					*rememberPasswordLbl;
@property (nonatomic, retain) IBOutlet UILabel					*newUserLbl;
@property (nonatomic, retain) IBOutlet UITextField				*emailTxtField;
@property (nonatomic, retain) IBOutlet UITextField				*passwordTxtField;
@property (nonatomic, retain) IBOutlet UIButton					*checkRememberPasswordBtn;
@property (nonatomic, retain) IBOutlet UIButton					*loginBtn;
@property (nonatomic, retain) IBOutlet UIButton					*forgotPasswordBtn;
@property (nonatomic, retain) IBOutlet UIButton					*registerHereBtn;
@property (nonatomic, retain) IBOutlet UIView					*activityIndicatorView; 
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView	*spinner;
@property (nonatomic, retain) NSDate                            *startDate;

- (IBAction)backgroundTouched:(id)sender;
- (IBAction)loginAction:(id)sender;
- (IBAction)forgotPasswordAction:(id)sender;
- (IBAction)registerNewUserAction:(id)sender;
- (IBAction)rememberPasswordAction:(id)sender;

- (void)setLocalizableText;
- (void)animateView:(NSNotification*)aNotification keyboardWillShow:(BOOL)keyboardWillShow;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;
- (void)stopActivityIndicator;

- (BOOL)autoLogin;
- (BOOL)validateEmailAndPassword;

@end