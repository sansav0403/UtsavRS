//
//  OfferDetailsViewController.m
//  Ubira
//
//  Created by [Cybage Team]  on 23/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "OfferDetailsViewController.h"
#import "UserAnalytics.h"

@implementation OfferDetailsViewController
@synthesize offerUrl = _offerUrl;
@synthesize webView;
@synthesize startDate = _startDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil url:(NSString *)offerUrl
{
	self = [super init];
	if(self != nil)
	{
		self.offerUrl = offerUrl;
	}
	return self;
}

- (void)viewDidLoad 
{
    [super viewDidLoad];
	
	// Set navigation title
	[self setTitle:kUbiraTitle];
	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
    
	//URL object with urlstring
	NSURL *url = [NSURL URLWithString:self.offerUrl];
	
	//URL Requst Object
	NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
	
	//Load the request in the UIWebView.
	[webView loadRequest:requestObj];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsOfferDetailsScreen startDate:self.startDate endDate:[NSDate date]];
    
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)didReceiveMemoryWarning 
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];    
}

- (void)viewDidUnload 
{
    [self setWebView:nil];
    [super viewDidUnload];
}

- (void)dealloc {
    [webView release];
    [_offerUrl release];
    [_startDate release];
    [super dealloc];
}


@end
