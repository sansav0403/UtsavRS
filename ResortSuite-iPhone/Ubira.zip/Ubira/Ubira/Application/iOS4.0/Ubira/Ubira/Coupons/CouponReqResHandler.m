//
//  CouponReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "CouponReqResHandler.h"
#import "UbiraAppDelegate.h"

@interface CouponReqResHandler ()
- (void)parseCouponsList:(NSData *)data;
- (void)parseCouponDetails:(NSData*)data;
- (void)parseCouponDelete:(NSData*)data;
- (void)parseCouponCheck:(NSData*)data;
- (void)parseCouponAccept:(NSData*)data;
@end

@implementation CouponReqResHandler

@synthesize cupReqState = _cupReqState;
@synthesize couponsList = _couponsList;
@synthesize couponCount = _couponCount;

/*!
 @function      coupons
 @abstract      get all coupons of current user.
 @discussion    get all the coupons for the user stored at the server.
 @param         coupons - result will be return in this parameter.
 */
- (void)coupons:(NSArray *)coupons productId:(NSString*)productid storeId:(NSString*)storeId 
{
    TRC_ENTRY
    self.couponsList = coupons;
	self.cupReqState = kCUPReqGetCoupon;
    
    //user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
    
    NSString *parameterString = [NSString stringWithFormat:@"userid=%@",userId];
    
    if (productid)
    {
        parameterString = [parameterString stringByAppendingFormat:@"&productid=%@",productid];
    }
    
    if (storeId)
    {
        parameterString = [parameterString stringByAppendingFormat:@"&storeid=%@",storeId];
    }
	
    // generate runtime urlstring
	NSString* queryString = [NSString stringWithFormat:@"%@/coupon/get/?%@"
							 ,kUbiraServerUrl
							 ,parameterString];
	TRC_DBG(@"QueryStr= %@",queryString);
	NSURL* url = [NSURL URLWithString:queryString];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kGet];			
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      deleteCoupon
 @abstract      delete the selected coupon.
 @discussion    delete the user coupon from the server.
 @param         couponId - couponId which needs to be delete.
 */
- (void)deleteCoupon:(NSString*)couponId
{
    TRC_ENTRY
	self.cupReqState = kCUPReqDeleteCoupon;
	
	//user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
	NSString* postData = [NSString stringWithFormat:@"userid=%@&couponid=%@"
						  ,userId
						  ,couponId];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];	
	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/coupon/delete",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      couponDetails
 @abstract      get the detailed information of the coupon.
 @discussion    get the detailed information of the coupon.
 @param         productId - productId for selected product.
 @param         storeId - merchantId for the selected store.
 @param         Coupon - result will be return in the parameter.
 */
- (void)couponDetails:(NSString*)productId storeId:(NSString*)storeId coupon:(Coupon*)aCoupon
{
    TRC_ENTRY
	self.cupReqState = kCUPReqCouponDetails;
	coupon = aCoupon;
	
	//user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
    storeId = [storeId stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
	NSString* queryString = [NSString stringWithFormat:@"%@/deal/checker/?userid=%@&productid=%@&storeid=%@"
							 ,kUbiraServerUrl
							 ,userId
							 ,productId
							 ,storeId];
    
    TRC_DBG(@"query string =%@",queryString);
	NSURL* url = [NSURL URLWithString:queryString];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kGet];			
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      couponCheck
 @abstract      get the detailed information of the coupon.
 @discussion    get the detailed information of the coupon.
 @param         productId - productId for selected product.
 @param         storeId - storeid for the selected store.
 @param         compititorPrice - price of compititors
 */
- (void)couponCheck:(NSString*)productId storeId:(NSString*)storeId competitorPrice:(NSString*)competitorPrice  resultString:(NSString*)resultString;
{
    TRC_ENTRY
	self.cupReqState = kCupReqCouponCheck;
    self.couponCount = resultString;
    
    storeId = [storeId stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    //user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
	NSString* postData = [NSString stringWithFormat:@"userid=%@&productid=%@&storeid=%@&competitor_price=%@"
						  ,userId
						  ,productId
                          ,storeId
                          ,competitorPrice];
    
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];	
	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/coupon/check",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      couponAccept
 @abstract      check if coupon accepted or not 
 @discussion    check if coupon accepted or not
 @param         storeId - storeid for the selected store.
 @param         compititorPrice - price of compititors
 */
- (void)couponAccept:(NSString*)productId storeId:(NSString*)storeId competitorPrice:(NSString*)competitorPrice  resultString:(NSString*)resultString
{
    TRC_ENTRY
	self.cupReqState = kCupReqCouponAccept;
    self.couponCount = resultString;
    
    storeId = [storeId stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    //user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
	NSString* postData = [NSString stringWithFormat:@"userid=%@&productid=%@&storeid=%@&competitor_price=%@"
						  ,userId
						  ,productId
                          ,storeId
                          ,competitorPrice];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];	
	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/coupon/accept",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      handleReceivedData
 @abstract      decides the action based on the request.
 @discussion    decides the action based on the request.
 @param         data - server response.
 */
- (void)handleReceivedData:(NSData*)data
{	
    TRC_ENTRY
    
    if (![self checkForErrors:data]) {
        return;
    }
    
	switch (self.cupReqState) {
			
		case kCUPReqGetCoupon:
		{
			//Coupons Parsing
            [self parseCouponsList:data];
		}break;
		case kCUPReqCouponDetails:
		{
			//Coupon details Parsing
            [self parseCouponDetails:data];
            
		}break;
		case kCUPReqDeleteCoupon:
		{
			//Delete Coupon Parsing
            [self parseCouponDelete:data];
            
		}break;
        case kCupReqCouponCheck:
        {
            //Check coupon exist for merchant
            [self parseCouponCheck:data];
        }break;
        case kCupReqCouponAccept:
        {
            //Check coupon exist for merchant
            [self parseCouponAccept:data];
        }break;
		default:
			break;
	}
    TRC_EXIT
}

- (void)dealloc
{	
    _delegate =  nil;
	[_couponsList release];
    if(_couponCount)
    {
        [_couponCount release];
        _couponCount = nil;
    }
	[super dealloc];
}

#pragma mark -
#pragma mark Private methods

/*!
 @function      parseCouponsList
 @abstract      parse the coupon list.
 @discussion    parse all the coupon object and fill the list.
 @param         data - server response.
 */
- (void)parseCouponsList:(NSData *)data
{
    TRC_ENTRY
    //Get the json key value dictionary for the data
    NSString *resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    
    NSDictionary *resultDictionary = [resultString JSONValue];
    [resultString release];
    
    NSError *error = nil;
    
    @try {
        NSArray *resultList = [resultDictionary valueForKey:kCoupon];
        
        //Create the all available coupon models 
        for(NSDictionary *couponDict in resultList)
        {        
            Coupon *coupons = [[Coupon alloc] init];
            coupons.imageUrl = [couponDict valueForKey:kCouponImageUrl];
            
            coupons.code = [couponDict valueForKey:kCouponCode];
            TRC_DBG(@"couponcode = %@", coupons.code)
            
            NSString *creationDate = [couponDict valueForKey:kCreateDate];
            NSDateFormatter *createDateFormatter = [[NSDateFormatter alloc] init];
            [createDateFormatter setDateFormat:kDateFormatRevised];
            [coupons setCreateDate:[createDateFormatter dateFromString:creationDate]];
            TRC_DBG(@"create_date -%@-",  coupons.createDate);
            TRC_DBG(@"create_date -%@-", [createDateFormatter  stringFromDate:coupons.createDate]);
            
            [createDateFormatter release];
            
            coupons.description = [couponDict valueForKey:kDescription];
            TRC_DBG(@"description =%@", coupons.description);
            
            NSString *expireDate = [couponDict valueForKey:kExpirationDate];
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            
            [dateFormatter setDateFormat:kDateFormatRevised];
            [coupons setExpireDate:[dateFormatter dateFromString:expireDate]];
            TRC_DBG(@"expiration_date -%@-", coupons.expireDate);
            TRC_DBG(@"expiration_date -%@-", [dateFormatter  stringFromDate:coupons.expireDate]);
            [dateFormatter release];
            
            coupons.couponId = [couponDict valueForKey:kId];
            TRC_DBG(@"couponId =%@", coupons.couponId);
            
            coupons.active = [[couponDict valueForKey:kIsActive] intValue];
            TRC_DBG(@"active =%d", coupons.active);
            
            coupons.storeId = [couponDict valueForKey:kStoreId];
            TRC_DBG(@"storeId =%@", coupons.storeId);
            
            coupons.productId = [couponDict valueForKey:kProductId];
            TRC_DBG(@"productid =%@", coupons.productId);
            
            coupons.userId = [couponDict valueForKey:kUserId];
            TRC_DBG(@"userid =%@", coupons.userId);
            
            [(NSMutableArray *)self.couponsList addObject:coupons];
            [coupons release];
        }
    }
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        self.couponsList = nil;
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kInvalidDataErr userInfo:userInfo];
        [userInfo release]; 
    }
    
    //Update the caller about the result
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
    TRC_EXIT
}

/*!
 @function      parseCouponDetails
 @abstract      parse the coupon detailed information.
 @discussion    parse coupon details.
 @param         data - server response.
 */
- (void)parseCouponDetails:(NSData*)data
{
    TRC_ENTRY
    //Get the json key value dictionary for the data
    NSString *resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    NSDictionary *resultDictionary = [resultString JSONValue];    
    [resultString release];
   
    NSError *error = nil;
    
    @try {
        NSArray *resultList = [resultDictionary valueForKey:kDeals];
        
        if (![self isValid:resultList for:kNSArray]) {
            return;
        }
        
        //Create the all available coupon models 
        for(NSDictionary *couponDict in resultList)
        {
            coupon.imageUrl = [couponDict valueForKey:kCouponImageUrl];
            
            coupon.code = [couponDict valueForKey:kCouponCode];
            TRC_DBG(@"couponcode = %@", coupon.code)
            
            NSString* expiryDateString	=	[couponDict valueForKey:kCreateDate];		
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];		
            [dateFormatter setDateFormat:kDateFormat];		
            coupon.createDate = [dateFormatter dateFromString:expiryDateString];
            TRC_DBG(@" create_date : %@",[dateFormatter stringFromDate:coupon.createDate])
            
            coupon.description = [couponDict valueForKey:kDescription];
            TRC_DBG(@"description =%@", coupon.description);
            
            expiryDateString	=	[couponDict valueForKey:kExpirationDate];		
            coupon.expireDate = [dateFormatter dateFromString:expiryDateString];
            TRC_DBG(@" expiration_date : %@",[dateFormatter stringFromDate:coupon.expireDate])
            [dateFormatter release];
            
            coupon.couponId = [couponDict valueForKey:kId];
            TRC_DBG(@"couponId =%@", coupon.couponId);
            
            coupon.active = [[couponDict valueForKey:kIsActive] intValue];
            TRC_DBG(@"active =%d", coupon.active);
            
            coupon.storeId = [couponDict valueForKey:kStoreId];
            TRC_DBG(@"storeId =%@", coupon.storeId);
            
            coupon.productId = [couponDict valueForKey:kProductId];
            TRC_DBG(@"productid =%@", coupon.productId);
            
            coupon.userId = [couponDict valueForKey:kUserId];
            TRC_DBG(@"userid =%@", coupon.userId);
        }
    }
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        coupon = nil;
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kInvalidDataErr userInfo:userInfo];
        [userInfo release]; 
    }
    
    //Update the caller about the result
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
    TRC_EXIT
}

/*!
 @function      parseCouponDelete
 @abstract      parse the coupon delete information.
 @discussion    parse coupon delete information success/failure.
 @param         data - server response.
 */
- (void)parseCouponDelete:(NSData*)data
{
    TRC_ENTRY
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:nil];
    }
    TRC_EXIT
}

/*!
 @function      parseCouponCheck
 @abstract      parse the coupon check information.
 @discussion    parse coupon check.
 @param         data - server response.
 */
- (void)parseCouponCheck:(NSData*)data
{
    TRC_ENTRY
    [self parseCouponCheckAccept:data cupReqstatus:kCupReqCouponCheck];
    TRC_EXIT
}

/*!
 @function      parseCouponAccept
 @abstract      parse the coupon accept information.
 @discussion    parse coupon accept.
 @param         data - server response.
 */
- (void)parseCouponAccept:(NSData*)data
{
    TRC_ENTRY
    [self parseCouponCheckAccept:data cupReqstatus:kCupReqCouponAccept];
    TRC_EXIT
}

/*!
 @function      parseCouponCheckAccept
 @abstract      parse the coupon accept information.
 @discussion    parse coupon accept.
 @param         data - server response.
 @param         cupReqstatus - server response  
 */
- (void)parseCouponCheckAccept:(NSData*)data cupReqstatus:(NSInteger)cupReqstatus
{
    TRC_ENTRY
    //Get the json key value dictionary for the data
    NSString *resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    NSDictionary *resultDictionary = [resultString JSONValue];    
    [resultString release];
    
    NSError *error = nil;
    
    int resultValue;
    @try {
        NSNumber *num;
        switch (cupReqstatus) {
            case kCupReqCouponCheck:
            {
                num = [resultDictionary objectForKey:kCoupons];
            }
                break;
            case kCupReqCouponAccept:
                num = [resultDictionary objectForKey:kAccepted];
                break;
            default:
                break;
        }
        resultValue = [num intValue];
        [(NSMutableString*)_couponCount setString:[NSString stringWithFormat:@"%d",resultValue]];
    }
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        coupon = nil;
        self.couponCount = nil;
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kInvalidDataErr userInfo:userInfo];
        [userInfo release]; 
    }
    
    //Update the caller about the result
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
    TRC_EXIT
}

@end