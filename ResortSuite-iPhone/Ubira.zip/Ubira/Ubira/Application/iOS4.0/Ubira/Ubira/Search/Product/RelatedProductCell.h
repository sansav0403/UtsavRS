//
//  RelatedProductCell.h
//  Ubira
//
//  Created by [Cybage Team] on 30/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Product.h"

@protocol RelatedProdcutCellDelegate <NSObject>

-(void) relatedProdcutTapedDelegate :(int)currentIndex;

@end

/*!
    @class          RelatedProductCell
    @abstract       create the related product cell.
    @discussion     create the custom cell for all the related product which.
 */
@interface RelatedProductCell : UITableViewCell <ImageDownloadDelegate,UIGestureRecognizerDelegate>{
    UIButton                        *nextButton;
    UIButton                        *previousButton;
    UILabel                         *productName;
    UIImageView                     *imageView;
    NSArray                         *_relatedProducts;
    UITapGestureRecognizer          *_tapRecognizer;
    int                             currentRelatedProduct;
    id <RelatedProdcutCellDelegate> _delegate;
}

@property(nonatomic, retain) NSArray                 *relatedProducts;
@property(nonatomic, retain) UITapGestureRecognizer  *tapRecognizer;
@property(nonatomic, assign) id <RelatedProdcutCellDelegate> delegate;

- (void)setRelatedProductsData;

@end
