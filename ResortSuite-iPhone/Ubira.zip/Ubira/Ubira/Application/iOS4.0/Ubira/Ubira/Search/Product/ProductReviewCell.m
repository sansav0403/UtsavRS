//
//  ProductReviewCell.m
//  Ubira
//
//  Created by [Cybage Team] on 30/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProductReviewCell.h"
#import "Review.h"

@implementation ProductReviewCell
@synthesize expand;
@synthesize delegate = _delegate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;

        postLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [postLabel setBackgroundColor:[UIColor clearColor]];
        [postLabel setFont:[UIFont boldSystemFontOfSize:13]];
        [postLabel setTextColor:[UIColor redColor]];
        [postLabel setText:kPosted];
        [self.contentView addSubview:postLabel];

        ratingLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [ratingLabel setBackgroundColor:[UIColor clearColor]];
        [ratingLabel setFont:[UIFont boldSystemFontOfSize:13]];
        [ratingLabel setTextColor:[UIColor redColor]];
        [ratingLabel setText:kRating];
        [self.contentView addSubview:ratingLabel];

        
        postDateLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [postDateLabel setBackgroundColor:[UIColor clearColor]];
        [postDateLabel setFont:[UIFont systemFontOfSize:13]];
        [self.contentView addSubview:postDateLabel];
        
        /*productDescriptionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [productDescriptionLabel setBackgroundColor:[UIColor clearColor]];
        [productDescriptionLabel setLineBreakMode:UILineBreakModeWordWrap];
        [productDescriptionLabel setFont:[UIFont systemFontOfSize:13]];
        [productDescriptionLabel setNumberOfLines:0];
        [productDescriptionLabel sizeToFit];
        [productDescriptionLabel setTextAlignment:UITextAlignmentLeft];
        [self.contentView addSubview:productDescriptionLabel];*/
        
        productDescriptionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [productDescriptionLabel setBackgroundColor:[UIColor clearColor]];
        //[productDescriptionLabel setLineBreakMode:UILineBreakModeWordWrap];
        [productDescriptionLabel setFont:[UIFont systemFontOfSize:13]];
        [productDescriptionLabel setTextAlignment:UITextAlignmentLeft];
        [self.contentView addSubview:productDescriptionLabel];
        
        ratingView = [[RatingView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:ratingView];
        
        //Add "More" button
        moreButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [moreButton setTitle:kMoreButtonTitle forState:UIControlStateNormal];
        [moreButton setBackgroundImage:[UIImage imageNamed:kMoreBtnImg] forState:UIControlStateNormal];
        [moreButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [moreButton.titleLabel setFont:[UIFont fontWithName:@"Helvetica" size:8]];
        [moreButton addTarget:self action:@selector(moreAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:moreButton];
        expand = NO;
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        //set frame for the title
        frame = CGRectMake(5, 5, 70, 20);
        [postLabel setFrame:frame];
        
        frame = CGRectMake(5, postLabel.frame.size.height + 5, 70, 20);
        [ratingLabel setFrame:frame];
        
        frame = CGRectMake(postLabel.frame.size.width, 5, 200, 20);
        [postDateLabel setFrame:frame];
        
        frame = CGRectMake(ratingLabel.frame.size.width, postLabel.frame.size.height + 5, 70, 16);
        [ratingView setFrame:frame];
        
        if(expand)
        {
            reviewDescription = [reviewDescription stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            frame = CGRectMake(5, ratingView.frame.origin.y+ratingView.frame.size.height + 5, 300, [self calculateHeightForCell:reviewDescription]);
            [productDescriptionLabel setFrame:frame];
            [productDescriptionLabel setLineBreakMode:UILineBreakModeWordWrap];
            [productDescriptionLabel setNumberOfLines:0];
            [productDescriptionLabel sizeToFit];
        }
        else
        {
            frame = CGRectMake(5, ratingView.frame.origin.y+ratingView.frame.size.height + 5, 286, 20);
            [productDescriptionLabel setFrame:frame];
            [productDescriptionLabel setLineBreakMode:UILineBreakModeTailTruncation];
            
            frame = CGRectMake(285, ratingView.frame.origin.y+ratingView.frame.size.height + 10, 35, 11);
            [moreButton setFrame:frame];
        }
        
        TRC_DBG(@"lableHt =%f",[self calculateHeightForCell:reviewDescription]);
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      moreAction
 @abstract      more button action.
 @discussion    more button action expand cell for display full description.
 @param         id.
 @result        void
 */
- (IBAction)moreAction:(id)sender
{
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:[sender tag] inSection:0];

    //inf check in store then ask for update
    if([self.delegate respondsToSelector:@selector(moreActionDelegate:)])
    {
        [self.delegate moreActionDelegate:indexPath];
    }  
}

/*!
 @function      setReviewDetails
 @abstract      set the review of product.
 @discussion    set the review of product with ratings and review post date.
 @param         Review
 @result        void
 */
- (void)setReviewDetails:(Review*)review indexPath:(NSIndexPath *)indexPath
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat: kDateFormatRevised]; 
    NSString *dateString = [formatter stringFromDate:review.createDate];
    [formatter release];
    
    [postDateLabel setText:dateString];
    
    reviewDescription = review.description;
    [productDescriptionLabel setText:review.description];
    
    [ratingView setRating:review.rating];
    
    [moreButton setTag:indexPath.row];
    
    moreButton.hidden = ([self calculateHeightForCell:review.description]<=kLabelHeightForOneLine || expand)?YES:NO;    
}

/*!
 @function      calculateHeightForCell
 @abstract      This function will calculate the hight for the lable.
 @discussion    This function will calculate the hight for the lable based on the description
                for the product and break the lable accordingly.
 @param         NSString - description of which details need to set to cell.
 @result        void
 */
- (float)calculateHeightForCell:(NSString *)description
{
    CGFloat maxWidth = [UIScreen mainScreen].bounds.size.width - 170;
	CGFloat maxHeight = 9999;
    CGSize maximumLabelSize = CGSizeMake(maxWidth,maxHeight);
	
	CGSize expectedLabelSize = [description sizeWithFont:[UIFont systemFontOfSize:13] 
                                              constrainedToSize:maximumLabelSize 
                                                  lineBreakMode:UILineBreakModeWordWrap];
    
     return expectedLabelSize.height; 
}

- (void)dealloc
{
     _delegate = nil;
    [postLabel release];
    [ratingLabel release];
    [postDateLabel release];
    [productDescriptionLabel release];
    [ratingView release];
    [super dealloc];
}

@end
