//
//  ProductSearchReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "ProductSearchReqResHandler.h"
#import "ProductDetail.h"
#import "LocationManager.h"
#import "CoreDataApplicationStack.h"
#import "ProductData.h"
#import "ImageDownloadQueue.h"


#define kProductData                    @"ProductData"
#define kProductSearch                  @"ProductSearch"
#define kIndexKey                       @"rowIndex"
#define kCacheName                      @"Ubira"


static int rowIndex = 0;

@implementation ProductSearchReqResHandler

@synthesize searchString;
@synthesize pageSize;
@synthesize currentPage;
@synthesize delegateForNSFetchResultsController;
@synthesize fetchedResultsController;
@synthesize requestInProgress;

- (id)init
{
    if ((self = [super init])) {
        requestInProgress = NO;
       
    }
    
    return self;
}

#pragma mark request function

/*!
 @function		searchProduct
 @abstract		make product search request.
 @discussion	make product search request.
 @param			searchString - product search string
 @param			productList	 - on success it will return product list.
 @result		void
 */
- (void)searchForProduct:(BOOL)newSearch
{
    if( requestInProgress == NO )
    {
        NSString *searchKeywords = [searchString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

        NSString* queryString = [NSString stringWithFormat:@"%@/search/?q=%@&psize=%@&page=%@&lat=%f&long=%f"
                                 ,kUbiraServerUrl
                                 ,searchKeywords
                                 ,pageSize
                                 ,currentPage
                                 ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
                                 ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
                                 ];
        TRC_DBG(@"query string %@",queryString);
        [self fetchProductSearch:newSearch];
        if (searchData) {
            
            [searchData setSearchString:searchString];
            [searchData setPageSize:pageSize];
            [searchData setCurrentPage:currentPage];
            
            NSURL* url = [NSURL URLWithString:queryString];
            NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
            [theRequest setHTTPMethod:kGet];	
            
            requestInProgress = YES;
            
            [webService makeRequest:theRequest];
        }        
    }
}

#pragma mark parse function

/*!
 @function		handleReceivedData
 @abstract		parse the product detail information.
 @discussion	parse the product detail information.
 @param			data - response data
 @result		bool
 */
- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
	TRC_ENTRY
	
    NSString* responseString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
	
    NSString *decodedResponse = [responseString stringByDecodingXMLEntities];
    TRC_DBG(@"%@",decodedResponse)
	
	NSDictionary *resultDictionary = [decodedResponse JSONValue];
	[responseString release];
    
	NSError *error = nil;
    @try {
        NSArray *productDetail = [resultDictionary valueForKey:kProduct];
        for(NSDictionary *productDict in productDetail)
        {   
            TRC_DBG(@"--------------------Product Details------------------------")
            
            ProductData * productData = (ProductData *) [NSEntityDescription insertNewObjectForEntityForName:kProductData inManagedObjectContext:[CoreDataApplicationStack globalStack].addingManagedObjectContext];
            
            NSString* dateString	=	[productDict valueForKey:kCreateDate];		
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];		
            [dateFormatter setDateFormat:kDateFormat];		
            [productData setCreationDate:[dateFormatter dateFromString:dateString]];
            TRC_DBG(@" create_date : %@",[dateFormatter stringFromDate:productData.creationDate])
            [dateFormatter release];
            
            NSString * productDesc = [productDict valueForKey:kDescription];
            productDesc = [productDesc stringByDecodingXMLEntities];
            [productData setProductDescription:productDesc];
            TRC_DBG(@"Product Description : %@",productData.productDescription )
            
            [productData setProductId:[productDict valueForKey:kId]];
            TRC_DBG(@"Product Id : %@",productData.productId )
            
            [productData setImageUrl:[productDict valueForKey:kImageUrl]];
            TRC_DBG(@"Product image url : %@",productData.imageUrl )
        
            [productData setProductName:[productDict valueForKey:kName]];
            TRC_DBG(@"Product Name : %@",productData.productName )
            
            NSNumber * rating = [NSNumber numberWithFloat:[[productDict valueForKey:kRatings] floatValue]];
            [productData setRating: rating];
            TRC_DBG(@"Product Rating : %d",rating)
            
            NSNumber * reviews = [NSNumber numberWithFloat:[[productDict valueForKey:kReviews] intValue]];
            [productData setReviews:reviews];
            TRC_DBG(@"Product Reviews : %d",reviews)
            
            //Add relation
            [searchData addProductSearchToProductDataObject:productData];
        }
        
        //commit data to store
        [self saveDataToStore];
    }
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        //self.productReviewList = nil;
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kInvalidDataErr userInfo:userInfo];
        [userInfo release]; 
    }

    //Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:error];
	}  
    
    //set the flag
    requestInProgress = NO;
    
	TRC_EXIT
}

/*!
 @function		prepareForNewSearch
 @abstract		function to prepare for a new search.
 @discussion	This function will reset row index and cancell all operations that are pending.
 @param			none
 @result		void
 */
- (void)prepareForNewSearch
{
    rowIndex = 0;
    [[ImageDownloadQueue sharedQueue] cancelAllOperations];    
}

#pragma mark core data helper methods

/*!
 @function		fetchProductSearch
 @abstract		this function will return an ProductSearch managed object .
 @discussion	Returns the ProductSearch managed object. Creates and configures the 
                managed object if necessary.
 @param			bool - newsearch
 @result		void
 */
- (void)fetchProductSearch:(BOOL)newSearch
{
    NSManagedObjectContext *managedContext = [CoreDataApplicationStack globalStack].addingManagedObjectContext;
	
    if( !fetchRequestForProductSearch )
	{
		fetchRequestForProductSearch = [[NSFetchRequest alloc] init];
		[fetchRequestForProductSearch setEntity:[NSEntityDescription entityForName:         kProductSearch 
                                                            inManagedObjectContext:managedContext]];
	}
	 
	NSError *err = nil;
	NSArray *result = [managedContext executeFetchRequest:fetchRequestForProductSearch error:&err];
	
	if( err )
	{
		TRC_ERR(@"Error: FetchProductSearch %@", [err localizedDescription] );
	}
	else
    {
        @try {
            //we have some data already in database
            if( [result count] > 0)
            {
                //get existing data into ivar
                searchData = [result objectAtIndex:0];
                if (newSearch)
                {
                    //We are in a new search:flush the data and insert an entity for new search 
                    [managedContext deleteObject:searchData];
                    [self saveDataToStore]; 
                    searchData = (ProductSearch *)[NSEntityDescription insertNewObjectForEntityForName:kProductSearch inManagedObjectContext:managedContext];
                }
            }
            else 
            {
                //We don't have any data, insert a new entity and return 
                searchData = (ProductSearch *)[NSEntityDescription insertNewObjectForEntityForName:kProductSearch inManagedObjectContext:managedContext];		
            }
        }
        @catch (NSException *exception) 
        {
            TRC_EXCEPTION(exception);
            searchData = nil;
           TRC_ERR(@"Error: FetchProductSearch %@", [exception reason]);
        }
    }
}

/*!
 @function		fetchedResultsController
 @abstract		Returns the fetched results controller. Creates and configures the
                controller if necessary.
 @discussion	Returns the fetched results controller. Creates and configures the
                controller if necessary.
 @param			bool - newsearch
 @result		void
 */
- (NSFetchedResultsController *)fetchedResultsController {
    
    //return cache object if exists
    if (fetchedResultsController != nil) {
        return fetchedResultsController;
    }
    
    //get the context for reading
    NSManagedObjectContext *managedObjectContext = [CoreDataApplicationStack globalStack].managedObjectContext;
	
    // Create and configure a fetch request with the ProductData entity.
	NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
	NSEntityDescription *entity = [NSEntityDescription entityForName:kProductData inManagedObjectContext:managedObjectContext];
	[fetchRequest setEntity:entity];
    [fetchRequest setFetchBatchSize:20];
	
    //create a sort descriptor with rowIndex as key
	NSSortDescriptor *rowDescriptor = [[NSSortDescriptor alloc] initWithKey:kIndexKey ascending:YES];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:rowDescriptor, nil];
	[fetchRequest setSortDescriptors:sortDescriptors];
    
	// Create and initialize the fetch results controller.
	NSFetchedResultsController *aFetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:managedObjectContext sectionNameKeyPath:nil cacheName:kCacheName];
	fetchedResultsController = aFetchedResultsController;
	fetchedResultsController.delegate = delegateForNSFetchResultsController;
    	
    
    NSError * err = nil;
    [[self fetchedResultsController] performFetch:&err];
    
    // Memory management.
	[fetchRequest release];
    [rowDescriptor release];
	[sortDescriptors release];
	
	//return fetchedResultsController;
    return fetchedResultsController;
}  

/*!
 @function		saveDataToStore
 @abstract		save the data to store and prepare for Context save notifications.
 @discussion	save the data to store and prepare for Context save notifications.
 @param			none
 @result		void
 */
- (void)saveDataToStore
{
    //get the context where we are adding data
    NSManagedObjectContext * managedObjectContext = [CoreDataApplicationStack globalStack].addingManagedObjectContext;
    
    //add observer for notifications
    NSNotificationCenter *dnc = [NSNotificationCenter defaultCenter];
    [dnc addObserver:self selector:@selector(addControllerContextDidSave:) name:NSManagedObjectContextDidSaveNotification object:managedObjectContext];
    [[CoreDataApplicationStack globalStack] commitData];
    
    //remove observer
    [dnc removeObserver:self name:NSManagedObjectContextDidSaveNotification object:managedObjectContext];
}

/*!
 @function		saveDataToStore
 @abstract		method to merge adding and reading contexts.
 @discussion	Notification from the add controller's context's save operation. This is
                used to update the fetched results controller's managed object context with
                the new data instead of performing a fetch (which would be a much more
                computationally expensive operation).
 @param			none
 @result		void
 */
- (void)addControllerContextDidSave:(NSNotification*)saveNotification {
	
	NSManagedObjectContext *context = [fetchedResultsController managedObjectContext];
    
    // Merging changes causes the fetched results controller to update its results
	[context mergeChangesFromContextDidSaveNotification:saveNotification];	
}

#pragma mark class methods

/*!
 @function		currentRowIndex
 @abstract		
 @discussion	class method which keep track of the last index of the row inserted in core data..
 @param			none
 @result		void
 */
+ (int)currentRowIndex
{
    return ++rowIndex;
}

/*!
 @function		flushSearchData
 @abstract		function to flush data from core data.
 @discussion	This function will be called before a new search is initiated by search feature.
 @param         none
 @result		void
 */
+ (void)flushSearchData
{
    NSManagedObjectContext *managedContext = [CoreDataApplicationStack globalStack].addingManagedObjectContext;
    
	//create a fetch request for ProductSearch
    NSFetchRequest *fetchRequestForProductSearch = [[NSFetchRequest alloc] init];
	[fetchRequestForProductSearch setEntity:[NSEntityDescription entityForName:kProductSearch 
                                                        inManagedObjectContext:managedContext]];
	
    NSError *err = nil;
	NSArray *result = [managedContext executeFetchRequest:fetchRequestForProductSearch error:&err];
	
	if( err )
	{
		TRC_ERR(@"Error: FetchProductSearch %@", [err localizedDescription] );
	}
	
    if( [result count] > 0)
	{
		ProductSearch *searchData = [result objectAtIndex:0];
        //delete search data. This will inturn delete all the product data as we have 
        //set cascade property set on ProductSearch entity
        [managedContext deleteObject:searchData];
        
        //commit the data to store 
        [[CoreDataApplicationStack globalStack] commitData];  
        
        //flush the managed object context
        [[[CoreDataApplicationStack globalStack] managedObjectContext] reset];
	}
    
    [fetchRequestForProductSearch release];
}

#pragma mark memory management

/*!
 @function		dealloc
 @abstract		release data member variables
 @discussion	release data member variables
 @param			none
 @result		void
 */
- (void)dealloc
{	
    //cancell all pending downloads
    [[ImageDownloadQueue sharedQueue] cancelAllOperations];
        
    [searchString release];
    [pageSize release];
    [currentPage release];
    [fetchRequestForProductSearch release];
    [fetchedResultsController release];
	[super				dealloc];
}

@end
