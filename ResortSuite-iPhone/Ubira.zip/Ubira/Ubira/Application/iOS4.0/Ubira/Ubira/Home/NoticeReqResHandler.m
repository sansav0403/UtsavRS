//
//  NoticeReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "NoticeReqResHandler.h"
#import "Notice.h"

#define kNotices	@"notices" 
#define kExpires	@"expires"
#define kId			@"id"
#define kNotice		@"notice"
#define kPrice		@"price"

@implementation NoticeReqResHandler

@synthesize noticeList = _noticeList;

- (void)noticeList:(NSArray*)noticesList
{
	self.noticeList = noticesList;
	
	NSString* queryString = [NSString stringWithFormat:@"%@/notice/home?",kUbiraServerUrl];
	NSURL* url = [NSURL URLWithString:queryString];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kGet];			
	
	[webService makeRequest:theRequest];
}

/*!
 @function      handleReceivedData
 @abstract      response data for notice list request to server.
 @discussion    response data for notice list request to server.
 @param         data - response data
 @result        bool
 */
- (void)handleReceivedData: (NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
	//Get the json key value dictionary for the data
    NSString *resultString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        
    NSDictionary *resultDictionary = [resultString JSONValue];
    [resultString release];

	NSArray *resultList = [resultDictionary valueForKey:kNotices];
	
    NSError *error = nil;
    @try {
        //Create the all available offer models 
        for(NSDictionary *offerDict in resultList)
        {    
            TRC_DBG(@"----------------------------------------")
            Notice *notice = [[Notice alloc] init];
            
            notice.noticeId = [offerDict valueForKey:kId];
            TRC_DBG(@"Notice Id : %@",notice.noticeId )
        
            notice.description = [offerDict valueForKey:kNotice];
            notice.description = [notice.description stringByDecodingXMLEntities];                              
            TRC_DBG(@"Notice description : %@",notice.description )
            
            notice.price = [offerDict valueForKey:kPrice];
            TRC_DBG(@"Notice price : %@",notice.price )
            
            NSString* expiryDateString	=	[offerDict valueForKey:kExpires];		
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];		
            [dateFormatter setDateFormat:kDateFormat];		
            notice.expireDate = [dateFormatter dateFromString:expiryDateString];
            TRC_DBG(@"Notice expireDate : %@",[dateFormatter stringFromDate:notice.expireDate])
            [dateFormatter release];
            
            [(NSMutableArray *)self.noticeList addObject:notice];
            [notice release];
        }
    }
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        self.noticeList = nil;
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kInvalidDataErr userInfo:userInfo];
        [userInfo release]; 
        
    }
    //Update the caller about the result
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
}

/*!
 @function		dealloc
 @abstract		release data member variables
 @discussion	release data member variables
 @param			none
 @result		void
 */
- (void)dealloc
{	
	[super dealloc];
}

@end
