 //
 //  RatingView.h
 //  Ubira
 //
 //  Created by [Cybage Team] on 25/05/11.
 //  Copyright 2011 FreeCause. All rights reserved.
 //


#import <UIKit/UIKit.h>

/*!
    @class         RatingView
    @abstract      draw a rating on the view
    @discussion    draw a rating on the view based on the current ratings for the product.
 */
@interface RatingView : UIView
{
    float           rating;
    UIImageView     *backgroundImageView;
    UIImageView     *foregroundImageView;
}

@property float rating;

@end
