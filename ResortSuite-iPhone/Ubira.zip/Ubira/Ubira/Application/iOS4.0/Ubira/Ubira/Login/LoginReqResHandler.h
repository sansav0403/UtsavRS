//
//  LoginReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"
#import "UserExtended.h"

/*!
    @class			LoginReqResHandler
    @abstract		This class hadles all login releated network and parsing functionality.
    @discussion		This class hadles all login releated network and parsing functionality.
*/
@interface LoginReqResHandler : RequestResponseBase {

	UserExtended    *_user;
}

@property (nonatomic, retain) UserExtended  *userBasicDetails;

- (void)logIn:(UserExtended*)user;

@end
