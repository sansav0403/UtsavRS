//
//  UserProfileReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"
#import "UserExtended.h"

typedef enum
{
	kUPReqNone,
	kUPReqGetProfile,
	kUPReqUpdateProfile
}UserProfileReqState;

@class UserExtended;

/*!
    @class          UserProfileReqResHandler
    @abstract       Handler the user request response.
    @discussion     Create the required url request and respond to the caller.
 */
@interface UserProfileReqResHandler : RequestResponseBase {

	UserExtended        *_userDetails;
	UserProfileReqState	_userProfileReqState;
}

@property (nonatomic,retain) UserExtended   *userDetails;
@property (nonatomic) UserProfileReqState	userProfileReqState;

- (void)profile:(UserExtended*)userDetail;

- (void)updateProfile:(UserExtended*)userDetail;

@end
