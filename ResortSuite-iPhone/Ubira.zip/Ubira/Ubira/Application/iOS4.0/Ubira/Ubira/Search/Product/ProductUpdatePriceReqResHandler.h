//
//  ProductUpdatePriceReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"
#import "NSString+HTML.h"
/*!
    @class          ProductUpdatePriceReqResHandler
    @abstract       Handler the update product price request response.
    @discussion     Create the required url request and respond to the caller.
 */
@interface ProductUpdatePriceReqResHandler : RequestResponseBase {

}

- (void)updatePrice:(NSString*)productId storeId:(NSString*)storeId updatedprice:(NSString*)price;

@end
