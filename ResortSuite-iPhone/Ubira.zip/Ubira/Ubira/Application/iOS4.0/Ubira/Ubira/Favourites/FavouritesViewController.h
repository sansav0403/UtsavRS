//
//  FavouritesViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FavoriteReqResHandler.h"
#import "ProductCell.h"

@class Favorites;

typedef enum
{
	kFavoriteProductFetchRequest,
	kFavoriteProductDeleteRequest
}FavoritesRequestState;

/*!
 @class			FavouritesViewController
 @abstract		This class hadles releated UI interaction functionality for favorites.
 @discussion	This class hadles releated UI interaction functionality for favorites.
 */
@interface FavouritesViewController : UIViewController <RequestResponseBaseDelegate>{
    Favorites                   *favoritesList;
    FavoriteReqResHandler       *favoriteReqResHandler;
	
	IBOutlet UITableView        *productTbl;
	FavoritesRequestState		favoritesRequestState;
	
	UIActivityIndicatorView		*activityIndicator;
    UILabel                     *messageLabel;
    NSDate                      *_startDate;
    NSIndexPath                 *selectedIndexPath;
    NSArray                     *favoritesListArray;
}

@property (nonatomic, retain) IBOutlet UITableView              *productTbl;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView  *activityIndicator;
@property (nonatomic, retain) IBOutlet UILabel                  *messageLabel;
@property (nonatomic, retain) NSDate                            *startDate;
@property (nonatomic, retain) NSArray                           *favoritesListArray;
@property (nonatomic, retain) NSIndexPath                       *selectedIndexPath;

- (void)refreshData;
- (void)firstVisibleCellImageDownload:(NSIndexPath*)indexPath productCell:(ProductCell*)productCell;
- (void)loadImagesForOnscreenRows;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;

@end
