//
//  User.m
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "User.h"

@implementation User

@synthesize userId,email,password,autoLogin;

- (void)dealloc
{
	[userId release];
	[email release];
	[password release];
	[super dealloc];
}

@end
