//
//  Coupon.m
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "Coupon.h"
#import "ImageDownloadQueue.h"

@implementation Coupon

@synthesize couponId = _couponId, code = _code,description = _description ,imageUrl = _imageUrl, storeId = _storeId;
@synthesize createDate = _createDate, expireDate = _expireDate ,productId = _productId, userId = _userId, active = _active;
@synthesize delegate = _delegate, image = _image;

- (void)dealloc
{
	_delegate  = nil;
    if ([_imageDownloadOperation isExecuting]) {
        [_imageDownloadOperation removeObserver:self forKeyPath:@"isFinished"];    
    } 
    [_imageDownloadOperation release];
    
	[_couponId release];
	[_code	release];
	[_description release];
	[_imageUrl release];
	[_productId release];
	[_storeId release];
	[_userId release];
	[_createDate release];
	[_expireDate release];
	[_image release];
	[super dealloc];
}

/*!
 @function      downloadImage
 @abstract      Request to start download image.
 @discussion    Request to start download image.
 @param         none
 @result        void
 */
- (void)downloadImage
{
    if (imageRequestInProgress == NO) {
        NSURLRequest *imageUrlRequest = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:self.imageUrl]];
        _imageDownloadOperation = [[RemoteDataOperation alloc] initWithUrlRequest:imageUrlRequest];
        [_imageDownloadOperation addObserver:self forKeyPath:@"isFinished" options:NSKeyValueObservingOptionNew context:NULL];
        [[ImageDownloadQueue sharedQueue] addOperation:_imageDownloadOperation];	
        [imageUrlRequest release];
        imageRequestInProgress = YES;
    }
}

#pragma mark RemoteDataOperation keyValue callback method
/*!
 @function      observeValueForKeyPath
 @abstract      RemoteDataOperation keyValue callback
 @discussion    RemoteDataOperation keyValue callback
 @result        void
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
	@try {
		RemoteDataOperation* remoteDataOperation = (RemoteDataOperation*)object;
		[remoteDataOperation removeObserver:self forKeyPath:@"isFinished"];
		if( [remoteDataOperation error] ) 
		{
			[self.delegate imageDownloadComplete:[remoteDataOperation error] ];
		} 
		else
		{
			self.image = [UIImage imageWithData:remoteDataOperation.remoteData];
			[self.delegate imageDownloadComplete:nil];
			
		}
		if( remoteDataOperation == _imageDownloadOperation ) {
			[_imageDownloadOperation release];
			_imageDownloadOperation =  nil;
		}
        imageRequestInProgress = NO;
	}
	@catch (NSException * e) {
		TRC_EXCEPTION(e);
	}
}

@end
