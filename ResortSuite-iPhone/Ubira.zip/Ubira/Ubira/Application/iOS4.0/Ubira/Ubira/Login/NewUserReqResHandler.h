//
//  NewUserReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserExtended.h"
#import "RequestResponseBase.h"


/*!
    @class			NewUserReqResHandler
    @abstract		This class hadles new user related network and parsing functionality.
    @discussion		This class hadles new user related network and parsing functionality.
*/
@interface NewUserReqResHandler : RequestResponseBase {

	UserExtended    *_user;
}

@property (nonatomic,retain) UserExtended   *userDetail;

- (void)registerNewUser:(UserExtended*)user;

@end
