//
//  SearchViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "SearchViewController.h"
#import "SearchResultViewController.h"
#import "ProductSearchReqResHandler.h"
#import "UserAnalytics.h"
#import "ValidationHandler.h"
#import "Store.h"
#import "StoreListViewController.h"

#define kSearchResultViewController @"SearchResultViewController"

@implementation SearchViewController

@synthesize searchBar;
@synthesize startDate = _startDate;
@synthesize scanBtn,notCheckInReminderLbl;

@synthesize overlayView, overlayViewTopLbl, overlayViewCancelBtn, overlayViewCheckInBtn, overlayViewToolbarTypeView,overlayNotCheckInReminderLbl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (void)dealloc
{
    [searchBar release];
    [_startDate release];
    [scanBtn release];
    [notCheckInReminderLbl release];
    [objRakutenImageUtil release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

/*!
 @function      setBackNavigationButton
 @abstract      create the cancel button for the navigation bar.
 @discussion    create the cancel button for the navigation bar.
 @param         void
 @result        void
 */
- (void)setBackNavigationButton
{
    //set the navigation back button with back title
    UIBarButtonItem *back = [[UIBarButtonItem alloc] initWithTitle:kBack style:UIBarButtonItemStylePlain target:self action:nil];	
	self.navigationItem.backBarButtonItem = back;
    [back release];
}

/*!
 @function      setCancelNavigationButton
 @abstract      create the cancel button for the navigation bar.
 @discussion    create the cancel button for the navigation bar.
 @param         BOOL - show/hide cancel button
 @result        void
 */
- (void)setCancelNavigationButton:(BOOL)aBool
{
    if(!aBool)
    {
        // if not checkIn display checkIn button
        Store * store = [Store sharedStore];
        self.navigationItem.rightBarButtonItem = (store.storeId)?nil:[[[UIBarButtonItem alloc]initWithTitle:kCheckInButtonTitle style:UIBarButtonItemStylePlain target:self action:@selector(checkIntoStore)] autorelease];
    }
    else
    {
        UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:kCancelButton style:UIBarButtonItemStylePlain target:self action:@selector(cancelButtonAction:)];	
        
        //Show the cancel button and hide back button
        self.navigationItem.rightBarButtonItem = cancelButton;
        [cancelButton release];
    }
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSBundle mainBundle] loadNibNamed:@"BarcodeOverlayView" owner:self options:nil];
        
    [self setTitle:kSearchTitle];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
    
    
    objRakutenImageUtil = [[RakutenImageUtil alloc]init];
    [objRakutenImageUtil setDelegate:self];
    
    [self.searchBar setPlaceholder:kSearchBarPlaceHolder];
    [scanBtn setTitle:kScanBtnTitle forState:UIControlStateNormal];
    
    [[self.navigationController navigationBar] setTintColor:kSCNavigationBarTintColor];
    
    [searchBar setTintColor:kSCNavigationBarTintColor];
    [notCheckInReminderLbl setText:kPleaseCheckInText];
    
    // Do any additional setup after loading the view from its nib.
    [self setBackNavigationButton];
}

- (void)viewDidUnload
{
    [searchBar release];
    searchBar = nil;
    scanBtn = nil;
    notCheckInReminderLbl = nil;
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    searchBar.text = nil;
    
    // if not checkIn display checkIn button
    Store * store = [Store sharedStore];
    self.navigationItem.rightBarButtonItem = (store.storeId)?nil:[[[UIBarButtonItem alloc]initWithTitle:kCheckInButtonTitle style:UIBarButtonItemStylePlain target:self action:@selector(checkIntoStore)] autorelease];
    
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
    
    //if not checkedIn then remind
    notCheckInReminderLbl.hidden = (store.storeId)?YES:NO;
}

- (void)viewWillDisappear:(BOOL)animated
{    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsSearchScreen startDate:self.startDate endDate:[NSDate date]];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*!
 @function      showSearchResultView
 @abstract      search keyword will be sent to search result controller.
 @discussion    search keyword will be sent to search result controller.
 @param         NSString - keyword
 BOOL - is barcode or only text search
 @result        void
 */
- (void)showSearchResultView:(NSString*)keyWord barCode:(BOOL)barCode
{
    SearchResultViewController *searchResultViewController = [[SearchResultViewController alloc] initWithNibName:kSearchResultViewController bundle:[NSBundle mainBundle]];
    
    //Pass the search text to the result controller
    searchResultViewController.searchKeyword = keyWord;
    searchResultViewController.barCode = barCode;
    
    //Flush existing search data as we are starting with a new search
    [ProductSearchReqResHandler flushSearchData];
    
    [self.navigationController pushViewController:searchResultViewController animated:YES];
    [searchResultViewController release];
}

#pragma mark - Cancel button action
/*!
 @function      cancelButtonAction
 @abstract      hide the cancel button and hide the keyboard
 @discussion    hide the cancel button and hide the keyboard.
 @param         id
 @result        void
 */
- (IBAction)cancelButtonAction:(id)sender
{
    //Show the back button and hide cancel button
    [self setCancelNavigationButton:NO];
    [searchBar resignFirstResponder];
}

/*!
 @function      dismissBarCodeReader
 @abstract      dismiss the barcode reader
 @discussion    dismiss the barcode reader.
 @param         id
 @result        void
 */
- (IBAction)dismissBarCodeReader:(id)sender
{
    [reader dismissModalViewControllerAnimated: YES];
}

/*!
 @function      cancelButtonAction
 @abstract      launch the camera controller
 @discussion    launch the camera controller to scan the bar code.
 @param         id
 @result        void
 */
- (IBAction)scanBarAction:(id)sender 
{    
    [self selectImageSourceForbarcode];
}

#pragma mark - Image picked and scan result is available
- (void)imagePickerController:(UIImagePickerController*)barreader
didFinishPickingMediaWithInfo:(NSDictionary*)info
{
    // ADD: get the decode results
    id<NSFastEnumeration> results = [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        // EXAMPLE: just grab the first barcode
        break;
	
    // EXAMPLE: do something useful with the barcode data
	// resultText.text = symbol.data;
	TRC_DBG(@"Barcode %@",symbol.data)
	
    // EXAMPLE: do something useful with the barcode image
	// resultImage.image = [info objectForKey: UIImagePickerControllerOriginalImage];
	
    // ADD: dismiss the controller (NB dismiss from the *reader*!)
    [barreader dismissModalViewControllerAnimated: YES];
    
    if([symbol.data length])
    {
        [self showSearchResultView:symbol.data barCode:YES];
    }
}

#pragma mark - RakutenImageUtilDelegate
- (void)didFinishImageProcessing:(UIImage*) image errorinfo:(NSError*) error
{
    [self scanImage:image];
}

- (void)scanImage:(UIImage*) image
{
    if (image) {
        ZBarReaderController* zbarController = [ZBarReaderController new];
        id results = nil;
        results = [zbarController scanImage:[image CGImage]];
        
        if(results) {
            NSMutableDictionary *newinfo = [[NSMutableDictionary alloc]init];//[info mutableCopy];
            [newinfo setObject: results
                        forKey: ZBarReaderControllerResults];
            SEL cb = @selector(imagePickerController:didFinishPickingMediaWithInfo:);
            if([self respondsToSelector: cb])
                [self imagePickerController: nil
              didFinishPickingMediaWithInfo: newinfo];
            else
                [self dismissModalViewControllerAnimated: YES];
            [newinfo release];
            return;
        }
        [zbarController release];    
    }
    
}

#pragma mark - SearchBarDelegate
// return NO to not become first responder
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)aSearchBar
{
    [self setCancelNavigationButton:YES];
    
    return YES;
}

- (BOOL)searchBar:(UISearchBar *)aSearchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
	if ([aSearchBar.text isEqualToString:@" "] && [aSearchBar.text length]==1)
	{ 
		aSearchBar.text = @"";
		return NO;
	}
	return YES;
}

// called when keyboard search button pressed
- (void)searchBarSearchButtonClicked:(UISearchBar *)aSearchBar
{
    TRC_ENTRY
    
    TRC_DBG(@"Search with keyword %@",aSearchBar.text)
    aSearchBar.text = [ValidationHandler trimCurrentString:aSearchBar.text];
    if([ValidationHandler checkSpaceOrNewLineCharacter:aSearchBar.text])
    {
        //hide the cancel button of search bar
        [self setCancelNavigationButton:NO];
        
        [searchBar resignFirstResponder];
        if([searchBar.text length])
        {
            [self showSearchResultView:searchBar.text barCode:NO];
        }
    }
    TRC_EXIT
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function      showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
 alertMessage - Message description for AlertView		
 @result		void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
	[alert show];
	[alert release];
}

/*!
 @method		clickedButtonAtIndex
 @abstract		redirect to Login Page 
 @discussion	redirect to Login Page when password sent successfully
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    // do something after button clicked of alertview.
}

#pragma Other Methods
/*!
 @function      checkIntoStore
 @abstract      redirect to store list 
 @discussion    redirect to store list for checkIn
 @param         id
 @result        void
 */
- (void)checkIntoStore
{
    StoreListViewController* storeListViewController = [[StoreListViewController alloc]init];
    [self.navigationController pushViewController:storeListViewController animated:YES];
    [storeListViewController release];
}

- (IBAction)overlayViewButtonAction:(id)sender
{
    [reader dismissModalViewControllerAnimated: YES];
    switch ([sender tag]) {
        case 0:
        {
            TRC_DBG(@"Cancel button Pressed");
        }break;
        case 1:
        {
            TRC_DBG(@"Check In button Pressed");
            [self checkIntoStore];
        }break;    
        default:
            break;
    }
}

- (void)selectImageSourceForbarcode
{
    UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:kScanOrSelectBacodeTitle delegate:self cancelButtonTitle:kButtoncancel destructiveButtonTitle:kCameraTitle otherButtonTitles:kAlbumTitle, kLibraryTitle, nil];
	popupQuery.actionSheetStyle = UIActionSheetStyleAutomatic;
    
    UbiraAppDelegate  *appDelegate = (UbiraAppDelegate*)[[UIApplication sharedApplication]delegate];    
    [popupQuery showInView:appDelegate.tabBarController.view];
    
	[popupQuery release];
}

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
   
    CGSize scSize;
    scSize.width = 0;
    scSize.height = 0;
    
    switch (buttonIndex) {
        case 0:{
            [self scanBarcode];
        }break;
        case 1:{
            [objRakutenImageUtil takePictureAndScale:scSize placeViewController:self imageSourceType:kImageSourcePhotoLibrary];            
        }break;
        case 2:{
            [objRakutenImageUtil takePictureAndScale:scSize placeViewController:self imageSourceType:kImageSourcePhotoAlbum];
        }break;
        case 3:{
            //Do Nothing
        }break;
        default:
            break;
    }
}
- (void)scanBarcode
{
    // ADD: present a barcode reader that scans from the camera feed
     reader = [ZBarReaderViewController new];   
     
     
     [overlayViewCancelBtn setTitle:kCancelButton forState:UIControlStateNormal];
     [overlayViewToolbarTypeView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"navBarBg.PNG"]]];
     [overlayNotCheckInReminderLbl setText:kPleaseCheckInText];
     
     Store * store = [Store sharedStore];
     if (store.storeId ) {
     [overlayViewCheckInBtn setHidden:TRUE];
     [overlayNotCheckInReminderLbl setHidden:TRUE];
     }else{
     [overlayViewCheckInBtn setHidden:FALSE];
     [overlayNotCheckInReminderLbl setHidden:FALSE];
     [overlayViewCheckInBtn setTitle:kCheckInButtonTitle forState:UIControlStateNormal];
     }    
     [overlayViewTopLbl setText:kBarcodeDisclaimer];
     
     [reader.view addSubview:overlayView];
     reader.readerDelegate = self;
     reader.showsZBarControls = NO;
     ZBarImageScanner *scanner = reader.scanner;
     // TODO: (optional) additional reader configuration here
     
     // EXAMPLE: disable rarely used I2/5 to improve performance
     [scanner setSymbology: ZBAR_I25 config: ZBAR_CFG_ENABLE to: 0];
     
     // present and release the controller
     [self presentModalViewController: reader
     animated: YES];
     [reader release];
}
@end
