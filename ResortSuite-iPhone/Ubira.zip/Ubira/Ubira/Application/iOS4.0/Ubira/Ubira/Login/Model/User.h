//
//  User.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject {
	
	NSString    *userId;
	NSString    *email;
	NSString    *password;
	bool		autoLogin;
	
}

@property (nonatomic, copy) NSString    *userId;
@property (nonatomic, copy) NSString    *email;
@property (nonatomic, copy) NSString    *password;
@property (nonatomic, assign) bool		autoLogin;

@end
