//
//  TwitterPopoverViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 6/2/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SA_OAuthTwitterController.h"
#import "ProductDetail.h"

typedef enum
{
    kTwitterRequestNone,
    kTwitterUpdateRequest
}TwitterUpdateRequest;

@class SA_OAuthTwitterEngine;

@protocol PopoverDelegate <NSObject>

@required
-(void)closePopover;

@end

/*!
 @class			TwitterPopoverViewController
 @abstract		This class hadles releated UI interaction functionality for twitter.
 @discussion	This class hadles twitter functionalities.
 */
@interface TwitterPopoverViewController : UIViewController <UITextViewDelegate, SA_OAuthTwitterControllerDelegate> {
	
    //IBOutlets
	IBOutlet UITextView		*tweetField;

    //delegate
	id <PopoverDelegate>	delegate;
    
    //BOOL
	BOOL                    isAuthenticated;
    
    // others 
    SA_OAuthTwitterEngine	*_engine;
    ProductDetail           *product;
    TwitterUpdateRequest    _twitterUpdateRequestStatus;
}

@property (nonatomic,retain) IBOutlet UITextView    *tweetField;
@property (nonatomic,retain) id <PopoverDelegate>   delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil product:(ProductDetail*)aProduct;

- (IBAction)postTweet:(id)sender;
- (IBAction)cancel:(id)sender;
- (void)moveView:(int)vertOffset;
- (void)statusFinished;
- (void)redirectToProductDetailsPage;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;

@end
