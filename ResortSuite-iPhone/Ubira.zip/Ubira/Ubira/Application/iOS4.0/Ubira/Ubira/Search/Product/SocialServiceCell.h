//
//  SocialServiceCell.h
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RatingView.h"
#import "FBConnect.h"
#import "ProductDetail.h"
#import	"FavoriteReqResHandler.h"

@class FBSession;

@protocol SocialServiceCellDelegate <NSObject>

- (void)twitterButtonActionDelegate;

@end
/*!
    @class          SocialServiceCell
    @abstract       create the social service cell.
    @discussion     create the social service cell.
 */
@interface SocialServiceCell : UITableViewCell <FBDialogDelegate, FBSessionDelegate, FBRequestDelegate, RequestResponseBaseDelegate> {
    UILabel                         *totalReviewsLable;
    UIButton                        *favouriteButton;
    UIButton                        *facebookButton;
    UIButton                        *twitterButton;
    RatingView                      *ratingView;
    ProductDetail                   *product;
    FBSession                       *_session;
	FBLoginDialog                   *login;
	FavoriteReqResHandler			*favoriteReqResHandler;
    
    id <SocialServiceCellDelegate> _delegate;
}

@property (nonatomic, assign) id <SocialServiceCellDelegate> delegate;

- (void)setReviewsDetails:(ProductDetail*)productDetails;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;

@end
