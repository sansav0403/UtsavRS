//
//  SearchResultViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductSearchReqResHandler.h"

/*!
    @class          SearchResultViewController
    @abstract       handler the search result request response.
    @discussion     handle the text and barcode search for product.
 */
@class ProductCell;
@interface SearchResultViewController : UIViewController<RequestResponseBaseDelegate, NSFetchedResultsControllerDelegate> {
    
    NSString                    *_searchKeyword;
    ProductSearchReqResHandler  *productSearchReqResHandler;
    IBOutlet UITableView        *productTbl;
    IBOutlet UISearchBar        *searchBar;
    int                         rowCount;
    int                         currentPage;

    BOOL                        _barCode;
    UIView                      *loadingFooterView;
    UIActivityIndicatorView     *activityIndicator;
    NSDate                      *_startDate;
}

@property (nonatomic, retain)   IBOutlet UIView                     *loadingFooterView;
@property (nonatomic, retain)   IBOutlet UITableView                *productTbl;
@property (nonatomic, retain)   NSDate                              *startDate;
@property (nonatomic, copy)     NSString                            *searchKeyword;
@property (nonatomic , assign)  BOOL                                barCode;
@property (nonatomic, retain)   IBOutlet UIActivityIndicatorView    *activityIndicator;


- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath;
- (void)firstVisibleCellImageDownload:(NSIndexPath*)indexPath productCell:(ProductCell*)productCell;
- (void)loadImagesForOnscreenRows;

@end
