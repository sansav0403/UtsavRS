//
//  FavoriteReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "FavoriteReqResHandler.h"
#import "Favorites.h"
#import "Product.h"
#import "UbiraAppDelegate.h"
#import "LocationManager.h"

@interface FavoriteReqResHandler ()
- (void)parseFavouritesList:(NSData *)data;
- (void)parseAddFavourites:(NSData*)data;
- (void)parseFavouritesDelete:(NSData*)data;
@end

@implementation FavoriteReqResHandler
@synthesize _favReqState,favoritesArray;

/*!
 @function      favorites
 @abstract      get favorites information.
 @discussion    parse favorites list.
 @param         Favorites - result will be return in this.
 */
- (void)favorites:(NSArray*)aFavorites
{
    TRC_ENTRY
    self.favoritesArray = aFavorites;
    
	self._favReqState = kFavReqGetFavorite;
	
	//user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
	NSString* queryString = [NSString stringWithFormat:@"%@/favorite/get/?userid=%@&lat=%f&long=%f"
							 ,kUbiraServerUrl
							 ,userId
							 ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
							 ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
							 ];
	TRC_DBG(@"Get Favorite URL : %@", queryString)
	TRC_DBG(@"Favorite QueryStr= %@",queryString);
	NSURL* url = [NSURL URLWithString:queryString];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kGet];			
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      addFavorite
 @abstract      add favorites to user account on server.
 @discussion    parse favorites list.
 @param         productId - product id which need to be added.
 */
- (void)addFavorite:(NSString*)productId
{
    TRC_ENTRY
	self._favReqState = kFavReqAddFavorite;
		
	//user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;	
	
	NSString* postData = [NSString stringWithFormat:@"userid=%@&productid=%@&lat=%f&long=%f"
						  ,userId
						  ,productId
						  ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
						  ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
						  ];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];

	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/favorite/add",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      deleteFavorite
 @abstract      delete favorites to user account on server.
 @discussion    delete favorites from the user account.
 @param         favoriteId - favorite product id which need to be added.
 */
- (void)deleteFavorite:(NSString*)favoriteId
{
    TRC_ENTRY
	self._favReqState = kFavReqDeleteFavorite;
		
	//user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
	NSString* postData = [NSString stringWithFormat:@"userid=%@&favoriteid=%@&lat=%f&long=%f"
						  ,userId
						  ,favoriteId
						  ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
						  ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
						  ];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];	
	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/favorite/delete",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      addFavorite
 @abstract      add favorites to user account on server.
 @discussion    parse favorites list.
 @param         productId - product id which need to be added.
 */
- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
    TRC_ENTRY
	switch (self._favReqState) {
			
		case kFavReqGetFavorite:
			{
				TRC_DBG(@"Get Favorite Parsing...");
                [self parseFavouritesList:data];
			}break;
		case kFavReqAddFavorite:
			{
				TRC_DBG(@"Add Favorite Parsing...");
                [self parseAddFavourites:data];
			}break;
		case kFavReqDeleteFavorite:
			{
				TRC_DBG(@"Delete Favorite Parsing...");
                [self parseFavouritesDelete:data];
			}break;
			
		default:
			break;
	}
	
    TRC_EXIT
}


- (void)dealloc
{	
    _delegate = nil;
    [favoritesArray release];
	[super dealloc];
}

#pragma mark - FavouriteReqResHandler Private Methods
/*!
 @function      parseFavouritesList
 @abstract      get favorites to user account from server.
 @discussion    parse favorites list.
 @param         data - server response.
 */
- (void)parseFavouritesList:(NSData *)data
{
    TRC_ENTRY
    
    //Get the json key value dictionary for the data
    NSString *resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    
	NSString *newResultString = [resultString stringByDecodingXMLEntities];
	
    NSDictionary *resultDictionary = [newResultString JSONValue];
    [resultString release];
    
    NSArray *resultList = [resultDictionary valueForKey:kFavourites];
     NSError *error = nil;
    Favorites *favoritesObj = nil;
    @try 
    {
        for(NSDictionary *productDict in resultList)
        {        
            favoritesObj = [[Favorites alloc] init];
            
            favoritesObj.favoriteId = [productDict valueForKey:kId];
            TRC_DBG(@"Favorite Id : %@",favoritesObj.favoriteId )
            
            favoritesObj.product.productId = [productDict valueForKey:kProductId];
            TRC_DBG(@"Product Id : %@",favoritesObj.product.productId )
            
            favoritesObj.product.description = [productDict valueForKey:kDescription];
            TRC_DBG(@"description %@", favoritesObj.product.description);
            
            favoritesObj.product.name = [productDict valueForKey:kName];
            TRC_DBG(@"name %@", favoritesObj.product.name );
            
            favoritesObj.product.imageUrl = [productDict valueForKey:kImageUrl];
            TRC_DBG(@"imageUrl %@", favoritesObj.product.imageUrl);
            
            favoritesObj.product.rating = [[productDict valueForKey:kRatings] intValue];
            TRC_DBG(@"rating %d", favoritesObj.product.rating);            
            
            favoritesObj.product.reviews = [[productDict valueForKey:kReviews] intValue];
            TRC_DBG(@"reviews %d", favoritesObj.product.reviews);
            
            [(NSMutableArray *)favoritesArray addObject:favoritesObj];
            
            [favoritesObj release];
        }
    }
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        if (favoritesArray)
        {
            [(NSMutableArray *)favoritesArray removeAllObjects];
            [favoritesArray release];
            favoritesArray = nil;
        }
        
        if (favoritesObj)
        {
            [favoritesObj release];
            favoritesObj = nil;
        }
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kInvalidDataErr userInfo:userInfo];
        [userInfo release]; 
    }
    
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
    
    TRC_EXIT
}

/*!
 @function      parseAddFabourites
 @abstract      add favorites to user account to server.
 @discussion    parse favorites add result.
 @param         data - server response.
 */
- (void)parseAddFavourites:(NSData*)data
{
    TRC_ENTRY
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:nil];
    }
    TRC_EXIT
}

/*!
 @function      parseFavouritesDelete
 @abstract      delete favorites of user account from server.
 @discussion    parse favorites delete result.
 @param         data - server response.
 */
- (void)parseFavouritesDelete:(NSData*)data
{
    TRC_ENTRY
      if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:nil];
    }
    TRC_EXIT
}

@end
