//
//  Review.m
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "Review.h"

@implementation Review

@synthesize reviewId, createDate,productId,rating,description,author;

- (void)dealloc
{
    [createDate     release];
	[reviewId       release];
	[productId      release];
	[description    release];
	[author         release];
	[super dealloc];
}

@end
