//
//  RelatedProductCell.m
//  Ubira
//
//  Created by [Cybage Team] on 30/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "RelatedProductCell.h"

@implementation RelatedProductCell
@synthesize relatedProducts = _relatedProducts;
@synthesize tapRecognizer   = _tapRecognizer;
@synthesize delegate        = _delegate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier 
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) 
    {
        // Initialization code
        [self setSelectionStyle:UITableViewCellEditingStyleNone];
        [self.contentView setBackgroundColor:[UIColor whiteColor]];
        
        nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [nextButton setImage:[UIImage imageNamed:@"RightArrow.png"] forState:UIControlStateNormal];
 
        [nextButton addTarget:self action:@selector(nextAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:nextButton];
        
        previousButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [previousButton setImage:[UIImage imageNamed:@"leftArrow.png"] forState:UIControlStateNormal];
        
        [previousButton addTarget:self action:@selector(previousAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:previousButton];
        
        imageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        [imageView setImage:[UIImage imageNamed:kNoImagesImg]];
        [imageView setUserInteractionEnabled:TRUE];
        /*
         Create and configure the four recognizers. Add each to the view as a gesture recognizer.
         */
        UIGestureRecognizer *recognizer;
        
        /*
         Create a tap recognizer and add it to the view.
         Keep a reference to the recognizer to test in gestureRecognizer:shouldReceiveTouch:.
         */
        recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapFrom:)];
        [imageView addGestureRecognizer:recognizer];
        self.tapRecognizer = (UITapGestureRecognizer *)recognizer;
        recognizer.delegate = self;
        [recognizer release];
        
        [self.contentView addSubview:imageView];
        
        productName = [[UILabel alloc] initWithFrame:CGRectZero];
        [productName setBackgroundColor:[UIColor clearColor]];
        [productName setTextAlignment:UITextAlignmentCenter];
        [productName setFont:[UIFont systemFontOfSize:13.0f]];
        [self.contentView addSubview:productName];
        
        currentRelatedProduct = 0;
    }
    return self;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    
    // Disallow recognition of tap gestures in the cell.
    if ((touch.view == self.contentView) && (gestureRecognizer == self.tapRecognizer)) {
        return NO;
    }
    return YES;
}

/*!
 @function      handleTapFrom
 @abstract      tap gesture
 @discussion    In response to a tap gesture, show the image view appropriately then make 
                it fade out in place.
 @param         recognizer - UITapGestureRecognizer object
 @result        void
 */
- (void)handleTapFrom:(UITapGestureRecognizer *)recognizer 
{
    TRC_DBG(@"handleTapForImage");
    if([self.delegate respondsToSelector:@selector(relatedProdcutTapedDelegate:)])
    {
        [self.delegate relatedProdcutTapedDelegate:currentRelatedProduct];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;                
        frame = CGRectMake(0, 0, 60, 20);
        [nextButton setFrame:frame];
        [nextButton setCenter:CGPointMake(self.frame.size.width - nextButton.frame.size.width/2, self.frame.size.height/2)];
        
        frame = CGRectMake(0, 0, 60, 20);
        [previousButton setFrame:frame];
        [previousButton setCenter:CGPointMake(previousButton.frame.size.width/2 , self.frame.size.height/2)];
        
        frame = CGRectMake(0, 0, 80, 80);
        [imageView setFrame:frame];
        [imageView setCenter:CGPointMake(self.frame.size.width/2 , self.frame.size.height/2)];
        
        frame = CGRectMake(0, 0, 200, 20);
        [productName setFrame:frame];
        [productName setCenter:CGPointMake(self.frame.size.width/2 , self.frame.size.height - 10)];
	}
}

/*!
 @function      setRelatedProductsData
 @abstract      set the related product image.
 @discussion    set the related product images if exist.
 @param         void
 @result        void
 */
- (void)setRelatedProductsData 
{
    if([self.relatedProducts count])
    {
        Product *product = [self.relatedProducts objectAtIndex:currentRelatedProduct];
        [productName setText:product.name];
        [product setDelegate:self];
        product.productIndex = currentRelatedProduct;
        [product downloadImage];
    }
}

/*!
 @function      nextAction
 @abstract      set the next product image.
 @discussion    set the next related product images if exist.
 @param         void
 @result        void
 */
- (IBAction)nextAction:(id)sender
{
    if(currentRelatedProduct < [self.relatedProducts count]-1)
    {
        currentRelatedProduct++;
        Product *product = [self.relatedProducts objectAtIndex:currentRelatedProduct];
        
        if(product.image)
        {
            [imageView setImage:product.image];
        }
        else
        {
            [product setDelegate:self];
            product.productIndex = currentRelatedProduct;
            [product setDelegate:self];
            [product downloadImage];
            
            //set dummy image
            [imageView setImage:[UIImage imageNamed:kNoImagesImg]];
        }
        [productName setText:product.name]; 
        [previousButton setEnabled:TRUE];
    }
    
    if(currentRelatedProduct == [self.relatedProducts count]-1)
    {
        [nextButton setEnabled:FALSE];
    }
}

/*!
 @function      previousAction
 @abstract      set the previous product image.
 @discussion    set the previous related product images if exist.
 @param         void
 @result        void
 */
- (IBAction)previousAction:(id)sender
{
    if(currentRelatedProduct > 0)
    {
        currentRelatedProduct--;
        Product *product = [self.relatedProducts objectAtIndex:currentRelatedProduct];
        [productName setText:product.name]; 
    
        if(product.image)
        {
            [imageView setImage:product.image];
        }
        else
        {
            [imageView setImage:[UIImage imageNamed:kNoImagesImg]];
        }
        [nextButton setEnabled:TRUE];
    }
   
    if(currentRelatedProduct == 0)
    {
        [previousButton setEnabled:FALSE];
    }
}

#pragma mark - ImageDownloadComplete Delegate
-(void)imageDownloadComplete:(NSError*)error productIndex:(int)productIndex
{
	TRC_ENTRY
    Product* product = nil;
    if(currentRelatedProduct == productIndex)
    {
        product = [self.relatedProducts objectAtIndex:currentRelatedProduct];
    }
	if (error)
	{
		TRC_ERR(@"%@",error)
         product.image = [UIImage imageNamed:kNoImagesImg];
	}
	else
	{		
		TRC_DBG(@"Setting related product image" )

        if(!product.image)
        {
            product.image = [UIImage imageNamed:kNoImagesImg];                
        }
	}
    [imageView setImage:product.image];
	TRC_EXIT
}

- (void)dealloc
{
    _delegate = nil;
    [_tapRecognizer release];
    [_relatedProducts release];
    [imageView release];
    [productName release];
    [super dealloc];
}

@end
