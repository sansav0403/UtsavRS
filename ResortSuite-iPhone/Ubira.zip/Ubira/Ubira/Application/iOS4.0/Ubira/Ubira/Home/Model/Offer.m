//
//  Offer.m
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "Offer.h"
#import "ImageDownloadQueue.h"

@implementation Offer

@synthesize offerId, imageUrl,price,description,offerurl,storeId,expireDate;
@synthesize image = _image;
@synthesize delegate = _delegate;
@synthesize coverIndex = _coverIndex;

/*!
 @function		dealloc
 @abstract		release data member variables
 @discussion	release data member variables
 @param			none
 @result		void
 */

- (void)dealloc
{
    if ([_imageDownloadOperation isExecuting]) {
        [_imageDownloadOperation removeObserver:self forKeyPath:@"isFinished"];    
    } 
    [_imageDownloadOperation release];
    
	[offerId release];
	[imageUrl release];
	[price release];
	[description release];
	[offerurl	release];
	[storeId	release];
    [_image     release];
	[super dealloc];
}

/*!
 @function      downloadImage
 @abstract      Request to start download image.
 @discussion    Request to start download image.
 @param         none
 @result        void
 */
- (void)downloadImage
{
    if (imageRequestInProgress == NO) {
        NSURLRequest *imageUrlRequest = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:self.imageUrl]];
        _imageDownloadOperation = [[RemoteDataOperation alloc] initWithUrlRequest:imageUrlRequest];
        [_imageDownloadOperation addObserver:self forKeyPath:@"isFinished" options:NSKeyValueObservingOptionNew context:NULL];
        [[ImageDownloadQueue sharedQueue] addOperation:_imageDownloadOperation];	
        [imageUrlRequest release];
        imageRequestInProgress = YES;
    }
}

#pragma mark RemoteDataOperation keyValue callback method
/*!
 @function      observeValueForKeyPath
 @abstract      RemoteDataOperation keyValue callback
 @discussion    RemoteDataOperation keyValue callback
 @result        void
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
	@try {
		RemoteDataOperation* remoteDataOperation = (RemoteDataOperation*)object;
		[remoteDataOperation removeObserver:self forKeyPath:@"isFinished"];
		if( [remoteDataOperation error] ) 
		{
			[self.delegate imageDownloadComplete:[remoteDataOperation error] offerIndex:self.coverIndex];
		} 
		else
		{
			self.image = [UIImage imageWithData:remoteDataOperation.remoteData] ;
           
			[self.delegate imageDownloadComplete:nil offerIndex:self.coverIndex];
		}
		if( remoteDataOperation == _imageDownloadOperation ) {
			[_imageDownloadOperation release];
			_imageDownloadOperation =  nil;
		}
        imageRequestInProgress = NO;
        
	}
	@catch (NSException * exception) {
		TRC_EXCEPTION(exception);

	}
}

@end