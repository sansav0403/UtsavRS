//
//  LogoutReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "LogoutReqResHandler.h"


@implementation LogoutReqResHandler

@synthesize userBasicDetails =_user;

/*!
    @function       logOut
    @abstract       logOut and update session details from server
    @discussion     logOut and update session details from server
    @param          user - user detais to logout from server
 */
- (void)logOut:(User*)user
{
	self.userBasicDetails = user;
	
	NSString* postData = [NSString stringWithFormat:@"userid=%@",self.userBasicDetails.userId];
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];	
	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/signout",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
}

- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
	TRC_ENTRY

	if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:nil];
    }
}

- (void)dealloc
{	
	[_user release];
	[super dealloc];
}

@end
