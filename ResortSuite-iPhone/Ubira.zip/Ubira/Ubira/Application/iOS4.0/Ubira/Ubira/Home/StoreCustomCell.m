//
//  StoreCustomCell.m
//  Ubira
//
//  Created by [Cybage Team] Parihar on 23/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "StoreCustomCell.h"

@implementation StoreCustomCell
@synthesize storeNameLbl;
@synthesize storeAddressLbl;
@synthesize storeImageView, storeCheckInBtn;
@synthesize delegate = _delegate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) 
    {
        // Initialization code.
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];    
}

/*!
 @function      setStoreData
 @abstract      set the data to store cell
 @discussion    set the data like text and image to store cell
 @param         currStore - object of store for cell
 @result        void
 */
- (void)setStoreData:(Store *)currStore
{   
	store = currStore;
	
	// set the text for store name and address
	[storeNameLbl setText:store.name];
	[storeAddressLbl setText:store.address];
	
	if (!store.storeImage)
	{
		[store setDelegate:self];
		
		//check is imageUrl not null
		([store.imageUrl isKindOfClass:[NSNull class]])?[storeImageView setImage:[UIImage imageNamed:kNoImagesImg]]:[store downloadImage];
	}
	else
	{
		[storeImageView setImage:store.storeImage];
	}
	
	// set text, tag and action for every chekin button
	[storeCheckInBtn setTitle:kCheckInButtonTitle forState:UIControlStateNormal];
}

/*!
 @function      checkInToStoreAction
 @abstract      checkIn button action.
 @discussion    checkIn button action to delegate to the update price screen.
 @param         id.
 @result        void
 */
- (IBAction)checkInToStoreAction:(id)sender
{
  	if([self.delegate respondsToSelector:@selector(checkInActionDelegate:)])
	{
		[self.delegate checkInActionDelegate:store];
	}
}

#pragma mark - ImageDownloadComplete Delegate
-(void)imageDownloadComplete:(NSError*)error storeIndex:(int)storeIndex
{
	TRC_ENTRY
	if (error)
	{
		TRC_ERR(@"Summary image %@",error)
        store.storeImage = [UIImage imageNamed:kNoImagesImg];
	}
	else
	{		
		TRC_DBG(@"Setting product summary image" )
        if(!store.storeImage)
            store.storeImage = [UIImage imageNamed:kNoImagesImg];
	}
    if(store.storeIndex == storeIndex)
    {
		[storeImageView setImage:store.storeImage];
    }
	TRC_EXIT
}

- (void)dealloc 
{
	_delegate = nil;
	[storeNameLbl release];
	[storeAddressLbl release];
	[storeImageView release];
	[storeCheckInBtn release];
    [super dealloc];
}


@end
