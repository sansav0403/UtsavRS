//
//  Notice.m
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "Notice.h"


@implementation Notice

@synthesize	noticeId,description,price,expireDate;

- (void)dealloc
{
	[noticeId release];
	[description release];
	[price release];
	[super dealloc];
}

@end
