//
//  FavouritesViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "FavouritesViewController.h"
#import "Favorites.h"
#import "ProductDetailsViewController.h"
#import "ImageDownloadQueue.h"
#import "UserAnalytics.h"

#define kFavoriteProductCell                    @"FavoriteProductCell"
#define kProductDetailsViewController           @"ProductDetailsViewController"

@implementation FavouritesViewController
@synthesize productTbl;
@synthesize activityIndicator;
@synthesize messageLabel;
@synthesize startDate = _startDate;
@synthesize favoritesListArray,selectedIndexPath;;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
	[[ImageDownloadQueue sharedQueue] cancelAllOperations];
    [favoriteReqResHandler release];
    [favoritesList release];
	[productTbl release];
	[activityIndicator release];
    [messageLabel release];
    [_startDate release];
    [favoritesListArray release];
    if (selectedIndexPath) {
        [selectedIndexPath release];
        selectedIndexPath = nil;
    }
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle
- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewDidLoad
{
    [self setTitle:kFavouritesTitle];
    [super viewDidLoad];
    
    [[self.navigationController navigationBar] setTintColor:kSCNavigationBarTintColor];    
	
	UIView	*view = [[UIView alloc]initWithFrame:CGRectZero];
	[self.productTbl setTableFooterView:view];
	[view release];
	
    [self.messageLabel setText:kNoFavoritesAdded];
	self.navigationItem.rightBarButtonItem = [self editButtonItem];
    
    favoriteReqResHandler = [[FavoriteReqResHandler alloc] init];
    [favoriteReqResHandler setDelegate:self];
	
	[activityIndicator setHidesWhenStopped:YES];
    
    // get favorites details
    [self refreshData];
	
}

- (void)viewDidUnload
{
    [self setMessageLabel:nil];
   	[productTbl release];
	productTbl  = nil;
	[self setActivityIndicator:nil];
    
     [super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated
{    
    [self setEditing:NO animated:NO];
    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsFavoritesScreen startDate:self.startDate endDate:[NSDate date]];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Parsing complete delegate
/*!
 @function      parseComplete
 @abstract      delegat on parse complete.
 @discussion    Take the action based on the parameter.
 @param         error - server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
	
	TRC_ENTRY
	if(error != nil)
	{
		TRC_ERR(@"Favorite Error : %@",error)
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kFavouritesTitle message:errorString delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
	}
	else
	{
		switch (favoritesRequestState) {
			case kFavoriteProductFetchRequest:
				{
					if([favoritesListArray count])
					{
						//update UI
                        [self.productTbl setHidden:NO];
                        [self.messageLabel setHidden:YES];
						TRC_DBG(@"Total Products = %d", [favoritesListArray count])						
						[self.productTbl reloadData];
					}
				}
				break;
			case kFavoriteProductDeleteRequest:
				{
                    // Delete the row from the data source.
                    [(NSMutableArray*)favoritesListArray removeObjectAtIndex:selectedIndexPath.row];
                    [productTbl beginUpdates];
                    [productTbl deleteRowsAtIndexPaths:[NSArray arrayWithObject:selectedIndexPath] withRowAnimation:UITableViewRowAnimationFade];
                    [productTbl endUpdates];
				}
				break;
			default:
				break;
		}
	}	
	[activityIndicator stopAnimating];
	
    if([favoritesListArray count]==0)
    {
        [self.productTbl setHidden:YES];
        [self.messageLabel setHidden:NO];
        
        //This will change button from edit to done if u have deleted last record from table
        [self setEditing:NO animated:NO];
    }
    
    [productTbl setUserInteractionEnabled:YES];
	TRC_EXIT
	
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
	TRC_DBG(@"No Of Rows : %d", [favoritesListArray count])
    return [favoritesListArray count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *identifier = kFavoriteProductCell;
    ProductCell *cell = (ProductCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if(!cell)
    {
        cell = [[[ProductCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];        
    }
    // Only load cached images; defer new downloads until scrolling ends
    {
        if (tableView.dragging == NO && tableView.decelerating == NO)
        {
            [self firstVisibleCellImageDownload:indexPath productCell:cell];
        }
        // if a download is deferred or in progress, return a placeholder image
        cell.imageView.image = [UIImage imageNamed:@"Placeholder.png"];                
    }
    if ([favoritesListArray count]) {
        Favorites *favoritesObj = [favoritesListArray objectAtIndex:indexPath.row];
        [cell setProductData:favoritesObj.product index:indexPath.row];
    }    
    return cell;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self loadImagesForOnscreenRows];
}

/*!
 @function      firstVisibleCellImageDownload
 @abstract      load the images for the products if user is not scrolled the scrollview
 @discussion    load the images for the products if user is not scrolled the scrollview.
 @param         NSIndexPath
                productCell
 @result        void
 */
- (void)firstVisibleCellImageDownload:(NSIndexPath*)indexPath productCell:(ProductCell*)productCell
{
    // Only load cached images; defer new downloads until scrolling ends
    if ([favoritesListArray count]) {
        Favorites *favoritesObj = [favoritesListArray objectAtIndex:indexPath.row];
        if(!favoritesObj.product.image)
        {
            [favoritesObj.product setProductIndex:indexPath.row];
            [favoritesObj.product setDelegate:productCell];
            [favoritesObj.product downloadImage];
        }
    }	
}

/*!
 @function      loadImagesForOnscreenRows
 @abstract      load the images for the products
 @discussion    load the images for the products.
 @param         void
 @result        void
 */
- (void)loadImagesForOnscreenRows
{
    NSArray *visibleCells = [productTbl indexPathsForVisibleRows];
    
    for(NSIndexPath *indexPath in visibleCells)
    {
        Favorites *favoritesObj = [favoritesListArray objectAtIndex:indexPath.row];
        ProductCell *productCell = (ProductCell*)[productTbl cellForRowAtIndexPath:indexPath];
        if(!favoritesObj.product.image)
        {
            TRC_DBG(@"Start Download");
            [favoritesObj.product setProductIndex:indexPath.row];
            [favoritesObj.product setDelegate:productCell];
            [favoritesObj.product downloadImage];
        }
    }
}

 // Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 
	 if (editingStyle == UITableViewCellEditingStyleDelete) 
     {
		 TRC_DBG(@"commitEditingStyle : Delete")		 
		 self.selectedIndexPath = indexPath;
         
         [self showAlertView:nil alertMessage:kDeleteConfrmationDescription setDelegate:self];
	 }   
}
 
#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
      
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
    //Selected product for details
    Favorites *favoritesObj = [favoritesListArray objectAtIndex:indexPath.row];
    
	if(favoritesObj.product.productId){
		TRC_DBG(@"Product ID : %@",favoritesObj.product.productId)
		
		//Navigate to details screen of the selected product
		ProductDetailsViewController *productDetailsViewController = [[ProductDetailsViewController alloc] initWithNibName:kProductDetailsViewController bundle:[NSBundle mainBundle]];
		[productDetailsViewController setProduct:favoritesObj.product];
		
		[self.navigationController pushViewController:productDetailsViewController animated:YES];
		[productDetailsViewController release];
	}
}

/*!
 @function      setEditing
 @abstract		Allow editing of textfields in editing mode
 @discussion	Allow editing of textfields in editing mode
 @param			editing - bool value set editing true or false
                animated - bool value set animation to be done 
 @result		void
 */
- (void)setEditing:(BOOL)editing animated:(BOOL)animated 
{
	[super setEditing:editing animated:animated];
	[productTbl setEditing:editing];
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function		showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
                alertMessage - Message description for AlertView		
 @result		void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kButtoncancel otherButtonTitles:kButtonOk, nil];
	[alert show];
	[alert release];
}

/*!
 @method		clickedButtonAtIndex
 @abstract		redirect to Login Page 
 @discussion	redirect to Login Page when password sent successfully
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	switch (buttonIndex)
    {
        case 0:
                // handle cancel event of alert box
            break;
        case 1:
        {
            Favorites *favoritesObj = [favoritesListArray objectAtIndex:selectedIndexPath.row];
             favoritesRequestState	= kFavoriteProductDeleteRequest;
             [favoriteReqResHandler deleteFavorite:favoritesObj.favoriteId];
            [activityIndicator setHidden:NO];
            [activityIndicator startAnimating];
            [productTbl setUserInteractionEnabled:NO];
        }
            break;    
        default:
            break;
    }
}

#pragma Other Methods
/*!
 @function		refreshData
 @abstract		refresh favorites data
 @discussion	refresh favorites data 
 @param			none
 @result		void
 */
- (void)refreshData
{
    [productTbl setUserInteractionEnabled:NO];
    
    [activityIndicator setHidden:NO];
    [activityIndicator startAnimating];
    
    //get the favorites from the server
	if(favoritesListArray)
	{
		[favoritesListArray release];
        favoritesListArray = nil;
	}
    favoritesListArray = [[NSMutableArray alloc] init];	
	favoritesRequestState	= kFavoriteProductFetchRequest;
    [favoriteReqResHandler favorites:favoritesListArray];
}

@end
