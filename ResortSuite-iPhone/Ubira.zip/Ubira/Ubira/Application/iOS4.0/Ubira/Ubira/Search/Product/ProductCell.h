//
//  ProductCell.h
//  Ubira
//
//  Created by [Cybage Team] on 25/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RatingView.h"
#import "ProductData.h"
#import "Product.h"

/*!
    @class         ProductCell
    @abstract      create the custom product cell.
    @discussion    create the custom cell for all the screens which are showing the product in list.
 */
@interface ProductCell : UITableViewCell  <ImageDownloadDelegate>{
    UILabel                 *productTitleLbl;
    UILabel                 *productDescriptionLbl;
    UIImageView             *productImageView;
    UIActivityIndicatorView *activityIndicatorView;
    RatingView              *ratingView;
    Product                 *product;
}

- (void) setProductData :(ProductData*) productData;
- (void)setProductData:(Product*)aProduct index:(int)index;

@end
