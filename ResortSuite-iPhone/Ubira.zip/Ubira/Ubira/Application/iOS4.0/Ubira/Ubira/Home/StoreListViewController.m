//
//  StoreListViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "StoreListViewController.h"
#import "AddNewStoreViewController.h"
#import "HomeViewController.h"
#import "ImageDownloadQueue.h"
#import "UserAnalytics.h"
#import "LocationManager.h"
 
@implementation StoreListViewController

@synthesize storeList = _storeList, store = _store;
@synthesize storeListtblView;
@synthesize activityIndicatorView;
@synthesize spinner;
@synthesize startDate = _startDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil url:(NSString *)offerUrl
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
	[[ImageDownloadQueue sharedQueue] cancelAllOperations];
    [storeListtblView release];
    [activityIndicatorView release];
    [spinner release];
    
    
	[_storeReqResHandler	release];
	[_storeList				release];
    [_startDate release];
    [super					dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
	[super viewDidLoad];
	[self setTitle:kStoreTitle];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
	
    UIView	*view = [[UIView alloc]initWithFrame:CGRectZero];
	[storeListTblView setTableFooterView:view];
	[view release];
    
    [storeListTblView setBackgroundColor:[UIColor clearColor]];
    
    // set bool as no by default  
	ischeckInToStore = NO;
    
	//Set the navigationBar for adding a new store (Temporary commented)  
	//self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addStoreAction:)]autorelease];
   
}

- (void)viewDidUnload
{    
    [self setStoreListtblView:nil];
    [self setActivityIndicatorView:nil];
    [self setSpinner:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
    [self fetchStoreList];
}

- (void)viewWillDisappear:(BOOL)animated
{
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsStoreListScreen startDate:self.startDate endDate:[NSDate date]];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table view datasource and delegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	// Number of sections  
	return 1;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section 
{
	// Number of rows is the number of stores  
    TRC_DBG(@"array count : %d",[self.storeList count]);
	return [self.storeList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
	TRC_DBG(@"indexpath.row = %d and array count : %d",indexPath.row, [self.storeList count]);
	Store *localStore  = nil;
    if ([self.storeList count] > 0) {
        localStore  = [self.storeList objectAtIndex:indexPath.row];	
    }
    //Store *localStore  = [self.storeList objectAtIndex:indexPath.row];	
	static NSString *CellIdentifier = @"StoreCustomCellID";
	
    StoreCustomCell *cell = (StoreCustomCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        // Load the top-level objects from the custom cell XIB.
        NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"StoreCustomCell" owner:self options:nil];
        
        // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
        cell = [topLevelObjects objectAtIndex:0];
    }
    [cell setBackgroundColor:[UIColor clearColor]];
    
	// set delegate for storeCustomCell
	[cell setDelegate:self];
	[localStore setStoreIndex:indexPath.row];
    
	// set store for cell
	[cell setStoreData:localStore];

	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	// deselect the row after it has been selected.
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark 
#pragma mark Action Methods
/*!
 @function		addStoreAction
 @abstract		add a store
 @discussion	add a new store
 @param			none
 @result		void
*/
- (void)addStoreAction:(id)sender
{
	AddNewStoreViewController *addNewStoreObj = [[AddNewStoreViewController alloc]initWithNibName:@"AddNewStoreViewController" bundle:[NSBundle mainBundle]];	
	[self.navigationController pushViewController:addNewStoreObj animated:YES];
	[addNewStoreObj release];
}

#pragma mark 
#pragma mark Action Methods
/*!
 @function		checkInActionDelegate
 @abstract		check into a store delegate
 @discussion	check into a particuller store
 @param			aStore - Store class for which checkIn is done
 @result		void
 */
- (void)checkInActionDelegate:(Store *)aStore
{
	ischeckInToStore = YES;

	Store *sharedStore = [Store sharedStore];
	
	//Show activity indicator while checkin to store
	[self showActivityIndicator];
	[_storeReqResHandler checkIn:aStore.storeId storeInformation:sharedStore];
}

#pragma mark - Parsing complete delegate
/*!
 @function			parseComplete
 @abstract			delegat on parse complete.
 @discussion		Take the action based on the parameter.
 @param				error-server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
	TRC_ENTRY
	
	// Remove activity indicator
	[self stopActivityIndicator];
	
	if(error != nil)
	{
		TRC_ERR(@"%@",error)
		
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
		[self showAlertView:kStore alertMessage:errorString setDelegate:nil
						cancelButtonTitle:kButtonOk otherButtonTitle:nil];
	}
	else
	{
		//update UI		
		if (ischeckInToStore)
		{
			ischeckInToStore = NO;
            
            //Start Region Monitoring with checkedin location(region)
            [self startMonitoringCurrentLoction];
            
            [[NSNotificationCenter defaultCenter]postNotificationName:kCheckInCheckOutNotificationKey object:nil];

            [self.navigationController popViewControllerAnimated:YES];
		}
		else
		{
			if ([self.storeList count])
			{
				[storeListTblView reloadData];
			}
			else
			{
                //  Temoprary commented to remove creating a new store    //
				//[self showAlertView:kNoStoreFound alertMessage:kNoStoreFoundDescription setDelegate:self
				//  cancelButtonTitle:kButtoncancel otherButtonTitle:kButtonCreateStore];
                
                [self showAlertView:kNoStoreFound alertMessage:kNoStoreFoundDescription setDelegate:nil cancelButtonTitle:kButtoncancel otherButtonTitle:nil];
			}	
		}
	}
	TRC_EXIT
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function			showAlertView
 @abstract			Common method to display alert message 
 @discussion		Common method to display alert message 
 @param				alertTitle - Title for AlertView
					alertMessage - Message description for AlertView		
 @result			void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage 
					setDelegate:(id)currentDelegate 
					cancelButtonTitle:(NSString *)cancelButtonTitle
					otherButtonTitle:(NSString *)otherButtonTitle
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage 
						delegate:currentDelegate cancelButtonTitle:cancelButtonTitle 
						otherButtonTitles:otherButtonTitle, nil];
	[alert show];
	[alert release];
}

/*!
 @method			clickedButtonAtIndex
 @abstract			redirect to Add Store or Home page 
 @discussion		redirecting to Add Store page when Create Store button tapped
					redirecting to Home page when Cancel button tapped
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	switch (buttonIndex) {
		case 0:
		{
			[self.navigationController popViewControllerAnimated:YES];
		}
			break;
		case 1:
		{
			AddNewStoreViewController *addNewStoreObj = [[AddNewStoreViewController alloc]initWithNibName:@"AddNewStoreViewController" bundle:[NSBundle mainBundle]];	
			[self.navigationController pushViewController:addNewStoreObj animated:YES];
			[addNewStoreObj release];
		}
			break;
		default:
			break;
	}
	
}

#pragma mark 
#pragma mark Other Methods
/*!
 @function			fetchStoreList
 @abstract			fetch the store listfrom server
 @discussion		fetch the store listfrom server
 @param				none
 @result			Void
 */
- (void)fetchStoreList
{
	//Get the store List to display. 
    if(_storeReqResHandler)
    {
        [_storeReqResHandler release];
        _storeReqResHandler = nil;
    }
    _storeReqResHandler = [[StoreReqResHandler alloc]init];
    _storeReqResHandler.delegate = self;
    
    // Show indicator while fetching store list 
    [self showActivityIndicator];
    
    if (_storeList)
    {
        [_storeList release];
        _storeList = nil;
    }
    _storeList = [[NSMutableArray alloc]init];
    [_storeReqResHandler storeList:self.storeList];	
}

/*!
 @function			showActivityIndicator
 @abstract			show activity indicator
 @discussion		show activity indicator while process is running in background
 @param				none
 @result			Void
 */
- (void)showActivityIndicator
{
	// Show activity indicator while searching for location
	[self.view addSubview:activityIndicatorView];
	[spinner startAnimating];	
}

/*!
 @function			stopActivityIndicator
 @abstract			stop activity indicator
 @discussion		stop activity indicator and remove from superview
 @param				none
 @result			Void
 */
- (void)stopActivityIndicator
{
	// stop running activity indicator
	[spinner stopAnimating];
	[activityIndicatorView removeFromSuperview];
}

/*! 
 @function			locationFailed
 @abstract			when location service failes 	
 @discussion		when location service failes retrive errore code for further action
 @param				NSNotification - notification object from failure 
 @result			void
 */
- (void)locationFailed:(NSNotification *)aNotification
{
    [[LocationManager sharedInstance]stop];
    NSError *err = [aNotification object];
    if(err && [err code] == kCLErrorDenied)
    {
        [self showAlertView:kCheckInButtonTitle alertMessage:kCheckInDescription setDelegate:nil cancelButtonTitle:kButtonOk otherButtonTitle:nil];
    }
    else if(!err)
    {
        [self fetchStoreList];
    }
}

/*! 
 @function			startMonitoringCurrentLoction
 @abstract			it will start region monitoring 
 @discussion		it will start region monitoring using location manager
 @param				none
 @result			void
 */
- (void)startMonitoringCurrentLoction
{
    [[LocationManager sharedInstance] startRegionMonitoring];
}

@end
