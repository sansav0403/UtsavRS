//
//  UbiraAppDelegate.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LoginViewController.h"
#import "ProductReviewReqResHandler.h"
#import "LoginReqResHandler.h"

@interface UbiraAppDelegate : NSObject <UIApplicationDelegate,LoginViewControllerDelegate,UITabBarControllerDelegate> {
   
    IBOutlet LoginViewController        *loginViewController;
    IBOutlet UIWindow                   *_window; 
    IBOutlet UITabBarController         *_tabBarController;
    IBOutlet UIView                     *activityIndicatorView; 
    IBOutlet UIActivityIndicatorView    *spinner;
    UINavigationController              *navigationController;
	
	LoginReqResHandler                  *loginReqResHandler;

    NSArray                             *review;
}

@property (nonatomic, retain) IBOutlet UIWindow             *window;
@property (nonatomic, retain) IBOutlet UITabBarController   *tabBarController;

- (void)redirectToLoginView;
- (void)setTabBarItemText;
- (void)handleLogOut;

@end
