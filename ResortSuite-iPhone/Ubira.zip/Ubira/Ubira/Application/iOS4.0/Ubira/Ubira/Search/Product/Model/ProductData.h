//
//  ProductData.h
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "RemoteDataOperation.h"

@class ProductSearch;

@interface ProductData : NSManagedObject {
    
    RemoteDataOperation		*_imageDownloadOperation;
    BOOL                    imageRequestInProgress;
}

@property (nonatomic, retain) NSString      *productId;
@property (nonatomic, retain) NSString      *productName;
@property (nonatomic, retain) NSString      *productDescription;
@property (nonatomic, retain) NSNumber      *rating;
@property (nonatomic, retain) NSNumber      *reviews;
@property (nonatomic, retain) NSNumber      *rowIndex;
@property (nonatomic, retain) NSString      *imageUrl;
@property (nonatomic, retain) NSData        *imageData;
@property (nonatomic, retain) NSDate        *creationDate;
@property (nonatomic, retain) ProductSearch *productDataToProductSearch;

- (void)downloadImage;

@end
