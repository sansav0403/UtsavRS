//
//  MerchantStore.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Store.h"

@interface MerchantStore : Store {

	NSString    *merchantId;
	NSString    *detailsUrl;
	NSString    *price;
	NSString    *productId;
}

@property (nonatomic, copy) NSString    *merchantId;
@property (nonatomic, copy) NSString    *detailsUrl;
@property (nonatomic, copy) NSString    *price;
@property (nonatomic, copy) NSString    *productId;

@end
