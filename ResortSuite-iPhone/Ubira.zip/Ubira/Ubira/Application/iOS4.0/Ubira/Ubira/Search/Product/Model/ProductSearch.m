//
//  ProductSearch.m
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "ProductSearch.h"

@implementation ProductSearch (CoreDataGeneratedAccessors)

- (void)addProductSearchToProductDataObject:(NSManagedObject *)value {    
    NSSet *changedObjects = [[NSSet alloc] initWithObjects:&value count:1];
    [self willChangeValueForKey:@"productSearchToProductData" withSetMutation:NSKeyValueUnionSetMutation usingObjects:changedObjects];
    [[self primitiveValueForKey:@"productSearchToProductData"] addObject:value];
    [self didChangeValueForKey:@"productSearchToProductData" withSetMutation:NSKeyValueUnionSetMutation usingObjects:changedObjects];
    [changedObjects release];
}

- (void)removeProductSearchToProductDataObject:(NSManagedObject *)value {
    NSSet *changedObjects = [[NSSet alloc] initWithObjects:&value count:1];
    [self willChangeValueForKey:@"productSearchToProductData" withSetMutation:NSKeyValueMinusSetMutation usingObjects:changedObjects];
    [[self primitiveValueForKey:@"productSearchToProductData"] removeObject:value];
    [self didChangeValueForKey:@"productSearchToProductData" withSetMutation:NSKeyValueMinusSetMutation usingObjects:changedObjects];
    [changedObjects release];
}

- (void)addProductSearchToProductData:(NSSet *)value {    
    [self willChangeValueForKey:@"productSearchToProductData" withSetMutation:NSKeyValueUnionSetMutation usingObjects:value];
    [[self primitiveValueForKey:@"productSearchToProductData"] unionSet:value];
    [self didChangeValueForKey:@"productSearchToProductData" withSetMutation:NSKeyValueUnionSetMutation usingObjects:value];
}

- (void)removeProductSearchToProductData:(NSSet *)value {
    [self willChangeValueForKey:@"productSearchToProductData" withSetMutation:NSKeyValueMinusSetMutation usingObjects:value];
    [[self primitiveValueForKey:@"productSearchToProductData"] minusSet:value];
    [self didChangeValueForKey:@"productSearchToProductData" withSetMutation:NSKeyValueMinusSetMutation usingObjects:value];
}

@end


@implementation ProductSearch

@dynamic searchString;
@dynamic pageSize;
@dynamic currentPage;
@dynamic productSearchToProductData;

@end
