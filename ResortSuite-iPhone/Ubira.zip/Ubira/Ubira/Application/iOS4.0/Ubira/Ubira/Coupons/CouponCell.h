//
//  CouponCell.h
//  Ubira
//
//  Created by [Cybage Team] on 08/06/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Coupon.h"

@interface CouponCell : UITableViewCell {
	
    //IBOutlets
    UILabel                 *couponDescriptionLbl;
	UILabel                 *couponExpireLbl;
	UIImageView             *newCouponLbl;
    
    //Others
	Coupon					*coupon;
}

- (void)setCouponData:(Coupon*)aCoupon;
-(NSDate*)convertToGMT:(NSDate*)sourceDate;

@end
