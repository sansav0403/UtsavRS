//
//  MerchantStore.m
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "MerchantStore.h"


@implementation MerchantStore

@synthesize merchantId,detailsUrl,price,productId;

@end
