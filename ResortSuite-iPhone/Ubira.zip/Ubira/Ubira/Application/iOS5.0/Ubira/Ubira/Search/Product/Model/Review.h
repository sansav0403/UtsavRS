//
//  Review.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Review : NSObject {

	NSString    *reviewId;
	NSDate      *createDate;
	NSString    *productId;
	NSString    *description;
	NSString    *author;
    int         rating;
}

@property(nonatomic,copy)   NSString    *reviewId;
@property(nonatomic,retain) NSDate      *createDate;
@property(nonatomic,copy)   NSString    *productId;
@property(nonatomic,copy)   NSString    *description;
@property(nonatomic,copy)   NSString    *author;
@property(nonatomic,assign) int         rating;

@end
