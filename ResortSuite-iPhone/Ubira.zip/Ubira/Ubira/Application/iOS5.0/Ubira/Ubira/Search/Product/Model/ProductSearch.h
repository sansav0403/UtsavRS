//
//  ProductSearch.h
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface ProductSearch : NSManagedObject {
    
@private
    
}

@property (nonatomic, retain) NSString  * searchString;
@property (nonatomic, retain) NSNumber  * pageSize;
@property (nonatomic, retain) NSNumber  * currentPage;
@property (nonatomic, retain) NSSet     * productSearchToProductData;

@end


@interface ProductSearch (CoreDataGeneratedAccessors)

- (void)addProductSearchToProductDataObject:(NSManagedObject *)value;
- (void)removeProductSearchToProductDataObject:(NSManagedObject *)value;
- (void)addProductSearchToProductData:(NSSet *)value;
- (void)removeProductSearchToProductData:(NSSet *)value;

@end
