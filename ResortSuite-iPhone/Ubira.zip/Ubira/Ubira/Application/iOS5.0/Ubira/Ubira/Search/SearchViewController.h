//
//  SearchViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"
#include "RakutenImageUtil.h"

/*!
 @class          SearchViewController
 @abstract       handler the search request response.
 @discussion     handle the text and barcode search for product.
 */ 
@interface SearchViewController : UIViewController<ZBarReaderDelegate, RakutenImageUtilDelegate, UIActionSheetDelegate>{
    
    IBOutlet UISearchBar        *searchBar;
    IBOutlet UIButton           *scanBtn;
    IBOutlet UILabel            *notCheckInReminderLbl;
    ZBarReaderViewController    *reader;
    NSDate                      *_startDate;
    RakutenImageUtil            *objRakutenImageUtil;
    
    IBOutlet UIView             *overlayView;    
    IBOutlet UILabel            *overlayViewTopLbl;
    IBOutlet UIButton           *overlayViewCancelBtn;
    IBOutlet UIButton           *overlayViewCheckInBtn;
    IBOutlet UIView             *overlayViewToolbarTypeView;
    IBOutlet UILabel            *overlayNotCheckInReminderLbl;
}

@property (nonatomic, retain) IBOutlet UISearchBar  *searchBar;
@property (nonatomic, retain) IBOutlet UIButton     *scanBtn;
@property (nonatomic, retain) IBOutlet UILabel      *notCheckInReminderLbl;
@property (nonatomic, retain) NSDate                *startDate;

@property (nonatomic, retain) IBOutlet UIView       *overlayView;
@property (nonatomic, retain) IBOutlet UILabel      *overlayViewTopLbl;
@property (nonatomic, retain) IBOutlet UIButton     *overlayViewCancelBtn;
@property (nonatomic, retain) IBOutlet UIButton     *overlayViewCheckInBtn;
@property (nonatomic, retain) IBOutlet UIView       *overlayViewToolbarTypeView;
@property (nonatomic, retain) IBOutlet UILabel      *overlayNotCheckInReminderLbl;

- (IBAction)scanBarAction:(id)sender;
- (void)checkIntoStore;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;


- (void)scanImage:(UIImage*) image;
- (void)selectImageSourceForbarcode;
- (IBAction)overlayViewButtonAction:(id)sender;
- (void)scanBarcode;
@end
