//
//  ProductSummaryViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProductSummaryViewController.h"
#import "UserAnalytics.h"

#define kTotalPage 1

@implementation ProductSummaryViewController
@synthesize scrollView;
@synthesize pageControl;
@synthesize imageViewArray;
@synthesize descriptionLabel;
@synthesize descriptionView;
@synthesize productDetail;
@synthesize startDate = _startDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setTitle:self.productDetail.name];
    [self.descriptionLabel setText:kDescriptionTitle];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
    
    //Set the image controllers
    imageViewArray = [[NSMutableArray alloc] init];
    
    for (unsigned i = 0; i < kTotalPage; i++) 
    {
        UIImageView *imageController = [[UIImageView alloc] initWithImage:productDetail.image];        
        [imageViewArray addObject:imageController];
        CGRect frame = scrollView.frame;
        frame.size.height = (scrollView.bounds.size.height >= productDetail.image.size.height)? productDetail.image.size.height : scrollView.bounds.size.height ;
        frame.size.width = (scrollView.bounds.size.width >= productDetail.image.size.width)? productDetail.image.size.width : scrollView.bounds.size.width;
    
        frame.origin.x = (frame.size.width * i)+((scrollView.bounds.size.width - frame.size.width)/2);
        frame.origin.y = (scrollView.frame.size.height - frame.size.height)/2;
        imageController.frame = frame;
        [scrollView addSubview:imageController];
         [imageController setBackgroundColor: [UIColor redColor]];
    }
    
    [self.descriptionView setText:productDetail.description];
    scrollView.contentSize = CGSizeMake(scrollView.frame.size.width * kTotalPage, scrollView.frame.size.height);
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.scrollsToTop = NO;
    
    pageControl.numberOfPages = kTotalPage;
    pageControl.currentPage = 0;
}

- (void)viewDidUnload
{
    [self setPageControl:nil];
    [self setScrollView:nil];
    [self setDescriptionView:nil];
    [self setDescriptionLabel:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsUserProductSummaryScreen startDate:self.startDate endDate:[NSDate date]];
}

#pragma mark ScrollView Delegate
- (void)scrollViewDidScroll:(UIScrollView *)sender {
    if (pageControlUsed) {
        return;
    }
    CGFloat pageWidth = scrollView.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    pageControl.currentPage = page;
    
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    pageControlUsed = NO;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*!
 @function      pageChanged
 @abstract      pageChanged
 @discussion    this function will update the current page
 @param         id
 @result        void
 */
- (IBAction)pageChanged:(id)sender 
{
    int page = pageControl.currentPage;
    CGRect frame = scrollView.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
    [scrollView scrollRectToVisible:frame animated:YES];
    pageControlUsed = YES;
}

@end