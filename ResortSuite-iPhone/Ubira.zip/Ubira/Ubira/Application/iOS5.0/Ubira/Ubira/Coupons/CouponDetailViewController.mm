//
//  CouponDetailViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 09/06/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "CouponDetailViewController.h"
#import "ImageDownloadQueue.h"
#import "UserExtended.h"
#import "QREncoder.h"

@implementation CouponDetailViewController

@synthesize couponDescriptionLbl ,couponCodeLbl ,couponValidTillLbl ,couponImageView,couponCodeTitleLbl;
@synthesize coupon = _coupon;

- (void)viewDidLoad {
    [super viewDidLoad];
	
	[self setTitle:kUbiraTitle];
	[self updateDataValue];
}

- (void)didReceiveMemoryWarning {
   
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
   
    self.couponImageView = nil;
    self.coupon = nil;
    self.couponDescriptionLbl = nil;
    self.couponCodeLbl = nil;
    self.couponValidTillLbl = nil;	
	self.couponCodeTitleLbl = nil;
    [super viewDidUnload];
}

- (void)dealloc {
    
	[[ImageDownloadQueue sharedQueue] cancelAllOperations];
}

- (void)updateDataValue
{
	[couponCodeTitleLbl setText:kCouponCodeLabelTitle];
	[couponImageView setImage:[UIImage imageNamed:kNoImagesImg]];
	[couponDescriptionLbl setText:self.coupon.description];
	[couponCodeLbl setText:self.coupon.code];	
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];			
	//[dateFormatter setDateFormat:@"dd/MM/yyyy"];
    [dateFormatter setDateFormat:kDateFormatDisplay];
    
	[couponValidTillLbl setText:[NSString stringWithFormat:@"%@ %@",kValidTill, [dateFormatter stringFromDate:self.coupon.expireDate]]];
	[self generateQRCodeImage];
}

/*!
 @function		generateQRCodeImage
 @abstract		generate QRCode image 
 @discussion	generate QRCode image using User id and Coupon code  
 @param			none
 @result		void
 */
- (void)generateQRCodeImage
{
    UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
    
    //the qrcode is square. now we make it 150 pixels wide
    int qrcodeImageDimension = 150;
    
    //the string can be very long
   // NSString    *textToConvertInQRCode = nil;
    
    NSString *qrJsonText = [NSString stringWithFormat:@"{\"coupon\":{\"userid\":\"%@\", \"couponcode\":\"%@\"}}",userExtendedObj.userId,self.coupon.code];
    
    //textToConvertInQRCode = [qrJsonText stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    //first encode the string into a matrix of bools, TRUE for black dot and FALSE for white. Let the encoder decide the error correction level and version
    DataMatrix* qrMatrix = [QREncoder encodeWithECLevel:QR_ECLEVEL_AUTO version:QR_VERSION_AUTO string:qrJsonText];
    
    //then render the matrix
    UIImage* qrcodeImage = [QREncoder renderDataMatrix:qrMatrix imageDimension:qrcodeImageDimension];
    
    //and that's it!
    [self.couponImageView setImage:qrcodeImage];
    [self.couponImageView setContentMode:UIViewContentModeScaleToFill];
    [self.couponImageView setBackgroundColor:[UIColor greenColor]];
}

@end