//
//  HomeViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OfferReqResHandler.h"
#import "NoticeReqResHandler.h"
#import "Offer.h"
#import "Notice.h"
#import "AFOpenFlowView.h"
#import "RemoteDataOperation.h"
#import "StoreListViewController.h"

#define kCheckInTag  1
#define kCheckOutTag 2

/*!
    @class			HomeViewController
    @abstract		This class shows the notices along with coverflow effect  
    @discussion		This class shows the notices along with coverflow effect
*/
@interface HomeViewController : UIViewController <RequestResponseBaseDelegate> 
{
	// IBOutlets
	IBOutlet UIView         *coverFlowHolderView;
	IBOutlet UILabel		*storeNameLbl;
	IBOutlet UILabel		*userNameLbl;
	IBOutlet UILabel		*welcomeLbl;
	IBOutlet UILabel		*offersForYouLbl;
	IBOutlet UILabel		*crunchBusterOfferLbl;
	IBOutlet UILabel		*noticesHeaderLbl;
	IBOutlet UILabel		*noticesLbl;
	IBOutlet UITextView		*noticesTextView;
	IBOutlet UIButton		*checkInBtn;
		
	// View objects
    AFOpenFlowView *coverFlowView;
    
	// Others
	NoticeReqResHandler		*_noticeReqResHandler;
	
    NSDate                  *_startDate;
	NSArray					*_noticeList;
}

@property (nonatomic,retain) IBOutlet UIView        *coverFlowHolderView;
@property (nonatomic,retain) IBOutlet UILabel		*storeNameLbl;
@property (nonatomic,retain) IBOutlet UILabel		*noticesHeaderLbl;
@property (nonatomic,retain) IBOutlet UILabel		*welcomeLbl;
@property (nonatomic,retain) IBOutlet UILabel		*userNameLbl;
@property (nonatomic,retain) IBOutlet UILabel		*offersForYouLbl;
@property (nonatomic,retain) IBOutlet UILabel		*crunchBusterOfferLbl;
@property (nonatomic,retain) IBOutlet UILabel		*noticesLbl;
@property (nonatomic,retain) IBOutlet UITextView	*noticesTextView;
@property (nonatomic,retain) IBOutlet UIButton		*checkInBtn;
@property (nonatomic,retain) NSDate                 *startDate;
@property (nonatomic,retain) NSArray                *noticeList;

- (void)setLocalizableText;
- (void)setUpViewFor:(NSInteger)checkFlag;
- (void)offersAndNotices;
- (void)checkOutFromStore;

- (IBAction)checkInAction:(id)sender;

@end
