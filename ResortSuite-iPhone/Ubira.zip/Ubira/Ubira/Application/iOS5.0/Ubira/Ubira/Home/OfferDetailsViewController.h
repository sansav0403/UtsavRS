//
//  OfferDetailsViewController.h
//  Ubira
//
//  Created by [Cybage Team]  on 23/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>

/*!
    @class          OfferDetailsViewController
    @abstract       This class show the details for selected offer
    @discussion     This class show the details for selected offer
*/
@interface OfferDetailsViewController : UIViewController 
{
	// IBOutlets
	IBOutlet UIWebView	*webView;
	
	// Others
	NSString			*_offerUrl;
    NSDate              *_startDate;
}

@property(nonatomic,retain) IBOutlet UIWebView	*webView;
@property(nonatomic,retain) NSString            *offerUrl;
@property (nonatomic,retain) NSDate             *startDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil url:(NSString *)offerUrl;

@end
