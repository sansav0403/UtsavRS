//
//  ForgotPasswordReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "ForgotPasswordReqResHandler.h"

@implementation ForgotPasswordReqResHandler

/*!
 @function      forgetPassword
 @abstract		forgetPassword request to server.
 @discussion	forgetPassword request to server.
 @param			email - email address which is registred on server.
 @result		void
 */
- (void)forgetPassword:(NSString*)email
{
	NSString* postData = [NSString stringWithFormat:@"email=%@"
						  ,email];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/password/forgot",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
}

/*!
 @function		handleReceivedData
 @abstract		response data for forgot password request to server.
 @discussion	response data for forgot password request to server.
 @param			data - response data
 @result		bool
 */
- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
	TRC_ENTRY
    @try {
        //Update the caller
        if([self.delegate respondsToSelector:@selector(parseComplete:)])
        {
            [self.delegate parseComplete:nil];
        }        
	}
	@catch (NSException * exception) {
		TRC_EXCEPTION(exception); 
	}
		
	TRC_EXIT
}

@end