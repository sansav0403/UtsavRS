//
//  ProductSummaryCell.m
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProductSummaryCell.h"

@implementation ProductSummaryCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self.contentView setBackgroundColor:[UIColor whiteColor]];
        
         UIImageView *imgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"disclosure.png"]];
        [imgView setContentMode:UIViewContentModeScaleAspectFit];
        [imgView setFrame:CGRectMake(300, 0, 20, 94)];
        [imgView setBackgroundColor:[UIColor whiteColor]];
        [self.contentView addSubview:imgView];
          
        productImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:productImageView];
        
        descriptionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [descriptionLabel setBackgroundColor:[UIColor clearColor]];
        [descriptionLabel setLineBreakMode:UILineBreakModeWordWrap];
        [descriptionLabel setNumberOfLines:4];
        [descriptionLabel setFont:[UIFont systemFontOfSize:13.0]];
        
        [self.contentView addSubview:descriptionLabel];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        //set frame for the title
        frame = CGRectMake(100, 0, 200, 100);
        [descriptionLabel setFrame:frame];
        
        frame = CGRectMake(10, 7, 80, 80);
        [productImageView setFrame:frame];
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

/*!
 @function      setSummaryDetails
 @abstract      set product summary to cell.
 @discussion    set product summary to cell.
 @param         ProductDetail - product of which details need to set to cell.
 @result        void
 */
- (void)setSummaryDetails:(ProductDetail*)productDetail
{
    productDetails = productDetail;
    
    if(!productDetails.image)
    {
        [productDetails setDelegate:self];
        [productDetails downloadImage];
    }
    else
    {
        [productImageView setImage:productDetail.image];
    }
    CGRect rect = CGRectMake(100, 0, 200, [self calculateHeightForCell:productDetails.description]);
	[descriptionLabel setFrame:rect];
    
    [descriptionLabel setText:productDetails.description];
}

/*!
 @function      calculateHeightForCell
 @abstract      This function will calculate the hight for the lable.
 @discussion    This function will calculate the hight for the lable based on the description
                for the product and break the lable accordingly.
 @param         NSString - description of which details need to set to cell.
 @result        void
 */
- (float)calculateHeightForCell:(NSString *)description
{
	CGSize size = [description sizeWithFont:[UIFont systemFontOfSize:13.0] constrainedToSize:CGSizeMake(200,160) lineBreakMode:UILineBreakModeWordWrap];
	return size.height + 10;
}

#pragma mark - ImageDownloadComplete Delegate
-(void)imageDownloadComplete:(NSError*)error productIndex:(int)productIndex
{
	TRC_ENTRY
	if (error)
	{
		TRC_ERR(@"Summary image %@",error)
        productDetails.image = [UIImage imageNamed:kNoImagesImg];
	}
	else
	{		
		TRC_DBG(@"Setting product summary image" )
        if(!productDetails.image)
                productDetails.image = [UIImage imageNamed:kNoImagesImg];
	}
    [productImageView setImage:productDetails.image];
	TRC_EXIT
}

@end