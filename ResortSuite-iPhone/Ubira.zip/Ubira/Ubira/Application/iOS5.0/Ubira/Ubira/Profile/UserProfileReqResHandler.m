//
//  UserProfileReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "UserProfileReqResHandler.h"
#import "UserExtended.h"
#import "UbiraAppDelegate.h"
#import "LocationManager.h"

#define kProfile @"profile"
#define kProfileUpdate @"Profile"
#define kAddress @"address"
#define kEMail @"email"
//#define kNoUserExist 50005

@interface UserProfileReqResHandler ()
- (void)parseProfileDetails:(NSData *)data;
- (void)parseUpdateProfileResponse:(NSData*)data;
@end

@implementation UserProfileReqResHandler

@synthesize userDetails = _userDetails, userProfileReqState = _userProfileReqState;

/*!
 @function      profile
 @abstract      get user profile details.
 @discussion    get user profile details.
 @param         userDetail - result will be return in this parameter.
 */
- (void)profile:(UserExtended*)userDetail
{
    TRC_ENTRY	
	self.userDetails = userDetail;
	self.userProfileReqState = kUPReqGetProfile;
	
	//user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
	NSString* queryString = [NSString stringWithFormat:@"%@/profile/get/?userid=%@"
							 ,kUbiraServerUrl
							 ,userId];
	
	NSURL* url = [NSURL URLWithString:queryString];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kGet];			
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      updateProfile
 @abstract      update user profile details to server.
 @discussion    update user profile details to server.
 @param         coupons - result will be return in this parameter.
 */
- (void)updateProfile:(UserExtended*)userDetail
{
    TRC_ENTRY
	self.userProfileReqState = kUPReqUpdateProfile;
	
	self.userDetails = userDetail;

	//user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
	//User id mangement	
	NSString* deviceId = [[UIDevice currentDevice] uniqueIdentifier];
	
	NSString* postData = [NSString stringWithFormat:@"userid=%@&name=%@&email=%@&password=%@&password2=%@&address=%@&deviceid=%@&lat=%f&long=%f"
						  ,userId
						  ,self.userDetails.name
						  ,self.userDetails.email
						  ,self.userDetails.password
						  ,self.userDetails.password
						  ,self.userDetails.address
						  ,deviceId
						  ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
						  ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
						  ];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];
	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/profile/update",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      handleReceivedData
 @abstract      decides the action based on the request.
 @discussion    decides the action based on the request.
 @param         data - server response.
 */
- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
    TRC_ENTRY
	TRC_DBG(@"User Profile : handleReceivedData");
	
	switch (self.userProfileReqState) {
		case kUPReqGetProfile:
			{
				TRC_DBG(@" Get Profile parsing...");
                [self parseProfileDetails:data];
			}break;
		case kUPReqUpdateProfile:
			{
				TRC_DBG(@" Update Profile parsing...");
                [self parseUpdateProfileResponse:data];
			}break;			
			
		default:
			break;
	}
    
    TRC_EXIT
}

#pragma mark -
#pragma mark Private methods

/*!
 @function      parseProfileDetails
 @abstract      parse the profile details.
 @discussion    parse the profile details.
 @param         data - server response.
 */
- (void)parseProfileDetails:(NSData *)data
{
    //Get the json key value dictionary for the data
    NSString *resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    
    NSDictionary *resultDictionary = [resultString JSONValue];
    
    TRC_DBG(@"User Profile %@", resultDictionary);
    
    NSArray *resultList = [resultDictionary valueForKey:kProfile];
    
    if (![self isValid:resultList for:kNSArray]) {
        return;
    }
    
    NSError *error = nil;
    @try {
        //Create the all available coupon models 
        for(NSDictionary *userDict in resultList)
        {          
            NSString* valueString = [userDict valueForKey:kAddress];        
            if (![self isValidString:valueString]) {
                _userDetails.address = KEmptyString;
            }else{
                _userDetails.address = valueString;
            }
            
            valueString = [userDict valueForKey:kEMail];
            if (![self isValidString:valueString]) {
                _userDetails.email = KEmptyString;
            }else{
                _userDetails.email = valueString;
            }
            
            valueString = [userDict valueForKey:kName];
            if (![self isValidString:valueString]) {
                _userDetails.name = KEmptyString;
            }else{
                _userDetails.name = valueString;
            }
            
            valueString = [userDict valueForKey:kId];
            if (![self isValidString:valueString]) {
                _userDetails.userId = KEmptyString;
            }else{
                _userDetails.userId = valueString;
            }
        }
    }
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        self.userDetails = nil;
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kInvalidDataErr userInfo:userInfo];
        
    }
    
    //Update the caller about the result
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
}

/*!
 @function      parseUpdateProfileResponse
 @abstract      parse the update profile response.
 @discussion    parse the update profile response.
 @param         data - server response.
 */
- (void)parseUpdateProfileResponse:(NSData*)data
{	
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:nil];
    }
}

@end