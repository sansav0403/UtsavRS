//
//  UserExtended.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "User.h"

@interface UserExtended : User {

	NSString    *name;
	NSString    *address;
}

@property (nonatomic, copy) NSString    *name;
@property (nonatomic, copy) NSString    *address;

+ (id)sharedUserExteded;

@end
