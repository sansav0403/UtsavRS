//
//  Product.m
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "Product.h"
#import "ImageDownloadQueue.h"

@implementation Product

@synthesize productId = _productId;
@synthesize name = _name;
@synthesize description = _description;
@synthesize rating = _rating;
@synthesize reviews = _reviews;
@synthesize productIndex = _productIndex;
@synthesize imageUrl = _imageUrl;
@synthesize createDate = _createDate ;
@synthesize image = _image;
@synthesize delegate = _delegate;
@synthesize detailsUrl;

- (void)dealloc
{
    TRC_ENTRY
    _delegate = nil;
    
    if ([_imageDownloadOperation isExecuting]) {
        [_imageDownloadOperation removeObserver:self forKeyPath:@"isFinished"];    
    } 
    
    TRC_EXIT
}

/*!
 @function      downloadImage
 @abstract      Request to start download image.
 @discussion    Request to start download image.
 @param         none
 @result        void
 */
- (void)downloadImage
{
    if (imageRequestInProgress == NO) {
        NSURLRequest *imageUrlRequest = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:self.imageUrl]];
        _imageDownloadOperation = [[RemoteDataOperation alloc] initWithUrlRequest:imageUrlRequest];
        [_imageDownloadOperation addObserver:self forKeyPath:@"isFinished" options:NSKeyValueObservingOptionNew context:NULL];
        [[ImageDownloadQueue sharedQueue] addOperation:_imageDownloadOperation];	
        imageRequestInProgress = YES;
    }
}

#pragma mark RemoteDataOperation keyValue callback method
/*!
 @function      observeValueForKeyPath
 @abstract      RemoteDataOperation keyValue callback
 @discussion    RemoteDataOperation keyValue callback
 @result        void
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
	@try {
		RemoteDataOperation* remoteDataOperation = (RemoteDataOperation*)object;
		[remoteDataOperation removeObserver:self forKeyPath:@"isFinished"];
		if( [remoteDataOperation error] ) 
		{
			[self.delegate imageDownloadComplete:[remoteDataOperation error] productIndex:self.productIndex];
		} 
		else
		{
			self.image = [UIImage imageWithData:remoteDataOperation.remoteData];
			[self.delegate imageDownloadComplete:nil productIndex:self.productIndex];
		}
		if( remoteDataOperation == _imageDownloadOperation ) {
			_imageDownloadOperation =  nil;
		}
        imageRequestInProgress = NO;
	}
	@catch (NSException * e) {
		TRC_ERR(@"%@", [e reason]);
	}
}

@end