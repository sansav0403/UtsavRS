//
//  AddNewStoreViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "AddNewStoreViewController.h"
#import "ValidationHandler.h"
#import "HomeViewController.h"
#import "UserAnalytics.h"

@implementation AddNewStoreViewController
@synthesize storeMandatoryLbl = _storeMandatoryLbl;
@synthesize storeNameTxtField = _storeNameTxtField;
@synthesize storeAddressTxtField = _storeAddressTxtField;
@synthesize	storeTelNoTxtField =_storeTelNoTxtField;
@synthesize	storeDescriptionTxtView = _storeDescriptionTxtView;
@synthesize storeSubmitBtn = _storeSubmitBtn;
@synthesize store = _store;
@synthesize storeId = _storeId;
@synthesize startDate = _startDate;
@synthesize activityIndicatorView, spinner;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
	
	// set initial setup for view
	[self initialSetup];
	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
    viewFrame = self.view.frame;
    
	// set view animated
	ischeckInToStore = NO;
	
	// Observe keyboard hide and show notifications to resize the text view appropriately.
	[self addRequireObservers];
	
	_storeReqResHandler	= [[StoreReqResHandler alloc]init];
	_storeReqResHandler.delegate = self;
	
	_store = [[Store alloc]init];
	_storeId = [[NSMutableString alloc]init];
}

- (void)viewDidUnload
{
    [super viewDidUnload];

    [self setStoreMandatoryLbl:nil];
    [self setStoreNameTxtField:nil];
    [self setStoreAddressTxtField:nil];
    [self setStoreTelNoTxtField:nil];
    [self setStoreDescriptionTxtView:nil];
    [self setStoreSubmitBtn:nil];
    [self setActivityIndicatorView:nil];
    [self setSpinner:nil];
	
	// unregister for keyboard notifications while not visible.
	[self removeObservers];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsAddNewStoreScreen startDate:self.startDate endDate:[NSDate date]];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*!
 @function      initialSetup
 @abstract      set up initial text for page
 @discussion    set up initial text for page
 @param         non
 @result        void
*/
- (void)initialSetup
{
	// set navigation bar's title
	[self setTitle:kAddStore];
	
	// set text for buttons and textfield's placeholder text
	[self.storeMandatoryLbl setText:kStoreMandatoryText];
	[self.storeNameTxtField setPlaceholder:kStoreNamePlaceHolderText];
	[self.storeAddressTxtField setPlaceholder:kStoreAddressPlaceHolderText];
	[self.storeTelNoTxtField setPlaceholder:kStoreTelNoPlaceHolderText];
	[self.storeDescriptionTxtView setText:kStoreDescriptionPlaceHolderText];
    [self.storeDescriptionTxtView setTextColor:[UIColor lightGrayColor]];
	[self.storeSubmitBtn setTitle:kStoreSubmitButtonText forState:UIControlStateNormal];
	
    //set Initials
    viewFrame = self.view.frame;
    animatedDis=0;
    yForKeyBoard = 264;
}

#pragma mark 
#pragma mark TextField delegate Methods
/*!
 @function      textFieldShouldReturn
 @abstract		delegate for textField 
 @discussion	discard the keyboard when tap on return button of keyboard
 @param			textField - selected textField 
 @result		will return YES 
 */
- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{
	// descard the keyboard
	[textField resignFirstResponder];
	return YES;
}

/*!
 @function		textFieldShouldBeginEditing
 @abstract		delegate for textField 
 @discussion	check if the view is already animated if not then set active fields y for 
				animation
 @param			textField - selected textField 
 @result		will return YES 
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	return YES;
}

/*!
 @function		shouldChangeCharactersInRange
 @abstract		delegate for textField 
 @discussion	cheks if text field not exceeding the max character length 
 @result		will return YES 
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string   
{
    if ((range.location > 0 && [string length] > 0 && [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[string characterAtIndex:0]] &&           [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[[textField text] characterAtIndex:range.location - 1]])) 
    {
        return NO;
    }
    // if first character is a space
    if ([string isEqualToString:@" "] && [textField.text length]==0)
	{ 
		return NO;
	}
    
	// if user presses backspace key
	if ([string isEqualToString:@""]) 
	{
		return YES;
	}
	
	// set constraint on name field
	if ([textField isEqual:_storeNameTxtField] && [_storeNameTxtField.text length]>=kStoreNameMaxLength)
		return NO;
	
	// set constraint on phone field
	if ([textField isEqual:_storeTelNoTxtField] && [_storeTelNoTxtField.text length]>=kPhoneMaxLength)
		return NO;

	return YES;
}

/*!
 @function      textFieldDidBeginEditing
 @abstract      delegate for textField 
 @discussion    beign to end of text input animateView accordingly.
 @param         text - selected textfields 
 @result        void 
 */
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextControl:textField up:YES];
}

/*!
 @function      textFieldDidEndEditing
 @abstract      delegate for textField 
 @discussion    did end of text input animateView accordingly.
 @param         text - selected textfields 
 @result        void  
 */
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextControl:textField up:NO];
}

#pragma mark
#pragma mark TextView Delegate Methods
/*!
 @function		textViewShouldBeginEditing
 @abstract		delegate for textView
 @discussion	check if the view is already animated if not then set active 
                field's y for animation
 @param			textView - selected textField 
 @result		will return YES 
 */
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if([textView.text isEqualToString:kStoreDescriptionPlaceHolderText])
    {
        [textView setText:@""];
    }
	return YES;
}

/*!
 @function      textFieldDidBeginEditing
 @abstract      delegate for textField 
 @discussion    beign to end of text input animateView accordingly.
 @param         text - selected textfields 
 @result        void 
 */
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [self animateTextControl:(UIControl*)textView up:YES];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    if([textView.text length]<=0)
    {
        [textView setText:kStoreDescriptionPlaceHolderText];
        [textView setTextColor:[UIColor lightGrayColor]];
    }
    [self animateTextControl:(UIControl*)textView up:NO];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ((range.location > 0 && [text length] > 0 && [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[text characterAtIndex:0]] &&           [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[[textView text] characterAtIndex:range.location - 1]])) 
    {
        return NO;
    }
    
    if ([text isEqualToString:@" "] && [textView.text length]==0)
	{ 
		return NO;
	}
    else
    {
        [textView setTextColor:[UIColor blackColor]];
    }
    return YES;
}

#pragma mark
#pragma mark ViewAnimation Custom Methods

/*!
 @function      animateTextControl
 @abstract		animate view up or down when keyboard overlays
 @discussion	Common function to animate view up or down when keyboard overlays
                view's textfield or textView
 @param			keyboardWillHide
 @result		void
 */
- (void)animateTextControl:(UIControl*)textControl up:(BOOL)up
{
    CGPoint temp = [textControl.superview convertPoint:textControl.frame.origin toView:nil];
    if(up)
    {
        int moveUpValue = temp.y+textControl.frame.size.height;
        animatedDis = yForKeyBoard-(viewFrame.size.height-moveUpValue-5);
    }
    else
    {
        [self viewAnimationwithFrame:viewFrame]; 
        return;
    }
    if(animatedDis>0)
    {
        const int movementDistance = animatedDis;
        int movement = (up ? -movementDistance : movementDistance);
        [self viewAnimationwithFrame:CGRectOffset(self.view.frame, 0, movement)];
    }
}

/*!
 @function		viewAnimationwithFrame
 @abstract		animate view up or down 
 @discussion	Common function to animate view up or down when keyboard overlays
                view's textfield
 @param			currentFrame - Frame to set for View animation
 @result		void
 */
- (void)viewAnimationwithFrame:(CGRect)currentFrame
{
    [UIView beginAnimations: nil context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration:kViewUpDownAnimationDuration];
    
    self.view.frame = currentFrame;       
    [UIView commitAnimations];
}

#pragma mark -
#pragma mark KeyBoard delegate methods
/*!
 @function      keyboardWillShow
 @abstract		keyboard about to appear on view
 @discussion	keyboard about to appear on view
 @param			nNotification - notificationo object 
 @result		void
 */
- (void)keyboardWillShow:(NSNotification*)aNotification
{	
    // get size of keyboard
	NSDictionary *info = [aNotification userInfo];
	NSValue *aValue = [info objectForKey:UIKeyboardFrameEndUserInfoKey];
    yForKeyBoard = [aValue CGRectValue].origin.y;
}

#pragma mark 
#pragma mark Action Methods
/*!
 @method		backgroundTouched
 @abstract		discard keyboard when tapped on view apart from keyBoard
 @discussion	discard keyboard when tapped on view apart from keyBoard
 */
- (IBAction)backgroundTouched:(id)sender
{
	[_storeNameTxtField resignFirstResponder];
	[_storeAddressTxtField resignFirstResponder];
	[_storeTelNoTxtField resignFirstResponder];
	[_storeDescriptionTxtView resignFirstResponder];
}

- (IBAction)submitAction:(id)sender
{	
	[_storeTelNoTxtField resignFirstResponder];
	[_storeDescriptionTxtView resignFirstResponder];
	
	// If fields are validated then send it to server to create new store 
	if ([self validateTextFields])
	{
		self.store.name = _storeNameTxtField.text;
		self.store.address = _storeAddressTxtField.text;
		self.store.phone = _storeTelNoTxtField.text;
		self.store.description = _storeDescriptionTxtView.text;
		
        // show activity indicator
		[self showActivityIndicator];
        
		[_storeReqResHandler addStore:self.store storeid:self.storeId];
	}
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function      showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
				alertMessage - Message description for AlertView		
 @result		void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
	[alert show];
}

/*!
 @method		clickedButtonAtIndex
 @abstract		redirect to Login Page 
 @discussion	redirect to Login Page when password sent successfully
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	ischeckInToStore = YES;
	Store *sharedStore = [Store sharedStore];
	sharedStore.storeId = self.storeId;
    
	//Show activity indicator while checkin to store
	[self showActivityIndicator];
	[_storeReqResHandler checkIn:self.storeId storeInformation:sharedStore];
}

#pragma mark - Parsing complete delegate
/*!
 @function		parseComplete
 @abstract		delegat on parse complete.
 @discussion	Take the action based on the parameter.
 @param			error-server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
	TRC_ENTRY
	
	// Remove activity indicator
	[self stopActivityIndicator];
	
	if(error != nil)
	{
		ischeckInToStore = NO;
		TRC_ERR(@"%@",error)
		
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
		[self showAlertView:kStore alertMessage:errorString setDelegate:nil];
	}
	else
	{
		//update UI		
		if (ischeckInToStore)
		{
            //Post the notification when checkin is done
             [[NSNotificationCenter defaultCenter]postNotificationName:kCheckInCheckOutNotificationKey object:nil];
            
			//Store *shrStore = [Store sharedStore];
			ischeckInToStore = NO;
			[self.navigationController popToRootViewControllerAnimated:YES];
		}
		else
		{
			self.store.storeId = self.storeId;
			[self showAlertView:kStoreAddedSuccessfully alertMessage:kStoreAddedSuccessDescription setDelegate:self];	
		}
	}
	TRC_EXIT
}

#pragma mark
#pragma mark Observer Methods
/*! 
 @function      addRequireObservers
 @abstract		add the required observer to listen the notification 	
 @discussion	add the required observer to listen the notification
 @param			none
 @result		void
 */
- (void)addRequireObservers
{
	// Observe keyboard hide and show notifications to resize the text view appropriately.
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardDidShowNotification object:nil];
}

/*! 
 @function		removeObservers
 @abstract		remove observers from listening the notification 	
 @discussion	remove observers from listening the notification
 @param			none
 @result		void
 */
- (void)removeObservers
{
	// unregister for keyboard notifications while not visible.
	[[NSNotificationCenter defaultCenter] removeObserver:self 
                                                    name:UIKeyboardDidShowNotification object:nil];
}

#pragma mark 
#pragma mark Other Methods
/*!
 @function		showActivityIndicator
 @abstract		show activity indicator
 @discussion	show activity indicator while process is running in background
 @param			none
 @result		Void
 */
- (void)showActivityIndicator
{
	// Show activity indicator while searching for location
	[self.view addSubview:activityIndicatorView];
	[spinner startAnimating];
	self.navigationController.navigationBar.userInteractionEnabled = NO;	
}

/*!
 @function		stopActivityIndicator
 @abstract		stop activity indicator
 @discussion	stop activity indicator and remove from superview
 @param			none
 @result		Void
 */
- (void)stopActivityIndicator
{
	[spinner stopAnimating];
	[activityIndicatorView removeFromSuperview];
	self.navigationController.navigationBar.userInteractionEnabled = YES; 
}

/*!
 @function      validateTextFields
 @abstract      validate all text fields
 @discussion    validate all text fields
 @param         none
 @result        will return YES is all textField comply the business rule else NO
 */
- (BOOL)validateTextFields
{
   	// Check all fields are filled
	if ([_storeNameTxtField.text length]<=0)
	{
		[self showAlertView:nil alertMessage:kNoStoreAddedSuccessfullyDescription setDelegate:nil];
		return NO;
	}
	
	// check is phone valid
	if ([_storeTelNoTxtField.text length]>0 && ![ValidationHandler phoneValidate:_storeTelNoTxtField.text]) 
	{
		[self showAlertView:kPhoneInvalid alertMessage:kPhoneInvalidDescription setDelegate:nil];
		return NO;
	}
	
    if ([_storeDescriptionTxtView.text isEqualToString:kStoreDescriptionPlaceHolderText])
    {
        [_storeDescriptionTxtView setText:@""];
    }
	return YES;
}

@end