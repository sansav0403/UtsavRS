//
//  Notice.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Notice : NSObject {

	NSString    *noticeId;
	NSString    *description;
	NSString    *price;
	NSDate      *__unsafe_unretained expireDate;
}

@property (nonatomic, copy) NSString    *noticeId;
@property (nonatomic, copy) NSString    *description;
@property (nonatomic, copy) NSString    *price;
@property (nonatomic, assign) NSDate    *expireDate;

@end
