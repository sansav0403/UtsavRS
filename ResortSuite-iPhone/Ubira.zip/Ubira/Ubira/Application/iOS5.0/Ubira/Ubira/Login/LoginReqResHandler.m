//
//  LoginReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "LoginReqResHandler.h"
#import "LocationManager.h"

@implementation LoginReqResHandler

@synthesize userBasicDetails =_user;

/*!
 @function      logIn
 @abstract		login request to server.
 @discussion	login request to server.
 @param			user - user model class having user id
 @result		void
*/
- (void)logIn:(UserExtended*)user
{
	self.userBasicDetails = user;
	
	//Optional fields in this request lat and long
	NSString* postData = [NSString stringWithFormat:@"email=%@&password=%@"
						  ,self.userBasicDetails.email
						  ,self.userBasicDetails.password
						  ];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];	

	NSURL* url = [NSURL URLWithString:[NSString	stringWithFormat:@"%@/signin",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
	
}

/*!
 @function		handleReceivedData
 @abstract		response data for login request to server.
 @discussion	response data for login request to server.
 @param			data - response data
 @result		bool
*/
- (void)handleReceivedData: (NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
	TRC_ENTRY
	
	NSString* responseString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
	TRC_DBG(@"%@",responseString)
	
	NSDictionary *resultDictionary = [responseString JSONValue];	
	
	self.userBasicDetails.userId = [resultDictionary objectForKey:kUserId];
	TRC_DBG(@"User ID = %@", self.userBasicDetails.userId)
	
	self.userBasicDetails.name = [resultDictionary objectForKey:kName];
	TRC_DBG(@"User Name = %@", self.userBasicDetails.name)
	
	//Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:nil];
	}
	
	TRC_EXIT
}

@end