//
//  Offer.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RemoteDataOperation.h"

@protocol ImageDownloadDelegate

- (void)imageDownloadComplete:(NSError*)error offerIndex:(int)index;

@end

@interface Offer : NSObject {
	NSString                *offerId;
	NSString                *imageUrl;
	NSString                *price;
	NSString                *description;
	NSString                *offerurl;
	NSString                *storeId;
	NSDate                  *__unsafe_unretained expireDate;
	
	UIImage                 *_image;
    
	RemoteDataOperation		*_imageDownloadOperation;
	BOOL                    imageRequestInProgress;
	id<ImageDownloadDelegate>__unsafe_unretained _delegate;
	
	int                     _coverIndex;
}

@property (nonatomic, copy)   NSString                    *offerId;
@property (nonatomic, copy)   NSString                    *imageUrl;
@property (nonatomic, copy)   NSString                    *price;
@property (nonatomic, copy)   NSString                    *description;
@property (nonatomic, copy)   NSString                    *offerurl;
@property (nonatomic, copy)   NSString                    *storeId;
@property (nonatomic, assign) NSDate                      *expireDate;
@property (nonatomic, retain) UIImage                     *image;
@property (nonatomic, assign) id<ImageDownloadDelegate>	  delegate;
@property (nonatomic, assign) int                         coverIndex;

- (void) downloadImage;

@end
