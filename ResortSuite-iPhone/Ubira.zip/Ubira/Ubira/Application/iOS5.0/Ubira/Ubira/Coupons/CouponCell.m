//
//  CouponCell.m
//  Ubira
//
//  Created by [Cybage Team] on 08/06/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "CouponCell.h"

@implementation CouponCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code.        
        couponDescriptionLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [couponDescriptionLbl setBackgroundColor:[UIColor clearColor]];
		[couponDescriptionLbl setTextColor:[UIColor redColor]];
        [couponDescriptionLbl setFont:[UIFont systemFontOfSize:14]];
        [self.contentView addSubview:couponDescriptionLbl];
		
        newCouponLbl = [[UIImageView alloc] initWithFrame:CGRectZero];
        [newCouponLbl setBackgroundColor:[UIColor clearColor]];
        //[newCouponLbl setTextColor:[UIColor redColor]];
        //[newCouponLbl setFont:[UIFont systemFontOfSize:16]];
        [newCouponLbl setContentMode:UIViewContentModeScaleAspectFit];
        [self.contentView addSubview:newCouponLbl];
        
		couponExpireLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        [couponExpireLbl setBackgroundColor:[UIColor clearColor]];
        [couponExpireLbl setTextColor:[UIColor blackColor]];
        [couponExpireLbl setFont:[UIFont systemFontOfSize:14]];
        [self.contentView addSubview:couponExpireLbl];
        
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    
    [super setSelected:selected animated:animated];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;
        //set frame for the title      
		
        frame = CGRectMake(10, 0, 200, 40);
        [couponDescriptionLbl setFrame:frame];	
        
        frame = CGRectMake(210, 0, 60, 40);
        [newCouponLbl setFrame:frame];
		
		frame = CGRectMake(10, 22, 200, 40);
        [couponExpireLbl setFrame:frame];
	}
}

- (void)setCouponData:(Coupon*)aCoupon
{
	coupon = aCoupon;
	[couponDescriptionLbl setText:coupon.description];
	
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];			
    [dateFormatter setDateFormat:kDateFormatDisplay];
    
	[couponExpireLbl setText:[NSString stringWithFormat:@"%@ %@",kValidTill, [dateFormatter stringFromDate:coupon.expireDate]]];
    
    // If coupons are newly(below 10 mins) added then display New on the coupon title
    // convert server created time into GMT and then calculate the difference.
    [newCouponLbl setImage:[UIImage imageNamed:@"newLabel.png"]];
    NSDate *convertedCreateDate = [self convertToGMT:aCoupon.createDate];
    TRC_DBG(@"CouponDate =%@",aCoupon.createDate);
    TRC_DBG(@"GMTconvertedCreateDate =%@",convertedCreateDate);
    TRC_DBG(@"currentDate =%@",[NSDate date]);
    TRC_DBG(@"ConcurrentDate =%@",[self convertToGMT:[NSDate date]]);
    NSTimeInterval timeDiff = [[NSDate date] timeIntervalSinceDate:convertedCreateDate];
    TRC_DBG(@"%f",timeDiff);
    newCouponLbl.hidden = (timeDiff > 600);
}

-(NSDate*)convertToGMT:(NSDate*)sourceDate
{
    NSTimeZone  *currentTimeZone = [NSTimeZone localTimeZone];   
    NSInteger currentGMTOffset = [currentTimeZone secondsFromGMTForDate:sourceDate];   
    NSTimeInterval gmtInterval = currentGMTOffset; 
    NSDate  *destinationDate = [[NSDate alloc] initWithTimeInterval:gmtInterval sinceDate:sourceDate];   
    return destinationDate;
}

@end