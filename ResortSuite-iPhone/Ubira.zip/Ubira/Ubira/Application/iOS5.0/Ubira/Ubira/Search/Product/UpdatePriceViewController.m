//
//  UpdatePriceViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "UpdatePriceViewController.h"
#import "UserAnalytics.h"
#import "ValidationHandler.h"

@implementation UpdatePriceViewController
@synthesize productTitle = _productTitle;
@synthesize merchantId = __merchantId;
@synthesize startDate = _startDate;
@synthesize productId = _productId;
@synthesize coupons;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setTitle:self.productTitle];
    [updatePriceLabel setText:kUpdatePriceLblText];
    [submitButton setTitle:kStoreSubmitButtonText forState:UIControlStateNormal];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
    
    productUpdatePriceReqResHandler  = [[ProductUpdatePriceReqResHandler alloc]init];
	[productUpdatePriceReqResHandler setDelegate:self];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(checkoutCheckinActionNotification) name:kCheckInCheckOutNotificationKey object:nil];
}

- (void)viewDidUnload
{
    updatePriceLabel = nil;
    updatePriceTextField = nil;
    submitButton = nil;
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:kCheckInCheckOutNotificationKey object:nil];
    
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsUpdatePriceScreen startDate:self.startDate endDate:[NSDate date]];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*!
 @function      submitAction
 @abstract      submit button action 
 @discussion    this function will update the price for the product in the current store
 @param         id
 @result        void
 */
- (IBAction)submitAction:(id)sender 
{
    if([updatePriceTextField.text length]) {
        
        if ([ValidationHandler priceValidate:updatePriceTextField.text] && [updatePriceTextField.text floatValue] != 0) {
            
            updatedPrice = [[NSString alloc] init];
            [productUpdatePriceReqResHandler updatePrice:updatePriceTextField.text merchantId:self.merchantId updatedprice:updatedPrice];
            
        }else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kCouponsTitle message:kEnterValidPrice delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
            [alert show];
        }

    }else{
        //Show Alert
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kCouponsTitle message:kEnterValidPrice delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
        [alert show];
    }
}

/*!
 @function      textFieldShouldReturn
 @abstract      delegate for textField 
 @discussion    discard the keyboard when tap on return button of keyboard
 @param         textField - selected textField 
 @result        will return YES 
 */
- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{
	// Discard keyBoard form window when return key tap on keyboard.
	[textField resignFirstResponder];
	return YES;
}

#pragma TextField Delegate methods
/*!
 @function		shouldChangeCharactersInRange
 @abstract		delegate for textField 
 @discussion	entered text should replace
 @param			range - on which entered text needs to replace 
                string - needs to replace
 @result		BOOL - if space entered returns NO else YES. 
 */
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ((range.location > 0 && [string length] > 0 && [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[string characterAtIndex:0]] &&           [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[[textField text] characterAtIndex:range.location - 1]])) 
    {
        return NO;
    }
    // if first character is a space
    if ([string isEqualToString:@" "] && [textField.text length]==0)
	{ 
		return NO;
	}
    return YES;
}

#pragma mark - Parsing complete delegate
/*!
 @function      parseComplete
 @abstract		delegate on parse complete.
 @discussion	Take the action based on the parameter.
 @param			error - server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
	TRC_ENTRY
	if(error != nil)
	{
		TRC_ERR(@"%@",error)
        NSString *errorString = [[error userInfo] valueForKey:@"error"];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kUpdatePriceError message:errorString delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
        [alert show];
	}
	else
	{
		//update UI		
		TRC_DBG(@"=============================================================")
        TRC_DBG(@"=========================Price Updated %@====================================", updatedPrice)
	}
	TRC_EXIT
}

/*!
 @function      checkoutCheckinActionNotification
 @abstract		persorm action when checkin or checkout notification 
 @discussion	redirect to parentview controller when checkin or checkout notification fires
 @param			nil
 */
- (void) checkoutCheckinActionNotification
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end