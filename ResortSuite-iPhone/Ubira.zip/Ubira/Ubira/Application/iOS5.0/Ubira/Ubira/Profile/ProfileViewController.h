//
//  ProfileViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserProfileReqResHandler.h"
#import "FBConnect.h"
#import "SA_OAuthTwitterController.h"

#define kViewAnimationDuration  0.3

/*!
 @protocol    ProfileViewController
 @abstract    delegate for login status
 @discussion  delegate for login status
 */
@protocol ProfileViewControllerDelegate <NSObject>
- (void)loginStatusDelegate:(BOOL)aStatus;
@end

@class UserExtended;
@class FBSession;
@class SA_OAuthTwitterEngine;

/*!
 @class			ProfileViewController
 @abstract		This class hadles releated UI interaction functionality for user profile.
 @discussion	This class hadles releated UI interaction functionality for user profile.
 */
@interface ProfileViewController : UIViewController <UITextFieldDelegate,UITextViewDelegate, RequestResponseBaseDelegate,FBSessionDelegate>
{
	// IBOutlets
	IBOutlet UITextField				*nameTxtField;
	IBOutlet UITextField				*emailTxtField;
	IBOutlet UITextField				*passwordTxtField;
	IBOutlet UITextField				*confirmPasswordTxtField;
	IBOutlet UITextField				*addressTxtField;
    IBOutlet UITextView 				*addressTxtView;
	IBOutlet UIButton					*logOutBtn;
	
	IBOutlet UIView						*activityIndicatorView; 
	IBOutlet UIActivityIndicatorView	*spinner;
	
	// Delegates
	id <ProfileViewControllerDelegate> __unsafe_unretained _delegate;
	
	// BOOL
	BOOL								isUpdatingProfile;
    BOOL                                dataFatched;    
	
	// Others
    FBSession                           *_session;
    FBLoginDialog                       *login;
    SA_OAuthTwitterEngine               *_engine;
    UserProfileReqResHandler			*userProfileReqResHandler;
    UserExtended						*user;
	
    NSDate                              *_startDate;
    
    CGRect                              viewFrame;    
    NSInteger                           animatedDis;
    CGFloat                             yForKeyBoard;
}

@property (nonatomic,assign) id <ProfileViewControllerDelegate> delegate;
@property (nonatomic, retain) IBOutlet UITextField				*nameTxtField;
@property (nonatomic, retain) IBOutlet UITextField				*emailTxtField;
@property (nonatomic, retain) IBOutlet UITextField				*passwordTxtField;
@property (nonatomic, retain) IBOutlet UITextField				*confirmPasswordTxtField;
@property (nonatomic, retain) IBOutlet UITextField				*addressTxtField;
@property (nonatomic, retain) IBOutlet UITextView 				*addressTxtView;
@property (nonatomic, retain) IBOutlet UIButton					*logOutBtn;
@property (nonatomic, retain) IBOutlet UIView					*activityIndicatorView; 
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView	*spinner;
@property (nonatomic, retain) NSDate                            *startDate;

- (void)addRequireObservers;
- (void)removeObservers;

- (void)initialSetup;
- (void)setupViewForNoEditing;
- (void)setupViewforLogOut;
- (void)fillTextFieldsWithUserDetails;
- (void)userProfileDetails;
- (void)doneAction;
- (void)updateUserDetailsToServer;
- (void)enableTextFields:(BOOL)isenable;

- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;

- (void)animateTextControl:(UIControl*)textControl up:(BOOL)up;
- (void)viewAnimationwithFrame:(CGRect)currentFrame;

- (void)showActivityIndicator;
- (void)stopActivityIndicator;

- (BOOL)validateTextFields;

- (IBAction)backgroundTouched:(id)sender;
- (IBAction)logOutAction:(id)sender;

@end