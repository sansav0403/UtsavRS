//
//  ProfileViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProfileViewController.h"
#import "UserProfileReqResHandler.h"
#import "KeychainItemWrapper.h"
#import "ValidationHandler.h"
#import "UbiraAppDelegate.h"
#import "UserExtended.h"
#import "UserAnalytics.h"
#import "SA_OAuthTwitterEngine.h"
#import "Store.h"

//Facebook
static NSString* kApiKey = @"5587d77bb2adc4a1a81ff342a49d08a7";
static NSString* kApiSecret = @"2212fb168eb6649daab0c9a058def434";

//Twitter
#define kOAuthConsumerKey				@"CaFlUVfpFOEu99H1IgJ8g"
#define kOAuthConsumerSecret			@"2IGlIA1Qufj5b2ZGnhlaaeI3f5cyEYvTj9a4Xmzus9Q"

@implementation ProfileViewController

@synthesize delegate = _delegate;
@synthesize nameTxtField;
@synthesize emailTxtField;
@synthesize passwordTxtField;
@synthesize confirmPasswordTxtField;
@synthesize addressTxtField,addressTxtView;
@synthesize logOutBtn;
@synthesize activityIndicatorView; 
@synthesize spinner;
@synthesize startDate = _startDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
	_delegate = nil;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{   
	// set up view
	[self initialSetup];
	[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
    
    [[self.navigationController navigationBar] setTintColor:kSCNavigationBarTintColor];
    [self.addressTxtView setUserInteractionEnabled:NO];
    
    user = [[UserExtended alloc] init];
    userProfileReqResHandler = [[UserProfileReqResHandler alloc] init];
   
	[super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:YES];
 
    // if data not fatched, get user's details
    if (!dataFatched)
    {
        // show avtivityIndicator while processing
        [self showActivityIndicator];
        
        isUpdatingProfile = NO;
        //get user's details
        [self userProfileDetails];        
    }
    
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[userProfileReqResHandler setDelegate:nil];
	[super viewWillDisappear:YES];
    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsProfileScreen startDate:self.startDate endDate:[NSDate date]];
}

- (void)viewDidUnload
{
	[super viewDidUnload];
	
	nameTxtField = nil;
	emailTxtField = nil;
	passwordTxtField = nil;
	confirmPasswordTxtField = nil;
    addressTxtView = nil;
    addressTxtField = nil;
    logOutBtn = nil;
    activityIndicatorView = nil;
    spinner = nil;
	
	[self removeObservers];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark 
#pragma mark Edit Button Delegate

/*!
 @function      setEditing
 @abstract		Allow editing of textfields in editing mode
 @discussion	Allow editing of textfields in editing mode
 @param			editing - bool value set editing true or false
				animated - bool value set animation to be done 
 @result		void
*/
- (void)setEditing:(BOOL)editing animated:(BOOL)animated 
{
	if (editing)
	{
		TRC_DBG(@"Edit Pressed");
		
		// set left bar button to cancel editing
		self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelAction:)];
		
		// enable textFields to edit
		[self enableTextFields:YES];
        [self.nameTxtField becomeFirstResponder];
		[super setEditing:editing animated:animated];
	}
	else
	{		
		TRC_DBG(@"Done pressed");
		
		// perform done action 
		[self doneAction];
	}
}

#pragma mark 
#pragma mark TextField delegate Methods
/*!
 @function      textFieldShouldReturn
 @abstract		delegate for textField 
 @discussion	discard the keyboard when tap on return button of keyboard
 @param			textField - selected textField 
 @result		will return YES 
 */
- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{
	// descard the keyboard
	[textField resignFirstResponder];
	return YES;
}

/*!
 @function      textFieldShouldBeginEditing
 @abstract		delegate for textField 
 @discussion	check if the view is already animated if not then set active 
				field's y for animation
 @param			textField - selected textField 
 @result		will return YES 
 */
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
	return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ((range.location > 0 && [string length] > 0 && [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[string characterAtIndex:0]] &&           [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[[textField text] characterAtIndex:range.location - 1]])) 
    {
        return NO;
    } 
    
    if ([string isEqualToString:@" "] && [textField.text length]==0)
	{ 
		return NO;
	}
    return YES;
}

/*!
 @function      textFieldDidBeginEditing
 @abstract      delegate for textField 
 @discussion    beign to end of text input animateView accordingly.
 @param         text - selected textfields 
 @result        void 
 */
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self animateTextControl:textField up:YES];
}

/*!
 @function      textFieldDidEndEditing
 @abstract      delegate for textField 
 @discussion    did end of text input animateView accordingly.
 @param         text - selected textfields 
 @result        void  
 */
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self animateTextControl:textField up:NO];
}

/*!
 @function      animateTextControl
 @abstract		animate view up or down when keyboard overlays
 @discussion	Common function to animate view up or down when keyboard overlays
                view's textfield or textView
 @param			keyboardWillHide
 @result		void
 */
- (void)animateTextControl:(UIControl*)textControl up:(BOOL)up
{
    CGPoint temp = [textControl.superview convertPoint:textControl.frame.origin toView:nil];
    if(up)
    {
        int moveUpValue = temp.y+textControl.frame.size.height;
        animatedDis = yForKeyBoard-(viewFrame.size.height-moveUpValue-5);
    }
    else
    {
        [self viewAnimationwithFrame:viewFrame]; 
        return;
    }
    if(animatedDis>0)
    {
        const int movementDistance = animatedDis;
        int movement = (up ? -movementDistance : movementDistance);
        [self viewAnimationwithFrame:CGRectOffset(self.view.frame, 0, movement)];
    }
}

/*!
 @function      viewAnimationwithFrame
 @abstract		animate view up or down 
 @discussion	Common function to animate view up or down when keyboard 
                overlays view's textfield
 @param			currentFrame - Frame to set for View animation
 @result		void
 */
- (void)viewAnimationwithFrame:(CGRect)currentFrame
{
    [UIView beginAnimations: nil context: nil];
    [UIView setAnimationBeginsFromCurrentState: YES];
    [UIView setAnimationDuration:kViewUpDownAnimationDuration];
    
    self.view.frame = currentFrame;       
    [UIView commitAnimations];
}

#pragma TextView Delegate Methods
/*!
 @function      textViewShouldBeginEditing
 @abstract		delegate for textView
 @discussion	check if the view is already animated if not then set active 
                field's y for animation
 @param			textView - selected textField 
 @result		will return YES 
 */
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if([textView.text isEqualToString:kAddressPlaceHolderText])
    {
        [textView setText:@""];
    }
	return YES;
}

/*!
 @function      textFieldDidBeginEditing
 @abstract      delegate for textField 
 @discussion    beign to end of text input animateView accordingly.
 @param         text - selected textfields 
 @result        void 
 */
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [self animateTextControl:(UIControl*)textView up:YES];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    if([textView.text length]<=0)
    {
        [textView setText:kAddressPlaceHolderText];
        [textView setTextColor:[UIColor lightGrayColor]];
    }
    [self animateTextControl:(UIControl*)textView up:NO];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ((range.location > 0 && [text length] > 0 && [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[text characterAtIndex:0]] &&           [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[[textView text] characterAtIndex:range.location - 1]])) 
    {
        return NO;
    }
    
    if ([text isEqualToString:@" "] && [textView.text length]==0)
	{ 
		return NO;
	}
    else
    {
        [textView setTextColor:[UIColor blackColor]];
    }
    return YES;
}

#pragma mark -
#pragma mark KeyBoard delegate methods
/*!
 @function      keyboardWillShow
 @abstract		keyboard about to appear on view
 @discussion	keyboard about to appear on view
 @param			nNotification - notificationo object 
 @result		void
 */
- (void)keyboardWillShow: (NSNotification*)aNotification;
{	
    // get size of keyboard
	NSDictionary *info = [aNotification userInfo];
	NSValue *aValue = [info objectForKey:UIKeyboardFrameEndUserInfoKey];
    yForKeyBoard = [aValue CGRectValue].origin.y;
}

#pragma mark 
#pragma mark Action Methods
/*!
 @method        backgroundTouched
 @abstract		discard keyboard when tapped on view apart from keyBoard
 @discussion	discard keyboard when tapped on view apart from keyBoard
 */
- (IBAction)backgroundTouched:(id)sender
{
	[nameTxtField resignFirstResponder];
	[emailTxtField resignFirstResponder];
	[passwordTxtField resignFirstResponder];
	[confirmPasswordTxtField resignFirstResponder];
    [addressTxtView resignFirstResponder];
}

/*!
 @method        logOutAction
 @abstract		logout the user from system and redirect to login page
 @discussion	logout the user from system and redirect to login page
 */
- (IBAction)logOutAction:(id)sender 
{
	[self setupViewForNoEditing];
    
    //flushed the data hence dataFatched set to no. 
    dataFatched = NO;
	isUpdatingProfile = NO;
	
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:kAutoLoginKey];
    KeychainItemWrapper *keychainItemWrapper = [[KeychainItemWrapper alloc] initWithIdentifier:@"Ubira" accessGroup:kBundleIdentifier];
    [keychainItemWrapper resetKeychainItem];
    
    keychainItemWrapper = [[KeychainItemWrapper alloc] initWithIdentifier:@"Ubira1" accessGroup:kBundleIdentifier];
    [keychainItemWrapper resetKeychainItem];
    
    NSArray *pathsArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *finalPath = [[pathsArray objectAtIndex:0] stringByAppendingPathComponent:@"myList.plist"];    
    NSDictionary *array = [[NSDictionary alloc] initWithObjectsAndKeys:@"FALSE",kAutoLoginKey, nil];           
    [array writeToFile:finalPath atomically: TRUE];
	
    Store *sharedStore = [Store sharedStore];
    sharedStore.storeId = nil;
    
	// send response to ubiraAppdelegate about login
	UbiraAppDelegate *ubiraAppDelegate = (UbiraAppDelegate *)[[UIApplication sharedApplication]delegate];
	[ubiraAppDelegate loginStatusDelegate:NO];	
    
    //Logout FaceBook
    _session = [FBSession sessionForApplication:kApiKey secret:kApiSecret delegate:self];
    [_session logout];
    
    //Twitter Logout
    [[NSUserDefaults standardUserDefaults] setValue:nil forKey:@"authData"];
	_engine = [[SA_OAuthTwitterEngine alloc] initOAuthWithDelegate: nil];
	_engine.consumerKey = kOAuthConsumerKey;
	_engine.consumerSecret = kOAuthConsumerSecret;
    [_engine setClearsCookies:YES];
    [_engine clearsCookies];
    [_engine clearAccessToken];
    
    [self setupViewforLogOut];
}

/*!
 @function      setupViewforLogOut
 @abstract		setup view for LogOut
 @discussion	setup view for LogOut
 @param			none 
 @result		void
 */
- (void)setupViewforLogOut
{
    nameTxtField.text = @"";
	emailTxtField.text = @"";
    passwordTxtField.text = @"";
	confirmPasswordTxtField.text = @"";
    [addressTxtView setText:kAddressPlaceHolderText];
    [addressTxtView setTextColor:[UIColor lightGrayColor]];
    
    self.navigationItem.leftBarButtonItem = nil;
    [self enableTextFields:NO];
	[super setEditing:NO animated:YES];
}

/*!
 @method        doneAction
 @abstract		update the user details
 @discussion	update the user details if all validation done successful
 */
- (void)doneAction
{
	// Validate all text fields
	if ([self validateTextFields])
	{
		// set yes to update 
		isUpdatingProfile = YES;
		
		// Show indicator while registration activity is running
		[self showActivityIndicator];
		
		//update on server
		[self updateUserDetailsToServer];
	}
}

/*!
 @method        cancelAction
 @abstract		cancel the editin of user detail 
 @discussion	cancel the editin of user detail
 */
- (IBAction)cancelAction:(id)sender 
{
	[self setupViewForNoEditing];
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function		showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
				alertMessage - Message description for AlertView		
 @result		void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
	[alert show];
}

/*!
 @method		clickedButtonAtIndex
 @abstract		redirect to Login Page 
 @discussion	redirect to Login Page when password sent successfully
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	UbiraAppDelegate *ubiraAppDelegate = (UbiraAppDelegate *)[[UIApplication sharedApplication]delegate];
	[ubiraAppDelegate loginStatusDelegate:YES];	
}

#pragma mark 
#pragma mark - Parsing complete delegate
/*!
 @function		parseComplete
 @abstract		delegat on parse complete.
 @discussion	Take the action based on the parameter.
 @param			error - server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
	// Remove activity indicator view.
	[self stopActivityIndicator];
	
    if(error)
    {
        TRC_ERR(@"Login Error %@",error)
				
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
		
		[self showAlertView:kPleaseLogin alertMessage:errorString setDelegate:nil];
    }
    else
    {
         dataFatched = YES;
		// Update User Details
		UserExtended *userExtended = [UserExtended sharedUserExteded];
		userExtended.name = user.name;
		userExtended.email = user.email;
		userExtended.password = user.password;
		userExtended.address = user.address;
		
		// update textFields value
		[self fillTextFieldsWithUserDetails];
		
		if (isUpdatingProfile)
		{
			isUpdatingProfile = NO;
			
			[self setupViewForNoEditing];
			
			// password fields set to blank
			passwordTxtField.text = nil;
			confirmPasswordTxtField.text = nil;
			
			// Show successful message.
			[self showAlertView:kProfileSuccessful alertMessage:kProfileSuccessfulDescription setDelegate:nil];
		}
	}
}

#pragma mark 
#pragma mark  Other Methods
/*! 
 @function      addRequireObservers
 @abstract		add the required observer to listen the notification 	
 @discussion	add the required observer to listen the notification
 @param			none
 @result		void
 */
- (void)addRequireObservers
{
	// Observe keyboard hide and show notifications to resize the text view appropriately.
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:)
												name:UIKeyboardDidShowNotification object:nil];
}

/*! 
 @function      removeObservers
 @abstract		remove observers from listening the notification 	
 @discussion	remove observers from listening the notification
 @param			none
 @result		void
 */
- (void)removeObservers
{
	// unregister for keyboard notifications while not visible.
	[[NSNotificationCenter defaultCenter] removeObserver:self 
												name:UIKeyboardDidShowNotification object:nil];
}

/*! 
 @function      userProfileDetails
 @abstract		get user's profile details 	
 @discussion	get user's profile details 
 @param			none
 @result		void
 */
- (void)userProfileDetails
{
    // Get user profile
	[userProfileReqResHandler setDelegate:self];
	[userProfileReqResHandler profile:user];
}

/*! 
 @function      updateStatusOfTextFields
 @abstract		update textFields enable status	
 @discussion	update textFields enable status
 @param			none
 @result		void
 */
- (void)enableTextFields:(BOOL)isenable
{
	self.nameTxtField.enabled = isenable; 
	self.passwordTxtField.enabled = isenable; 
	self.confirmPasswordTxtField.enabled = isenable;
    self.addressTxtView.userInteractionEnabled = isenable;
    [self.addressTxtView setUserInteractionEnabled:isenable];
}

/*! 
 @function      fillTextFieldsWithUserDetails
 @abstract		fill textFields with User details 	
 @discussion	fill textFields with User details
 @param			none
 @result		void
 */
- (void)fillTextFieldsWithUserDetails
{
	// set user's details into textfields
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	[self.nameTxtField setText:userExtendedObj.name];
	[self.emailTxtField setText:userExtendedObj.email];
    [self.passwordTxtField setText:@""];
	[self.confirmPasswordTxtField setText:@""];
    [self.addressTxtView setText:userExtendedObj.address];
    [self.addressTxtView setTextColor:[UIColor blackColor]];
}

/*!
 @function      initialSetup
 @abstract		set up initial text for page
 @discussion	set up initial text for page
 @param			non
 @result		void
 */
- (void)initialSetup
{
	// set navigation bar's title
    [self.navigationItem setTitle:kProfileTitle];
    [self.tabBarController.tabBarItem setTitle:kProfileTabTitle];
	self.navigationItem.rightBarButtonItem = [self editButtonItem];
	[super setEditing:NO animated:YES];

	// set text for buttons and textfield's placeholder text
	[self.nameTxtField setPlaceholder:kNamePlaceHolderText];
	[self.emailTxtField setPlaceholder:kEmailPlaceHolderText];
	[self.passwordTxtField setPlaceholder:kPasswordPlaceHolderText];
	[self.confirmPasswordTxtField setPlaceholder:kConfirmPasswordPlaceHolderText];
    [self.addressTxtView setText:kAddressPlaceHolderText];
    [self.addressTxtView setTextColor:[UIColor lightGrayColor]];
	[self.logOutBtn setTitle:kLogOutButtonText forState:UIControlStateNormal];	
	
    //set Initials
    viewFrame = self.view.frame;
    viewFrame.origin.y =0;
    animatedDis=0;
    yForKeyBoard = 264;
    
	// set BOOL values
	isUpdatingProfile = NO;
    dataFatched = NO;

	[self addRequireObservers];
}

/*!
 @function      setupViewForNoEditing
 @abstract		Common settings of user interface when page is not in edit mode 
 @discussion	Common settings of user interface when page is not in edit mode
 @param			none	
 @result		void
 */
- (void)setupViewForNoEditing
{
	[self fillTextFieldsWithUserDetails];
    [self enableTextFields:NO];
	[super setEditing:NO animated:YES];
	self.navigationItem.leftBarButtonItem = nil;
}

/*!
 @function      showActivityIndicator
 @abstract		show activity indicator
 @discussion	show activity indicator while process is running in background
 @param			none
 @result		Void
 */
- (void)showActivityIndicator
{
	// Show activity indicator while searching for location
	[self.view addSubview:activityIndicatorView];
	[spinner startAnimating];
	self.navigationController.navigationBar.userInteractionEnabled = NO;	
}

/*!
 @function      stopActivityIndicator
 @abstract		stop activity indicator
 @discussion	stop activity indicator and remove from superview
 @param			none
 @result		Void
 */
- (void)stopActivityIndicator
{
	// stop running activity indicator
	[spinner stopAnimating];
	[activityIndicatorView removeFromSuperview];
	self.navigationController.navigationBar.userInteractionEnabled = YES; 
}

/*!
 @method        updateUserDetailsToServer
 @abstract		update the user details on server
 @discussion	update the user details on serverif all validation done successful
 */
- (void)updateUserDetailsToServer
{
	//set the user details from entered text
    user.name = nameTxtField.text;
	user.email = emailTxtField.text;
	user.password = passwordTxtField.text;
    user.address = addressTxtView.text;
	if (userProfileReqResHandler)
	{
		userProfileReqResHandler = nil;
	}
	userProfileReqResHandler = [[UserProfileReqResHandler alloc]init];
	[userProfileReqResHandler setDelegate:self];
	[userProfileReqResHandler updateProfile:user];
}

/*!
 @function      validateTextFields
 @abstract		validate all text fields
 @discussion	validate all text fields
 @param			none
 @result		will return YES is all textField comply the business rule else NO
 */
- (BOOL)validateTextFields
{
	// Check all fields are filled
	if ([nameTxtField.text length]<=0 || [passwordTxtField.text length]<=0 || [confirmPasswordTxtField.text length]<=0 || [addressTxtView.text length]<=0 || [addressTxtView.text isEqualToString:kAddressPlaceHolderText]) 
	{
		[self showAlertView:nil alertMessage:kNoProfileUpdationDescription setDelegate:nil];
		return NO;
	}
    
    if ([ValidationHandler isSpace:nameTxtField.text] || [ValidationHandler isSpace:passwordTxtField.text] || [ValidationHandler isSpace:confirmPasswordTxtField.text] || [ValidationHandler isSpace:addressTxtView.text]) 
	{
		[self showAlertView:nil alertMessage:kNoProfileUpdationDescription setDelegate:nil];
		return NO;
	}
	
	// Check text length for name field should be 30 characters or less
	if(![ValidationHandler checkMaxLength:30 string:nameTxtField.text])
	{
		[self showAlertView:kNameInvalid alertMessage:kNameInvalidDescription setDelegate:nil];
		return NO;
	}
	
	// Check for password lenght
	if (![ValidationHandler checkMinLength:8 string:passwordTxtField.text])
	{
		[self showAlertView:kPasswordInvalid alertMessage:kPasswordLengthInvalidDescription setDelegate:nil];	
		return NO;
	}	
	
	// Check for password comply the business rule
	if (![ValidationHandler passwordValidate:passwordTxtField.text])
	{
		[self showAlertView:kPasswordInvalid alertMessage:kPasswordBusinessRuleInvalidDescription setDelegate:nil];	
		return NO;
	}
	
	// Check is password and confirm password are same  
	if (![passwordTxtField.text isEqualToString:confirmPasswordTxtField.text])
	{
		[self showAlertView:kPasswordInvalid alertMessage:kConfirmPasswordInvalidDescription setDelegate:nil];	
		return NO;
	}
	
	return YES;
}

#pragma mark - FaceBook Seesion Delegate

- (void)session:(FBSession*)session didLogin:(FBUID)uid 
{	
	// do some stuff when login to facebbok
}

- (void)sessionDidNotLogin:(FBSession*)session {
	if (login)
	{
		login = nil;
	}
}

- (void)sessionDidLogout:(FBSession*)session {
	
	if (login)
	{
		login = nil;
	}
}

@end