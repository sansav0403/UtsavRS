//
//  ForgotPasswordViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "ForgotPasswordViewController.h"
#import "ValidationHandler.h"
#import "UserAnalytics.h"

@implementation ForgotPasswordViewController
@synthesize emailTxtField, activityIndicatorView, spinner;
@synthesize forgotPasswordLbl,doneBtn,registrationBtn;
@synthesize startDate = _startDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    TRC_DBG(@"ForgotPasswordViewController ------------------ Release")    
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
	[self setLocalizableText];
	[self.navigationController setNavigationBarHidden:NO];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsForgotPasswordScreen startDate:self.startDate endDate:[NSDate date]];
}

- (void)viewDidUnload
{
	emailTxtField = nil;
    [self setForgotPasswordLbl:nil];
    [self setDoneBtn:nil];
    [self setRegistrationBtn:nil];
    [self setEmailTxtField:nil];
    [self setActivityIndicatorView:nil];
    [self setSpinner:nil];
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*!
 @function      textFieldShouldReturn
 @abstract		delegate for textField 
 @discussion	discard the keyboard when tap on return button of keyboard
 @param			textField - selected textField 
 @result		will return YES 
 */
- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{
	[textField resignFirstResponder];
	return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ((range.location > 0 && [string length] > 0 && [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[string characterAtIndex:0]] &&           [[NSCharacterSet whitespaceCharacterSet] characterIsMember:[[textField text] characterAtIndex:range.location - 1]])) 
    {
        return NO;
    } 
    
    if ([string isEqualToString:@" "] && [textField.text length]==0)
	{ 
		return NO;
	}
    
    return YES;
}

#pragma mark 
#pragma mark Action Methods
/*!
 @method        backgroundTouched
 @abstract		discard keyboard when tapped on view apart from keyBoard
 @discussion	discard keyboard when tapped on view apart from keyBoard
 */
- (IBAction)backgroundTouched:(id)sender
{
	[emailTxtField resignFirstResponder];
}

/*!
 @method		doneAction
 @abstract		sent mail to entered email address 
 @discussion	validate and sent mail to entered email address
 */
- (IBAction)doneAction:(id)sender 
{
	// discard the keyBoard
	[emailTxtField resignFirstResponder];
	
	if ([self validateEmail]) 
	{
		if (forgotPasswordReqResHandler)
		{
			forgotPasswordReqResHandler = nil;
		}
		forgotPasswordReqResHandler = [[ForgotPasswordReqResHandler alloc]init];
		[forgotPasswordReqResHandler setDelegate:self];
		[forgotPasswordReqResHandler forgetPassword:emailTxtField.text];
		
		// Show activity indicator while sever sending the password
		// to entered email address  
		[self.view addSubview:activityIndicatorView];
		[spinner startAnimating];
		self.navigationController.navigationBar.userInteractionEnabled = NO;
	}
}

/*!
 @method        registerNewUserAction 
 @abstract		redirect to registration page
 @discussion	redirect to registration page
*/
- (IBAction)registerNewUserAction:(id)sender 
{
    registerViewController = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController" bundle:[NSBundle mainBundle]];
    
    [self.navigationController setNavigationBarHidden:NO];
	UINavigationController *navController = self.navigationController;
	[navController popViewControllerAnimated:NO];
    [navController pushViewController:registerViewController animated:YES];
	
}

#pragma mark - Parsing complete delegate
/*!
 @function      parseComplete
 @abstract      delegat on parse complete.
 @discussion    Take the action based on the parameter.
 @param         error - server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
	// Remove activity indicator view.
	[self stopActivityIndicator];
    if(error)
    {
        TRC_ERR(@"Login Error %@",error)
		
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
		[self showAlertView:kPleaseLogin alertMessage:errorString delegate:nil];
    }
    else
    {
        //update UI
		[self showAlertView:kPasswordSent alertMessage:kPasswordSentDescription delegate:self];
    }
}

#pragma mark 
#pragma mark Other Methods

/*!
 @function      setLocalizableText
 @abstract      set localizable text 
 @discussion    set localizable text for UI
 @param         none
 @result        void
 */
- (void)setLocalizableText
{
	// set text for navigation title, buttons and textfield's placeholder text
	[self setTitle:kUbiraTitle];
	[self.forgotPasswordLbl setText:kForgot_Password_WithoutQuestionMark];
	[self.emailTxtField setPlaceholder:kForgotEmailText];

	[self.doneBtn setTitle:kDone forState:UIControlStateNormal];
	[self.registrationBtn setTitle:kNewUserRegistration forState:UIControlStateNormal];	
}

/*!
 @function      validateEmail
 @abstract		validate email text
 @discussion	validate email text
 @param			none
 @result		will return YES of email comply the business rule else NO
*/
- (BOOL)validateEmail
{
	// Check is textFields are blank or not
	if ([emailTxtField.text length]<=0 )
	{
		[self showAlertView:nil alertMessage:kNoEmailIdDescription delegate:nil];
		return NO;
	}
	
	// check is email entered is valid or not
	if (![ValidationHandler emailValidate:emailTxtField.text]) 
	{
		[self showAlertView:kEmailInvalid alertMessage:kEmailInvalidDescription delegate:nil];
		return NO;
	}
	return YES;
}

/*!
 @function      showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
				alertMessage - Message description for AlertView		
 @result		void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage delegate:(id)delegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:delegate cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
	[alert show];
}

/*!
 @method		clickedButtonAtIndex
 @abstract		redirect to Login Page 
 @discussion	redirect to Login Page when password sent successfully
*/
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	[self.navigationController popViewControllerAnimated:YES];	
}

/*!
 @function		stopActivityIndicator
 @abstract		stop activity indicator
 @discussion	stop activity indicator and remove from superview
 @param			none
 @result		Void
 */
- (void)stopActivityIndicator
{
	[spinner stopAnimating];
	[activityIndicatorView removeFromSuperview];
	self.navigationController.navigationBar.userInteractionEnabled = YES; 
}

@end
