//
//  CouponsViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 05/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "CouponsViewController.h"
#import "CouponDetailViewController.h"
#import "Coupon.h"
#import "CouponCell.h"
#import "UserAnalytics.h"

#define	kCouponCell @"Coupon"
#define kCouponDetailViewController   @"CouponDetailViewController"

@implementation CouponsViewController

@synthesize couponTbl;
@synthesize startDate = _startDate;
@synthesize NoCouponLbl;
@synthesize activityIndicator,productid;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsCouponScreen startDate:self.startDate endDate:[NSDate date]];
}

- (void)viewDidLoad
{
    // set navigation
    [self setTitle:kCouponsTitle];
    [[self.navigationController navigationBar] setTintColor:kSCNavigationBarTintColor];
    self.navigationItem.rightBarButtonItem = [self editButtonItem];
    [self.NoCouponLbl setText:kNoCouponAvailable];
    
    // set table's footer view
	UIView	*view = [[UIView alloc]initWithFrame:CGRectZero];
	[self.couponTbl setTableFooterView:view];
	
    [activityIndicator setHidesWhenStopped:YES];

    //Initializer couponReqResHandler
	couponReqResHandler = [[CouponReqResHandler alloc] init];
    [couponReqResHandler setDelegate:self];    

    //get coupons list
    [self refreshData];
    
    [super viewDidLoad];
}

- (void)viewDidUnload
{
	couponTbl  = nil;
    [self setNoCouponLbl:nil];
    
    [self setActivityIndicator:nil]; 
    
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Parsing complete delegate
/*!
 @function      parseComplete
 @abstract      delegat on parse complete.
 @discussion    Take the action based on the parameter.
 @param         error - server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
    [activityIndicator stopAnimating];
    
    if(error)
    {
        TRC_ERR(@"Coupon Error : %@",error)
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kCouponsTitle message:errorString delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
        [alert show];
    }
    else
    {
		switch (couponsRequestState) {
			case kCouponFetchRequest:{
				//update UI
				TRC_DBG(@"Total Coupons = %d", [couponsList count])	
                [self.NoCouponLbl setHidden:YES];
				[couponTbl reloadData];
				}break;
			case kCouponDeleteRequest:{
				TRC_DBG(@"Coupon delete success")
                // Delete the row from the data source.
                [(NSMutableArray*)couponsList removeObjectAtIndex:deleteCouponIndexPath.row];
                [couponTbl beginUpdates];
                [couponTbl deleteRowsAtIndexPaths:[NSArray arrayWithObject:deleteCouponIndexPath] withRowAnimation:UITableViewRowAnimationFade];
                [couponTbl endUpdates];
                
                if (![couponsList count])
                {
                    [self setEditing:NO animated:YES];
                }
			}break;

			default:
				break;
		}        
    }
    if([couponsList count] == 0){
        [self.couponTbl reloadData];
        [self.NoCouponLbl setHidden:NO];
    }
    
    [couponTbl setUserInteractionEnabled:YES];
}

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [couponsList count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *identifier = kCouponCell;
    CouponCell *cell = (CouponCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if(!cell)
    {
        cell = [[CouponCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];        
    }

	if ([couponsList count]) {
		Coupon *coupon = [couponsList objectAtIndex:indexPath.row];
		[cell setCouponData:coupon];
	}    
    return cell;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
	
	if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        [self showAlertView:kCouponsTitle alertMessage:kCouponDeleteConfirmation setDelegate:self
          cancelButtonTitle:kButtoncancel otherButtonTitle:kButtonOk];
		
		TRC_DBG(@"commitEditingStyle : Delete")	
		deleteCouponIndexPath = indexPath;
	}   
}

#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
	if ([couponsList count]) {
		//Selected product for details
		Coupon *coupon = [couponsList objectAtIndex:indexPath.row];    	

		//Navigate to details screen of the selected product
		CouponDetailViewController *couponDetailViewController = [[CouponDetailViewController alloc] initWithNibName:kCouponDetailViewController bundle:[NSBundle mainBundle]];
		[couponDetailViewController setCoupon:coupon];
		
		[self.navigationController pushViewController:couponDetailViewController animated:YES];	
	}
}

/*!
 @function      setEditing
 @abstract		Allow editing of textfields in editing mode
 @discussion	Allow editing of textfields in editing mode
 @param			editing - bool value set editing true or false
                animated - bool value set animation to be done 
 @result		void
 */
- (void)setEditing:(BOOL)editing animated:(BOOL)animated 
{	
	[super setEditing:editing animated:animated];
	[couponTbl setEditing:editing];
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function      showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
                alertMessage - Message description for AlertView		
 @result		void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage 
          setDelegate:(id)currentDelegate 
    cancelButtonTitle:(NSString *)cancelButtonTitle
     otherButtonTitle:(NSString *)otherButtonTitle
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage 
                                                   delegate:currentDelegate cancelButtonTitle:cancelButtonTitle 
                                          otherButtonTitles:otherButtonTitle, nil];
	[alert show];
}

/*!
 @function      clickedButtonAtIndex
 @abstract		redirect to Add Store or Home page
 @discussion	redirecting to Add Store page when Create Store button tapped
                redirecting to Home page when Cancel button tapped
 @param			buttonIndex - index of cancel or Create store button 
 @result		void
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	switch (buttonIndex) {
		case 0:
		{
			TRC_DBG(@"0 is pressed")
		}
			break;
		case 1:
		{
			TRC_DBG(@"1 is pressed")            
            
            if ([couponsList count]) {
                Coupon	*coupon = [couponsList objectAtIndex:deleteCouponIndexPath.row];
                if(coupon.couponId){
                    TRC_DBG(@"Coupon ID : %@",coupon.couponId)
                    couponsRequestState = kCouponDeleteRequest;
                    [couponReqResHandler deleteCoupon:coupon.couponId];  
                    [activityIndicator startAnimating];
                    [couponTbl setUserInteractionEnabled:NO];
                }
            }
		}
			break;
		default:
            TRC_DBG(@"default is pressed")
			break;
	}
}

#pragma Other Methods
/*!
 @function      refreshData
 @abstract		refresh coupons data
 @discussion	refresh coupons data 
 @param			none
 @result		void
 */
- (void)refreshData
{
    [activityIndicator setHidden:NO];
    [activityIndicator startAnimating];
	
    [couponTbl setUserInteractionEnabled:NO];
    
	couponsRequestState = kCouponFetchRequest;
	
	//get the coupons from the server
	if(couponsList)
	{
		couponsList = nil;
	}
    couponsList = [[NSMutableArray alloc] init];    
    [couponReqResHandler coupons:couponsList productId:productid storeId:sharedStore.storeId];
}

@end