//
//  RatingView.m
//  Ubira
//
//  Created by [Cybage Team] on 25/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "RatingView.h"

#define MAX_RATING 5.0
#define kStarBackground @"StarsBackground.png"
#define kStarForeground @"StarsForeground.png"

@implementation RatingView

/*!
 @function      _commonInit
 @abstract      initialise the ratings view.
 @discussion    initialise the ratings view for background and forground image.
 @param         void
 @result        void
 */
- (void)_commonInit
{
    backgroundImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:kStarBackground]];
    backgroundImageView.contentMode = UIViewContentModeLeft;
    [self addSubview:backgroundImageView];
    
    foregroundImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:kStarForeground]];
    foregroundImageView.contentMode = UIViewContentModeLeft;
    foregroundImageView.clipsToBounds = YES;
    [self addSubview:foregroundImageView];
}

- (id)initWithFrame:(CGRect)frame
{
    if ((self = [super initWithFrame:frame]))
    {
        [self _commonInit];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)coder
{
    if ((self = [super initWithCoder:coder]))
    {
        [self _commonInit];
    }
    return self;
}

/*!
 @function      setRating
 @abstract      set the rating to draw for product.
 @discussion    draw the rating based on the passed rating for the current produt.
 @param         float - new ratings
 @result        void
 */
- (void)setRating:(float)newRating
{
    rating = newRating;
    foregroundImageView.frame = CGRectMake(0.0, 0.0, backgroundImageView.frame.size.width * (rating / MAX_RATING), foregroundImageView.bounds.size.height);
}

/*!
 @function      rating
 @abstract      it will return the current ratings.
 @discussion    it will return the current ratings for the product.
 @param         void
 @result        float - current product rating
 */
- (float)rating
{
    return rating;
}

@end