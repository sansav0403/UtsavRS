//
//  CouponDetailViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 09/06/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Coupon.h"

@interface CouponDetailViewController : UIViewController {

    // IBOutlets
	IBOutlet UILabel		*couponDescriptionLbl;
	IBOutlet UILabel		*couponCodeLbl;
	IBOutlet UILabel		*couponValidTillLbl;	
	IBOutlet UILabel		*couponCodeTitleLbl;
	IBOutlet UIImageView	*couponImageView;
    
    //Others
	Coupon					*_coupon;
}

@property (nonatomic, retain) IBOutlet UILabel			*couponDescriptionLbl;
@property (nonatomic, retain) IBOutlet UILabel			*couponCodeLbl;
@property (nonatomic, retain) IBOutlet UILabel			*couponValidTillLbl;
@property (nonatomic, retain) IBOutlet UILabel			*couponCodeTitleLbl;
@property (nonatomic, retain) IBOutlet UIImageView		*couponImageView;
@property (nonatomic, retain) Coupon					*coupon;

- (void)updateDataValue;
- (void)generateQRCodeImage;

@end
