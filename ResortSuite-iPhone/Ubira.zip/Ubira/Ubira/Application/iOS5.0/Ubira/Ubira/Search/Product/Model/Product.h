//
//  Product.h
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RemoteDataOperation.h"

@protocol ImageDownloadDelegate

- (void)imageDownloadComplete:(NSError*)error productIndex:(int)productIndex;

@end

@interface Product : NSObject {

	NSString                *_productId;
	NSString                *_name;
	NSString                *_description;
	NSString                *_imageUrl;
	NSDate                  *__unsafe_unretained _createDate;
   	UIImage                 *_image;
    int                     _rating;
	int                     _reviews;
    int                     _productIndex;
    RemoteDataOperation		*_imageDownloadOperation;
    BOOL                    imageRequestInProgress;
    
    NSString                *detailsUrl;
	
	id<ImageDownloadDelegate>__unsafe_unretained _delegate;
}

@property (nonatomic, copy) NSString                    *productId;
@property (nonatomic, copy) NSString                    *name;
@property (nonatomic, copy) NSString                    *description;
@property (nonatomic, copy) NSString                    *imageUrl;
@property (nonatomic, assign) NSDate                    *createDate;
@property (nonatomic, retain) UIImage                   *image;
@property (nonatomic, assign) int                       rating;
@property (nonatomic, assign) int                       reviews;
@property (nonatomic, assign) int                       productIndex;
@property (nonatomic, copy) NSString                    *detailsUrl;
@property (nonatomic, assign) id<ImageDownloadDelegate>	delegate;

- (void)downloadImage;

@end