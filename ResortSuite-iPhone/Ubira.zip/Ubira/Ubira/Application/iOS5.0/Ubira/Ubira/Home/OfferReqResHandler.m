//
//  OfferReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "OfferReqResHandler.h"
#import "Offer.h"
#import "LocationManager.h"

#define kOffers				@"offers" 
#define kOfferDescription	@"description" 
#define kOfferExpires		@"expires"
#define kOfferId			@"id"
#define kOfferImageUrl		@"image_url"
#define kOfferDetailUrl		@"offer_url"
#define kOfferPrice			@"price"
#define kOfferStoreId		@"storeid"

@implementation OfferReqResHandler

@synthesize offerList = _offerList;
@synthesize storeId = _storeId;

/*!
 @function      offers
 @abstract      request to server for getting offer list.
 @discussion    request to server for getting offer list.
 @param         storeId - store id to get the offers for perticular store otherwise pass null
 @param         offerList - stores the offer list after successful parse
 @result        bool
 */
- (void)offers:(NSString*)storeId offerList:(NSArray*)offerlist
{
	self.offerList = offerlist;
    self.storeId = storeId;
	
    if ([LocationManager sharedInstance].onceLocationUpdated) {
        [self fetchOffers];
    }else{
        [[LocationManager sharedInstance] setDelegate:self];
    }
	
}

- (void)fetchOffers
{
    NSString* queryString = [NSString stringWithFormat:@"%@/offer/home?storeid=%@&lat=%f&long=%f"
							 ,kUbiraServerUrl
							 ,self.storeId
							 ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
							 ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
							 ];
    NSLog(@"%@",queryString);
	NSURL* url = [NSURL URLWithString:queryString];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kGet];			
	
	[webService makeRequest:theRequest];
}
- (void)locationUpdateSuccess:(NSError*) error
{
    [self fetchOffers];
}

/*!
 @function      handleReceivedData
 @abstract      response data for offer list request to server.
 @discussion    response data for offer list request to server.
 @param         data - response data
 @result        bool
 */
- (void)handleReceivedData: (NSData*)data
{	
    if (![self checkForErrors:data]) {
        return;
    }
    
	TRC_ENTRY
    //Get the json key value dictionary for the data
    NSString *resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    
    NSDictionary *resultDictionary = [resultString JSONValue];
    
	NSArray *resultList = [resultDictionary valueForKey:kOffers];
    
	NSError *error = nil;
    
    @try {
        //Create all available offer models 
        for(NSDictionary *offerDict in resultList)
        {    
            TRC_DBG(@"----------------------------------------")
            Offer *offer = [[Offer alloc] init];
            
            offer.offerId = [offerDict valueForKey:kOfferId];
            TRC_DBG(@"Offer Id : %@",offer.offerId)
            
            offer.imageUrl = [offerDict valueForKey:kOfferImageUrl];
            TRC_DBG(@"Offer Image Url : %@",offer.imageUrl)
            
            offer.price = [offerDict valueForKey:kOfferPrice];
            TRC_DBG(@"Offer price : %@",offer.price)
            
            offer.description = [offerDict valueForKey:kOfferDescription];
            TRC_DBG(@"Offer description : %@",offer.description)
            
            offer.offerurl = [offerDict valueForKey:kOfferDetailUrl];
            TRC_DBG(@"Offer offerurl : %@",offer.offerurl)
            
            offer.storeId = [offerDict valueForKey:kOfferStoreId];
            TRC_DBG(@"Offer storeId : %@",offer.storeId)
            
            NSString* expiryDateString	=	[offerDict valueForKey:kOfferExpires];		
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];		
            [dateFormatter setDateFormat:kDateFormat];		
            offer.expireDate = [dateFormatter dateFromString:expiryDateString];
            TRC_DBG(@"Offer expireDate : %@",[dateFormatter stringFromDate:offer.expireDate])
            
            [(NSMutableArray *)self.offerList addObject:offer];
        }
    }
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        self.offerList = nil;
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kInvalidDataErr userInfo:userInfo];
    }
    
    //Update the caller about the result
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
}

@end