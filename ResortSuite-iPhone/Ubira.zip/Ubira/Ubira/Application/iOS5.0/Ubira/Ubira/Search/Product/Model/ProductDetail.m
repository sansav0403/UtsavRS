//
//  ProductDetail.m
//  fressTest
//
//  Created by [Cybage Team] on 04/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "ProductDetail.h"

@implementation ProductDetail
@synthesize  merchantStoreList, releatedProducts, inStore;

@end
