//
//  ProductDetailReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "ProductDetailReqResHandler.h"
#import	"MerchantStore.h"
#import "UbiraAppDelegate.h"
#import "LocationManager.h"
#import "NSString+HTML.h"

@implementation ProductDetailReqResHandler

#pragma mark request functions

/*!
 @function      productDetails
 @abstract		make request for product detail information.
 @discussion	make request for product detail information.
 @param			productId	-	product id for product information.
 @param			merchantId	-	merchant id
 @result		void
 */
- (void)productDetails:(NSString*)productId merchantid:(NSString*)merchantId productDetails:(ProductDetail*)product
{
	TRC_ENTRY
	
	//user id mangement
	UserExtended *userExtendedObj = [UserExtended sharedUserExteded];
	NSString* userId = userExtendedObj.userId;
	
	_productDetail			= product;
	
	NSString* queryString = [NSString stringWithFormat:@"%@/product/detail/?userid=%@&productid=%@&merchantid=%@&lat=%f&long=%f"
							 ,kUbiraServerUrl
							 ,userId
							 ,productId
							 ,merchantId
							 ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
							 ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
							 ];
	TRC_DBG(@"queryString for Product Detail %@",queryString);
	NSURL* url = [NSURL URLWithString:queryString];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kGet];			
	
	[webService makeRequest:theRequest];
    
	TRC_EXIT
}

#pragma mark parse functions

/*!
 @function      handleReceivedData
 @abstract		parse the product detail information.
 @discussion	parse the product detail information.
 @param			data - response data
 @result		bool
 */
-(void)handleReceivedData:(NSData*)data
{	
    if (![self checkForErrors:data]) {
        return;
    }
    
	TRC_ENTRY
    
	NSString* responseString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    
    NSString *newResponse = [responseString stringByDecodingXMLEntities];
    
	TRC_DBG(@"%@",newResponse)
    
	NSDictionary *resultDictionary = [newResponse JSONValue];
    
    NSError *error = nil;
    
    @try
    {
        //1. parse instore list
        TRC_DBG(@"--------------------InStore Store list------------------------")
        NSArray *inStoreList		= [resultDictionary valueForKey:kInStore];
        NSMutableArray*	inStore     = [[NSMutableArray alloc]init];
        //Create the all available offer models 
        if([inStoreList isKindOfClass:[NSArray class]])
        {
            for(NSDictionary *merchantDict in inStoreList)
            {    
                MerchantStore  *store = [[MerchantStore alloc] init];
                
                store.detailsUrl = [merchantDict valueForKey:kDetailLink];
                TRC_DBG(@"Store detailsUrl : %@",store.detailsUrl )
                
                store.storeId = [merchantDict valueForKey:kId];
                TRC_DBG(@"Store storeId : %@",store.storeId )
                
                store.imageUrl = [merchantDict valueForKey:kImageUrl];
                TRC_DBG(@"Store imageUrl : %@",store.imageUrl )
                
                store.merchantId = [merchantDict valueForKey:kMerchantId];
                TRC_DBG(@"Store merchantId : %@",store.merchantId )
                
                store.price = [merchantDict valueForKey:kPrice];
                TRC_DBG(@"Store price : %@",store.price )
                
                store.productId = [merchantDict valueForKey:kProductId];
                TRC_DBG(@"Store productid : %@",store.productId )
                
                [inStore addObject:store];
            }
        }
        _productDetail.inStore = inStore;
        
        //2. parse marchant store list
        TRC_DBG(@"--------------------Merchant Store list------------------------")
        NSArray *merchantStoreList		= [resultDictionary valueForKey:kMerchants];
        NSMutableArray*	merchantArray	= [[NSMutableArray alloc]init];
        
        //Create the all available offer models
        if([merchantStoreList isKindOfClass:[NSArray class]])
            for(NSDictionary *merchantDict in merchantStoreList)
            {    
                MerchantStore  *store = [[MerchantStore alloc] init];
                
                store.detailsUrl = [merchantDict valueForKey:kDetailLink];
                TRC_DBG(@"Store detailsUrl : %@",store.detailsUrl )
                
                store.storeId = [merchantDict valueForKey:kId];
                TRC_DBG(@"Store storeid : %@",store.storeId )
                
                store.imageUrl = [merchantDict valueForKey:kImageUrl];
                TRC_DBG(@"Store imageUrl : %@",store.imageUrl )
                
                store.merchantId = [merchantDict valueForKey:kMerchantId];
                TRC_DBG(@"Store merchantId : %@",store.merchantId )
                
                store.price = [merchantDict valueForKey:kPrice];
                TRC_DBG(@"Store price : %@",store.price )
                
                store.productId = [merchantDict valueForKey:kProductId];
                TRC_DBG(@"Store productid : %@",store.productId )
                
                [merchantArray addObject:store];
            }
        _productDetail.merchantStoreList = merchantArray;
        
        //3. parse product details
        TRC_DBG(@"--------------------Product Details------------------------")
        NSArray *productDetail			= [resultDictionary valueForKey:kProduct];
        for(NSDictionary *productDict in productDetail)
        {   
            _productDetail.createDate = [productDict valueForKey:kCreateDate];
            TRC_DBG(@"Product Create Date : %@",_productDetail.createDate )
            
            _productDetail.description = [productDict valueForKey:kDescription];
            _productDetail.description = [_productDetail.description stringByDecodingXMLEntities]; 
            
            TRC_DBG(@"Product Description : %@",_productDetail.description )
            
            _productDetail.productId = [productDict valueForKey:kId];
            TRC_DBG(@"Product Id : %@",_productDetail.productId )
            
            _productDetail.imageUrl = [productDict valueForKey:kImageUrl];
            TRC_DBG(@"Product image url : %@",_productDetail.imageUrl )
            
            _productDetail.name = [productDict valueForKey:kName];
            TRC_DBG(@"Product Name : %@",_productDetail.name )
            
            _productDetail.rating = [[productDict valueForKey:kRatings]intValue];
            TRC_DBG(@"Product Rating : %d",_productDetail.rating )
            
            _productDetail.reviews = [[productDict valueForKey:kReviews]intValue];
            TRC_DBG(@"Product Reviews : %d",_productDetail.reviews )
        }
        
        //3. Parse releated product 
        TRC_DBG(@"--------------------Releated Product parsing------------------------")
        NSArray *releatedProductList	= [resultDictionary valueForKey:kReleatedProducts];
        NSMutableArray*	productArray	= [[NSMutableArray alloc]init];
        for(NSDictionary *productDict in releatedProductList)
        {   
            Product* product = [[Product alloc]init];
            
            product.productId = [productDict valueForKey:kId];
            TRC_DBG(@"Product Id : %@",product.productId )
            
            product.detailsUrl = [productDict valueForKey:kDetailLink];
            TRC_DBG(@"Product Detail : %@",product.detailsUrl )
            
            product.imageUrl = [productDict valueForKey:kImageUrl];
            TRC_DBG(@"Product image url : %@",product.imageUrl )
            
            product.name = [productDict valueForKey:kName];
            TRC_DBG(@"Product Name : %@",product.name )
            
            [productArray addObject:product];
        }
        _productDetail.releatedProducts = productArray;
        
	}
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        _productDetail = nil;
        
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kInvalidData,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kProductDetailErr userInfo:userInfo];
    }
   	//Update the caller
	if([self.delegate respondsToSelector:@selector(parseComplete:)])
	{
		[self.delegate parseComplete:error];
	}
    
	TRC_EXIT
}

@end