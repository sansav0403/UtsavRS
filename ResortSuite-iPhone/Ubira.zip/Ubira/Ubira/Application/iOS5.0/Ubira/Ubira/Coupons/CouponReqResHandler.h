//
//  CouponReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"
#import "Coupon.h"

typedef enum
{
	kCUPReqGetCoupon,	
	kCUPReqDeleteCoupon,
	kCUPReqCouponDetails,
    kCupReqCouponCheck,
    kCupReqCouponAccept
} CUPReqState;

/*!
    @class          CouponReqResHandler
    @abstract       Handler the coupon request response.
    @discussion     Create the required url request and respond to the caller.
 */
@interface CouponReqResHandler : RequestResponseBase {
	
	CUPReqState     _cupReqState;
    Coupon          *coupon;
    NSArray         *_couponsList;
    NSString        *_couponCount;
}

@property (nonatomic) CUPReqState       cupReqState;
@property (nonatomic, retain) NSArray   *couponsList;
@property (nonatomic, retain) NSString  *couponCount;

- (void)coupons:(NSArray *)coupons productId:(NSString*)productid storeId:(NSString*)storeId; 
- (void)deleteCoupon:(NSString*)couponId;
- (void)couponDetails:(NSString*)productId storeId:(NSString*)storeId coupon:(Coupon*)aCoupon;

- (void)couponCheck:(NSString*)productId storeId:(NSString*)storeId competitorPrice:(NSString*)competitorPrice  resultString:(NSString*)resultString;

- (void)couponAccept:(NSString*)productId storeId:(NSString*)storeId competitorPrice:(NSString*)competitorPrice  resultString:(NSString*)resultString;
- (void)parseCouponCheckAccept:(NSData*)data cupReqstatus:(NSInteger)cupReqstatus;

@end