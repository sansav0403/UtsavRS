//
//  ProductReviewCell.h
//  Ubira
//
//  Created by [Cybage Team] on 30/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//


#import <UIKit/UIKit.h>
#import "RatingView.h"
#import "NSString+HTML.h"

#define kLabelHeightForOneLine  32
@class Review;

@protocol ProductReviewCellDelegate <NSObject>

- (void)moreActionDelegate:(NSIndexPath *)indexPath;

@end

/*!
    @class          ProductReviewCell
    @abstract       create the product review cell.
    @discussion     create the custom cell for all product review.
 */
@interface ProductReviewCell : UITableViewCell {
    UILabel     *postLabel;
    UILabel     *ratingLabel;
    UILabel     *postDateLabel;
    UILabel     *productDescriptionLabel;
    UIButton    *moreButton;
    NSIndexPath *selectedCellIndexPath;
    
    RatingView  *ratingView;
    NSString    *reviewDescription;
    BOOL        expand;
    id <ProductReviewCellDelegate>__unsafe_unretained  _delegate;
}

@property(nonatomic,assign) BOOL        expand;
@property (nonatomic, assign) id <ProductReviewCellDelegate> delegate;

- (void)setReviewDetails:(Review*)review indexPath:(NSIndexPath *)indexPath;
- (float)calculateHeightForCell:(NSString *)description;

@end
