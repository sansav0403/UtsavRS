//
//  SocialServiceCell.m
//  Ubira
//
//  Created by [Cybage Team] on 27/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "SocialServiceCell.h"
#import "FBConnect.h"
#import "FBSession.h"

static NSString* kApiKey = @"5587d77bb2adc4a1a81ff342a49d08a7";
// Enter either your API secret or a callback URL (as described in documentation):
static NSString* kApiSecret = @"2212fb168eb6649daab0c9a058def434";
//static NSString* kGetSessionProxy = nil; // @"<YOUR SESSION CALLBACK)>";

@implementation SocialServiceCell
@synthesize delegate;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
        
        ratingView = [[RatingView alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:ratingView];
        
        totalReviewsLable = [[UILabel alloc] initWithFrame:CGRectZero];
        [totalReviewsLable setBackgroundColor:[UIColor clearColor]];
        [totalReviewsLable setFont:[UIFont boldSystemFontOfSize:13.0]];
        [self.contentView addSubview:totalReviewsLable];
        
        favouriteButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [favouriteButton setImage:[UIImage imageNamed:@"favoritesIcon.png"] forState:UIControlStateNormal];
        [favouriteButton addTarget:self action:@selector(favouritesButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:favouriteButton];
        
        facebookButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [facebookButton setImage:[UIImage imageNamed:@"facebook.png"] forState:UIControlStateNormal];
        [facebookButton addTarget:self action:@selector(facebookButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:facebookButton];
        
        twitterButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [twitterButton setImage:[UIImage imageNamed:@"twitter.png"] forState:UIControlStateNormal];
        [twitterButton addTarget:self action:@selector(twitterButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:twitterButton];
        
        [self.contentView setBackgroundColor:[UIColor clearColor]];
		
		favoriteReqResHandler	=	nil;
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
	
	if (!self.editing) 
	{
        CGRect frame = CGRectZero;        
        frame = CGRectMake(100, 10, 70, 16);
        [ratingView setFrame:frame];
        
        
        frame = CGRectMake(170, 7, 100, 20);
        [totalReviewsLable setFrame:frame];
        
        frame = CGRectMake(120, 50, 25, 25);
        [favouriteButton setFrame:frame];
        
        frame = CGRectMake(155, 50, 25, 25);
        [facebookButton setFrame:frame];
        
        frame = CGRectMake(190, 50, 25, 25);
        [twitterButton setFrame:frame];
	}
}

/*!
 @function      setReviewsDetails
 @abstract      set product reviews details to cell.
 @discussion    set product reviews details to cell.
 @param         productDetails
 @result        void
 */
- (void)setReviewsDetails:(ProductDetail*)productDetails
{
    product = productDetails;
    [totalReviewsLable setText:[NSString stringWithFormat:@"%d %@", product.reviews,kProductReviews]];
    
    [ratingView setRating:product.rating];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)dealloc
{
    _delegate = nil;
    if(_session)
	{
		if(_session)
		{
			_session = nil;
		}
	}
    if (login) {
        [login dismissWithSuccess:NO animated:YES];
    }
	login = nil;
}

#pragma mark Social Networking button action

/*!
 @method        facebookButtonAction
 @abstract		open facebook login or home page if already logged in.
 @discussion	open facebook login or home page if already logged in.
 */
- (IBAction)facebookButtonAction:(id)sender
{
    if(login)
	{
		login = nil;
	}
	if(!login)
	{
		_session = [FBSession sessionForApplication:kApiKey secret:kApiSecret delegate:self];
		if(![_session resume])
		{
			login = [[FBLoginDialog alloc] initWithSession:_session];
			[login show];
		}
	}
}

/*!
 @method		twitterButtonAction
 @abstract		open twitter login or home page if already logged in.
 @discussion	open twitter login or home page if already logged in.
 */
- (IBAction)twitterButtonAction:(id)sender
{
    if([self.delegate respondsToSelector:@selector(twitterButtonActionDelegate)])
    {
        [self.delegate twitterButtonActionDelegate];
    }
}

/*!
 @method		favouritesButtonAction
 @abstract		add product to favorites list
 @discussion	add product to favorites list
 */
- (IBAction)favouritesButtonAction:(id)sender
{
    if (!favoriteReqResHandler) {		
		favoriteReqResHandler			=	[[FavoriteReqResHandler alloc]init];
		favoriteReqResHandler.delegate	=	self;
	}
	[favoriteReqResHandler addFavorite:product.productId];
}

#pragma mark - Facebook dialog delegate

- (void)dialog:(FBDialog*)dialog didFailWithError:(NSError*)error {
	TRC_DBG(@"%@",[NSString stringWithFormat:@"Error(%d) %@", error.code,
                 error.localizedDescription]);
	if (login)
	{
		login = nil;
	}
}

#pragma mark - Facebook session delegate

- (void)session:(FBSession*)session didLogin:(FBUID)uid 
{	
	NSString* fql = [NSString stringWithFormat:
					 @"select uid,name from user where uid == %lld", session.uid];
	
	NSDictionary* params = [NSDictionary dictionaryWithObject:fql forKey:@"query"];
	[[FBRequest requestWithDelegate:self] call:@"facebook.fql.query" params:params];
}

- (void)sessionDidNotLogin:(FBSession*)session {
	if (login)
	{
		login = nil;
	}
	TRC_DBG(@"%@",@"Canceled login");
}

- (void)sessionDidLogout:(FBSession*)session {
	TRC_DBG(@"Disconnected");
	if (login)
	{
		login = nil;
	}
}

#pragma mark - Facebook Request Delegate Methods

- (void)request:(FBRequest*)request didLoad:(id)result {
	@try {
		
        if ([request.method isEqualToString:@"facebook.fql.query"]) 
        {
            FBStreamDialog* dialog = [[FBStreamDialog alloc] init];
            dialog.delegate = self;
            dialog.userMessagePrompt = @"Enter your Feeds";
            
            dialog.attachment = [NSString stringWithFormat:@"{\"name\":\"UBIRA for iPhone\",\"href\":\"http://developers.facebook.com/connect.php?tab=iphone\",\"caption\":\"%@\",\"media\":[{\"type\":\"image\",\"src\":\"%@\",\"href\":\"http://developers.facebook.com/connect.php?tab=iphone/\"}],\"properties\":{\"another link\":{\"text\":\"Ubira home page\",\"href\":\"http://www.ubira.com\"}}}",product.name,product.imageUrl];
                        
            [dialog show];
            
        } else if ([request.method isEqualToString:@"facebook.users.setStatus"]) {
            NSString* success = result;
            if ([success isEqualToString:@"1"]) {
                TRC_DBG(@"%@",[NSString stringWithFormat:@"Status successfully set"]); 
            } else {
                TRC_DBG(@"%@",[NSString stringWithFormat:@"Problem setting status"]); 
            }
        } 
	}
	@catch (NSException * e) {
		TRC_DBG(@"Error -%@", [e description]);
	}
	
}

- (void)request:(FBRequest*)request didFailWithError:(NSError*)error {
	TRC_DBG(@"%@",[NSString stringWithFormat:@"Error(%d) %@", error.code,
                 error.localizedDescription]);
}

#pragma mark other methods
/*!
 @function      askPermission
 @abstract		Method is used to ask permission to access facebook account  
 @discussion	Method is used to ask permission to access facebook account 
 @param			target		
 @result		void
 */
- (void)askPermission:(id)target {
	FBPermissionDialog* dialog = [[FBPermissionDialog alloc] init];
	dialog.delegate = self;
	dialog.permission = @"status_update";
	[dialog show];
}

/*!
 @function		publishFeed
 @abstract		Method is used to publish feeds on facebook  
 @discussion	Method is used to publish feeds on facebook 
 @param			target		
 @result		void
 */
- (void)publishFeed:(id)target {
	FBStreamDialog* dialog = [[FBStreamDialog alloc] init];
	dialog.delegate = self;
	dialog.userMessagePrompt = @"Example prompt";
	dialog.attachment = @"{\"name\":\"Facebook Connect for iPhone\",\"href\":\"http://developers.facebook.com/connect.php?tab=iphone\",\"caption\":\"Caption\",\"description\":\"Description\",\"media\":[{\"type\":\"image\",\"src\":\"http://img40.yfrog.com/img40/5914/iphoneconnectbtn.jpg\",\"href\":\"http://developers.facebook.com/connect.php?tab=iphone/\"}],\"properties\":{\"another link\":{\"text\":\"Facebook home page\",\"href\":\"http://www.facebook.com\"}}}";
	[dialog show];
}

/*!
 @function		setStatus
 @abstract		Method is used to set facebook status 
 @discussion	Method is used to set facebook status
 @param			target		
 @result		void
 */
- (void)setStatus:(id)target {
	NSString *statusString = @"Testing iPhone Connect SDK";
	NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
							statusString, @"status",
							@"true", @"status_includes_verb",
							nil];
	[[FBRequest requestWithDelegate:self] call:@"facebook.users.setStatus" params:params];
}

/*!
 @function      uploadPhoto
 @abstract		Call back method uploading photo on face book 
 @discussion	Call back method uploading photo on face book
 @param			target		
 @result		void
 */
- (void)uploadPhoto:(id)target {
	NSString *path = @"http://www.facebook.com/images/devsite/iphone_connect_btn.jpg";
	NSURL    *url  = [NSURL URLWithString:path];
	NSData   *data = [NSData dataWithContentsOfURL:url];
	UIImage  *img  = [[UIImage alloc] initWithData:data];
	
	NSDictionary *params = nil;
	[[FBRequest requestWithDelegate:self] call:@"facebook.photos.upload" params:params dataParam:(NSData*)img];
}

#pragma mark RequestResponseBaseDelegate
/*!
 @function		parseComplete
 @abstract		Call back method server rever request 
 @discussion	Call back method server rever request
 @param			error		
 @result		void
 */
- (void)parseComplete:(NSError*)error
{
	if(error)
    {
        TRC_ERR(@"Add Favorite Error %@",error)
		
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
		
		[self showAlertView:kFavouritesTitle alertMessage:errorString setDelegate:nil];
    }
    else
    {		
		// Show successful message.
		[self showAlertView:@"" alertMessage:kProductAddSuccessfulDescription setDelegate:nil];
	}	
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function      showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
                alertMessage - Message description for AlertView		
 @result		void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
	[alert show];
}

@end
