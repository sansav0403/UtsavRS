//
//  ProductUpdatePriceReqResHandler.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "ProductUpdatePriceReqResHandler.h"
#import "LocationManager.h"

@implementation ProductUpdatePriceReqResHandler

/*!
 @function      updatePrice
 @abstract      update the product price on the server for selected merchant.
 @discussion    update the product price on the server for selected merchant.
 @param         productId - product id.
 @param         merchantId - merchant id.
 @param         updatedprice - new price to update.
 */
- (void)updatePrice:(NSString*)productId merchantId:(NSString*)merchantId updatedprice:(NSString*)price
{
	TRC_ENTRY
	NSString* postData = [NSString stringWithFormat:@"productid=%@&merchantid=%@&price=%@&lat=%f,&long=%f"
						  ,productId
						  ,merchantId
						  ,price
						  ,[LocationManager sharedInstance].currentLocation.coordinate.latitude
						  ,[LocationManager sharedInstance].currentLocation.coordinate.longitude
						  ];
	
	NSData* data=[postData dataUsingEncoding:NSUTF8StringEncoding];

	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/price/update",kUbiraServerUrl]];
	NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
	[theRequest setHTTPMethod:kPost];			
	[theRequest setValue:kApplicationFormEncoded forHTTPHeaderField:kContentType];
	[theRequest setHTTPBody:data];
	
	[webService makeRequest:theRequest];
    TRC_EXIT
}

/*!
 @function      handleReceivedData
 @abstract      parse the update price response.
 @discussion    parse the update price response.
 @param         data - server response.
 */
- (void)handleReceivedData:(NSData*)data
{
    if (![self checkForErrors:data]) {
        return;
    }
    
	NSString *resultString = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
    
    NSString *newResponse = [resultString stringByDecodingXMLEntities];
    
    TRC_DBG(@"Product Price Update", newResponse)
    
	NSDictionary *resultDictionary = [newResponse JSONValue];
    
    NSError *error = nil;
    @try {
        if(resultDictionary)
        {
            if([resultDictionary valueForKey:kSuccess])
            {
                error = nil;
            }
            else
            {
                NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:[resultDictionary valueForKey:kError],kError, nil];
                
                error = [NSError errorWithDomain:@"Ubira" code:kNoMerchantFound userInfo:userInfo];
            }
        }
    }
    @catch (NSException *exception) 
    {
        TRC_EXCEPTION(exception);
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kServerError,kError, nil];
        error = [NSError errorWithDomain:@"Ubira" code:kInvalidDataErr userInfo:userInfo];
    }
    
    if([self.delegate respondsToSelector:@selector(parseComplete:)])
    {
        [self.delegate parseComplete:error];
    }
}

@end