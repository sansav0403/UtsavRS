//
//  ProductReviewViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductReviewReqResHandler.h"
#import "ProductReviewCell.h"

#define kHeightOfOtherLabels    49
/*!
 @class         ProductReviewViewController
 @abstract      handler the product review details presentation.
 @discussion    handler the product review details presentation.
 */
@interface ProductReviewViewController : UIViewController<RequestResponseBaseDelegate,ProductReviewCellDelegate> {
    
    IBOutlet UITableView        *productReviews;
    NSArray                     *reviewList;
    NSString                    *productId;
    ProductReviewReqResHandler  *productReviewReqResHandler;
    UIActivityIndicatorView     *activityIndicator;
    NSDate                      *_startDate;
    NSIndexPath                 *selectedCellIndexPath; 
}

@property (nonatomic, retain) IBOutlet UITableView             *productReviews;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, retain) NSDate                           *startDate;
@property (nonatomic, retain) NSIndexPath                      *selectedCellIndexPath;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil productId:(NSString *)aProductId;
- (float)calculateHeightForCell:(NSString *)description;

@end
