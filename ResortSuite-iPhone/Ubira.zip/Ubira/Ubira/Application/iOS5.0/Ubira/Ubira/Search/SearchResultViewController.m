//
//  SearchResultViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "SearchResultViewController.h"
#import "ProductDetailsViewController.h"
#import "ProductCell.h"
#import "ProductData.h"
#import "ImageDownloadQueue.h"
#import "UserAnalytics.h"
#import "ValidationHandler.h"

#define kProductCell                    @"ProductCell"
#define kProductDetailsViewController   @"ProductDetailsViewController"

static const int pageSize = 30;

@implementation SearchResultViewController

@synthesize searchKeyword = _searchKeyword;
@synthesize loadingFooterView;
@synthesize productTbl;
@synthesize barCode = _barCode;
@synthesize activityIndicator;
@synthesize startDate = _startDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [[ImageDownloadQueue sharedQueue] cancelAllOperations];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setTitle:kSearchTitle];
    self.productTbl.tableFooterView = loadingFooterView;
    [self.productTbl.tableFooterView setHidden:YES];
        
    rowCount = 0;
    currentPage = 1;
    
	[searchBar setText:self.searchKeyword];
       
    [searchBar setTintColor:kSCNavigationBarTintColor];
    
    //Search for the product with the keyword text
    productSearchReqResHandler = [[ProductSearchReqResHandler alloc]init];
    
    //set delegate for fetched results controller
    productSearchReqResHandler.delegateForNSFetchResultsController = self;
    [productSearchReqResHandler setDelegate:self];
    
    //validate search string
    NSMutableString *text = [NSMutableString stringWithString:self.searchKeyword];
    [text replaceOccurrencesOfString:@" " withString:@"%20" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [text length])];
    self.searchKeyword = text;

    productSearchReqResHandler.searchString = self.searchKeyword;
    
    //set current page and page size
    productSearchReqResHandler.currentPage = [NSNumber numberWithInt:currentPage];
    productSearchReqResHandler.pageSize    = [NSNumber numberWithInt:pageSize];
    
    //prepare for new search
    [productSearchReqResHandler prepareForNewSearch];
    
    //search for product
    [productSearchReqResHandler searchForProduct:YES];
}

- (void)viewDidUnload
{
    self.searchKeyword = nil;
    productTbl = nil;
    searchBar = nil;
    [self setLoadingFooterView:nil];
    [self setActivityIndicator:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsSearchResultScreen startDate:self.startDate endDate:[NSDate date]];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - SearchBarDelegate
// return NO to not become first responder
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)aSearchBar
{
    [searchBar setShowsCancelButton:YES animated:YES];
    return YES;
}

// called when cancel button pressed
- (void)searchBarCancelButtonClicked:(UISearchBar *)aSearchBar
{
    [searchBar setShowsCancelButton:NO animated:YES];
    [searchBar resignFirstResponder];
}

// called when keyboard search button pressed
- (void)searchBarSearchButtonClicked:(UISearchBar *)aSearchBar
{
    TRC_ENTRY
    //hide the cancel button of search bar
    [aSearchBar setShowsCancelButton:NO];
    TRC_DBG(@"Search with keyword %@",aSearchBar.text)
    aSearchBar.text = [ValidationHandler trimCurrentString:aSearchBar.text];
    if([ValidationHandler checkSpaceOrNewLineCharacter:aSearchBar.text])
    {
        [activityIndicator setHidden:NO];
        [activityIndicator startAnimating];
        
        //remove whitespaces from initails and end of string
        NSMutableString *text = (NSMutableString *)aSearchBar.text;
        [text replaceOccurrencesOfString:@" " withString:@"%20" options:NSCaseInsensitiveSearch range:NSMakeRange(0, [text length])];
        self.searchKeyword = text;
        
        currentPage = 1;
        [searchBar resignFirstResponder];
        productSearchReqResHandler.searchString = self.searchKeyword;
        
        //set current page
        productSearchReqResHandler.currentPage = [NSNumber numberWithInt:currentPage];
        productSearchReqResHandler.pageSize    = [NSNumber numberWithInt:pageSize];
        
        //prepare for new search
        [productSearchReqResHandler prepareForNewSearch];
        
        //request fro new search
        [productSearchReqResHandler searchForProduct:YES];
    }
    TRC_EXIT
}

#pragma mark -
#pragma mark Table view datasource and delegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	// Number of sections is the number of regions
	return 1;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	id <NSFetchedResultsSectionInfo> sectionInfo = [[productSearchReqResHandler.fetchedResultsController sections] objectAtIndex:0];
    return [sectionInfo numberOfObjects]; 
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
    static NSString *identifier = @"Cell"; //kProductCell;
    ProductCell *cell = (ProductCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if(cell == nil)
    {
        cell = [[ProductCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    // Download images for visible(4) cells.
    if(indexPath.row < 4)
    {
         [self firstVisibleCellImageDownload:indexPath productCell:cell];
    }
    // Configure the cell.
	[self configureCell:cell atIndexPath:indexPath];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	/*
	 To conform to the Human Interface Guidelines, selections should not be persistent --
	 deselect the row after it has been selected.
	 */
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
        
    //Selected product for details
    ProductData *productData = [productSearchReqResHandler.fetchedResultsController objectAtIndexPath:indexPath];
    
    //Navigate to details screen of the selected product
    ProductDetailsViewController *productDetailsViewController = [[ProductDetailsViewController alloc] initWithNibName:kProductDetailsViewController bundle:[NSBundle mainBundle]];
    [productDetailsViewController setProductData:productData];

    [self.navigationController pushViewController:productDetailsViewController animated:YES];
}

/*!
 @function      firstVisibleCellImageDownload
 @abstract      load the images for the products if user is not scrolled the scrollview
 @discussion    load the images for the products if user is not scrolled the scrollview.
 @param         NSIndexPath
                productCell
 @result        void
 */
- (void)firstVisibleCellImageDownload:(NSIndexPath*)indexPath productCell:(ProductCell*)productCell
{
    // Only load cached images; defer new downloads until scrolling ends
    ProductData *productData = [productSearchReqResHandler.fetchedResultsController objectAtIndexPath:indexPath];
    if(!productData.imageData)
    {
        [productData downloadImage];        
    }
}

/*!
 @function      loadImagesForOnscreenRows
 @abstract      load the images for the products
 @discussion    load the images for the products.
 @param         void
 @result        void
 */
- (void)loadImagesForOnscreenRows
{
    NSArray *visibleCells = [productTbl indexPathsForVisibleRows];
    
    for(NSIndexPath *indexPath in visibleCells)
    {
        ProductData *productData = [productSearchReqResHandler.fetchedResultsController objectAtIndexPath:indexPath];
        if(!productData.imageData)
        {
            TRC_DBG(@"Start Download");
            [productData downloadImage];           
        }
    }
}

#pragma mark - Parsing complete delegate
/*!
 @function		parseComplete
 @abstract		delegate on parse complete.
 @discussion	Take the action based on the parameter.
 @param			error - server response if no error it will be nil.
 */
- (void)parseComplete:(NSError*)error
{
	TRC_ENTRY
	if(error != nil)
	{
		TRC_ERR(@"Search result : %@",error)
		NSString *errorString = [[error userInfo] valueForKey:@"error"];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kSearchTitle message:errorString delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
        [alert show];
	}
	else
	{
        id <NSFetchedResultsSectionInfo> sectionInfo = [[productSearchReqResHandler.fetchedResultsController sections] objectAtIndex:0];
        rowCount = [sectionInfo numberOfObjects]; 
        
		if(rowCount == 0)
        {
            //If result is not found
            NSString *title = nil;
            NSString *description = nil; 
            if(self.barCode)
            {
                title = kNoProductFound;
                description = kNoProductFoundDesc;
            }   
            else
            {
                title = kNoResultFound;
                description = kNoResultFoundDesc;
            }
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:description delegate:self cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
            [alert show];
        }          
        [self.productTbl.tableFooterView setHidden:YES];        
	}
    productSearchReqResHandler.requestInProgress = NO;
    [activityIndicator stopAnimating];
	TRC_EXIT
}

/*!
 @function		scrollViewDidEndDecelerating
 @abstract		tells the delegate that scroll view ends
 @discussion	Tells the delegate that the table scroll view has ended decelerating the 
                scrolling movement.
 @param			scrollView - The product search table scroll view object that is decelerating
                the scrolling of the content view.
 */
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
	
    @try {
        [self loadImagesForOnscreenRows];
        
		int row = [self.productTbl numberOfRowsInSection:0] - 1;
        
		NSIndexPath* ip = [NSIndexPath indexPathForRow:row inSection:0];
        
		NSArray *visiblePaths = [self.productTbl indexPathsForVisibleRows];
		
		if( [visiblePaths containsObject:ip] == YES ) {
			
            [self.productTbl.tableFooterView setHidden:NO];
            productSearchReqResHandler.currentPage = [NSNumber numberWithInt:++currentPage];
            [productSearchReqResHandler searchForProduct:NO];     
        }
	} @catch (NSException * e) {
		TRC_ERR(@"%@", [e reason]);
	}
}

/**
 Delegate methods of NSFetchedResultsController to respond to additions, removals and so on.
 
 Effective way of using NSFetchedResultsController is to implement all delagates of NSFetchedResultsController 
 and do modification to table in batches by scoping all the changes between [tableview beginUpdates] ..and
 [tableView endUpdates]. Even though this  method works here, there is a performance issue reported when we go 
 with this approach. This already reported to apple through a radar.http://openradar.appspot.com/7316174
 
 In the context of this application this performace issue will have a bad impact as we are providing unlimited scrolling
 on the table view. Hence we are using this method only while updating an existing row and in other cases we are reloading
 the table which is having less performance hit compared to above mentioned issue.
*/
- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(NSIndexPath *)newIndexPath {
	
	UITableView *tableView = self.productTbl;
    
	switch(type) {	
		case NSFetchedResultsChangeUpdate:
            [self configureCell:[tableView cellForRowAtIndexPath:indexPath] atIndexPath:indexPath];
            break;
	}
}

- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller {
	// The fetch controller has sent all current change notifications, so tell the table view to process all updates.
    [self.productTbl reloadData];    
}

- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath {
	
    // Configure the cell to show the update
    ProductData *productData = [productSearchReqResHandler.fetchedResultsController objectAtIndexPath:indexPath];
	ProductCell * productCell = (ProductCell*) cell;
    [productCell setProductData:productData]; 
}

@end