//
//  ProductDetailsViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProductDetailsViewController.h"
#import "ProductSummaryCell.h"
#import "RelatedProductCell.h"
#import "UpdatePriceViewController.h"
#import "ProductSummaryViewController.h"
#import "ProductReviewViewController.h"
#import "TwitterPopoverViewController.h"
#import "ImageDownloadQueue.h"
#import "OfferDetailsViewController.h"
#import "CouponDetailViewController.h"
#import "UserAnalytics.h"
#import "StoreListViewController.h"
#import "CouponsViewController.h"
#import "ValidationHandler.h"

#define kProductSummaryCell     @"ProductSummaryCell"
#define kProductSocialCell      @"SocialServiceCell"
#define kMerchantsCell          @"MerchantStoreCell"
#define kRelatedProductCell     @"RelatedProductCell"

#define kProductSummaryViewController   @"ProductSummaryViewController"
#define kProductReviewViewController    @"ProductReviewViewController"
#define kUpdatePriceViewController      @"UpdatePriceViewController"

#define kTotalSections              3
#define kSummaryCellHeight          95
#define kStoreCellHeight            70
#define kRelatedProductCellHeight   120

#define kCouponDetailViewController   @"CouponDetailViewController"
#define kCouponsViewController        @"CouponsViewController"

@implementation ProductDetailsViewController

@synthesize productDetailsTable;
@synthesize product = _product;
@synthesize relatedProductView;
@synthesize relatedProductLbl; 
@synthesize activityIndicator;
@synthesize startDate = _startDate;
@synthesize coupon = _coupon;
@synthesize _merchantStore;
@synthesize couponCount = _couponCount;
@synthesize reuestResponseState = reuestResponseState;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        productDetailReqResHandler  = [[ProductDetailReqResHandler alloc]init];
        [productDetailReqResHandler setDelegate:self];
    }
    return self;
}

- (void)dealloc
{
    [[ImageDownloadQueue sharedQueue] cancelAllOperations];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

/*!
 @function      storeDetails
 @abstract      set name of the product
 @discussion 
 @param         product name
 @result        void
 */
- (void)setProductData:(ProductData*) productData
{
    _product = [[Product alloc] init];
    _product.name = productData.productName;
    _product.productId = productData.productId;
}

/*!
 @function      storeDetails
 @abstract      load the store details
 @discussion    load the store details and chech whether user is logged into any store or not.
 @param         void
 @result        void
 */
- (void)storeDetails
{
	productDetail = [[ProductDetail alloc] init];
    reuestResponseState = kResReqStProductList;
    
    if(sharedStore.storeId)
    {
        [productDetailReqResHandler productDetails:self.product.productId merchantid:sharedStore.storeId productDetails:productDetail];
    }
	else
        [productDetailReqResHandler productDetails:self.product.productId merchantid:@"0" productDetails:productDetail];
    [self.productDetailsTable setUserInteractionEnabled:NO];
}

#pragma mark - View lifecycle
- (void)viewDidLoad
{
	[super viewDidLoad];
    [self setTitle:self.product.name];
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:kGrayBackGroundImg]]];
    [productDetailsTable setBackgroundColor:[UIColor clearColor]];
    [self.productDetailsTable setUserInteractionEnabled:FALSE];
    [self.relatedProductLbl setText:kRelatedProductsLblText];
    // Do any additional setup after loading the view from its nib.
	
	UIView	*view = [[UIView alloc]initWithFrame:CGRectZero];
	[self.productDetailsTable setTableFooterView:view];
	
    //set the navigation back button with back title
    UIBarButtonItem *back = [[UIBarButtonItem alloc] initWithTitle:kBack style:UIBarButtonItemStylePlain target:self action:nil];	
	self.navigationItem.backBarButtonItem = back;
    
    sharedStore = [Store sharedStore];
    reuestResponseState = kResReqStNone;
    _couponCount = [[NSMutableString alloc] init];
    [self storeDetails];
}

- (void)viewDidUnload
{
    [self setRelatedProductView:nil];
    [self setRelatedProductLbl:nil];
    [self setProductDetailsTable:nil];
    [self setActivityIndicator:nil];
     [[NSNotificationCenter defaultCenter]removeObserver:self name:kCheckInCheckOutNotificationKey object:nil];
    
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
    
    // If not check in provide checkin button
    self.navigationItem.rightBarButtonItem = (sharedStore.storeId)?nil:[[UIBarButtonItem alloc]initWithTitle:kCheckInButtonTitle style:UIBarButtonItemStylePlain target:self action:@selector(checkIntoStore)];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(storeDetails) name:kCheckInCheckOutNotificationKey object:nil];
}

- (void)viewWillDisappear:(BOOL)animated
{    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsProductDetailScreen startDate:self.startDate endDate:[NSDate date]];       
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table view datasource and delegate methods

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    float cellHeight = kSummaryCellHeight;
    
    switch (indexPath.section) 
    {
        case kFirstCell:
            cellHeight = kSummaryCellHeight;
            break;
        case kSecondCell:
            cellHeight = kStoreCellHeight;
            break;
        case kThirdCell:
            cellHeight = kRelatedProductCellHeight;
            break;
    }
    return cellHeight;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	// Number of sections is the number of regions
    if(![productDetail.releatedProducts count])
        return kTotalSections - 1;
	return kTotalSections;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case kFirstCell:
            return 0;
        case kSecondCell:
            return 0;
        case kThirdCell:
            return relatedProductView.frame.size.height;
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case kFirstCell:
            return nil;
            
        case kSecondCell:
            return nil;
            
        case kThirdCell:
            return relatedProductView;
      }
    return nil;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section 
{    
    if(productDetail.name)
    {
        switch (section) {
            case kFirstCell:
                return 2;
                
            case kSecondCell:
                return [productDetail.merchantStoreList count];
                
            case kThirdCell:
                return 1;
        }
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
    static NSString *summaryIdentifier = kProductSummaryCell;
    static NSString *socialIdentifier = kProductSocialCell;
    static NSString *merchantIdentifier = kMerchantsCell;
    static NSString *relatedProductIdentifier = kRelatedProductCell;
    UITableViewCell *cell = nil;
    switch (indexPath.section) 
    {
        case kFirstCell:
        {
            switch (indexPath.row) 
            {
                case kFirstCell:
                {
                    ProductSummaryCell *cell = (ProductSummaryCell *)[tableView dequeueReusableCellWithIdentifier:summaryIdentifier];
                    if(!cell)
                    {
                        cell = [[ProductSummaryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:summaryIdentifier];
                    }
                    [cell setSummaryDetails:productDetail];
                    return cell;
                }
                break;
                case kSecondCell:
                {
                    SocialServiceCell *cell = (SocialServiceCell *)[tableView dequeueReusableCellWithIdentifier:socialIdentifier];
                    if(!cell)
                    {
                        cell = [[SocialServiceCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:socialIdentifier];
                    }
                    [cell setDelegate:self];
                    [cell setReviewsDetails:productDetail];
                    return cell;
                }
                    break;
            }
        }
        break;
        case kSecondCell:
        {
            MerchantStoreCell *cell = (MerchantStoreCell *)[tableView dequeueReusableCellWithIdentifier:merchantIdentifier];
            if(!cell)
            {
                cell = [[MerchantStoreCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:merchantIdentifier];
            }
            
            [cell setMerchantStoreDetails:[productDetail.merchantStoreList objectAtIndex:indexPath.row] storeIndex:indexPath.row];
            [cell setDelegate:self];
        
            return cell;
        }
        break;
        default:
        {
            RelatedProductCell *cell = (RelatedProductCell *)[tableView dequeueReusableCellWithIdentifier:relatedProductIdentifier];
            if(!cell)
            {
                cell = [[RelatedProductCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:relatedProductIdentifier];
                [cell setRelatedProducts:productDetail.releatedProducts];
                [cell setRelatedProductsData];
            }
            [cell setDelegate:self];
            return cell;
        }
        break;
    }

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	/*
	 To conform to the Human Interface Guidelines, selections should not be persistent --
	 deselect the row after it has been selected.
	 */
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.section) 
    {
        case kFirstCell:
        {
            switch (indexPath.row) 
            {
                case kFirstCell: //If summary cell
                {
                    ProductSummaryViewController *productSummaryViewController = [[ProductSummaryViewController alloc] initWithNibName:kProductSummaryViewController bundle:[NSBundle mainBundle]];
                    productSummaryViewController.productDetail = productDetail;
                    [self.navigationController pushViewController:productSummaryViewController animated:YES];
                }
                break;
                case kSecondCell: //If rating cell
                {
                    ProductReviewViewController *productReviewViewController = [[ProductReviewViewController alloc] initWithNibName:kProductReviewViewController bundle:[NSBundle mainBundle] productId:productDetail.productId];
                    [self.navigationController pushViewController:productReviewViewController animated:YES];
                }    
                break;
            }
        } 
        break;
            
        default:
            break;
    }
}

#pragma mark - Parsing complete delegate
-(void)parseComplete:(NSError*)error
{       
	TRC_ENTRY
	if(error != nil)
	{
        reuestResponseState = kResReqStNone;
		TRC_ERR(@"%@",error)
        NSString *errorString = [[error userInfo] valueForKey:@"error"];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kProductDetails message:errorString delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
        [alert show];
	}
	else
	{
		//update UI		
        switch (reuestResponseState)
        {
            case kResReqStProductList:
            {
                TRC_DBG(@"=============================================================")
                TRC_DBG(@"Product Name : %@",productDetail.name)
                TRC_DBG(@"Product instore Count : %d",[productDetail.inStore count])
                [self.productDetailsTable reloadData];
            }
                break;
            case kResReqStCouponCheck:
            {
                TRC_DBG(@"CouCnt in ParseCom=%@",self.couponCount);
                TRC_DBG(@"CouCnt intValue =%d",[_couponCount intValue]);
                if ([_couponCount intValue])
                {
                    NSString *altMsg = [NSString stringWithFormat:@"%@ %@ %@",sharedStore.name,kPurchaseProductDescriptionUpdate,kPurchaseProductDescriptionSecond];
                    [self showAlertView:nil alertMessage:altMsg setDelegate:self];
                }
                else
                {
                    //Navigate to online buy page
                    [self navigateToUrl:_merchantStore.detailsUrl];
                }
            }
                break;
            case kResReqStCouponAccept:
            {
                TRC_DBG(@"copCnt =%@",_couponCount);
                if ([_couponCount intValue])
                {
                    //self.couponCount = nil;
                    CouponsViewController *couponsViewController = [[CouponsViewController alloc] initWithNibName:kCouponsViewController bundle:[NSBundle mainBundle]];
                    [couponsViewController setProductid:_merchantStore.productId];
                    
                    [self.navigationController pushViewController:couponsViewController animated:YES];	
                }
                else
                {
                    [self navigateToUrl:_merchantStore.detailsUrl];
                }
            }
                break;
            default:
                break;
        }
	}
    
    [self.activityIndicator stopAnimating];
    [self.productDetailsTable setUserInteractionEnabled:TRUE];
	TRC_EXIT
}

#pragma mark - SocialServiceCellDelegate
- (void)twitterButtonActionDelegate
{
    TwitterPopoverViewController *tweet = [[TwitterPopoverViewController alloc] initWithNibName:@"TwitterPopoverViewController" bundle:[NSBundle mainBundle] product:productDetail];
    [self.navigationController pushViewController:tweet animated:YES];
}

#pragma mark - Buy Button or Update Button action
/*!
 @function      buyActionDelegate
 @abstract      delegate method to load the update price screen
 @discussion    This is the delegate method for the update button click.
 @param         merchantStore
 @result        void
 */
- (void)buyActionDelegate:(MerchantStore*)merchantStore
{
    _merchantStore = merchantStore;
    
    // Get user preference
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    BOOL enabled = [defaults boolForKey:@"enabledSpecialOffers"];
    
    if(sharedStore.storeId && enabled)
    {
        [self couponRequestResponseHandler:kResReqStCouponCheck];
        
        // call coupon/check api for avilable coupon
        //In this call merchantId is the checkedin store id.
        [couponReqResHandler couponCheck:_merchantStore.productId storeId:sharedStore.storeId competitorPrice:[ValidationHandler filterNumbersFromString:_merchantStore.price] resultString:_couponCount];
    }
    else
    {
        //Navigate to details screen of the selected product
        [self navigateToUrl:merchantStore.detailsUrl];
    }
}

/*!
 @function      updateActionDelegate
 @abstract      delegate method to load the update price screen
 @discussion    This is the delegate method for the update button click.
 @param         merchantStore
 @result        void
 */
- (void)updateActionDelegate:(MerchantStore*)merchantStore
{
    UpdatePriceViewController *updatePriceViewController = [[UpdatePriceViewController alloc] initWithNibName:kUpdatePriceViewController bundle:[NSBundle mainBundle]];
    [updatePriceViewController setMerchantId:merchantStore.merchantId];
    [updatePriceViewController setProductId:productDetail.productId];
    [updatePriceViewController setProductTitle:productDetail.name];
    [self.navigationController pushViewController:updatePriceViewController animated:YES];
}

#pragma make - RelatedProductCellDelegate
/*!
 @function      relatedProdcutTapedDelegate
 @abstract      delegate method to load related product
 @discussion    delegate method to load selected related product for details.
 @param         currentIndex
 @result        void
 */
-(void) relatedProdcutTapedDelegate :(int)currentIndex
{
    Product *relatedProduct = [productDetail.releatedProducts objectAtIndex:currentIndex];
    
    //Navigate to details screen of the selected product
    [self navigateToUrl:relatedProduct.detailsUrl];
}

#pragma mark 
#pragma mark AlertView Methods
/*!
 @function      showAlertView
 @abstract		Common method to display alert message 
 @discussion	Common method to display alert message 
 @param			alertTitle - Title for AlertView
                alertMessage - Message description for AlertView		
 @result		void
 */
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:alertTitle message:alertMessage delegate:currentDelegate cancelButtonTitle:kRejectButtonTitle otherButtonTitles:kAcceptButtonTitle, nil];
	[alert show];
}

/*!
 @method        clickedButtonAtIndex
 @abstract		redirect to Login Page 
 @discussion	redirect to Login Page when password sent successfully
 */
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case kReject:
        {
            //Navigate to details screen of the selected product
            [self navigateToUrl:_merchantStore.detailsUrl];
        }
             break;
        case kAccept:
        {
            [self.activityIndicator stopAnimating];
            [self.productDetailsTable setUserInteractionEnabled:FALSE];
            
            if (_coupon)
            {
                _coupon = nil;
            }
            _coupon = [[Coupon alloc] init];
            
            [self couponRequestResponseHandler:kResReqStCouponAccept];
            [couponReqResHandler couponAccept:_merchantStore.productId storeId:sharedStore.storeId competitorPrice:[ValidationHandler filterNumbersFromString:_merchantStore.price] resultString:_couponCount];
            
            TRC_DBG(@"productId:%@, merchantid:%@",_merchantStore.productId,sharedStore.storeId);
        }
            break;
        default:
            break;
    }
}

#pragma mark - Other Methods

/*!
 @function      checkIntoStore
 @abstract      redirect to store list 
 @discussion    redirect to store list for checkIn
 @param         id
 @result        void
 */
- (void)checkIntoStore
{
    StoreListViewController* storeListViewController = [[StoreListViewController alloc]init];
    [self.navigationController pushViewController:storeListViewController animated:YES];
}

/*!
 @function      couponRequestResponseHandler
 @abstract      set coupon response state  
 @discussion    set coupon response state 
 @param         reqresState - which needs to set
 @result        void
 */
- (void)couponRequestResponseHandler:(NSInteger)reqresState
{
    if(couponReqResHandler)
    {
        couponReqResHandler = nil;
    }
    couponReqResHandler = [[CouponReqResHandler alloc] init];
    [couponReqResHandler setDelegate:self];
    reuestResponseState = reqresState;
}

/*!
 @function      navigateToUrl
 @abstract      redirect to given url 
 @discussion    redirect to given url
 @param         pageUrl - url address to navigate
 @result        void
 */
- (void)navigateToUrl:(NSString*)pageUrl
{
    //Navigate to online buy screen of the selected product
    OfferDetailsViewController *offerDetailsViewController = [[OfferDetailsViewController alloc] initWithNibName:kOfferDetailsViewController bundle:[NSBundle mainBundle] url:pageUrl];
    
    [self.navigationController pushViewController:offerDetailsViewController animated:YES];
}

@end