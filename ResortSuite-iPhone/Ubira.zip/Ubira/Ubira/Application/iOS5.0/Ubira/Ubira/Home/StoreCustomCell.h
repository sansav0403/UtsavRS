//
//  StoreCustomCell.h
//  Ubira
//
//  Created by [Cybage Team] Parihar on 23/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Store.h"

/*!
    @protocol       StoreListViewControllerDelegate
    @abstract       delegate for storeId of checkin 
    @discussion     implement delegate for checkin storeId 
 */
@protocol StoreCustomCellDelegate <NSObject>
- (void)checkInActionDelegate:(Store *)aStore;
@end

/*!
    @class          StoreCustomCell
    @abstract       This class is a custom table cell class 
    @discussion     This class is a custom table cell class
*/
@interface StoreCustomCell : UITableViewCell <StoreImageDownloadDelegate>
{
	// IBOutlets
	IBOutlet UILabel			*storeNameLbl;
	IBOutlet UILabel			*storeAddressLbl;
	IBOutlet UIImageView		*storeImageView;
	IBOutlet UIButton			*storeCheckInBtn;
	
	//Others
	id<StoreCustomCellDelegate>	__unsafe_unretained _delegate;
	Store						*store;	
}

@property (nonatomic,retain) IBOutlet UILabel		*storeNameLbl;
@property (nonatomic,retain) IBOutlet UILabel		*storeAddressLbl;;
@property (nonatomic,retain) IBOutlet UIImageView	*storeImageView;
@property (nonatomic,retain) IBOutlet UIButton		*storeCheckInBtn;
@property (nonatomic,assign) id						delegate;

- (void)setStoreData:(Store *)currStore;
- (IBAction)checkInToStoreAction :(id)sender;

@end