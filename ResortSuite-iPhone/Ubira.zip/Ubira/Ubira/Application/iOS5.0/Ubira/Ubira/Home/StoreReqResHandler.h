//
//  StoreReqResHandler.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RequestResponseBase.h"
#import "Store.h"
#import "LocationManager.h"

typedef enum
{
	kSTReqNone,
	kSTReqGettingStoreList,
	kSTReqAddingNewStore,
	kSTReqCheckIn
}StoreRequestState;



/*!
 @class          StoreReqResHandler
 @abstract       Handler the store request response.
 @discussion     Create the required url request and respond to the caller.
 */
@interface StoreReqResHandler : RequestResponseBase <LocationManagerDelegate> {
    
	Store               *_store;
	StoreRequestState	_storeReqState;
	
	NSArray             *_storeList;
	NSString            *_storeId;
}

@property (nonatomic)			StoreRequestState		_storeReqState;
@property (nonatomic, retain)	Store					*storeDetails;
@property (nonatomic, retain)	NSArray                 *storeList;
@property (nonatomic, retain)	NSString				*newlyAddedstoreId;

- (void)storeList:(NSArray*)storeList;
- (void)addStore:(Store*)store storeid:(NSString*)storeId;
- (void)checkIn:(NSString*)storeId storeInformation:(Store*)store;

- (void)parseStorelist:(NSData*)data;
- (void)parseAddStore:(NSData*)data;
- (void)parseCheckIn:(NSData*)data;
- (void)nearbyStores;
- (void)makeAddStoreRequest;

@end
