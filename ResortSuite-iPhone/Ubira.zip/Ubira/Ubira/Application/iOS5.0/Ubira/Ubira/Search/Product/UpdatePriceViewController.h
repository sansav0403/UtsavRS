//
//  UpdatePriceViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductUpdatePriceReqResHandler.h"
#import "CouponReqResHandler.h"

/*!
    @class          UpdatePriceViewController
    @abstract       handler the product update price presentation.
    @discussion     handler the product update price presentation.
 */
@interface UpdatePriceViewController : UIViewController <RequestResponseBaseDelegate>{
    
    IBOutlet UILabel                *updatePriceLabel;
    IBOutlet UITextField            *updatePriceTextField;
    IBOutlet UIButton               *submitButton;
    NSString                        *_productId;
    NSString                        *_merchantId;
    NSString                        *updatedPrice;
    ProductUpdatePriceReqResHandler *productUpdatePriceReqResHandler;
    CouponReqResHandler             *couponReqResHandler;
    Coupon                          *_coupons;
    NSDate                          *_startDate;
    BOOL                            requestingCoupon;
}

@property (nonatomic, copy) NSString  *productTitle;
@property (nonatomic, copy) NSString  *merchantId;
@property (nonatomic, copy) NSString  *productId;
@property (nonatomic, retain) NSDate  *startDate;
@property (nonatomic, retain) Coupon  *coupons;

- (IBAction)submitAction:(id)sender;
-(void) checkoutCheckinActionNotification;

@end
