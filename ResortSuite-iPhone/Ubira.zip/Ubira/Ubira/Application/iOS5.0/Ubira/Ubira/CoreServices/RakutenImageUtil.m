//
//  RakutenImageHandler.m
//  RakutenLibrary
//
//  Created by [Cybage Team] on 29/08/11.
//  Copyright 2011 FreeCause. All rights reserved.
//

#import "RakutenImageUtil.h"


@implementation RakutenImageUtil

@synthesize delegate =_delegate;

/*!
 @function		takePictureAndScale
 @abstract		This function is for selecting image and scaling it. 
 @discussion	This function is for selecting image and scaling it. 
 @param			scaleSize       - Target size.
 @param			viewController  - View controller on which image picker will place.
 @param			sourceType      - Image source type: Library, Album or camera.
 @result		void
 */
- (void)takePictureAndScale:(CGSize) scaleSize placeViewController:(UIViewController*) viewController imageSourceType:(PickerImageSourceType) sourceType
{
    targetScaleSize = scaleSize;
    UIImagePickerController     *pickerController = nil;
    switch (sourceType) {
        case kImageSourceCamera:
        {
            if (! [self isCameraAvailable] ){
                //Delegate an Error message
                //This type of error occres only when server returns any HTML data. eg. Data base is down. 
                NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kNoCameraAvailableErrorString,kError, nil];
                NSError *error = [NSError errorWithDomain:@"" code:kNoCameraAvailableErr userInfo:userInfo];
                
                
                if([self.delegate respondsToSelector:@selector(didFinishImageProcessing:errorinfo:)])
                {
                    [self.delegate didFinishImageProcessing:nil errorinfo:error];
                }
                
                return;
            }
            pickerController = [[UIImagePickerController alloc]init]; 
            pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        }break;
        case kImageSourcePhotoLibrary:
        {
            pickerController = [[UIImagePickerController alloc]init]; 
            pickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        }break;
        case kImageSourcePhotoAlbum:
        {
            pickerController = [[UIImagePickerController alloc]init]; 
            pickerController.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        }break;
        default:
            break;
    }
    
	pickerController.delegate = self;	
	[viewController presentModalViewController: pickerController animated: YES];
}

/*!
 @function		takeScalePictureWithOverlayView
 @abstract		This function is for selecting image and scaling it. 
 @discussion	This function is for selecting image and scaling it. 
 @param			scaleSize       - Target size.
 @param			viewController  - View controller on which image picker will place.
 @param			overlayView     - Overlay view.
 @result		void
 */
- (void)takeScalePictureWithOverlayView:(CGSize) scaleSize placeViewController:(UIViewController*) viewController  cameraoverlayView:(UIView*) overlayView
{
    targetScaleSize = scaleSize;
    UIImagePickerController     *pickerController = nil;

    if (! [self isCameraAvailable] ){
        //Delegate an Error message
        //This type of error occres only when server returns any HTML data. eg. Data base is down. 
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kNoCameraAvailableErrorString,kError, nil];
        NSError *error = [NSError errorWithDomain:@"" code:kNoCameraAvailableErr userInfo:userInfo];
        
        if([self.delegate respondsToSelector:@selector(didFinishImageProcessing:errorinfo:)])
        {
            [self.delegate didFinishImageProcessing:nil errorinfo:error];
        }
        
        return;
    }
    pickerController = [[UIImagePickerController alloc]init]; 
    pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    [pickerController setCameraOverlayView:overlayView];
           
	pickerController.delegate = self;    
	[viewController presentModalViewController: pickerController animated: YES];
}

/*!
 @function		isCameraAvailable
 @abstract		This function checks for camera is available or not. 
 @discussion	This function checks for camera is available or not and return TRUE if available otherwise FALSE. 
 @param			none
 @result		bool
 */
- (BOOL)isCameraAvailable
{
    if ( ![UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera] ){
        return FALSE;
    }else{
        return TRUE;
    }
        
}

/*!
 @function		scaleImage
 @abstract		This funcation scales UIImage and returns new scaled UIImage. 
 @discussion	This funcation scales UIImage and returns new scaled UIImage.
 @param			sourceImage     -   Image to scale.
 @param         targetSize      -   target size to scale.
 @result		bool
 */
- (UIImage*)scaleImage:(UIImage*) sourceImage scalingsize:(CGSize) targetSize
{
    UIImage *newImage = nil;
    
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    
    if (CGSizeEqualToSize(imageSize, targetSize) == NO) {
        
        CGFloat widthFactor  = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor < heightFactor){ 
            scaleFactor = widthFactor;
        }else{
            scaleFactor = heightFactor;
        }
        
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image        
        if (widthFactor < heightFactor) {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5; 
        } else if (widthFactor > heightFactor) {
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
     

    // this is actually the interesting part:    
    UIGraphicsBeginImageContext(targetSize);
    
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width  = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    
    [sourceImage drawInRect:thumbnailRect];
    
    if (targetSize.width == 0 && targetSize.height ==0 ) {
        newImage = sourceImage;
    }else{
        newImage = UIGraphicsGetImageFromCurrentImageContext();
    }
    
    UIGraphicsEndImageContext();
    
    if(newImage == nil) NSLog(@"could not scale image");    
    
    
    return newImage ;
}

/*!
 @function		imageFromImage
 @abstract		This function provide specified rectanglar area from given image.
 @discussion	This function provide specified rectanglar area from given image.
 @param			image     -   Source image
 @param         rect      -   Rectangle to cut from source image.
 @result		UIImage
 */
- (UIImage *)imageFromImage:(UIImage *)image inRect:(CGRect)rect {  
    CGImageRef sourceImageRef = [image CGImage];  
    CGImageRef newImageRef = CGImageCreateWithImageInRect(sourceImageRef, rect);  
    UIImage *newImage = [UIImage imageWithCGImage:newImageRef];  
    CGImageRelease(newImageRef);  
    return newImage;  
} 

#pragma mark UIImagePickerControllerDelegate method
/*!
 @function		imagePickerController
 @abstract		This is call back funcation UIImagePickerControllerDelegate. 
 @discussion	This call back funcation of UIImagePickerControllerDelegate is called when image is 
                selected or picked from camera.
 @param			picker    -   Picker controller.
 @param         info      -   It is NSDictionary of image info.
 @result		bool
 */
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [picker dismissModalViewControllerAnimated:YES];
    NSLog(@"%@",info);  
    
    UIImage *originalImage = [info valueForKey:UIImagePickerControllerOriginalImage];
    UIImage *scaledImage = nil;
    
    if(CGSizeEqualToSize(targetScaleSize, originalImage.size)){
        scaledImage = originalImage;
    }else{
        scaledImage = [self scaleImage:originalImage scalingsize:targetScaleSize];
    }
    
    if (scaledImage){
        if([self.delegate respondsToSelector:@selector(didFinishImageProcessing:errorinfo:)]){
            [self.delegate didFinishImageProcessing:scaledImage errorinfo:nil];
        }
    }else{
        NSDictionary *userInfo = [[NSDictionary alloc] initWithObjectsAndKeys:kNotPerformOperationErrorString,kError, nil];
        NSError *error = [NSError errorWithDomain:@"" code:kNotPerformOperationErr userInfo:userInfo];
        
        if([self.delegate respondsToSelector:@selector(didFinishImageProcessing:errorinfo:)]){
            [self.delegate didFinishImageProcessing:nil errorinfo:error];
        }
    }
    
  
}

@end
