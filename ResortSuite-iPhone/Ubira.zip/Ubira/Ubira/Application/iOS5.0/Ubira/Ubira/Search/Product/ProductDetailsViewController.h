//
//  ProductDetailsViewController.h
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductDetailReqResHandler.h"
#import "ProductDetail.h"
#import "MerchantStoreCell.h"
#import "SocialServiceCell.h"
#import "RelatedProductCell.h"
#import "ProductData.h"
#import "Coupon.h"
#import "CouponReqResHandler.h"
#import "MerchantStore.h"

#define kOfferDetailsViewController   @"OfferDetailsViewController"

typedef enum
{
	kFirstCell,	
	kSecondCell,
	kThirdCell
} ProductDetails;

typedef enum
{
    kResReqStNone,
    kResReqStProductList,  
    kResReqStCouponCheck,
    kResReqStCouponAccept  
} ReuestResponseState;

typedef enum
{
    kReject,
    kAccept  
}AlertButtonIndex;

/*!
    @class          ProductDetailsViewController
    @abstract       handler the product details presentation.
    @discussion     handler the product details presentation.
 */
@interface ProductDetailsViewController : UIViewController <RequestResponseBaseDelegate, MerchantStoreDelegate, SocialServiceCellDelegate, RelatedProdcutCellDelegate>{
    
    IBOutlet UIView                 *relatedProductView;
    IBOutlet UILabel                *relatedProductLbl;
    UIActivityIndicatorView         *activityIndicator;
	ProductDetailReqResHandler      *productDetailReqResHandler;
	ProductDetail                   *productDetail;
    UITableView                     *productDetailsTable;
    Product                         *_product;
    NSDate                          *_startDate;
    
    Coupon                          *_coupon;
    CouponReqResHandler				*couponReqResHandler;
    MerchantStore                   *_merchantStore;
    Store                           *sharedStore;
    NSString                        *_couponCount;
    ReuestResponseState             reuestResponseState;
}

@property (nonatomic, retain) IBOutlet UITableView              *productDetailsTable;
@property (nonatomic, retain) IBOutlet UIView                   *relatedProductView;
@property (nonatomic, retain) IBOutlet UILabel                  *relatedProductLbl;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView  *activityIndicator;
@property (nonatomic, retain) Product                           *product;
@property (nonatomic, retain) NSDate                            *startDate;
@property (nonatomic, retain) Coupon                            *coupon;
@property (nonatomic, retain) MerchantStore                     *_merchantStore;
@property (nonatomic) ReuestResponseState                       reuestResponseState;
@property (nonatomic, retain) NSString                          *couponCount;

- (void)setProductData:(ProductData*) productData;
- (void)showAlertView:(NSString *)alertTitle alertMessage:(NSString *)alertMessage setDelegate:(id)currentDelegate;
- (void)couponRequestResponseHandler:(NSInteger)reqresState;
- (void)navigateToUrl:(NSString*)pageUrl;

@end