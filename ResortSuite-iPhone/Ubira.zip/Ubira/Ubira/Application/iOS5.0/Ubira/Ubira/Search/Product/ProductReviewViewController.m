//
//  ProductReviewViewController.m
//  Ubira
//
//  Created by [Cybage Team] on 06/05/11.
//  Copyright 2011 FreeCause All rights reserved.
//

#import "ProductReviewViewController.h"
#import "ProductReviewCell.h"
#import "UserAnalytics.h"

@implementation ProductReviewViewController

@synthesize activityIndicator;
@synthesize productReviews, selectedCellIndexPath;
@synthesize startDate = _startDate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil productId:(NSString *)aProductId
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        productId = [[NSString alloc] initWithString:aProductId];
    }
    return self;
}

- (void)dealloc
{
    TRC_DBG(@"ProductReviewViewController ------------ Release")
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setTitle:kReviewTitle];
    // Do any additional setup after loading the view from its nib.
    
	UIView	*view = [[UIView alloc]initWithFrame:CGRectZero];
	[self.productReviews setTableFooterView:view];
	
    productReviewReqResHandler = [[ProductReviewReqResHandler alloc] init];
	[productReviewReqResHandler setDelegate:self];
	reviewList = [[NSMutableArray alloc] init];
    [productReviewReqResHandler productReviews:productId review:reviewList];
}

- (void)viewDidUnload
{
    [productReviewReqResHandler setDelegate:nil];
    productReviews = nil;
    productId = nil;
    [self setActivityIndicator:nil];
    
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    //Set the start date time for anyalitics
	self.startDate = [NSDate date];
}

- (void)viewWillDisappear:(BOOL)animated
{    
    //Log the screen in anyalitics
    [[UserAnalytics sharedInstance] recordScreen:kAnyaliticsProductReviewScreen startDate:self.startDate endDate:[NSDate date]];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark -
#pragma mark Table view datasource and delegate methods
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(selectedCellIndexPath != nil  
       && [selectedCellIndexPath compare:indexPath] == NSOrderedSame)  
    {
        Review *review =[reviewList objectAtIndex:indexPath.row];
        return [self calculateHeightForCell:review.description];  
    }
    return 80;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)aTableView 
{
	// Number of sections is the number of regions
	return 1;
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section {
	// Number of rows is the number of time zones in the region for the specified section
	return [reviewList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  
{
    static NSString *identifier = @"ReviewCell";
    ProductReviewCell *cell = (ProductReviewCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if(!cell)
    {
        cell = [[ProductReviewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    Review *review =[reviewList objectAtIndex:indexPath.row];
    //if reloading only one cell
    [cell setExpand:(selectedCellIndexPath != nil  
                     && [selectedCellIndexPath compare:indexPath] == NSOrderedSame)?YES:NO];
    
    [cell setDelegate:self];
    [cell setReviewDetails:review indexPath:indexPath];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	/*
	 To conform to the Human Interface Guidelines, selections should not be persistent --
	 deselect the row after it has been selected.
	 */
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - More Button action
/*!
 @function      moreActionDelegate
 @abstract      delegate method to load the detail description
 @discussion    This is the delegate method for the more button click.
 @param         indexPath - selected row's indexPath
 @result        void
 */
- (void)moreActionDelegate:(NSIndexPath *)indexPath
{
    NSMutableArray *indexPathArray = [[NSMutableArray alloc] init];
    
    if (selectedCellIndexPath != nil && [selectedCellIndexPath compare:indexPath] != NSOrderedSame) 
    {
        [indexPathArray addObject:selectedCellIndexPath];        
    }
    
    [self setSelectedCellIndexPath:indexPath];
    
    [indexPathArray addObject:indexPath];
    
    // Forces the table view to call heightForRowAtIndexPath  
    [productReviews reloadRowsAtIndexPaths:indexPathArray withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark - Other Methods
/*!
 @function      calculateHeightForCell
 @abstract      This function will calculate the hight for the lable.
 @discussion    This function will calculate the hight for the lable based on the description
                for the product and break the lable accordingly.
 @param         NSString - description of which details need to set to cell.
 @result        void
 */
- (float)calculateHeightForCell:(NSString *)description
{
    CGFloat maxWidth = [UIScreen mainScreen].bounds.size.width - 170;
	CGFloat maxHeight = 9999;
    CGSize maximumLabelSize = CGSizeMake(maxWidth,maxHeight);
    
	CGSize expectedLabelSize = [description sizeWithFont:[UIFont systemFontOfSize:13] 
                                       constrainedToSize:maximumLabelSize 
                                           lineBreakMode:UILineBreakModeWordWrap];
    
    // resized label with sizeToFit of text after setting the expected height for label as expectedLabelSize is calculated on nsstring and it returns more than required. 
    UILabel *descriptionLbl = [[UILabel alloc]initWithFrame:CGRectZero];
    [descriptionLbl setLineBreakMode:UILineBreakModeWordWrap];
    [descriptionLbl setFont:[UIFont systemFontOfSize:13]];
    
    [descriptionLbl setTextAlignment:UITextAlignmentLeft];
    CGRect rect = CGRectMake(5, 20, 300,expectedLabelSize.height);
	[descriptionLbl setFrame:rect];
    [descriptionLbl setText:description];
    [descriptionLbl setNumberOfLines:0];
    [descriptionLbl sizeToFit];
    
    return (descriptionLbl.bounds.size.height + kHeightOfOtherLabels);
}

#pragma mark - Parsing complete delegate
/*!
 @function		parseComplete
 @abstract		delegate on parse complete.
 @discussion	Take the action based on the parameter.
 @param			error - server response if no error it will be nil.
 */
-(void)parseComplete:(NSError*)error
{
	TRC_ENTRY
	if(error != nil)
	{
		TRC_ERR(@"%@",error)
        NSString *errorString = [[error userInfo] valueForKey:@"error"];
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:kReviewTitle message:errorString delegate:nil cancelButtonTitle:kButtonOk otherButtonTitles:nil, nil];
        [alert show];
	}
	else
	{
		//update UI		
		TRC_DBG(@"=========================== Product Review ==================================")
        [self.productReviews reloadData];
	}
    [activityIndicator stopAnimating];
	TRC_EXIT
}

@end
